#include"fltr_chi.h"

int main( int argc, char *argv[] )
{
  
  FILE *inputFile, *temFile;
  FILE *chiOutputFile;
  FILE *fp;

  IIRTemplate *iirTemplate;
  unsigned int batch;
  float gpu_avgStepTime, cpu_avgStepTime;
  Parameters *parameters;
	

  /* ======================================================
  *
  *      Prepare parameters
  *
  * ======================================================
  */
  parameters = (Parameters *)malloc(sizeof(Parameters)); 
  if(prepareParameters(parameters, argc, argv)!=0)
  {
    free(parameters);
    return -1;
  }
  batch = parameters->batch;
  inputFile=fopen(parameters->inputFileName, "r");
  if(inputFile == 0)
  {
  	printf("File %s not found.\n", parameters->inputFileName);
        free(parameters);
  	return -1;
  }
  temFile=fopen(parameters->templateFileName, "r");
  if(temFile == 0)
  {
    printf("File %s not found.\n", parameters->templateFileName);
    free(parameters);
    fclose(inputFile);
  	return -1;
  }
  /* ======================================================
  *
  *      Input templates parameters from file
  *
  * ======================================================
  */  
  iirTemplate = createTemplate(temFile, parameters);
  if(iirTemplate == 0)
  {
    free(parameters);
    fclose(inputFile);
    fclose(temFile);
    return -1;
  }
  
  /* ======================================================
  *
  *      Run IIR filtering in different mode
  *      mode: (0) GPU_FLOAT; (1) CPU_FLOAT; (2) GPU_FLOAT & CPU_FLOAT (3) CPU_DOUBLE
  *
  * ======================================================
  */  
  parameters->mode = 1;
  perform_iir_filter_chi(iirTemplate, parameters, inputFile, &cpu_avgStepTime);
  /*
   *if(parameters->mode == 0 || parameters->mode == 2 )
   *{    
   *        cuda_perform_iir_filter_chi(iirTemplate, parameters, inputFile, &gpu_avgStepTime);
   *        rewind(inputFile);  
   *}  
   *if(parameters->mode == 1 || parameters->mode == 2)
   *{
   *  perform_iir_filter_chi(iirTemplate, parameters, inputFile, &cpu_avgStepTime);
   *  rewind(inputFile); 
   *}
   *if(parameters->mode == 3 )
   *{
   *  perform_iir_filter_chi_d(iirTemplate, parameters, inputFile, &cpu_avgStepTime);
   *}     
   */
  if(!parameters->verbose)
  {
    switch(parameters->mode)
    {
      case 0: printf("%f ", gpu_avgStepTime);break;
      case 1: printf("%f ", cpu_avgStepTime);break;
      case 2: printf("%f ", cpu_avgStepTime/gpu_avgStepTime); break;
      case 3: printf("%f ", cpu_avgStepTime);break;
    }
  }
  else
  {
    if(parameters->mode == 2)
    {
      printf("GPU speedup: %f\n", cpu_avgStepTime/gpu_avgStepTime);
    }
  }  

  /* ======================================================
   *
   *			Close files & clean up memory
   *
   * ======================================================
   */
  free(parameters); 
  fclose(inputFile);
  fclose(temFile);
  destroy_iir_filters(iirTemplate, batch);
  return 0;
}
