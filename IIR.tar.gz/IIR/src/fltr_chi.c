#include <getopt.h>
#include "fltr_chi.h"
#include <math.h>

unsigned int min(unsigned int a, unsigned int b)
{
	return a < b ? a : b;
}
void showHelp()
{
  char *help = 
    "\nUsage: ./myrun FILE -t FILE -n NUMBER [OPTION]\n"
    "\nOptions: \n"
    "\n"
    "-t, --tem=FILE_NAME     template coefficients file (required)\n"
    "-m, --mode=NUMBER       in which mode: 0:GPU_FLOAT;1:CPU_FLOAT;2:GPU_FLOAT&CPU_FLOAT;3:CPU_DOUBLE (default 0)\n"
    "-n, --num=NUMBER        number of templates (required)\n"
    "-s, --step=NUMBER       number of steps (default 10)\n"
    "    --skip=NUMBER       number of seconds of data to be skipped at the begining (default 1024)\n"
    "    --stepsz=NUMBER     number of seconds per step (default 1)\n"
    "-q, --quiet             run the program with limited screen output\n"
    "-f, --file              print results to files, using ascii format by default, can use --bo option to use binary format\n"
    "    --bi                using binary input data file\n"
    "    --bo                output results in binary format\n"
    "-h, --help              print this help message\n"
    "\n";
    printf("%s", help);
}

IIRTemplate * createTemplate(FILE *fp, Parameters *parameters)
{
	unsigned int i, j, k;
	unsigned int numTemplates;
  unsigned int maxGroups = 0;	
	IIRTemplate *ret;
	ret = (IIRTemplate *)malloc(sizeof(IIRTemplate) * parameters->batch);

	fscanf(fp, "%u\n", &numTemplates);
	
	for(i = 0; i < min(numTemplates, parameters->batch); ++i)
	{
		fscanf(fp, "%u %u %e\n", &(ret[i].numFilters), &(ret[i].numGroups), &(ret[i].threshold));
    if(ret[i].numGroups > maxGroups) maxGroups = ret[i].numGroups;
		ret[i].a1 = (COMPLEX8_F *)malloc(sizeof(COMPLEX8_F) * ret[i].numFilters);
		ret[i].b0 = (COMPLEX8_F *)malloc(sizeof(COMPLEX8_F) * ret[i].numFilters);
		ret[i].filterShift = (unsigned int *)malloc(sizeof(unsigned int) * ret[i].numFilters);
		ret[i].alpha = (float *)malloc(sizeof(float) * ret[i].numGroups);		
		ret[i].beta = (float *)malloc(sizeof(float) * ret[i].numGroups);
		ret[i].grpHeader = (unsigned int *)malloc(sizeof(unsigned int) * ret[i].numGroups);
	
		for(j = 0; j < ret[i].numFilters;++j)
		{
			fscanf(fp, "(%e,%e) ", &(ret[i].a1[j].re), &(ret[i].a1[j].im));
		}
		fscanf(fp, "\n");
		for(j = 0; j < ret[i].numFilters;++j)
		{
			fscanf(fp, "(%e,%e) ", &(ret[i].b0[j].re), &(ret[i].b0[j].im));
		}
		fscanf(fp, "\n");
		for(j = 0; j < ret[i].numFilters;++j)
		{
			fscanf(fp, "%u ", &(ret[i].filterShift[j]));
		}
		fscanf(fp, "\n");
		for(j = 0; j < ret[i].numGroups; ++j)
		{
			fscanf(fp, "%e ", &(ret[i].alpha[j]));
		}
		fscanf(fp, "\n");
		for(j = 0; j < ret[i].numGroups; ++j)
		{
			fscanf(fp, "%e ", &(ret[i].beta[j]));
		}
		fscanf(fp, "\n");
		for(j = 0; j < ret[i].numGroups; ++j)
		{
			fscanf(fp, "%u ", &(ret[i].grpHeader[j]));
		}
		fscanf(fp, "\n");
	}
  j = 0;
	for(i = numTemplates; i < parameters->batch; ++i)
	{
		copyTemplate(&(ret[i]), &(ret[j++]));
	}
	return ret;	
}
int copyTemplate(IIRTemplate *dst, IIRTemplate *src)
{
	dst->numFilters = src->numFilters;
	dst->numGroups = src->numGroups;
	dst->threshold = src->threshold;
	dst->a1 = (COMPLEX8_F *)malloc(sizeof(COMPLEX8_F) * dst->numFilters);
	dst->b0 = (COMPLEX8_F *)malloc(sizeof(COMPLEX8_F) * dst->numFilters);
	dst->filterShift = (unsigned int *)malloc(sizeof(unsigned int) * dst->numFilters);
	dst->alpha = (float *)malloc(sizeof(float) * dst->numGroups);		
	dst->beta = (float *)malloc(sizeof(float) * dst->numGroups);
	dst->grpHeader = (unsigned int *)malloc(sizeof(unsigned int) * dst->numGroups);
	memcpy(dst->a1, src->a1, sizeof(COMPLEX8_F) * dst->numFilters);
	memcpy(dst->b0, src->b0, sizeof(COMPLEX8_F) * dst->numFilters);	
	memcpy(dst->filterShift, src->filterShift, sizeof(unsigned int) * dst->numFilters);
	memcpy(dst->alpha, src->alpha, sizeof(float) * dst->numGroups);
	memcpy(dst->beta, src->beta, sizeof(float) * dst->numGroups);
	memcpy(dst->grpHeader, src->grpHeader, sizeof(unsigned int) * dst->numGroups);
	return 0;
}
void destroy_iir_filters(IIRTemplate *iirTemplate, unsigned int num)
{
	unsigned int i;
	if(!iirTemplate) 
  {
    printf("Error destroying IIRTemplate, recheck your program!\n" );
    exit(1);
  }
	for(i = 0; i < num; ++i)
	{    
    if( iirTemplate[i].a1 ) free(iirTemplate[i].a1);
    if( iirTemplate[i].b0 ) free(iirTemplate[i].b0);
    if( iirTemplate[i].filterShift) free(iirTemplate[i].filterShift);
    if(iirTemplate[i].alpha) free(iirTemplate[i].alpha);
    if(iirTemplate[i].beta) free(iirTemplate[i].beta);
    if(iirTemplate[i].grpHeader) free(iirTemplate[i].grpHeader);
  }
  free(iirTemplate);
  
}

int input_data( FILE * inputFile, float *dst, unsigned int len, char binaryInputFile)
{
  unsigned int i;
  int endOfFile = 0;
  if(binaryInputFile)  /* binary file form */
  {
    if(fread(dst, sizeof(float), len, inputFile) != len)
      endOfFile = -1;
  }
  else  /* ASCII file form */
  {
    for( i = 0; i < len && endOfFile != -1; ++i)
    {
        endOfFile = fscanf( inputFile, "%e\n", &( dst[i]));
    }
  }
  return endOfFile;  
}
void printParameters(Parameters *parameters)
{
  printf("\nparameters used:\n");
  printf("input file: %s\n", parameters->inputFileName);
  printf("template file: %s\n", parameters->templateFileName);
  printf("mode: ");
  char *modeStr;
  switch(parameters->mode)
  {
    case 0:
      modeStr = "GPU_FLOAT";
      break;
    case 1:
      modeStr = "CPU_FLOAT";
      break;
    case 2:
      modeStr = "GPU_FLOAT&CPU_FLOAT";
      break;
    case 3:
      modeStr = "CPU_DOUBLE";
      break;
  }
  printf("%s\n", modeStr);
  printf("number of templates: %u\n", parameters->batch);
  printf("number of steps: %u\n", parameters->numSteps);
  printf("skip seconds: %u\n", parameters->skipSecs);
  printf("step seconds: %u\n", parameters->stepSecs);
  printf("sample rate: %u\n", parameters->sampleRate);
  printf("do output to files: %u\n", parameters->outputSnr);
  printf("binaryInputFile: %u\n", parameters->binaryInputFile);
  printf("output file format: ");
  if( parameters->binaryOutputFile)
    printf("binary");
  else
    printf("ascii");
  printf("\n");
  printf("quiet: %u\n", !parameters->verbose);
  printf("\n");

}
char parseCfgFile(FILE *cfgFile, Parameters *parameters)
{
  if(fscanf(cfgFile, "%s\n%s\n%s\n%s\n%u\n%u\n%u\n%u\n%u\n",
      parameters->snrRealFileName, parameters->snrImagFileName,
      parameters->chiValFileName, parameters->chiTstRsltFileName, 
      &(parameters->skipSecs), &(parameters->stepSecs), &(parameters->sampleRate),
      &(parameters->binaryInputFile), &(parameters->binaryOutputFile)
      ) != 9)
  {
    printf("Load config file error.\n");
    return 1;
  }
  return 0;
}
char prepareParameters(Parameters *parameters, int argc, char *argv[])
{
  int c;
  static struct option longopts[] = {
            {"tem", required_argument, NULL, 't'},
            {"mode", required_argument, NULL, 'm'},
            {"num", required_argument, NULL, 'n'},
            {"step", required_argument, NULL, 's'},
            {"skip", required_argument, NULL, 'k'},
            {"stepsz", required_argument, NULL, 'z'},
            {"quiet", no_argument, NULL, 'q'},
            {"file", no_argument, NULL, 'f'},
            {"bi", no_argument, NULL, 'i'},
            {"bo", no_argument, NULL, 'o'},
            {"help", no_argument, NULL, 'h'},
            {0, 0, 0, 0, }
        };

  // set up default parameters
  strcpy(parameters->templateFileName, "");
  strcpy(parameters->inputFileName, "");
  parameters->mode = 0;
  parameters->batch = 0;
  parameters->numSteps = 10;
  parameters->skipSecs = 1024;
  parameters->stepSecs = 1;
  parameters->verbose = 1;
  parameters->outputSnr = 0;
  parameters->outputChiVal = 0;
  parameters->outputChiTstRslt = 0;
  parameters->sampleRate = 4096;
  parameters->binaryOutputFile = 0;
  parameters->binaryInputFile = 0;
  strcpy(parameters->snrRealFileName, "realSnr.log");
  strcpy(parameters->snrImagFileName, "imagSnr.log");
  strcpy(parameters->chiValFileName, "chiSquareValues.log");
  strcpy(parameters->chiTstRsltFileName, "chiSquareTestRslts.log");  
  int format; 
  while( (c=getopt_long(argc, argv, "t:m:n:s:qfh", longopts, NULL)) != -1)
  {
    switch(c)
    {
      case 't':
        strcpy(parameters->templateFileName, optarg);
        break;
      case 'm':
        parameters->mode = atoi(optarg);
        break;
      case 'n':
        parameters->batch = atoi(optarg);
        break;
      case 's':
        parameters->numSteps = atoi(optarg);
        break;
      case 'q':
        parameters->verbose = 0;
        break;
      case 'f':
        parameters->outputChiTstRslt = 1;
        parameters->outputSnr = 1;
        parameters->outputChiVal = 1;
        break;
      case 'i':
        parameters->binaryInputFile = 1;
        break;
      case 'o':
        parameters->binaryOutputFile = 1;
        break;
      case 'h':
        showHelp();
        return 1;
      case 'k':
        parameters->skipSecs = atoi(optarg);
        break;
      case 'z':
        parameters->stepSecs = atoi(optarg);
        break;
      case ':':
      case '?':
      default:
        showHelp();
        return -1;
    }
  }
  int i;
  for( i=0; optind<argc; ++optind, ++i)
  {
    if( i < 1)
    {
      strcpy(parameters->inputFileName, argv[optind]);
    }
    else
    {
      printf("Error: Too many arguments.\n");
      showHelp();
      return -1;
    }
  }
  if( i==0)
  {
    printf("Error: No input data file.\n");
    showHelp();
    return -1;
  }
  if( strlen(parameters->templateFileName) == 0)
  {
    printf("Error: Lack of 'tem' argument.\n");
    showHelp();
    return -1;
  }
  if( parameters->batch == 0)
  {
    printf("Error: A positive number of templates is needed.\n");
    showHelp();
    return -1;
  }
  if( parameters->verbose)
    printParameters(parameters);
  return 0;
}
void output_snr(char **realFileName, char **imagFileName, void *snr, char type, unsigned int width, unsigned int batch, char binaryOutputFile)
{
  unsigned int i, j;
  FILE *realFile, *imagFile;
  FILE *snrFile;
  unsigned int typeSize;
  switch(type)
  {
    case 0:typeSize = sizeof(float);break;
    case 1:typeSize = sizeof(double);break;
    default: typeSize = sizeof(float);break;
  }
  /*for( i=0; i<batch; i++)
  {
    for( j=0; j<width; j++)
    {
      if(fabs(snr[i*width*2+j]) < TO_ZERO)
        snr[i*width*2+j] = 0.0f;
      if(fabs(snr[i*width*2+width+j]) < TO_ZERO)
        snr[i*width*2+width+j] = 0.0f;
    }
  }*/
	if(binaryOutputFile)  /* binary file form */
  {
    for(i = 0; i < batch; i++)
    {
      realFile = fopen(realFileName[i], "a");
      imagFile = fopen(imagFileName[i], "a");
      fwrite(snr+i*width*typeSize*2, typeSize, width, realFile);
      fwrite(snr+width*typeSize*(2*i+1), typeSize, width, imagFile);
      fclose(realFile);
      fclose(imagFile);
    }
  }
  else  /* ASCII file form */
  {
    if( type == 0)
    {
      float *pSnr = (float *)snr;
      for(i = 0; i < batch; i++)
      {
        realFile = fopen(realFileName[i], "a");
        imagFile = fopen(imagFileName[i], "a");
        for( j = 0; j < width; j++ )
        {
          fprintf( realFile, "%e\n", pSnr[i*width*2+j] );
          fprintf( imagFile, "%e\n", pSnr[i*width*2+j+width] );
        }
        fclose(realFile);
        fclose(imagFile);
      }
    }   
    if( type == 1)
    {
      double *pSnr = (double *)snr;
      for(i = 0; i < batch; i++)
      {
        realFile = fopen(realFileName[i], "a");
        imagFile = fopen(imagFileName[i], "a");
        for( j = 0; j < width; j++ )
        {
          fprintf( realFile, "%e\n", pSnr[i*width*2+j] );
          fprintf( imagFile, "%e\n", pSnr[i*width*2+j+width] );
        }
        fclose(realFile);
        fclose(imagFile);
      }
    }   
  }
}

void output_result(FILE *chiFile, void *snr, void *chiVal, char type, char *flag, unsigned int width, unsigned int batch, float startTime, float timePerPoint)
{
  unsigned int i,j;
  if(type == 0)
  {
    float *pSnr = (float *)snr;
    float *pChi = (float *)chiVal;
    for(i = 0; i < width; ++i)
    {
      for(j = 0; j < batch; ++j)
      {
        if(flag[j*width+i] == 1)
        {
          fprintf(chiFile, "%f\t%d\t%f\t%f\t%f\n", startTime + i * timePerPoint, j, pSnr[j*width*2+i],
            pSnr[j*width*2+width+i], pChi[j*width+i]);
        }
      }
    }
  }
  if(type == 1)
  {
    double *pSnr = (double *)snr;
    double *pChi = (double *)chiVal;
    for(i = 0; i < width; ++i)
    {
      for(j = 0; j < batch; ++j)
      {
        if(flag[j*width+i] == 1)
        {
          fprintf(chiFile, "%f\t%d\t%f\t%f\t%f\n", startTime + i * timePerPoint, j, pSnr[j*width*2+i],
            pSnr[j*width*2+width+i], pChi[j*width+i]);
        }
      }
    }
  }      
}
void output_chi_val(char **chiValFileName, void *chiVal, char type, unsigned int width, unsigned int batch, char binaryOutputFile)
{
  unsigned int i, j;
  FILE *chiValFile;
  unsigned int typeSize;
  switch(type)
  {
    case 0:typeSize = sizeof(float);break;
    case 1:typeSize = sizeof(double);break;
    default: typeSize = sizeof(float);break;
  }
  if(binaryOutputFile)  /* binary file form */
  {
    for(i = 0; i < batch; i++)
    {
      chiValFile = fopen(chiValFileName[i], "a");
      fwrite(chiVal+i*width*typeSize, typeSize, width, chiValFile);
      fclose(chiValFile);
    }
  }
  else  /* ASCII file form */
  {
    if(type == 0)
    {
      float *pChi = (float *)chiVal;
      for(i = 0; i < batch; i++)
      {
        chiValFile = fopen(chiValFileName[i], "a");
        for( j = 0; j < width; j++ )
        {
          fprintf( chiValFile, "%e\n", pChi[i*width+j] );
        }
        fclose(chiValFile);
      }
    }
    if(type == 1)
    {
      double *pChi = (double *)chiVal;
      for(i = 0; i < batch; i++)
      {
        chiValFile = fopen(chiValFileName[i], "a");
        for( j = 0; j < width; j++ )
        {
          fprintf( chiValFile, "%e\n", pChi[i*width+j] );
        }
        fclose(chiValFile);
      }
    }
  }  
}
void outputTemplates(FILE *fp, IIRTemplate *iirTemplate, unsigned int batch)
{
	unsigned int i, j;
	fprintf(fp, "%u\n", batch);
	for(i = 0; i < batch; ++i)
	{
		fprintf(fp, "%u %u %f\n", iirTemplate[i].numFilters, iirTemplate[i].numGroups, iirTemplate[i].threshold);
		for(j = 0; j < iirTemplate[i].numFilters;++j)
		{
			fprintf(fp, "(%f,%f) ", iirTemplate[i].a1[j].re, iirTemplate[i].a1[j].im);
		}
		fprintf(fp, "\n");
		for(j = 0; j < iirTemplate[i].numFilters;++j)
		{
			fprintf(fp, "(%f,%f) ", iirTemplate[i].b0[j].re, iirTemplate[i].b0[j].im);
		}
		fprintf(fp, "\n");
		for(j = 0; j < iirTemplate[i].numFilters;++j)
		{
			fprintf(fp, "%u ", iirTemplate[i].filterShift[j]);
		}
		fprintf(fp, "\n");
		for(j = 0; j < iirTemplate[i].numGroups; ++j)
		{
			fprintf(fp, "%f ", iirTemplate[i].alpha[j]);
		}
		fprintf(fp, "\n");
		for(j = 0; j < iirTemplate[i].numGroups; ++j)
		{
			fprintf(fp, "%f ", iirTemplate[i].beta[j]);
		}
		fprintf(fp, "\n");
		for(j = 0; j < iirTemplate[i].numGroups; ++j)
		{
			fprintf(fp, "%u ", iirTemplate[i].grpHeader[j]);
		}
		fprintf(fp, "\n");
	}
}


