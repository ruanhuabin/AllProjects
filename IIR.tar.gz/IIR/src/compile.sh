#!/bin/bash
reg='0'
SKIP='64'
if [ $# -eq 2 ]
  then
  reg=$1
  SKIP=$2
fi
echo "reg="$reg", SKIP="$SKIP 
#--ptxas-options=-v
nvcc -O2 --ptxas-options=-v -maxrregcount=$reg -DSKIP=$SKIP -arch compute_20 -code compute_20,sm_20 -o myrun fltr_chi.c iir_filter_chi.c cuda_iir_filter_chi.cu iir_filter_chi_d.c main.c
#nvcc -ptx -O2 -maxrregcount=$reg -DSKIP=$SKIP -arch compute_20 -code compute_20,sm_20 -o cuda_chi.ptx cuda_iir_filter_chi.cu
rm -f *.log
#./myrun
