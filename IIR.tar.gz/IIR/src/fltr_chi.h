#ifndef _FLTR_CHI_H
#define _FLTR_CHI_H

#include <stdio.h>
#include <sys/time.h>
#include <stdlib.h>
#include <string.h>
#define MAX_FILE_NAME_LENGTH 64

#define TimeBetween(a,b) ( (b.tv_sec - a.tv_sec) + (b.tv_usec - a.tv_usec) / (float) 1000000 )
#define Module(a,b) sqrtf(Module_2(a,b))
#define Module_2(a,b) (a * a + b * b)

typedef struct Complex8_F
{
  float re;
  float im;
} COMPLEX8_F;

typedef struct Complex8_D
{
  double re;
  double im;
} COMPLEX8_D;

typedef struct parameters
{
  char inputFileName[MAX_FILE_NAME_LENGTH];
  char snrRealFileName[MAX_FILE_NAME_LENGTH];
  char snrImagFileName[MAX_FILE_NAME_LENGTH];
  char chiValFileName[MAX_FILE_NAME_LENGTH];    //file for chi-square values
  char chiTstRsltFileName[MAX_FILE_NAME_LENGTH];//file for chi-square test results (only those with a srn value beyond the threshold) 
  char templateFileName[MAX_FILE_NAME_LENGTH];
  unsigned int batch;
  unsigned int mode;        //running mode: (0) GPU_FLOAT; (1) CPU_FLOAT; (2) GPU_FLOAT&CPU_FLOAT (3) CPU_DOUBLE
  char verbose;             //print details to the screen
  char outputSnr;           //switch for outputing snr values to files
  char outputChiVal;        //switch for outputing chi-square values to files
  char outputChiTstRslt;    //switch for outputing chi-square test results to files
  unsigned int skipSecs;    //data skipped at the beginning in the unit of second
  unsigned int stepSecs;    //data processed per step in the unit of second
  int numSteps;             
  unsigned int sampleRate;
  char binaryInputFile;     
  char binaryOutputFile;
} Parameters;

typedef struct iir_template
{
  unsigned int numFilters;  //number of filters
  unsigned int numGroups;   //number of groups
  unsigned int *filterShift;
  COMPLEX8_F *a1;
  COMPLEX8_F *b0;
  float *alpha;
  float *beta;
  float threshold;
  unsigned int *grpHeader;     //the first filter number of each group
} IIRTemplate;

IIRTemplate * createTemplate(FILE *fp, Parameters *parameters);
int copyTemplate(IIRTemplate *dst, IIRTemplate *src);
void destroy_iir_filters(IIRTemplate *iirTemplate, unsigned int num);
int input_data( FILE * inputFile, float *dst, unsigned int len, char binaryInputFile);
char prepareParameters(Parameters *parameters, int argc, char *argv[]);
char parseCfgFile(FILE *cfgFile, Parameters *parameters);
void outputTemplates(FILE *fp, IIRTemplate *iirTemplate, unsigned int batch);
void output_snr(char **realFileName, char **imagFileName, void *snr, char type, unsigned int width, unsigned int batch, char binaryOutputFile);
void output_result(FILE *chiFile, void *snr, void *chiVal, char type, char *flag, unsigned int width, unsigned int batch, float startTime, float timePerPoint);
void output_chi_val(char **chiValFileName, void *chiVal, char type, unsigned int width, unsigned int batch, char binaryOutputFile);

void printArguments(FILE *stream);

int cuda_perform_iir_filter_chi(IIRTemplate *iirTemplate, Parameters *parameters, FILE *inputFile, float *gpu_avgStepTime);
int perform_iir_filter_chi(IIRTemplate *iirTemplate, Parameters *parameters, FILE *inputFile, float *cpu_avgStepTime);
int perform_iir_filter_chi_d(IIRTemplate *iirTemplate, Parameters *parameters, FILE *inputFile, float *cpu_avgStepTime);

#endif
