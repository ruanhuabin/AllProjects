#include "fltr_chi.h"


int step_iir_filter_chi_d(IIRTemplate *iirTemplate, Parameters *parameters, float *gwDataQueue, unsigned int tail, unsigned int step_points, unsigned int total_points, double *snr, double *chiVal, char *flag, COMPLEX8_D **prevSnr, COMPLEX8_D *grpOutput, unsigned int grpOutputSize)
{
  unsigned int i, j, k, ll;
  unsigned int batch = parameters->batch;
  int shiftIndex;
  unsigned int grpEnd;
  COMPLEX8_D previous, current, snrVar, chiTmp;
  float alpha, beta;
  COMPLEX8_F a1, b0;
  unsigned int filterShift;
  double thresholdSqr;
  
  memset(snr, 0, sizeof(double) * batch * step_points * 2);
  memset(chiVal, 0, sizeof(double) * batch * step_points);
  memset(flag, 0, sizeof(char) * batch * step_points);
  
 for(i = 0;i < batch; ++i)
  {
    memset(grpOutput, 0, sizeof(COMPLEX8_D) * grpOutputSize);
    thresholdSqr = iirTemplate[i].threshold;
    thresholdSqr *= thresholdSqr;
    for(j = 0;j < iirTemplate[i].numGroups; ++j)
    {
      if( j == iirTemplate[i].numGroups -1)
        grpEnd = iirTemplate[i].numFilters;
      else grpEnd = iirTemplate[i].grpHeader[j+1];
      for(k = iirTemplate[i].grpHeader[j]; k < grpEnd; ++k)
      {
        previous = prevSnr[i][k];
        a1 = iirTemplate[i].a1[k];
        b0 = iirTemplate[i].b0[k];
        filterShift = iirTemplate[i].filterShift[k];
        for(ll = 0; ll < step_points; ++ll)
        {
          shiftIndex = tail + ll - filterShift;
          if( shiftIndex < 0)
            shiftIndex += total_points;
          current.re = a1.re * previous.re - a1.im * previous.im + (double)b0.re * gwDataQueue[shiftIndex];
          current.im = a1.re * previous.im + a1.im * previous.re + (double)b0.im * gwDataQueue[shiftIndex];
          snr[i*step_points*2+ll] += current.re;
          snr[i*step_points*2+step_points+ll] += current.im;
          grpOutput[j*step_points+ll].re += current.re;
          grpOutput[j*step_points+ll].im += current.im;
          previous = current;
        }
        prevSnr[i][k] = previous; 
      }
    }
    //continue;
    for(j = 0;j < iirTemplate[i].numGroups; ++j)
    {
      alpha = iirTemplate[i].alpha[j];
      beta = iirTemplate[i].beta[j];
      for(ll = 0; ll < step_points; ++ll)
      {
        snrVar.re = snr[i*step_points*2+ll];
        snrVar.im = snr[i*step_points*2+ll+step_points];
        chiTmp.re = grpOutput[j*step_points+ll].re * alpha + snrVar.re * beta;
        chiTmp.im = grpOutput[j*step_points+ll].im * alpha + snrVar.im * beta;
        chiVal[i*step_points+ll] += Module_2(chiTmp.re, chiTmp.im);
      }
    }
    for(ll = 0; ll < step_points; ++ll)
    {
      snrVar.re = snr[i*step_points*2+ll];
      snrVar.im = snr[i*step_points*2+ll+step_points];
      if(Module_2(snrVar.re, snrVar.im) > thresholdSqr)
        flag[i*step_points+ll] = 1;
    }
  }  
}

int perform_iir_filter_chi_d(IIRTemplate *iirTemplate, Parameters *parameters, FILE *inputFile, float *cpu_avgStepTime)
{
  if(parameters->verbose)
  {
    printf("CPU iir filtering:\n");
  }    
  //Timing values
  struct timeval tvStart, tvEnd;
  struct timeval tvStepStart, tvStepEnd;
  struct timeval tv1,tv2;
  if(parameters->verbose)
    gettimeofday(&tvStart, NULL );
  float maxStepTime, stepTime, aveStepTime, fileAccessStepTime; 
     
  unsigned int i, j, k;
  float *gwDataQueue;
  unsigned int tail=0;
  int endOfFile;
  COMPLEX8_D **prevSnr;
  COMPLEX8_D *grpOutput;  
  double *snr, *chiVal;
  char *flag;
  unsigned int batch = parameters->batch;
  unsigned int skip_points, step_points, total_points;
  unsigned int steps;  
  unsigned int maxNumGroups;
  skip_points = parameters->skipSecs * parameters->sampleRate;
  step_points = parameters->stepSecs * parameters->sampleRate;
  total_points = skip_points + step_points; 
  
  /* ======================================================
  *
  *      Input the skiped data first
  *
  * ======================================================
  */  
  gwDataQueue = (float *) malloc( ( total_points) * sizeof( float) );   //data structure used to store input data
  if(input_data( inputFile, gwDataQueue, skip_points, parameters->binaryInputFile) == -1)
  {
    free( gwDataQueue);
    printf( "Not enough data to analyse!\n");
    return -1;
  }
  tail = skip_points;
  /* ======================================================
  *
  *      Prepare output files
  *
  * ======================================================
  */  
  char chiTstRsltFileName[MAX_FILE_NAME_LENGTH];
  FILE *chiTstRsltFile = 0;
  char **snrRealFileName = 0, **snrImagFileName = 0;
  char **chiValFileName = 0;
  if(parameters->outputChiTstRslt)
  {
    sprintf(chiTstRsltFileName, "cpu_d_%s", parameters->chiTstRsltFileName);
    chiTstRsltFile = fopen(chiTstRsltFileName, "a");
    if(chiTstRsltFile == 0)
    {
      printf("Open file %s error.\n", chiTstRsltFileName);
      free( gwDataQueue);
      return -1;
    }
    fprintf(chiTstRsltFile, "time(s)\tbatch\tsnr(re)\tsnr(im)\tchi\n");
  }
  if(parameters->outputChiVal)
  {
    chiValFileName = (char **)malloc(sizeof(char *) * batch);
    for(i = 0; i < batch; ++i)
    {
      chiValFileName[i] = (char *)malloc(sizeof(char) * MAX_FILE_NAME_LENGTH);
      sprintf(chiValFileName[i], "cpu_d_%d_%s", i, parameters->chiValFileName);
    }       
  }     
  if(parameters->outputSnr)
  {
    snrRealFileName = (char **)malloc(sizeof(char *) * batch);
    snrImagFileName = (char **)malloc(sizeof(char *) * batch);
    for(i = 0; i < batch; ++i)
    {
      snrRealFileName[i] = (char *)malloc(sizeof(char) * MAX_FILE_NAME_LENGTH);
      snrImagFileName[i] = (char *)malloc(sizeof(char) * MAX_FILE_NAME_LENGTH);
      sprintf(snrRealFileName[i], "cpu_d_%d_%s", i, parameters->snrRealFileName);
      sprintf(snrImagFileName[i], "cpu_d_%d_%s", i, parameters->snrImagFileName);
    }       
  }     
   
  /* ======================================================
  *
  *      Allocate memories
  *
  * ======================================================
  */   
  snr = (double *)malloc(batch*step_points*2*sizeof(double));
  chiVal = (double *)malloc(batch*step_points*sizeof(double));
  flag = (char *)malloc(batch*step_points*sizeof(char));
  
  prevSnr = (COMPLEX8_D **)malloc(batch * sizeof(COMPLEX8_D *));
  for(i = 0; i < batch; ++i)
  {
    if(iirTemplate[i].numGroups > maxNumGroups ) maxNumGroups = iirTemplate[i].numGroups;
    prevSnr[i] = (COMPLEX8_D *)malloc(iirTemplate[i].numFilters * sizeof(COMPLEX8_D));
    memset(prevSnr[i], 0, iirTemplate[i].numFilters * sizeof(COMPLEX8_D));
  }
  grpOutput = (COMPLEX8_D *)malloc(step_points * maxNumGroups * sizeof(COMPLEX8_D));  
  if(parameters->verbose)
  {
    gettimeofday(&tv1, NULL);
    printf("Time taken for preparation: %f (s)\n", TimeBetween(tvStart,tv1));
  }
     
  /* ======================================================
  *
  *      Process data step by step
  *
  * ======================================================
  */     
  endOfFile = 0;
  maxStepTime = 0.0f;
  stepTime = 0.0f;
  aveStepTime = 0.0f;
  steps = 0;
  fileAccessStepTime = 0.0f;
  /* ======================================================
  *
  *      Process data step by step
  *
  * ======================================================
  */  
  while(parameters->numSteps == -1 || steps < parameters->numSteps)
  {
    gettimeofday(&tvStepStart, NULL);
    
    endOfFile = input_data(inputFile, gwDataQueue + tail, step_points, parameters->binaryInputFile);
    if( endOfFile == -1) break;
    
    step_iir_filter_chi_d(iirTemplate, parameters, gwDataQueue, tail, step_points, total_points, snr, chiVal, flag, prevSnr, grpOutput, step_points * maxNumGroups);
    
    if(parameters->verbose)
    {
      gettimeofday(&tv2, NULL);
    }
    if(parameters->outputChiTstRslt)
      output_result(chiTstRsltFile, snr, chiVal, 1, flag, step_points, batch,(float)(parameters->skipSecs + steps * parameters->stepSecs), 1.0/parameters->sampleRate);
    if(parameters->outputSnr)
      output_snr(snrRealFileName, snrImagFileName, snr, 1, step_points, batch, parameters->binaryOutputFile);
    if(parameters->outputChiVal)
      output_chi_val(chiValFileName, chiVal, 1, step_points, batch, parameters->binaryOutputFile);
    tail = ( tail + step_points);
    if(tail >= total_points)
      tail %= total_points;    
    ++steps;

    gettimeofday(&tvStepEnd, NULL);
    if( ( stepTime = TimeBetween(tvStepStart,tvStepEnd) ) > maxStepTime )
      maxStepTime = stepTime;
    aveStepTime += stepTime;
    if(parameters->verbose) 
      fileAccessStepTime += TimeBetween(tv2, tvStepEnd);
  };
  *cpu_avgStepTime = aveStepTime / steps; 
  if(parameters->verbose)
  {
    printf("The maximum stepTime: %f (s)\n", maxStepTime);   
    printf("The average stepTime: %f (s)\n", aveStepTime / steps );
    printf("The average file write time: %f (s)\n", fileAccessStepTime / steps );
  }
      
  /* ======================================================
  *
  *      Close files & clean up memories
  *
  * ======================================================
  */  
  free( gwDataQueue);
  free(snr);
  free(chiVal);
  free(flag);
  for( i = 0; i < batch; ++i)
  {
    free( prevSnr[i]);
  }
  free( grpOutput);
  free( prevSnr);
  if(parameters->outputChiTstRslt)
  {
    fclose(chiTstRsltFile);
  }
  if(parameters->outputChiVal)
  {
    for(i = 0; i < batch; ++i)
    {
      free(chiValFileName[i]);
    }
    free(chiValFileName);
  }
  if(parameters->outputSnr)
  {
    for(i = 0; i < batch; ++i)
    {
      free(snrRealFileName[i]);
      free(snrImagFileName[i]);
    }
    free(snrRealFileName);
    free(snrImagFileName);
  }
  if(parameters->verbose)
  {
    gettimeofday(&tvEnd, NULL);
    printf("Time spent in total: %f (s)\n", TimeBetween(tvStart, tvEnd));
  }
  
  return 0;
}
