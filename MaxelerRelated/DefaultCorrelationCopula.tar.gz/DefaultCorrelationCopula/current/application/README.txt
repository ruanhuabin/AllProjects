To run the program, do following:
1. type make  in application directory to generate the executable program
2. run: ./DefaultCopula -n 400, where:
		-n is the total copula number to caculate.
If you want to run program with specify a, b, r, do following:
	./DefaultCopula -n 4 -s 1 -a 0.1 -b 0.2 -r 0.3, where
		1) 0.1, 0.2, 0.3 is the specify value for the copula input.
		2) -s parameter is a flag used to tell program to using the specify value as input, default is 0, 
			which means generate random values for a, b, r
		3) -n should be multiple of 4, because of 16 bytes aligment for the DEF.
