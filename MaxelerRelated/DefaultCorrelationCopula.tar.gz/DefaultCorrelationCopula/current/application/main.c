#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdarg.h>
#include "DefaultCopula.max"
#define REAL_ZERO  1.0E-12
#define ZERO_EPS   1.0E-8
#define ERROR      10.0E-8 /* Change the error boundary here if you need to */
int TOTAL_NUMBER = 1600000;
double mu        = 0.0L;
double sig       = 1.0L;
const double XX[10][3] =
{
	{ -0.932469514203152 , -0.981560634246719 , -0.993128599185095  },
	{ -0.661209386466265 , -0.904117256370475 , -0.963971927277914  },
	{ -0.238619186083197 , -0.769902674194305 , -0.912234428251326  },
	{ 0.                 , -0.587317954286617 , -0.839116971822219  },
	{ 0.                 , -0.36783149899818  , -0.746331906460151  },
	{ 0.                 , -0.125233408511469 , -0.636053680726515  },
	{ 0.                 , 0.                 , -0.510867001950827  },
	{ 0.                 , 0.                 , -0.37370608871542   },
	{ 0.                 , 0.                 , -0.227785851141645  },
	{ 0.                 , 0.                 , -0.0765265211334973 }
};

const double W[10][3] =
{
	{ 0.17132449237917  , 0.0471753363865118 , 0.0176140071391521 },
	{ 0.360761573048138 , 0.106939325995318  , 0.0406014298003869 },
	{ 0.46791393457269  , 0.160078328543346  , 0.0626720483341091 },
	{ 0.                , 0.203167426723066  , 0.0832767415767048 },
	{ 0.                , 0.233492536538355  , 0.10193011981724   },
	{ 0.                , 0.249147045813403  , 0.118194531961518  },
	{ 0.                , 0.                 , 0.131688638449177  },
	{ 0.                , 0.                 , 0.142096109318382  },
	{ 0.                , 0.                 , 0.149172986472604  },
	{ 0.                , 0.                 , 0.152753387130726  }
};

/**
 *  Generate N rand values between min and max, and min >=0.0, max <= 1.0, (The random value 
 *  not include 0.0 and 1.0, but include min and max)
 */
void gen_rand_value(double *buffer, double min, double max, int N)
{
	if( NULL == buffer )
	{
		fprintf(stderr, "[%s:%d]: gen_rand_probability: buffer is NULL\n", __FILE__, __LINE__);
		exit(1);
	}

	srand(time(NULL));
	int i = 0;
	int rand_num;
	int max_rand_value = 1000000;
	double tmp = 0.0;

	for( i = 0 ; i < N; i ++)
	{
		rand_num  = 1 + rand() % max_rand_value;
		tmp       = (((double)rand_num) / (double)(max_rand_value + 2));
		buffer[i] = tmp < min ? min : tmp;
		buffer[i] = buffer[i] < max ? buffer[i] :max;
	}
}

/**
 *  Generate N random values between -1.0 and 1.0, include -1.0 and 1.0
 */
void gen_rand_value2(double *buffer, int N)
{
	if( NULL == buffer )
	{
		fprintf(stderr, "[%s:%d]: gen_rand_probability: buffer is NULL\n", __FILE__, __LINE__);
		exit(1);
	}
	srand(time(NULL));
	int i = 0;
	double rand_num;
	double tmp = 0.0;

	for( i = 0 ; i < N; i ++)
	{
		rand_num = rand() / (double)RAND_MAX;
		tmp = 2.0 * rand_num - 1.0; /* Random value between -1.0 and 1.0, Not include -1.0 and 1.0 */
		buffer[i] = tmp;
	}
}
void max_print_double_vector(double *m, int cols, char *hint_msg)
{
	fprintf(stderr, "====>%s\n", hint_msg);
	for(int i = 0; i < 1; i ++)
	{
		for(int j = 0; j < cols; j ++)
		{
			fprintf(stderr, "%.16f ", m[i * cols + j]);
		}
		fprintf(stderr, "\n");
	}
}

void usage()
{
      printf("\nUsage:\n\n");
	  printf("\t./DefaultCopulaRun [-n <number >]");
	  printf("\nwhere:\n");
	  printf("\t");
	  printf("-n\tnumber of copula values to caculate, default 1600000\n\n");
}

double cumnorm_std(double x)
{
		double Exponential = 0.0;
		double build = 0.0;
		double Cumnorm = 0.0;
		double XAbs = fabs(x);
		if (XAbs > 37.0)
		{
				Cumnorm = 0.0;
		}
		else
		{
				Exponential = exp(-XAbs*XAbs / 2.0);
				if (XAbs < 7.07106781186547)
				{
						build = 3.52624965998911E-02 * XAbs + 0.700383064443688;
						build = build * XAbs + 6.37396220353165;
						build = build * XAbs + 33.912866078383;
						build = build * XAbs + 112.079291497871;
						build = build * XAbs + 221.213596169931;
						build = build * XAbs + 220.206867912376;
						Cumnorm = Exponential * build;
						build = 8.83883476483184E-02 * XAbs + 1.75566716318264;
						build = build * XAbs + 16.064177579207;
						build = build * XAbs + 86.7807322029461;
						build = build * XAbs + 296.564248779674;
						build = build * XAbs + 637.333633378831;
						build = build * XAbs + 793.826512519948;
						build = build * XAbs + 440.413735824752;
						Cumnorm = Cumnorm / build;
				}
				else
				{
						build = XAbs + 0.65;
						build = XAbs + 4.0 / build;
						build = XAbs + 3.0 / build;
						build = XAbs + 2.0 / build;
						build = XAbs + 1.0 / build;
						Cumnorm = Exponential / build / 2.506628274631;
				}
		}
		if( x > 0 ) 
		{
				Cumnorm = 1.0 - Cumnorm;
		}
		return Cumnorm;
}
double min(double n1, double n2)
{
	return n1 < n2 ? n1:n2;
}

/**
 *  This function is the implemation of author's paper
 */
double bivarcumnorm_std_paper(double a, double b, double r)
{
		int i;
		double x[5] = {0.04691008, 0.23076534, 0.5, 0.76923466, 0.95308992};
		double W[5] = {0.018854042, 0.038088059, 0.0452707394, 0.038088059, 0.018854042};
		double h1, h2;
		double LH = 0.0, h12;
		double h3, h5, h6, h7, h8;
		double r1, r2, r3, rr;
		double AA, ab;
		
		double Bivarcumnorm = 0.0;
		h1 = a;
		h2 = b;
		h12 = (h1 * h1 + h2 * h2) / 2.0;
		if (fabs(r) >= 0.7)
		{	r2 = 1.0 - r * r;
			r3 = sqrt(r2);
			if (r < 0.0)
		   	{
				h2 = -h2;
			}
			h3 = h1 * h2;
			h7 = exp(-h3 / 2.0);
			if (fabs(r) < 1.0)
			{
				h6 = fabs(h1 - h2);
				h5 = h6 * h6 / 2.0;
				h6 = h6 / r3;
				AA = 0.5 - h3 / 8.0;
				ab = 3.0 - 2.0 * AA * h5;
				LH = 0.13298076 * h6 * ab * (1.0 - cumnorm_std(h6)) - exp(-h5 / r2) * (ab + AA * r2) * 0.053051647;
				for (i = 0; i < 5; i ++)
				{
					r1 = r3 * x[i];
					rr = r1 * r1;
					r2 = sqrt(1.0 - rr);

					if(fabs(h7) < REAL_ZERO)
					{
						h8 = 0.0;
					}
					else
					{
						h8 = exp(-h3 / (1.0 + r2)) / r2 / h7;
					}
					LH = LH - W[i] * exp(-h5 / rr) * (h8 - 1.0 - AA * rr);
				}
			}

			Bivarcumnorm = LH * r3 * h7 + cumnorm_std(min(h1, h2));
			if( r < 0.0 )
			{
				Bivarcumnorm = cumnorm_std(h1) - Bivarcumnorm;
			}
		}
		else
		{
			h3 = h1 * h2;
			if (r != REAL_ZERO)
			{
				for(i = 0; i < 5; i ++)
				{	
					r1 = r * x[i];
					r2 = 1 - r1 * r1;
					LH = LH + W[i] * exp((r1 * h3 - h12) / r2) / sqrt(r2);
				}
			}
			Bivarcumnorm = cumnorm_std(h1) * cumnorm_std(h2) + r * LH;
		}
		return Bivarcumnorm;
}

double max(double n1, double n2)
{
	return n1 > n2 ? n1:n2;
}


/**
 *  This function is the author's implementation which download from his website
 */
double bivarcumnorm_std_author(double x, double y, double correlation)
{

	int NG;
	int LG;
	
	if (fabs(correlation) < 0.3)
	{
		NG = 1;
		LG = 3;
	}
	else if (fabs(correlation) < 0.75)
	{
		NG = 2;
		LG = 6;
	}
	else 
	{
		NG = 3;
		LG = 10;
	}

	double h = -x;
	double k = -y;
	double hk = h * k;
	double BVN = 0;

	if (fabs(correlation) < 0.925)
	{
		if (fabs(correlation) > 0)
		{
		    double hs = (h * h + k * k) / 2;
		    double asr = asin(correlation);
			for (int i = 1; i <= LG; ++i)
			{
				for (int iss = -1; iss <=1; iss += 2)
				{
					double sn = sin(asr * (iss * XX[i-1][NG-1] + 1) * 0.5);
					BVN = BVN + W[i-1][NG-1] * exp((sn * hk - hs) / (1.0 - sn * sn));
				}
			}
			BVN = BVN * asr * 0.795774715459476678e-1;
		}
		BVN = BVN + cumnorm_std(-h) * cumnorm_std(-k);
	}
	else
	{
		if (correlation < 0) 
		{
			k *= -1;
			hk *= -1;
		}
		if (fabs(correlation) < 1)
		{
		    double Ass = (1 - correlation) * (1 + correlation);
			double a = sqrt(Ass);
			double bs = (h-k)*(h-k);
			double c = (4 - hk) / 8;
			double d = (12 - hk) / 16;
			double asr = -(bs / Ass + hk) / 2;
			if (asr > -100)
			{
				BVN = a * exp(asr) * (1 - c * (bs - Ass) * (1 - d * bs / 5) / 3 + c * d * Ass * Ass / 5);
			}
			if (-hk < 100)
			{
				double B = sqrt(bs);
				BVN = BVN - exp(-hk / 2) * 2.506628274631 * cumnorm_std(-B / a) * B * (1 - c * bs * (1 - d * bs / 5) / 3);
			}
			a /= 2;
			for (int i = 1; i <= LG; ++i)
			{
				for (int iss = -1; iss <= 1; iss += 2)
				{
					double xs = a * (iss * XX[i-1][NG-1] + 1);	
					xs = fabs(xs*xs);
					double rs = sqrt(1 - xs);
					asr = -(bs / xs + hk) / 2;
					if (asr > -100)
					{
						BVN = BVN + a * W[i-1][NG-1] * exp(asr) * (exp(-hk * (1 - rs) / (2 * (1 + rs))) / rs - (1 + c * xs * (1 + d * xs)));
					}	
				}
			}
			BVN *= - 0.159154943091895336;
		}
		if (correlation > 0)
		{
			BVN = BVN + cumnorm_std(-max(h, k));
		}
		else
		{
			BVN *= -1;
			if (k > h)
			{
				BVN = BVN + cumnorm_std(k) - cumnorm_std(h);
			}
		}
	}	 
	return BVN;
}

/**
 *  The type of variable argment must be double
 */
void max_print_result(char (*headers)[64], size_t col_distance, size_t n, ...)
{

		/**
		 *  Print Headers using specify colum distance
		 */
		char space[col_distance+1];
		memset(space, ' ', sizeof(space));
		space[col_distance] = '\0';
		fprintf(stdout, "\n");
		for(int i = 0; i < n-1 ; i ++)
		{
			fprintf(stdout, "%s%s", headers[i], space);
		}
		fprintf(stdout, "%s\n", headers[n-1]);
		/**
		 *  Organize data
		 */
		char values[n][64];
		char total_values = n;
		va_list arg_ptr;
		va_start(arg_ptr, n);
		double arg_value;
		int index = 0;
		while(total_values)
		{
			arg_value = va_arg(arg_ptr, double);
			sprintf(values[index], "%.2f", arg_value);
			index ++;
			total_values --;
		}
		va_end(arg_ptr);

		/**
		 *  Print values in the second line
		 */
		char value_with_padding[64];
		char padding_space[64];
		size_t padding_space_len = 0;
		for(int i = 0; i < n; i ++)
		{
				memset(value_with_padding, 0, sizeof(value_with_padding));
				memset(padding_space, 0, sizeof(padding_space));
				strcpy(value_with_padding, values[i]);
				padding_space_len = strlen(headers[i]) + col_distance - strlen(values[i]);
				for(int j = 0; j < padding_space_len; j ++)
				{
					padding_space[j] = ' ';
				}
				strcat(value_with_padding, padding_space);
				fprintf(stdout, "%s", value_with_padding);
		}

		fprintf(stdout, "\n\n");

}
void max_init_mu_sig(double new_mu, double new_sig)
{
	mu = new_mu;
	sig = new_sig;
}

double  max_get_mu()
{
	return mu;
}

double max_get_sig()
{
	return sig;
}

double max_acklam_inverse_cdf(double p)
{
   double a[7];
   double b[6];
   double c[7];
   double d[5];

   double p_low  = 0.02425;
   double p_high = 1.0 - p_low;
   double q = 0.0;
   double x = 0.0;
   double r= 0.0;


   a[1] = -3.969683028665376e+01;
   a[2] =  2.209460984245205e+02;
   a[3] = -2.759285104469687e+02;
   a[4] =  1.383577518672690e+02;
   a[5] = -3.066479806614716e+01;
   a[6] =  2.506628277459239e+00;

   b[1] = -5.447609879822406e+01;
   b[2] =  1.615858368580409e+02;
   b[3] = -1.556989798598866e+02;
   b[4] =  6.680131188771972e+01;
   b[5] = -1.328068155288572e+01;

   c[1] = -7.784894002430293e-03;
   c[2] = -3.223964580411365e-01;
   c[3] = -2.400758277161838e+00;
   c[4] = -2.549732539343734e+00;
   c[5] =  4.374664141464968e+00;
   c[6] =  2.938163982698783e+00;

   d[1] =  7.784695709041462e-03;
   d[2] =  3.224671290700398e-01;
   d[3] =  2.445134137142996e+00;
   d[4] =  3.754408661907416e+00;
      
  // if 0 < p < p_low
  if(p > ZERO_EPS && (p - p_low) < ZERO_EPS)
  {     
	  q = sqrtl(-2*logl(p));
      x = (((((c[1]*q+c[2])*q+c[3])*q+c[4])*q+c[5])*q+c[6]) / ((((d[1]*q+d[2])*q+d[3])*q+d[4])*q+1);
  }
 
   //if p_low <= p <= p_high
   if((p_low - p) <= ZERO_EPS && (p - p_high) <= ZERO_EPS)
   {
	  q = p - 0.5;
      r = q*q;
      x = (((((a[1]*r+a[2])*r+a[3])*r+a[4])*r+a[5])*r+a[6])*q / (((((b[1]*r+b[2])*r+b[3])*r+b[4])*r+b[5])*r+1);
   }
  
   //if p_high < p < 1
   if( (p_high - p) < ZERO_EPS && (p - 1.0) < ZERO_EPS)
   {
      q = sqrt(-2*log(1-p));
      x = -(((((c[1]*q+c[2])*q+c[3])*q+c[4])*q+c[5])*q+c[6]) / ((((d[1]*q+d[2])*q+d[3])*q+d[4])*q+1);
   }
  	
	return ( p > ZERO_EPS && (p - 1.0) < ZERO_EPS) ? sig *x + mu : INFINITY;
	
}

double default_copula_std(double u1, double u2, double correlation)
{
	double inverse_u1 = max_acklam_inverse_cdf(u1);
	double inverse_u2 = max_acklam_inverse_cdf(u2);

	/**
	 *  Here we use the author's implementation of bivarcumnorm
	 */
//	double result     = bivarcumnorm_std_author(inverse_u1, inverse_u2, correlation);
	double result     = bivarcumnorm_std_paper(inverse_u1, inverse_u2, correlation);
	return result;
}
int main(int argc, char* argv[])
{
	char *opt_str = "ha:b:r:n:s:";
	int opt = 0;
	double sa = 0.1;
	double sb = 0.2;
	double sr = 0.3;
	int    s  = 0;    /* 1: using specify a, b,c, 0:using random a, b, c */
	while( (opt = getopt(argc, argv, opt_str)) != -1)
	{
		switch(opt)
		{
				case 'a':
						sa = atof(optarg);
						break;
				case 'b':
						sb = atof(optarg);
						break;
				case 'r':
						sr = atof(optarg);
						break;
				case 'n':
						TOTAL_NUMBER = atoi(optarg);
						break;
				case 's':
						s = atoi(optarg);
						break;
				case 'h':
					usage();
					return 0;
				default:
					printf("Invalid command line parameters: %s!\n", optarg);
					usage();
					return -1;
		}
	}	

	double *a = malloc(TOTAL_NUMBER * sizeof(double));
	double *b = malloc(TOTAL_NUMBER * sizeof(double));
	/**
	 *  Because r is scalar input, so we only generate only one random value for r
	 */
	double *r = malloc(1*sizeof(double));
	if(s)
	{
		for(int i = 0; i < TOTAL_NUMBER; i ++)
		{
			a[i] = sa;
			b[i] = sb;
			r[i] = sr;
		}	
	}
	else
	{
			gen_rand_value(a, 0.0, 1.0, TOTAL_NUMBER);
			gen_rand_value(b, 0.0, 1.0, TOTAL_NUMBER);

			/**
			 *  The values for r can between -1.0 and 1.0
			 */
			gen_rand_value2(r, 1);
	}

	float correlation = r[0];
	double *kernel_output = malloc(TOTAL_NUMBER * sizeof(double));
	clock_t engine_start = clock();
	DefaultCopula(
			  	  TOTAL_NUMBER, 
			  	  mu,
			  	  correlation,
			      sig,
			      a,
			      TOTAL_NUMBER*sizeof(double),
			      b,
			      TOTAL_NUMBER*sizeof(double),
			      kernel_output,
			      TOTAL_NUMBER*sizeof(double)
			     );

	clock_t engine_end = clock();
	double  engint_total_time = (double)(engine_end - engine_start) / CLOCKS_PER_SEC;
	double *std_output = malloc(TOTAL_NUMBER * sizeof(double));
	clock_t cpu_start = clock();
	for(int i = 0; i < TOTAL_NUMBER; i ++)
	{
		std_output[i] = default_copula_std(a[i], b[i], r[0]);
	}
	clock_t cpu_end   = clock();
	double cpu_total_time = (double)(cpu_end - cpu_start)/CLOCKS_PER_SEC;

	/**
	 *  Compare Kernel output and C output
	 */
	int pass_cnt          = 0  ;
	double actual         = 0.0;
	double expected       = 0.0;
	double absExpected    = 0.0;
	double abs_error      = 0.0;
	double max_absolute_error = -100;
	for(int i = 0; i < TOTAL_NUMBER; i ++)
	{
			actual = (double)kernel_output[i];
			expected =(double)std_output[i];
			absExpected = fabs(expected);
			abs_error = fabs(actual - expected);
			if(max_absolute_error < abs_error)
			{
				max_absolute_error = abs_error;
			}
			if(abs_error < ERROR )
			{
				pass_cnt ++;
			}
			else
			{
				fprintf(stderr, "%d: Actual=%.12f, Expected=%.12f, Absolute_Error=%.12e,\
							   	 a=%.8f, b = %.8f, correlation = %.8f\n",\
							   	 i, actual, expected, abs_error, a[i], b[i], correlation);
			}

	}
	if(TOTAL_NUMBER <= 8)
	{
		max_print_double_vector(a, TOTAL_NUMBER, "A");
		max_print_double_vector(b, TOTAL_NUMBER, "B");
		max_print_double_vector(r, TOTAL_NUMBER, "R");
		max_print_double_vector(kernel_output, TOTAL_NUMBER, "Kernel Output");
		max_print_double_vector(std_output, TOTAL_NUMBER, "Std Output");
	}

	double speedup = (engint_total_time < REAL_ZERO) ? 0.0: cpu_total_time / engint_total_time;
	char headers[][64] = {"Total Number", "DEF Time", "CPU Time", "Speedup"};
	size_t n = sizeof(headers)/sizeof(headers[0]);
	max_print_result(headers, 12, n, (double)TOTAL_NUMBER, engint_total_time, cpu_total_time, speedup);
	fprintf(stderr, "Max Absolute Error: %.3E\n", max_absolute_error);

	free(a);
	free(b);
	free(r);
	free(kernel_output);
	free(std_output);
	return 0;
}
