package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxConstantEncodingException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEUntypedConst;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplexType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplexType.ConstantValue;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * Test class to exercise as much as possible of the DFEComplex class; refer to nightly tests' EMMA output for coverage statistics.
 *
 * @author kate
 */
public class DFEComplexTest extends Kernel {

	private static Random m_random = null;

	private static final DFEComplexType int_cplx_type = new DFEComplexType( dfeInt(32) );
	private static final DFEComplexType flt_cplx_type = new DFEComplexType(dfeFloat(11,53), dfeFloat(11,53));
	private static final DFEComplexType mix_cplx_type = new DFEComplexType(dfeFloat(11,53), dfeInt(32)     );
	private static final DFEType angle90_type = dfeUInt(2);


	public DFEComplexTest( KernelParameters parameters ) {
		super( parameters );

		DFEComplex flt_cplx_inA = io.input ( "flt_cplx_inA", flt_cplx_type );
		DFEComplex flt_cplx_inB = io.input ( "flt_cplx_inB", flt_cplx_type );
		DFEComplex int_cplx_inA = io.input ( "int_cplx_inA", int_cplx_type );
		DFEComplex int_cplx_inB = io.input ( "int_cplx_inB", int_cplx_type );
		DFEComplex mix_cplx_inA = io.input ( "mix_cplx_inA", mix_cplx_type );
		DFEComplex mix_cplx_inB = io.input ( "mix_cplx_inB", mix_cplx_type );
		DFEVar inAngle90 = io.input ( "inAngle90", angle90_type );

		flush.whenInputFinished( "mix_cplx_inB" );
		mix_cplx_inA.watch( "mixed_input_A" );
		mix_cplx_inB.setReportOnUnused( false );

		DFEVar var = flt_cplx_inB.getReal();

		//----- cast override, and getKernel
		Kernel kernel = flt_cplx_inA.getKernel();
		try {
			DFEComplex a = flt_cplx_inA.cast( flt_cplx_inB.getType() );
			DFEComplex b = flt_cplx_inA.cast( var.getType() );
			a.setReportOnUnused( false );
			b.setReportOnUnused( false );
		} catch ( MaxCompilerAPIError e ) {
			kernel.logMsg( "Successfully caught exception, as required!  Ignoring." );
		}

		//----- DFEComplexType.toString
		kernel.logMsg( "flt_cplx_type = " + flt_cplx_type.toString() );
		kernel.logMsg( "int_cplx_type = " + int_cplx_type.toString() );
		kernel.logMsg( "mix_cplx_type = " + mix_cplx_type.toString() );
		if ( ! flt_cplx_type.equals(int_cplx_type) )
			kernel.logMsg( "flt_cplx_type != int_cplx_type   ...life is good." );
		if ( int_cplx_type.equals(new DFEComplexType(dfeInt(32))) )
			kernel.logMsg( "int_cplx_type == int_cplx_type   ...life get better." );

		try {
			DFEUntypedConst ut_const     = DFETypeFactory.dfeUntypedConst();
			DFEComplexType   ut_cplx_type = new DFEComplexType( ut_const );
			io.output( "untyped", ut_cplx_type ).connect( flt_cplx_inA );
		} catch (MaxCompilerAPIError e) {
			kernel.logMsg( "Successfully caught hwUntypedConst exception, as required!  Ignoring." );
		}

		//----- addition, casting
		io.output("t_flt_out", flt_cplx_type).connect(  (flt_cplx_inA + flt_cplx_inB) * 3 + constant.cplx(dfeFloat(11,53), 1, 1) );
		io.output("t_int_out", int_cplx_type).connect( ((flt_cplx_inA + flt_cplx_inB) * 3 + constant.cplx(1, 1) ).cast(int_cplx_type) );
		io.output("t_mix_out", mix_cplx_type).connect( flt_cplx_inA.cast(mix_cplx_type) + int_cplx_inB.cast(mix_cplx_type) );
		io.output("t_flt_int_add", flt_cplx_type).connect( flt_cplx_inA + int_cplx_inB.cast(flt_cplx_type) );

		//----- addAsRHS tests
		io.output("t_flt_addAsRHS", flt_cplx_type).connect( 10   + flt_cplx_inA );
		io.output("t_int_addAsRHS", int_cplx_type).connect( 10.0 + int_cplx_inA );
		io.output("t_mix_addAsRHS", mix_cplx_type).connect( 10L  + mix_cplx_inA );
		io.output("t_var_addAsRHS", flt_cplx_type).connect( var  + flt_cplx_inA );

		//----- addAsLHS tests
		io.output("t_flt_addAsLHS", flt_cplx_type).connect( flt_cplx_inA + 10   );
		io.output("t_int_addAsLHS", int_cplx_type).connect( int_cplx_inA + 10.0 );
		io.output("t_mix_addAsLHS", mix_cplx_type).connect( mix_cplx_inA + 10L  );
		io.output("t_var_addAsLHS", flt_cplx_type).connect( flt_cplx_inA + var  );

		//----- subAsRHS tests
		io.output("t_flt_subAsRHS", flt_cplx_type).connect( 10   - flt_cplx_inA );
		io.output("t_int_subAsRHS", int_cplx_type).connect( 10.0 - int_cplx_inA );
		io.output("t_mix_subAsRHS", mix_cplx_type).connect( 10L  - mix_cplx_inA );
		io.output("t_var_subAsRHS", flt_cplx_type).connect( var  - flt_cplx_inA );

		//----- subAsLHS tests
		io.output("t_flt_subAsLHS", flt_cplx_type).connect( flt_cplx_inA - 10   );
		io.output("t_int_subAsLHS", int_cplx_type).connect( int_cplx_inA - 10.0 );
		io.output("t_mix_subAsLHS", mix_cplx_type).connect( mix_cplx_inA - 10L  );
		io.output("t_var_subAsLHS", flt_cplx_type).connect( flt_cplx_inA - var  );

		//----- sub test
		io.output("t_cplx_subCplx",  flt_cplx_type).connect( flt_cplx_inA - int_cplx_inB.cast(flt_cplx_type)  );

		//----- neg tests
		io.output("t_flt_neg", flt_cplx_type).connect( - flt_cplx_inA );
		io.output("t_int_neg", int_cplx_type).connect( - int_cplx_inA );
		io.output("t_mix_neg", mix_cplx_type).connect( - mix_cplx_inA );

		//---- conjugate tests
		io.output("t_flt_conjugate", flt_cplx_type).connect( flt_cplx_inA.conjugate() );
		io.output("t_int_conjugate", int_cplx_type).connect( int_cplx_inA.conjugate() );
		io.output("t_mix_conjugate", mix_cplx_type).connect( mix_cplx_inA.conjugate() );

		//----- mulAsRHS tests
		io.output("t_flt_mulAsRHS", flt_cplx_type).connect( 10   * flt_cplx_inA );
		io.output("t_int_mulAsRHS", int_cplx_type).connect( 10.0 * int_cplx_inA );
		io.output("t_mix_mulAsRHS", mix_cplx_type).connect( 10L  * mix_cplx_inA );
		io.output("t_var_mulAsRHS", flt_cplx_type).connect( var  * flt_cplx_inA );

		//----- mulAsLHS tests
		io.output("t_flt_mulAsLHS", flt_cplx_type).connect( flt_cplx_inA * 10   );
		io.output("t_int_mulAsLHS", int_cplx_type).connect( int_cplx_inA * 10.0 );
		io.output("t_mix_mulAsLHS", mix_cplx_type).connect( mix_cplx_inA * 10L  );
		io.output("t_var_mulAsLHS", flt_cplx_type).connect( flt_cplx_inA * var  );

		//----- mul complex*complex
		io.output("t_flt_mul", flt_cplx_type).connect( flt_cplx_inA * int_cplx_inB.cast(flt_cplx_type) );

		//----- mul complex**2
		io.output("t_flt_sqr", flt_cplx_type).connect( flt_cplx_inA * flt_cplx_inA );

		//----- divAsRHS tests (adding (1+i) to divisor to guard against division by zero)
		//      N.B. division not supported for fixed point operations.
		io.output("t_flt_divAsRHS_l", flt_cplx_type).connect( 3000L   / (flt_cplx_inA + constant.cplx(dfeFloat(11,53), 1, 1)) );
		io.output("t_flt_divAsRHS_d", flt_cplx_type).connect( 3456.78 / (flt_cplx_inA + constant.cplx(1, 1)) );
		io.output("t_var_divAsRHS",   flt_cplx_type).connect( var     / (flt_cplx_inA + constant.cplx(flt_cplx_inA, 1, 1)) );

		//----- divAsLHS tests
		io.output("t_flt_divAsLHS", flt_cplx_type).connect( flt_cplx_inA / 3 );
		io.output("t_int_divAsLHS", int_cplx_type).connect( (int_cplx_inA.cast(flt_cplx_type) / 3.0).cast(int_cplx_type) );
		io.output("t_mix_divAsLHS", mix_cplx_type).connect( (mix_cplx_inA.cast(flt_cplx_type) / 3L ).cast(mix_cplx_type) );
		io.output("t_var_divAsLHS", flt_cplx_type).connect( flt_cplx_inA / var );

		//----- div complex/complex  (adding (1,i) to divisor to guard against division by zero)
		io.output("t_flt_div", flt_cplx_type).connect( flt_cplx_inA / (flt_cplx_inB + constant.cplx(1,1)) );

		//----- rotate in 90 degree steps
		io.output("t_flt_rot90", flt_cplx_type).connect( flt_cplx_inA.rotate90(inAngle90) );
		io.output("t_int_rot90", int_cplx_type).connect( int_cplx_inA.rotate90(inAngle90) );
	}


	/**
	 * This is run by the nightly tests.
	 * @param args - not used.
	 */
	public static void main(String[] args) {
		String                 name        = "DFEComplexTest";
		_DualSimulationManager manager     = new _DualSimulationManager(name);
		KernelParameters       parametersA = manager.makeKernelParameters_A();
		KernelParameters       parametersB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEComplexTest(parametersA), new DFEComplexTest(parametersB) );

		long seed = System.currentTimeMillis();
		m_random  = new Random(seed);
		manager.logMsg( "\n*****  Using Random seed = " + seed  + "  *****\n" );

		try {
			int[] doublet = new int[2];
			doublet[0] = 32;
			doublet[1] = 64;
			Bits bits1 = int_cplx_type.encodeConstant( doublet );
			manager.logMsg( "doublet = ( " + doublet[0] + ", " + doublet[1] + " ) = " + bits1.toString() );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "successfully caught exception, as required: " + e );
		}

		ConstantValue cv = new ConstantValue( -1, 0 );
		Bits       bits2 = int_cplx_type.encodeConstant( cv );
		manager.logMsg( "encoding ConstantValue = " + cv + " = " + bits2.toString() );
		Bits       bits3 = int_cplx_type.encodeConstant( bits2 );
		manager.logMsg( "encoding bits " + bits2.toString() + " = " + bits3.toString() );
		try {
			Bits   bits4 = flt_cplx_type.encodeConstant( bits2 );
			manager.logMsg( "encoding bits " + bits2.toString() + " = " + bits4.toString() );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "successfully caught exception, as required: " + e );
		}
		manager.logMsg( "flt_cplx_type.hashCode() = " + flt_cplx_type.hashCode() );
		manager.logMsg( "int_cplx_type.hashCode() = " + int_cplx_type.hashCode() );
		manager.logMsg( "mix_cplx_type.hashCode() = " + mix_cplx_type.hashCode() );


		int len = 10;
		double[] inA_re = initToRandom( len );
		double[] inA_im = initToRandom( len );
		double[] inB_re = initToRandom( len );
		double[] inB_im = initToRandom( len );

		double[] inAngle90 = new double[len];
		for (int i = 0; i < len; i++)
			inAngle90[i] = m_random.nextInt(4);

		for ( int i = 0 ; i < len ; i++ )
			System.out.println( "input data    inA[" + i + "] = { " + inA_re[i] + ", " + inA_im[i] + " }" +
					                      " \t inB[" + i + "] = { " + inB_re[i] + ", " + inB_im[i] + " }"  );
		manager.setInputDataRaw( "flt_cplx_inA", encodeValues(flt_cplx_type, inA_re, inA_im) );
		manager.setInputDataRaw( "flt_cplx_inB", encodeValues(flt_cplx_type, inB_re, inB_im) );
		manager.setInputDataRaw( "int_cplx_inA", encodeValues(int_cplx_type, inA_re, inA_im) );
		manager.setInputDataRaw( "int_cplx_inB", encodeValues(int_cplx_type, inB_re, inB_im) );
		manager.setInputDataRaw( "mix_cplx_inA", encodeValues(mix_cplx_type, inA_re, inA_im) );
		manager.setInputDataRaw( "mix_cplx_inB", encodeValues(mix_cplx_type, inB_re, inB_im) );
		manager.setInputData( "inAngle90", inAngle90);

		manager.runTest();

		//---------------------------------------- addition, casting tests
		double[]   re = new double[len];
		double[]   im = new double[len];
		List<Bits> output_bits;
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = (inA_re[i] + inB_re[i]) * 3.0 + 1.0;
			im[i] = (inA_im[i] + inB_im[i]) * 3.0 + 1.0;
		}
		checkResult(  manager.getOutputDataRaw("t_flt_out"), flt_cplx_type, re, im, "add flt type" );

		output_bits = manager.getOutputDataRaw("t_int_out");
		for ( int i = 0 ; i < len ; i++ )
			checkResult( i, output_bits, int_cplx_type, Math.round(re[i]), Math.round(im[i]), "add int type" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] =            inA_re[i]  + Math.round(inB_re[i]);
			im[i] = Math.round(inA_im[i]) + Math.round(inB_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_out"), mix_cplx_type, re, im, "add mix type" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] + Math.round(inB_re[i]);
			im[i] = inA_im[i] + Math.round(inB_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_flt_int_add"), flt_cplx_type, re, im, "add flt + int" );


		//---------------------------------------- addAsRHS tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] + 10.0;
			im[i] = inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_addAsRHS"), flt_cplx_type, re, im, "flt addAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = Math.round(inA_re[i]) + 10;
			im[i] = Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_addAsRHS"), int_cplx_type, re, im, "int addAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] + 10;
			im[i] = Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_addAsRHS"), mix_cplx_type, re, im, "mix addAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] + inB_re[i];
			im[i] = inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_var_addAsRHS"), flt_cplx_type, re, im, "var addAsRHS" );

		//---------------------------------------- addAsLHS tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] + 10.0;
			im[i] = inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_addAsLHS"), flt_cplx_type, re, im, "flt addAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = Math.round(inA_re[i]) + 10;
			im[i] = Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_addAsLHS"), int_cplx_type, re, im, "int addAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] + 10;
			im[i] = Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_addAsLHS"), mix_cplx_type, re, im, "mix addAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] + inB_re[i];
			im[i] = inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_var_addAsLHS"), flt_cplx_type, re, im, "var addAsLHS" );

		//---------------------------------------- subAsRHS tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 - inA_re[i];
			im[i] =    - inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_subAsRHS"), flt_cplx_type, re, im, "flt subAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 - Math.round(inA_re[i]);
			im[i] =    - Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_subAsRHS"), int_cplx_type, re, im, "int subAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 - inA_re[i];
			im[i] =    - Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_subAsRHS"), mix_cplx_type, re, im, "mix subAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inB_re[i] - inA_re[i];
			im[i] =           - inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_var_subAsRHS"), flt_cplx_type, re, im, "var subAsRHS" );

		//---------------------------------------- subAsLHS tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] - 10.0;
			im[i] = inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_subAsLHS"), flt_cplx_type, re, im, "flt subAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = Math.round(inA_re[i]) - 10;
			im[i] = Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_subAsLHS"), int_cplx_type, re, im, "int subAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] - 10;
			im[i] = Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_subAsLHS"), mix_cplx_type, re, im, "mix subAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] - inB_re[i];
			im[i] = inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_var_subAsLHS"), flt_cplx_type, re, im, "var subAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] - Math.round(inB_re[i]);
			im[i] = inA_im[i] - Math.round(inB_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_cplx_subCplx"), flt_cplx_type, re, im, "cplx subCplx" );

		//---------------------------------------- neg tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = - inA_re[i];
			im[i] = - inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_neg"), flt_cplx_type, re, im, "flt neg" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = - Math.round(inA_re[i]);
			im[i] = - Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_neg"), int_cplx_type, re, im, "int neg" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = - inA_re[i];
			im[i] = - Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_neg"), mix_cplx_type, re, im, "mix neg" );

		//---------------------------------------- conjugate tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] =   inA_re[i];
			im[i] = - inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_conjugate"), flt_cplx_type, re, im, "flt conjugate" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] =   Math.round(inA_re[i]);
			im[i] = - Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_conjugate"), int_cplx_type, re, im, "int conjugate" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] =   inA_re[i];
			im[i] = - Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_conjugate"), mix_cplx_type, re, im, "mix cojugate" );

		//---------------------------------------- mulAsRHS tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 * inA_re[i];
			im[i] = 10 * inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_mulAsRHS"), flt_cplx_type, re, im, "flt mulAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 * Math.round(inA_re[i]);
			im[i] = 10 * Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_mulAsRHS"), int_cplx_type, re, im, "int mulAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 * inA_re[i];
			im[i] = 10 * Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_mulAsRHS"), mix_cplx_type, re, im, "mix mulAsRHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inB_re[i] * inA_re[i];
			im[i] = inB_re[i] * inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_var_mulAsRHS"), flt_cplx_type, re, im, "var mulAsRHS" );

		//---------------------------------------- mulAsLHS tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 * inA_re[i];
			im[i] = 10 * inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_flt_mulAsLHS"), flt_cplx_type, re, im, "flt mulAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 * Math.round(inA_re[i]);
			im[i] = 10 * Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_int_mulAsLHS"), int_cplx_type, re, im, "int mulAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = 10 * inA_re[i];
			im[i] = 10 * Math.round(inA_im[i]);
		}
		checkResult( manager.getOutputDataRaw("t_mix_mulAsLHS"), mix_cplx_type, re, im, "mix mulAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inB_re[i] * inA_re[i];
			im[i] = inB_re[i] * inA_im[i];
		}
		checkResult( manager.getOutputDataRaw("t_var_mulAsLHS"), flt_cplx_type, re, im, "var mulAsLHS" );

		//---------------------------------------- mul complex*complex
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = (inA_re[i] * Math.round(inB_re[i])) - (inA_im[i] * Math.round(inB_im[i]));
			im[i] = (inA_re[i] * Math.round(inB_im[i])) + (inA_im[i] * Math.round(inB_re[i]));
		}
		checkResult( manager.getOutputDataRaw("t_flt_mul"), flt_cplx_type, re, im, "flt mul (flt * int)" );

		//----- mul complex**2
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = (inA_re[i] * inA_re[i]) - (inA_im[i] * inA_im[i]);
			im[i] =  inA_re[i] * inA_im[i] * 2;
		}
		checkResult( manager.getOutputDataRaw("t_flt_sqr"), flt_cplx_type, re, im, "flt ** 2" );

		//---------------------------------------- divAsRHS tests
		// N.B. division not supported for fixed point operations.
		for ( int i = 0 ; i < len ; i++ ) {
			double denom = (inA_re[i] + 1)*(inA_re[i] + 1) + (inA_im[i] + 1)*(inA_im[i] + 1);
			re[i] =  3000 * (inA_re[i]+1) / denom;
			im[i] = -3000 * (inA_im[i]+1) / denom;
		}
		checkResult( manager.getOutputDataRaw("t_flt_divAsRHS_l"), flt_cplx_type, re, im, "flt divAsRHS long" );

		for ( int i = 0 ; i < len ; i++ ) {
			double denom = (inA_re[i] + 1)*(inA_re[i] + 1) + (inA_im[i] + 1)*(inA_im[i] + 1);
			re[i] =  3456.78 * (inA_re[i]+1) / denom;
			im[i] = -3456.78 * (inA_im[i]+1) / denom;
		}
		checkResult( manager.getOutputDataRaw("t_flt_divAsRHS_d"), flt_cplx_type, re, im, "flt divAsRHS dbl" );

		for ( int i = 0 ; i < len ; i++ ) {
			double denom = (inA_re[i] + 1)*(inA_re[i] + 1) + (inA_im[i] + 1)*(inA_im[i] + 1);
			re[i] =  inB_re[i] * (inA_re[i]+1) / denom;
			im[i] = -inB_re[i] * (inA_im[i]+1) / denom;
		}
		checkResult( manager.getOutputDataRaw("t_var_divAsRHS"), flt_cplx_type, re, im, "var divAsRHS" );

		//---------------------------------------- divAsLHS tests
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] / 3;
			im[i] = inA_im[i] / 3;
		}
		checkResult( manager.getOutputDataRaw("t_flt_divAsLHS"), flt_cplx_type, re, im, "flt divAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = Math.round(inA_re[i] / 3);
			im[i] = Math.round(inA_im[i] / 3);
		}
		checkResult( manager.getOutputDataRaw("t_int_divAsLHS"), int_cplx_type, re, im, "int divAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] / 3;
			im[i] = Math.round(inA_im[i] / 3);
		}
		checkResult( manager.getOutputDataRaw("t_mix_divAsLHS"), mix_cplx_type, re, im, "mix divAsLHS" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_re[i] / inB_re[i];
			im[i] = inA_im[i] / inB_re[i];
		}
		checkResult( manager.getOutputDataRaw("t_var_divAsLHS"), flt_cplx_type, re, im, "var divAsLHS" );

		//---------------------------------------- div complex/complex
		for ( int i = 0 ; i < len ; i++ ) {
			double denom = (inB_re[i] + 1)*(inB_re[i] + 1) + (inB_im[i] + 1)*(inB_im[i] + 1);
			re[i] =  (inA_re[i]*(inB_re[i]+1) + inA_im[i]*(inB_im[i]+1)) / denom;
			im[i] =  (inA_im[i]*(inB_re[i]+1) - inA_re[i]*(inB_im[i]+1)) / denom;
		}
		checkResult( manager.getOutputDataRaw("t_flt_div"), flt_cplx_type, re, im, "flt div" );

		//---------------------------------------- rotate in 90 degree steps
		double old_thresh = err_threshold;
		err_threshold = 1.e-10;

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = (inA_re[i] * Math.cos(inAngle90[i] * (Math.PI/2.0))) - (inA_im[i] * Math.sin(inAngle90[i] * (Math.PI/2.0)));
			im[i] = (inA_re[i] * Math.sin(inAngle90[i] * (Math.PI/2.0))) + (inA_im[i] * Math.cos(inAngle90[i] * (Math.PI/2.0)));
		}
		checkResult( manager.getOutputDataRaw("t_flt_rot90"), flt_cplx_type, re, im, "flt rot90" );

		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = Math.round((Math.round(inA_re[i]) * Math.cos(inAngle90[i] * (Math.PI/2.0))) - (Math.round(inA_im[i]) * Math.sin(inAngle90[i] * (Math.PI/2.0))));
			im[i] = Math.round((Math.round(inA_re[i]) * Math.sin(inAngle90[i] * (Math.PI/2.0))) + (Math.round(inA_im[i]) * Math.cos(inAngle90[i] * (Math.PI/2.0))));
		}
		checkResult( manager.getOutputDataRaw("t_int_rot90"), int_cplx_type, re, im, "int rot90" );

		//----------------------------------------
		System.out.println( "     ***** Reached here, so everything passed! *****" );
		System.exit(0);

		err_threshold = old_thresh;
	}

	//----------------------------------------------------------------------------------------------------

	private static double  err_threshold = 1.e-14;
	private static final boolean full_printout = true;

	/**
	 * compares all the simulation results against required values, and throws an exception if they don't match.
	 * @param output is the simulation output
	 * @param cplx_type is the type of the simulation output
	 * @param re are the real components of the required values
	 * @param im are the imaginary components of the required values
	 * @param name is the name of the test
	 */
	@edu.umd.cs.findbugs.annotations.SuppressWarnings("UCF_USELESS_CONTROL_FLOW_NEXT_LINE")
	private static void checkResult( List<Bits> output, DFEComplexType cplx_type, double[] re, double[] im, String name )
	{
		System.out.println( "    Test: " + name );
		for ( int i = 0 ; i < output.size() ; i++ ) {
			DFEComplexType.ConstantValue  sim = cplx_type.decodeConstant( output.get(i) );
			boolean isOK   = isWithinThreshold(sim.getReal(),re[i]) && isWithinThreshold(sim.getImaginary(),im[i]);
			String  status = isOK ? "pass" : "fail";
			if ( !isOK || full_printout )
				System.out.println( i + ":  " + status + " :   Simulation = " + sim + ",  \t required = { " + re[i] + ", " + im[i] + " }" );
			if ( !isOK )
				throw new RuntimeException( "Test failed" );
		}
	}

	/**
	 * compares a single simulation result against required value, and throws an exception if it doesn't match.
	 * @param output is the simulation output
	 * @param cplx_type is the type of the simulation output
	 * @param re is the real component of the required value
	 * @param im is the imaginary component of the required value
	 * @param name is the name of the test
	 */
	@edu.umd.cs.findbugs.annotations.SuppressWarnings("UCF_USELESS_CONTROL_FLOW_NEXT_LINE")
	private static void checkResult( int i, List<Bits> output, DFEComplexType cplx_type, double re, double im, String name )
	{
		if ( i == 0 )
			System.out.println( "    Test: " + name );
		DFEComplexType.ConstantValue  sim = cplx_type.decodeConstant( output.get(i) );
		boolean isOK   = isWithinThreshold(sim.getReal(),re) && isWithinThreshold(sim.getImaginary(),im);
		String  status = isOK ? "pass" : "fail";
		if ( !isOK || full_printout )
			System.out.println( i + ":  " + status + " :   Simulation = " + sim + ",  \t required = { " + re + ", " + im + " }" );
		if ( !isOK )
			throw new RuntimeException( "Test failed" );
	}

	/**
	 * checks whether two values are within a given threshold of each other
	 * @param v1 is the first value, e.g. as returned by the simulator
	 * @param v2 is the second value, e.g. as calculated as the required value
	 * @return true = values match to within threshold; false = values differ
	 */
	private static boolean isWithinThreshold( double v1, double v2 ) {
		boolean isOK = true;
		if ( Math.abs(v1) > err_threshold )
			isOK = Math.abs((v2 - v1) / v1) < err_threshold;
		else if ( Math.abs(v2) > err_threshold )
			isOK = Math.abs((v2 - v1) / v2) < err_threshold;

		if (!isOK)
			System.out.println( "    threshold test failed comparing  " + v1 + "  vs  " + v2 );
		return isOK;
	}

	/**
	 * initialize an array with random values with the range 0 to 100.
	 * @param len is the length of the array
	 * @return the array of random values
	 */
	private static double[] initToRandom( int len ) {
		double[] arr = new double[len];
		for ( int i = 0 ; i < len ; i++ )
			arr[i] = m_random.nextDouble() * 100.0;
		return arr;
	}

	/**
	 * encodes arrays of real and imaginary values into a Bits List, ready for sending to simulator.
	 * @param ktype is the complex type to be encoded
	 * @param re is the array of real components
	 * @param im is the array of imaginary components
	 * @return is the encoded List of values
	 */
	private static ArrayList<Bits> encodeValues( DFEComplexType ktype, double[] re, double[] im ) {
		ArrayList<Bits> encoded = new ArrayList<Bits>();
		for ( int i = 0 ; i < re.length ; i++ ) {
			Bits bits;
			try {
				bits = ktype.encodeConstant( re[i], im[i] );
			}
			catch (MaxConstantEncodingException e) {
				bits = e.getPackedValue();
			}

			encoded.add( bits );
		}
		return encoded;
	}

}
