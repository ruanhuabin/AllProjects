package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;

public class _Control extends Control {

	public _Control(Kernel design) {
		super(design);
	}

}
