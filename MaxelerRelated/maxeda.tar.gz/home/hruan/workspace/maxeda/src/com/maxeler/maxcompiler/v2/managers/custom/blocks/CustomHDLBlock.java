package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.CustomHDLNode.CustomNodeClock;

public class CustomHDLBlock implements ManagerBlock {

	private final CustomHDLNode m_node;

	CustomHDLBlock(CustomHDLNode node) {
		m_node = node;
	}

	public DFELink getInput(String name) {
		return _CustomManagers.fromImp(m_node.getImpl().getInput(name));
	}

	public DFELink getOutput(String name) {
		return _CustomManagers.fromImp(m_node.getImpl().getOutput(name));
	}

	public void setClock(CustomNodeClock clock, ManagerClock mgr_clock) {
		m_node.getImpl().setClock(clock, mgr_clock);
	}

	@Override
	public void setClock(ManagerClock clock) {
		throw new MaxCompilerAPIError("Use setClock(CustomNodeClock clock, ManagerClock mgr_clock) for custom VHDL nodes.");
	}
}
