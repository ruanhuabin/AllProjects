package com.maxeler.maxcompiler.v2.kernelcompiler.tests;
import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortParams;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamWriteMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.MAXBoardModel;
import com.maxeler.maxcompiler.v2.managers.custom.CustomManager;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.KernelBlock;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.MathUtils;

public class MappedRAMFlushTest extends Kernel {
	private static final DFEType s_dataType = dfeUInt(32);
	private static final int s_ramDepth = 24;

	public MappedRAMFlushTest(KernelParameters parameters, boolean withCounter) {
		super(parameters);

		// overwrite the mapped RAM data with odd values
		DFEVar ramDataIn;
		if (withCounter)
			ramDataIn = 2 * (control.count.simpleCounter(s_dataType.getTotalBits()) + 1) + 1;
		else
			ramDataIn = io.input("data_in", s_dataType, constant.var(true));

		DFEVar address = control.count.simpleCounter(MathUtils.bitsToAddress(s_ramDepth), s_ramDepth);

		RamPortParams<DFEVar> port = mem.makeRamPortParams(RamPortMode.READ_WRITE, address, ramDataIn);
		port = port.withWriteEnable(constant.var(true));
		DFEVar data = mem.ramMapped("data", 24, RamWriteMode.READ_FIRST, port);

		io.output("data_out", data, s_dataType);
	}

	private static void simulate(boolean withCounter) {
		String buildName = MappedRAMFlushTest.class.getSimpleName() + (withCounter ? "_counter" : "_input") + "_sim";
		_DualSimulationManager sim = new _DualSimulationManager(buildName);
		sim.setKernels(
				new MappedRAMFlushTest(sim.makeKernelParameters_A(), withCounter),
				new MappedRAMFlushTest(sim.makeKernelParameters_B(), withCounter)
		);
		sim.build();

		// fill the mapped RAM with even values
		double[] mappedRAMData = new double[s_ramDepth];
		for (int i = 0; i < mappedRAMData.length; ++i)
			mappedRAMData[i] = 2 * (i + 1);

		// if we're using an input, feed in odd values
		if (!withCounter) {
			double[] data = new double[s_ramDepth];
			for (int i = 0; i < data.length; ++i)
				data[i] = 2 * (i + 1) + 1;
			sim.setInputData("data_in", data);
		}

		sim.setMappedRam("data", mappedRAMData);
		sim.setKernelCycles(s_ramDepth);
		sim.run();

		// the mapped RAM should now contain odd values
		for (int i = 0; i < s_ramDepth; ++i) {
			double e = 2 * (i + 1) + 1;
			double v = sim.getMappedRam("data", i);

			if (v != e)
				throw new AssertionError("Mapped RAM data @ " + i + " is " + v + ", not " + e + ".");
		}

		// the output data should contain the previous values of the mapped RAM,
		// i.e. even values
		double[] dataOut = sim.getOutputDataArray("data_out");
		if (dataOut.length != s_ramDepth)
			throw new AssertionError("Expected " + s_ramDepth + " of output data, got " + dataOut.length + ".");
		for (int i = 0; i < dataOut.length; ++i) {
			if (dataOut[i] != mappedRAMData[i])
				throw new AssertionError("Incorrect output data @ " + i + ": wanted " + mappedRAMData[i] + ", got " + dataOut[i] + ".");
		}
	}

	private static void buildHardware(boolean forSimulation, boolean withCounter) {
		String buildName = MappedRAMFlushTest.class.getSimpleName() + (withCounter ? "_counter" : "_input");
		if (forSimulation)
			buildName += "_hostsim";
		else
			buildName += "_hw";

		TestManager manager = new TestManager(forSimulation, MAX2BoardModel.MAX24412C, buildName);
		manager.setKernel(new MappedRAMFlushTest(manager.makeKernelParameters(MappedRAMFlushTest.class.getSimpleName()), withCounter));
		manager.build();
	}

	private static class TestManager extends CustomManager {
		public TestManager(boolean generate_max_file_for_simulation, MAXBoardModel board_model, String name) {
			super(new _EngineParameters(name, board_model, generate_max_file_for_simulation ? EngineParameters.Target.MAXFILE_FOR_SIMULATION : EngineParameters.Target.MAXFILE_FOR_HARDWARE));
		}

		public void setKernel(Kernel kernel) {
			KernelBlock kernelBlock = addKernel(kernel);

			// connect kernel inputs to PCIe
			for (String inputName : kernelBlock.getAllInputs())
				kernelBlock.getInput(inputName).connect(addStreamFromCPU(inputName));

			// connect kernel outputs to PCIe
			for (String outputName : kernelBlock.getAllOutputs())
				addStreamToCPU(outputName).connect(kernelBlock.getOutput(outputName));
		}
	}

	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("Usage: " + MappedRAMFlushTest.class.getSimpleName() + " simulate|hardware|hostsim counter|input");
			System.exit(1);
		}

		boolean simulate = args[0].equals("simulate");
		boolean withCounter = args[1].equals("counter");

		if (simulate)
			simulate(withCounter);
		else {
			boolean hardware = args[0].equals("hardware");
			buildHardware(!hardware, withCounter);
		}
	}

}
