package com.maxeler.maxcompiler.v2.kernelcompiler;

/**
 * Arithmetic rounding modes.
 */
public enum RoundingMode {
	/**
	 * Remove the least significant bits. This is equivalent to rounding towards
	 * negative infinity.
	 * <p>
	 * This is the least accurate method of rounding but also uses the fewest
	 * hardware resources.
	 */
	TRUNCATE,
	TONEAR,
	TONEAREVEN;
}
