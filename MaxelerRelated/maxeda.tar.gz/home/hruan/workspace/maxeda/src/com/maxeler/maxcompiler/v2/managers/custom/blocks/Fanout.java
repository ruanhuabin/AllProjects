package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import java.util.LinkedHashMap;
import java.util.Map;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;

public class Fanout implements ManagerBlock {
	com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeFanout m_imp;

	private final Map<String, Integer> m_outputs =
		new LinkedHashMap<String, Integer>();
	private int m_sel_count = 0;
	private static final int m_max_outputs = 8;

	Fanout(com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeFanout fanout) {
		m_imp = fanout;
	};

	public DFELink addOutput(String name) {
		if (m_outputs.containsKey(name)) {
			throw new MaxCompilerAPIError("Tried to add output with duplicate name '" + name + "'");
		}
		int sel = m_sel_count;
		if (sel >= m_max_outputs)
			throw new MaxCompilerAPIError("Fanout block output limit of " + m_max_outputs + " exceeded.");
		m_sel_count++;
		m_outputs.put(name, sel);
		return _CustomManagers.fromImp(m_imp.addOutput(name, sel));
	}

	public DFELink getInput() {
		return _CustomManagers.fromImp(m_imp.getInput());
	}

	@Override
	public void setClock(ManagerClock clock) {
		m_imp.setClock(_CustomManagers.managerClockToImp(clock));
	}

	public void setWidth(int bitwidth) {
		m_imp.setBitWidth(bitwidth);
	}
}
