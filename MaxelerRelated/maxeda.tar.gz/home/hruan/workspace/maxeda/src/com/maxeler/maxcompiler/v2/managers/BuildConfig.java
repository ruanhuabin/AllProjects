package com.maxeler.maxcompiler.v2.managers;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2._MaxCompiler;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.BuildPass;
import com.maxeler.maxdc.GenerateMaxFile;
import com.maxeler.maxdc.GenerateMaxFileDataFile;
import com.maxeler.maxdc.xilinx.BuildFileUCF;
import com.maxeler.maxdc.xilinx.ChipscopeInserter;
import com.maxeler.maxdc.xilinx.MPPR;
import com.maxeler.maxdc.xilinx.Mapper;
import com.maxeler.maxdc.xilinx.NGCBuild;
import com.maxeler.maxdc.xilinx.NGDBuild;
import com.maxeler.maxdc.xilinx.PAR;
import com.maxeler.maxdc.xilinx.ResourceCounter;
import com.maxeler.maxdc.xilinx.TimingAnalysis;
import com.maxeler.maxdc.xilinx.XDLBuild;
import com.maxeler.maxdc.xilinx.XDLBuild.Conversion;
import com.maxeler.maxdc.xilinx.XST;
import com.maxeler.maxdc.xilinx.XilinxBuildPass;
import com.maxeler.maxdc.xilinx.XilinxBuildPass.EffortLevel;
import com.maxeler.maxdc.xilinx.XilinxBuildPass.ExtraEffortLevel;
import com.maxeler.maxdc.xilinx.edif_parsing.EDIF2MxruBuildPass;
import com.maxeler.maxdc.xilinx.mxru.ResourceUsageBuildPass;
import com.maxeler.photon.core.PreliminaryResourceAnnotationBuildPass;
import com.maxeler.photon.core.ResourceAnnotationBuildPass;

public class BuildConfig {
	public enum Level {
		// ordering of these is important
		COMPILE_ONLY,
		SYNTHESIS,
		MAP,
		PAR,
		FULL_BUILD
	}

	public enum Effort {
		LOW       (XilinxBuildPass.EffortLevel.Std,  XilinxBuildPass.ExtraEffortLevel.None),
		MEDIUM    (XilinxBuildPass.EffortLevel.High, XilinxBuildPass.ExtraEffortLevel.None),
		HIGH      (XilinxBuildPass.EffortLevel.High, XilinxBuildPass.ExtraEffortLevel.Normal),
		VERY_HIGH (XilinxBuildPass.EffortLevel.High, XilinxBuildPass.ExtraEffortLevel.Continue);

		private final EffortLevel effort_level;
		private final ExtraEffortLevel extra_effort_level;

		private Effort(
			XilinxBuildPass.EffortLevel effort0,
			XilinxBuildPass.ExtraEffortLevel effort1)
		{
			effort_level = effort0;
			extra_effort_level = effort1;
		}
	}

	private static final int DEFAULT_MPPR_PARALLELISM_NO_CLUSTER = 1;
	private static final int DEFAULT_MPPR_PARALLELISM_WITH_CLUSTER = 6;

	private Level m_level;
	private boolean m_enable_timing_analysis = true;
	boolean m_enable_chipscope_inserter = false;
	private Integer m_mppr_parallelism = null;
	private Effort m_build_effort = Effort.MEDIUM;
	private Integer m_mppr_ct_min = null;
	private Integer m_mppr_ct_max = null;
	private boolean m_mppr_continue_after_meeting_timing = false;
	boolean m_physical_synthesis = false;
	protected List<BuildFileUCF> m_external_ucf_files = new ArrayList<BuildFileUCF>();

	private int m_mppr_retry_near_misses_threshold = 0;

	/** Special configuration option to prevent generation of max file when being run from no I/O manager */
	private boolean m_enable_gen_maxfile = true;

	void setEnableGenMaxFile(boolean v) {
		m_enable_gen_maxfile = v;
	}

	public BuildConfig(Level level) {
		m_level = level;
	}

	/**
	 * Set threshold under which MPPR cost tables will be judged as having
	 * come close to meeting timing will be re-run at maximum effort.
	 * This defaults to 0 (retry near misses OFF). By setting it to a value >= 0
	 * any cost tables that are run at less than maximum effort and finish with
	 * a timing score below that threshold will be automatically re-run as part of the
	 * MPPR.
	 * @param threshold Timing score threshold in picoseconds
	 */
	public void setMPPRRetryNearMissesThreshold (int threshold) {
		if (threshold < 0) throw new MaxCompilerAPIError("You can not set an MPPR near miss retry threshold of " + threshold + ", threshold must be greater than zero (or zero for off).");
		m_mppr_retry_near_misses_threshold = threshold;
	}

	/**
	 * Return MPPR retry-on-near-miss threshold. If zero the retry feature is disabled.
	 * @return Timing score threshold in picoseconds
	 */
	public int getMPPRRetryNearMissesThreshold() {
		return m_mppr_retry_near_misses_threshold;
	}

	public void setBuildLevel(Level level) {
		m_level = level;
	}

	public Level getBuildLevel() {
		return m_level;
	}

	public void setBuildEffort(Effort effort) {
		m_build_effort = effort;
	}

	public void setEnableTimingAnalysis(boolean v) {
		m_enable_timing_analysis = v;
	}

	public void setMPPRParallelism(int p) {
		m_mppr_parallelism = p;
	}

	public void setMPPRContinueAfterMeetingTiming(boolean v) {
		m_mppr_continue_after_meeting_timing = v;
	}

	public void setMPPRCostTableSearchRange(int min, int max) {
		if (min < 1 | max > 100)
			throw new MaxCompilerAPIError("MPPR only supports cost tables 1-100. You can not set MPPR cost table range of " + min + "-"+ max + ".");
		m_mppr_ct_min = min;
		m_mppr_ct_max = max;
	}

	List<BuildPass> getBuildPasses(BuildManager bm) {
		if(m_level == Level.FULL_BUILD) {
			if (m_mppr_parallelism == null)
				m_mppr_parallelism = 1;
			if (m_mppr_ct_min == null) {
				m_mppr_ct_min = 1;
				m_mppr_ct_max = 1;
			}
		}

		List<BuildPass> passes = new ArrayList<BuildPass>();

		passes.add(new GenerateMaxFileDataFile());

		if(m_level.ordinal() > Level.COMPILE_ONLY.ordinal()) {
			passes.add(new XST());
			passes.add(new NGCBuild());
			passes.add(new EDIF2MxruBuildPass());
			passes.add(new PreliminaryResourceAnnotationBuildPass("src_annotated_preliminary"));
			if(m_enable_chipscope_inserter)
				passes.add(new ChipscopeInserter());
			passes.add(new ResourceCounter());
		}

		if(m_level.ordinal() >= Level.SYNTHESIS.ordinal()) {
			NGDBuild ngd = new NGDBuild();
			for(BuildFileUCF external_ucf_file : m_external_ucf_files)
				ngd.includeExternalUCF(external_ucf_file);
			passes.add(ngd);
		}

		if(m_level == Level.FULL_BUILD &&
		   !(_MaxCompiler.isUsingMaxCompilerRunner() && !bm.isRestartedBuild() && bm.getMostRecentMXRUFile() == null) )
		{
			int parallelism;

			if(m_mppr_parallelism != null)
				parallelism = m_mppr_parallelism;
			else {
				if(bm.usingCluster())
					parallelism = DEFAULT_MPPR_PARALLELISM_WITH_CLUSTER;
				else
					parallelism = DEFAULT_MPPR_PARALLELISM_NO_CLUSTER;
			}

			MPPR mppr = new MPPR(parallelism);
			mppr.setDoTimingAnalysis(m_enable_timing_analysis);
			mppr.setEffort(m_build_effort.effort_level);
			mppr.setExtraEffort(m_build_effort.extra_effort_level);
			mppr.setContinueAfterMeetingTiming(m_mppr_continue_after_meeting_timing);
			mppr.setMapRegisterDuplication(m_physical_synthesis);
			if(m_mppr_ct_max != null)
				mppr.setCostTableSearchRange(m_mppr_ct_min, m_mppr_ct_max);

			if (m_mppr_retry_near_misses_threshold > 0) {
				mppr.setRetryNearMisses(true);
				mppr.setRetryNearMissesThreshold(m_mppr_retry_near_misses_threshold);
			}

			passes.add(mppr);

		} else if(m_level.ordinal() >= Level.MAP.ordinal()) {
			Mapper mapper = new Mapper();
			mapper.setEffort(m_build_effort.effort_level);
			mapper.setExtraEffort(m_build_effort.extra_effort_level);
			passes.add(mapper);

			if(m_level.ordinal() >= Level.PAR.ordinal()) {
				PAR par = new PAR();
				par.setEffort(m_build_effort.effort_level);
				par.setExtraEffort(m_build_effort.extra_effort_level);
				passes.add(par);
				if(m_enable_timing_analysis)
					passes.add(new TimingAnalysis(bm));
			}
		}

		// annotate source code with resource usage
		if(m_level.ordinal() >= Level.MAP.ordinal()) {
			passes.add(new XDLBuild(Conversion.NCD2XDL));
			passes.add(new ResourceUsageBuildPass());
			passes.add(new ResourceAnnotationBuildPass("src_annotated"));
		}

		if(m_level.ordinal() >= Level.FULL_BUILD.ordinal() && m_enable_gen_maxfile)
			passes.add(new GenerateMaxFile());

		return passes;
	}
}
