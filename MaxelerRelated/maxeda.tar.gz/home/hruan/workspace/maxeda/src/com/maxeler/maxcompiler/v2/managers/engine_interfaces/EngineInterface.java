package com.maxeler.maxcompiler.v2.managers.engine_interfaces;

import com.maxeler.utils.MaxCompilerHide;



public class EngineInterface {

	/**
	 * A Direction is used as an argument to some EngineInterface calls,
	 * namely {@link ignoreAll} and {@link ignoreMem},
	 * to control whether the parameters affected are input parameters,
	 * or output parameters, or both.
	 * <p>
	 * This argument is only required where there would be ambiguity.
	 * For example, scalar parameters are defined at their creation time as either
	 * input or output parameters; however, mapped memory rams may be used for both
	 * input and output, and so the call to {@link ignoreMem} takes an extra Direction argument.
	 */
	public static enum Direction {
		/** Input parameters only */
		IN,
		/** Output parameters only */
		OUT,
		/** Both input and output parameters */
		IN_OUT;
	};

	private final com.maxeler.maxeleros.managercompiler.software.modeinfo.EngineMode m_impl;

	/**
	 * Instantiate an EngineInterface
	 * @param name name of the interface
	 * @param doc brief documentation for the interface
	 */
	public EngineInterface(String name, String doc)
	{
		m_impl = new com.maxeler.maxeleros.managercompiler.software.modeinfo.EngineMode(name, doc);
	}

	/**
	 * Instantiate an EngineInterface
	 * @param name name of the interface
	 */
	public EngineInterface(String name)
	{
		this(name, null);
	}

	/**
	 * Instantiate an EngineInterface
	 */
	public EngineInterface()
	{
		this("default");
	}

	@MaxCompilerHide
	public EngineInterface(com.maxeler.maxeleros.managercompiler.software.modeinfo.EngineMode impl)
	{
		m_impl = impl;
	}

	@MaxCompilerHide
	public com.maxeler.maxeleros.managercompiler.software.modeinfo.EngineMode getImplementation()
	{
		return m_impl;
	}


	/**
	 * Indicate that elements that elements not explicitly referred to
	 * in the interface should not be visible in the generated SLiC code.
	 * @param flag see {@link Direction}: controls whether to suppress
	 * input parameters, or output parameters, or both.
	 */
	public void ignoreAll( Direction flag ) {
		if (flag == Direction.IN_OUT || flag == Direction.IN)
			m_impl.disableOmittedParams();

		if (flag == Direction.IN_OUT || flag == Direction.OUT)
			m_impl.markAllUnused();
	}

	/**
	 * Indicate that elements that are not explicitly set in the interface,
	 * should not be visible in the generated SLiC code.
	 * @deprecated use ignoreAll(Direction.IN_OUT)
	 */
	@Deprecated
	public void ignoreUnset() {
		ignoreAll( Direction.IN_OUT );
	}

	/**
	 * Indicate that a mapped memory should not be visible in the generated SLiC code.
	 * @param blockName name of the block to which the mapped memory belongs
	 * @param memName name of the mapped memory
	 * @param flag whether to ignore the input memory, output memory, or both
	 */
	public void ignoreMem(String blockName, String memName, Direction flag) {
		if (flag == Direction.IN_OUT || flag == Direction.IN)
			m_impl.disableMappedMemoryInput(blockName, memName);

		if (flag == Direction.IN_OUT || flag == Direction.OUT)
			m_impl.disableMappedMemoryOutput(blockName, memName);
	}


	/**
	 * Indicate that a mapped memory should not be visible in the generated SLiC code.
	 * @param blockName name of the block to which the mapped memory belongs
	 * @param memName name of the mapped memory
	 * @deprecated use ignoreMem(blockName, memName, Direction.IN_OUT)
	 */
	@Deprecated
	public void ignoreMem(String blockName, String memName) {
		ignoreMem(blockName, memName, Direction.IN_OUT);
	}

	/**
	 * Indicate that a mapped memory input should not be visible in the generated SLiC code.
	 * @param blockName name of the block to which the mapped memory belongs
	 * @param memName name of the mapped memory
	 * @deprecated use ignoreMem(blockName, memName, Direction.IN)
	 */
	@Deprecated
	public void ignoreMemInput(String blockName, String memName) {
		ignoreMem(blockName, memName, Direction.IN);
	}

	/**
	 * Indicate that a mapped memory output should not be visible in the generated SLiC code.
	 * @param blockName name of the block to which the mapped memory belongs
	 * @param memName name of the mapped memory
	 * @deprecated use ignoreMem(blockName, memName, Direction.OUT)
	 */
	@Deprecated
	public void ignoreMemOutput(String blockName, String memName) {
		ignoreMem(blockName, memName, Direction.OUT);
		m_impl.disableMappedMemoryOutput(blockName, memName);
	}

	/**
	 * Indicate that an output mapped memory should be visible in
	 * the generated SLiC code; this can be used to re-enable output
	 * rams that have been disabled via a call to {@link ignoreAll}.
	 * @param blockName name of the block to which the mapped memory belongs
	 * @param memName name of the mapped memory
	 */
	public void unignoreMem(String blockName, String memName) {
		m_impl.enableMappedMemoryOutput(blockName, memName);
	}

	/**
	 * Indicate that a DRAM should not be visible in the generated SLiC code.
	 * @param streamName name of the DRAM
	 */
	public void ignoreDram(String streamName) {
		m_impl.disableDram(streamName);
	}

	/**
	 * Indicate that a scalar parameter should not be visible in
	 * the generated SLiC code.
	 * @param blockName name of the block to which the scalar parameter belongs
	 * @param scalarName name of the scalar parameter
	 */
	public void ignoreScalar(String blockName, String scalarName) {
		m_impl.disableScalar(blockName, scalarName);
	}

	/**
	 * Indicate that an output scalar parameter should be visible in
	 * the generated SLiC code; this can be used to re-enable output scalars
	 * that have been disabled via a call to {@link ignoreAll}.
	 * @param blockName name of the block to which the scalar parameter belongs.
	 * @param scalarName name of the scalar parameter.
	 */
	public void unignoreScalar(String blockName, String scalarName) {
		m_impl.enableScalarOutput(blockName, scalarName);
	}

	/**
	 * Indicate that an offset should not be visible in the generated SLiC code.
	 * @param blockName name of the block to which the offset belongs
	 * @param offsetName name of the offset
	 */
	public void ignoreOffset(String blockName, String offsetName) {
		m_impl.disableScalar(blockName, offsetName);
	}

	/**
	 * Indicate that a stream should not be visible in the generated SLiC code.
	 * @param streamName name of the stream
	 */
	public void ignoreStream(String streamName) {
		m_impl.disableStream(streamName);
	}

	/**
	 * Indicate that no element of a kernel should be visible in the generated SLiC code.
	 * @param kernelName name of the kernel
	 */
	public void ignoreKernel(String kernelName) {
		m_impl.disableKernel(kernelName);
	}


	/**
	 * Add an interface parameter.
	 * The generated SLiC interface will allow users to set the value of used parameters at runtime.
	 * @param name name of the parameter
	 * @param type CPU type of the parameter
	 * @param doc brief documentation of the parameter
	 * @return a parameter instance
	 */
	public InterfaceParam addParam(String name, CPUTypes type, String doc)
	{
		return new InterfaceParam( m_impl.addParam(name, CPUTypes.toMaxelerOS(type), doc ));
	}

	/**
	 * Add an interface parameter.
	 * The generated SLiC interface will allow users to set the value of used parameters at runtime.
	 * @param name name of the parameter
	 * @param type CPU type of the parameter
	 * @return a parameter instance
	 */
	public InterfaceParam addParam(String name, CPUTypes type)
	{
		return addParam(name, type, null);
	}

	/**
	 * Add an interface parameter array.
	 * The generated SLiC interface will allow users to set the value of parameter array elements at runtime.
	 * @param name name of the parameter array
	 * @param type CPU type of the parameter array elements
	 * @param doc brief documentation of the parameter
	 * @return a parameter array instance
	 */
	public InterfaceParamArray addParamArray( String name, CPUTypes type, String doc )
	{
		return new InterfaceParamArray( m_impl.addParamArray(name, CPUTypes.toMaxelerOS(type), doc ) );
	}

	/**
	 * Add an interface parameter array.
	 * The generated SLiC interface will allow users to set the value of parameter array elements at runtime.
	 * @param name name of the parameter array
	 * @param type CPU type of the parameter array elements
	 * @return a parameter array instance
	 */
	public InterfaceParamArray addParamArray( String name, CPUTypes type )
	{
		return addParamArray( name, type, null );
	}

	/**
	 * Add a constant interface parameter of type long
	 * @param value value of the parameter
	 * @return a parameter instance
	 */
	public InterfaceParam addConstant(long value)
	{
		return new InterfaceParam( m_impl.addConstant(value) );
	}

	/**
	 * Add a constant interface parameter of type double
	 * @param value value of the parameter
	 * @return a parameter instance
	 */
	public InterfaceParam addConstant(double value)
	{
		return new InterfaceParam( m_impl.addConstant(value) );
	}


	/**
	 * Get the value of an Auto-Offset Loop
	 * @param kernelName the name of the kernel that the loop belongs to
	 * @param name the name of the auto-offset-loop
	 * @return a parameter instance, which will be of type INT32
	 */
	public InterfaceParam getAutoLoopOffset(String kernelName, String name)
	{
		return new InterfaceParam( m_impl.getAutoLoopOffset(kernelName, name) );
	}

	/**
	 * Get the value of an Auto-Offset Loop
	 * @param kernelName the name of the kernel that the loop belongs to
	 * @param name the name of the auto-offset-loop
	 * @param type the type of the interface parameter to be created
	 * @return a parameter instance
	 * @deprecated Replaced by {@link #getAutoLoopOffset(String, String)}.
	 */
	@Deprecated
	public InterfaceParam getAutoLoopOffset(String kernelName, String name, CPUTypes type)
	{
		return new InterfaceParam( m_impl.getAutoLoopOffset(kernelName, name, CPUTypes.toMaxelerOS(type)) );
	}

	/**
	 * Indicate that an auto-loop offset should not be visible in the generated SLiC code.
	 * @param kernelName name of the kernel to which the auto-loop offset belongs
	 * @param name name of the offset
	 */
	public void ignoreAutoLoopOffset(String kernelName, String name)
	{
		m_impl.disableAutoLoopOffset(kernelName, name);
	}

	/**
	 * Indicate that an auto-loop offset should be visible in the
	 * generated SLiC code; this can be used to re-enable auto-offset loops
	 * that have been disabled via a call to {@link ignoreAll}.
	 * @param kernelName name of the kernel to which the auto-loop offset belongs
	 * @param name name of the offset
	 */
	public void unignoreAutoLoopOffset(String kernelName, String name)
	{
		m_impl.enableAutoLoopOffset(kernelName, name);
	}


	/**
	 * Get a distance measurement
	 * @param kernelName the name of the kernel that the loop belongs to
	 * @param name the name of the loop
	 * @return a parameter instance, which will be of type INT32
	 */
	public InterfaceParam getDistanceMeasurement(String kernelName, String name)
	{
		return new InterfaceParam( m_impl.getDistanceMeasurement(kernelName, name) );
	}


	/**
	 * Get a distance measurement
	 * @param kernelName the name of the kernel that the loop belongs to
	 * @param name the name of the loop
	 * @param type the type of the interface parameter to be created
	 * @return a parameter instance
	 * @deprecated Replaced by {@link #getDistanceMeasurement(String, String)}.
	 */
	@Deprecated
	public InterfaceParam getDistanceMeasurement(String kernelName, String name, CPUTypes type)
	{
		return new InterfaceParam( m_impl.getDistanceMeasurement(kernelName, name, CPUTypes.toMaxelerOS(type)) );
	}

	/**
	 * Indicate that an distance measurement should not be visible in the generated SLiC code.
	 * @param kernelName name of the kernel to which the distance measurement belongs
	 * @param name name of the offset
	 */
	public void ignoreDistanceMeasurement(String kernelName, String name)
	{
		m_impl.disableDistanceMeasurement(kernelName, name);
	}

	/**
	 * Indicate that a distance measurement should be visible in the
	 * generated SLiC code; this can be used to re-enable distance measurements
	 * that have been disabled via a call to {@link ignoreAll}.
	 * @param kernelName name of the kernel to which the distance measurement belongs
	 * @param name name of the offset
	 */
	public void unignoreDistanceMeasurement(String kernelName, String name)
	{
		m_impl.enableDistanceMeasurement(kernelName, name);
	}


	public String getName()
	{
		return m_impl.getName();
	}

	/**
	 * Set the number of ticks of a block
	 * @param blockName block being modified
	 * @param p number of ticks of the block
	 */
	public void setTicks(String blockName, InterfaceParam p)
	{
		m_impl.setTicks(blockName, p.getImpl());
	}

	/**
	 * Set the number of ticks of a block
	 * @param blockName block being modified
	 * @param p number of ticks of the block
	 */
	public void setTicks(String blockName, long p)
	{
		m_impl.setTicks(blockName, p);
	}

	/**
	 * Set the value of an input scalar parameter
	 * @param blockName block being modified
	 * @param scalarName name of the scalar parameter
	 * @param value value to assign
	 */
	public void setScalar(String blockName, String scalarName, long value)
	{
		m_impl.setScalar(blockName, scalarName, value);
	}

	/**
	 * Set the value of an input scalar parameter
	 * @param blockName block being modified
	 * @param scalarName name of the scalar parameter
	 * @param value value to assign
	 */
	public void setScalar(String blockName, String scalarName, double value)
	{
		m_impl.setScalar(blockName, scalarName, value);
	}

	/**
	 * Set the value of an input scalar parameter
	 * @param blockName block being modified
	 * @param scalarName name of the scalar parameter
	 * @param value value to assign
	 */
	public void setScalar(String blockName, String scalarName, InterfaceParam p)
	{
		m_impl.setScalar(blockName, scalarName, p.getImpl());
	}

	/**
	 * Set the properties of a stream
	 * @param streamName name of the stream
	 * @param type type of the elements of the stream
	 * @param p size of the stream in bytes
	 */
	public void setStream(String streamName, CPUTypes type, InterfaceParam p)
	{
		m_impl.setStream(streamName, CPUTypes.toMaxelerOS(type), p.getImpl());
	}

	public void setStream(String streamName, CPUTypes type, ArrayShape ds)
	{
		m_impl.setStream(streamName, CPUTypes.toMaxelerOS(type), ds.getImpl());
	}

	/**
	 * Set the properties of a stream
	 * @param streamName name of the stream
	 * @param type type of the elements of the stream
	 * @param p size of the stream in bytes
	 */
	public void setStream(String streamName, CPUTypes type, long p)
	{
 		m_impl.setStream(streamName, CPUTypes.toMaxelerOS(type), p);
	}

	/**
	 * Set the value of a stream offset
	 * @param blockName block being modified
	 * @param offsetName name of the stream offset
	 * @param p value to assign
	 */
	public void setOffset(String blockName, String offsetName, InterfaceParam p)
	{
		m_impl.setOffset(blockName, offsetName, p.getImpl());
	}

	/**
	 * Set the value of a stream offset
	 * @param blockName block being modified
	 * @param offsetName name of the stream offset
	 * @param p value to assign
	 */
	public void setOffset(String blockName, String offsetName, long p)
	{
		m_impl.setOffset(blockName, offsetName, p);
	}

	/**
	 * Set a memory stream to send an interrupt when it has finished streaming.
	 * @param streamName the name of the stream for which an interrupt is needed.
	 */
	public void setDramInterruptOn(String streamName) {
		m_impl.setDramInterruptOn(streamName);
	}

	/**
	 * Set a memory read or write, using the simple linear pattern.
	 * @param streamName the name of the memory stream
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory
	 * @param size the size, in bytes, of the array.  It must be
	 *        a multiple of the burst size (see {@link getBurstSize}).
	 */
	public void setDramLinear(String streamName, InterfaceParam address, InterfaceParam size) {
		m_impl.setDramLinear(streamName, address.getImpl(), size.getImpl());
	}

	/**
	 * Set a memory read or write, using the simple linear pattern.
	 * @param streamName the name of the memory stream
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory
	 * @param size the size, in bytes, of the array.  It must be
	 *        a multiple of the burst size (see {@link getBurstSize}).
	 */
	public void setDramLinear(String streamName, long address, long size) {
		m_impl.setDramLinear(streamName, address, size);
	}

	/**
	 * Set a memory read or write, using the linear pattern.
	 * @param streamName the name of the memory stream.
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory.
	 * @param arrSize the size, in bytes, of the array.
	 *        It must be a multiple of the burst size (see {@link getBurstSize}).
	 * @param rwSize the number of bytes to be read or written.
	 *        It must be a multiple of the burst size (see {@link getBurstSize}).
	 *        If the read or write operation reaches the end of the array
	 *        boundary within the DRAM (<b><code>address + arrSize</code></b>),
	 *        then it will wrap to the beginning of the array (<b><code>address</code></b>)
	 *        and continue reading or writing from there.
	 * @param offset the offset, in bytes, from <b><code>address</code></b> at which the
	 *        read or write operation will begin.
	 *        It must be a multiple of the burst size (see {@link getBurstSize}).
	 */
	public void setDramLinearWrapped(String streamName, InterfaceParam address, InterfaceParam arrSize, InterfaceParam rwSize, InterfaceParam offset) {
		m_impl.setDramLinearWrapped(streamName, address.getImpl(), arrSize.getImpl(), rwSize.getImpl(), offset.getImpl() );
	}

	/**
	 * Set a memory read or write, using the linear pattern.
	 * @param streamName the name of the memory stream.
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory.
	 * @param arrSize the size, in bytes, of the array.
	 *        It must be a multiple of the burst size (see {@link getBurstSize}).
	 * @param rwSize the number of bytes to be read or written.
	 *        It must be a multiple of the burst size (see {@link getBurstSize}).
	 *        If the read or write operation reaches the end of the array
	 *        boundary within the DRAM (<b><code>address + arrSize</code></b>),
	 *        then it will wrap to the beginning of the array (<b><code>address</code></b>)
	 *        and continue reading or writing from there.
	 * @param offset the offset, in bytes, from <b><code>address</code></b> at which the
	 *        read or write operation will begin.
	 *        It must be a multiple of the burst size (see {@link getBurstSize}).
	 */
	public void setDramLinearWrapped(String streamName, long address, long arrSize, long rwSize, long offset) {
		m_impl.setDramLinearWrapped(streamName, address, arrSize, rwSize, offset );
	}

	/**
	 * Set a memory read or write, using the simple stride pattern.
	 * @param streamName the name of the memory stream
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory
	 * @param sizeFast the size, in bytes, of the fast
	 *        dimension of the array
	 * @param sizeSlow the size of the slow dimension of the
	 *        array. This is expressed as a multiplier of the fast
	 *        dimension, array_size_fast
	 * @param strideMode stride_mode sets the dimension in which the data is
	 *        accessed: <br>
	 *        <b><tt>stride_mode=0</tt></b> sets linear access, and
	 *        the data is accessed in the fast dimension; <br>
	 *        <b><tt>stride_mode=1</tt></b> sets strided access, and
	 *        the data is accessed in the slow dimension.  Note that
	 *        the width of the data "stripe" in the slow dimension is
	 *        equal to the burst size in bytes
	 */
	public void setDramStrided(String streamName, InterfaceParam address, InterfaceParam sizeFast, InterfaceParam sizeSlow, InterfaceParam strideMode) {
		m_impl.setDramStrided(streamName, address.getImpl(), sizeFast.getImpl(), sizeSlow.getImpl(), strideMode.getImpl() );
	}

	/**
	 * Set a memory read or write, using the simple stride pattern.
	 * @param streamName the name of the memory stream
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory
	 * @param sizeFast the size, in bytes, of the fast
	 *        dimension of the array
	 * @param sizeSlow the size of the slow dimension of the
	 *        array. This is expressed as a multiplier of the fast
	 *        dimension, array_size_fast
	 * @param strideMode stride_mode sets the dimension in which the data is
	 *        accessed: <br>
	 *        <b><tt>stride_mode=0</tt></b> sets linear access, and
	 *        the data is accessed in the fast dimension; <br>
	 *        <b><tt>stride_mode=1</tt></b> sets strided access, and
	 *        the data is accessed in the slow dimension.  Note that
	 *        the width of the data "stripe" in the slow dimension is
	 *        equal to the burst size in bytes
	 */
	public void setDramStrided(String streamName, long address, long sizeFast, long sizeSlow, long strideMode) {
		m_impl.setDramStrided(streamName, address, sizeFast, sizeSlow, strideMode);
	}

	/**
	 * Set a memory read or write, using the blocked pattern
	 *
	 * Note that arguments are specified in bytes; these are converted to
	 * bursts internally.  If the arguments are not burst-aligned, this
	 * function will raise an error.
	 *
	 * @param streamName the name of the memory stream
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory
	 * @param arraySizeFast the size, in bytes, of the fast
	 *        dimension of the array
	 * @param arraySizeMed the size of the medium dimension of the
	 *        array. This is expressed as a multiplier of the fast
	 *        dimension, <code>array_size_fast</code>
	 * @param arraySizeSlow the size of the slow dimension of the
	 *        array. This is expressed as a multiplier of the other
	 *        two dimensions, <code>array_size_fast*array_size_med</code>
	 * @param rwSizeFast the read/write size, in bytes, of the
	 *        fast dimension of the array
	 * @param rwSizeMed the read/write size of the medium dimension
	 *        of the array
	 * @param rwSizeSlow the read/write size of the slow dimension
	 *        of the array
	 * @param offsetFast the offset, in bytes, of the fast dimension
	 *        of the beginning of the read/write block within the
	 *        full array block
	 * @param offsetMed he offset of the medium dimension of the
	 *        beginning of the read/write block within the
	 *        full array block
	 * @param offsetSlow offset_slow the offset of the slow dimension of the
	 *        beginning of the read/write block within the
	 *        full array block
	 */
	public void setDramBlocked(String streamName, InterfaceParam address,
                               InterfaceParam arraySizeFast, InterfaceParam arraySizeMed, InterfaceParam arraySizeSlow,
                               InterfaceParam rwSizeFast,    InterfaceParam rwSizeMed,    InterfaceParam rwSizeSlow,
                               InterfaceParam offsetFast,    InterfaceParam offsetMed,    InterfaceParam offsetSlow ) {
		m_impl.setDramBlocked(streamName, address.getImpl(),
		                      arraySizeFast.getImpl(), arraySizeMed.getImpl(), arraySizeSlow.getImpl(),
		                      rwSizeFast.getImpl(),    rwSizeMed.getImpl(),    rwSizeSlow.getImpl(),
		                      offsetFast.getImpl(),    offsetMed.getImpl(),    offsetSlow.getImpl());
	}

	/**
	 * Set a memory read or write, using the blocked pattern
	 *
	 * Note that arguments are specified in bytes; these are converted to
	 * bursts internally.  If the arguments are not burst-aligned, this
	 * function will raise an error.
	 *
	 * @param streamName the name of the memory stream
	 * @param address the start address, in bytes, of the beginning of
	 *        the array within the whole DRAM memory
	 * @param arraySizeFast the size, in bytes, of the fast
	 *        dimension of the array
	 * @param arraySizeMed the size of the medium dimension of the
	 *        array. This is expressed as a multiplier of the fast
	 *        dimension, <code>array_size_fast</code>
	 * @param arraySizeSlow the size of the slow dimension of the
	 *        array. This is expressed as a multiplier of the other
	 *        two dimensions, <code>array_size_fast*array_size_med</code>
	 * @param rwSizeFast the read/write size, in bytes, of the
	 *        fast dimension of the array
	 * @param rwSizeMed the read/write size of the medium dimension
	 *        of the array
	 * @param rwSizeSlow the read/write size of the slow dimension
	 *        of the array
	 * @param offsetFast the offset, in bytes, of the fast dimension
	 *        of the beginning of the read/write block within the
	 *        full array block
	 * @param offsetMed he offset of the medium dimension of the
	 *        beginning of the read/write block within the
	 *        full array block
	 * @param offsetSlow offset_slow the offset of the slow dimension of the
	 *        beginning of the read/write block within the
	 *        full array block
	 */
	public void setDramBlocked(String streamName,  long address,
	                           long arraySizeFast, long arraySizeMed, long arraySizeSlow,
	                           long rwSizeFast,    long rwSizeMed,    long rwSizeSlow,
	                           long offsetFast,    long offsetMed,    long offsetSlow ) {
		m_impl.setDramBlocked(streamName, address,
		               arraySizeFast, arraySizeMed, arraySizeSlow,
		               rwSizeFast,    rwSizeMed,    rwSizeSlow,
		               offsetFast,    offsetMed,    offsetSlow );
	}

	/**
	 * Set the value of a mapped memory
	 * @param blockName block being modified
	 * @param memoryName name of the mapped memory
	 * @param index index to modify
	 * @param value value to assign
	 */
	public void setMem(String blockName, String memoryName, int index, double value)
	{
		m_impl.setMem(blockName, memoryName, index, value);
	}

	/**
	 * Set the value of a mapped memory
	 * @param blockName block being modified
	 * @param memoryName name of the mapped memory
	 * @param index index to modify
	 * @param value value to assign
	 */
	public void setMem(String blockName, String memoryName, int index, long value)
	{
		m_impl.setMem(blockName, memoryName, index, value);
	}

	/**
	 * Set the value of a mapped memory
	 * @param blockName block being modified
	 * @param memoryName name of the mapped memory
	 * @param index index to modify
	 * @param value value to assign
	 */
	public void setMem(String blockName, String memoryName, int index, InterfaceParam value)
	{
		m_impl.setMem(blockName, memoryName, index, value.getImpl());
	}


	/**
	 * Define how the routing block(s) should be set
	 * @param routeString is a string containing a comma-separated list of
	 * <b>"<code>from -> to</code>"</b> pairs, where <b>"<code>from</code>"</b>
	 * is the name of the routing block, and <b>"<code>to</code>"</b> is the name of
	 * the input or output port.
	 * <p>
	 * The name of the <b>"<code>from</code>"</b> or <b>"<code>to</code>"</b> entity
	 * may optionally be prepended by the name of the block to which it belongs,
	 * separated by a period.
	 * <p>
	 * As an example, for a design containing a demux called "split" and a mux called "join",
	 * the routeString might be <b>"<code>split -> x1, join.y1  ->  join.join </code>"</b>.
	 * Spaces are not significant, so may be used freely to aid readability.
	 * <p>
	 * Note that there is an important difference between fanouts and the other two
	 * routing block types when specifying connections: <br>
	 * For <b>muxes</b> and <b>demuxes</b>, any connection supersedes and overwrites
	 * any existing connection, since  a mux and demux can have only one connection. <br>
	 * For <b>fanouts</b>, any connection will add another output connection to the
	 * fanout, since a fanout can have zero or more connections.
	 * In order to remove all fanout connections, the symbol "<b>NULL</b>" is used,
	 * e.g. <b>"<code>my_fanout -> NULL</code>"</b>.
	 * The NULL form is not valid for muxes or demuxes.
	 */
	public void route(String routeString)
	{
		m_impl.setRoute(routeString);
	}

	/**
	 * Indicate that a routing block should not be visible in the generated SLiC code.
	 * @param routingBlock name of the mux, demux or fanout routing block.
	 */
	public void ignoreRoute(String routingBlock)
	{
		m_impl.disableRoute(routingBlock);
	}

	public ArrayShape addArrayShapeSpecification(InterfaceParam dim[], ArrayOrdering arrayOrder) {
		com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParam pdim[] =
			new com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParam[dim.length];
		for(int i=0; i<dim.length; i++)
			pdim[i] = dim[i].getImpl();

		return new ArrayShape(m_impl.addArrayShapeSpecification(pdim, ArrayOrdering.toMaxelerOS(arrayOrder)));

	}

	public ArrayShape addArrayShapeSpecification(long dim[], ArrayOrdering arrayOrder) {
		return new ArrayShape(m_impl.addArrayShapeSpecification(dim, ArrayOrdering.toMaxelerOS(arrayOrder)));
	}

}
