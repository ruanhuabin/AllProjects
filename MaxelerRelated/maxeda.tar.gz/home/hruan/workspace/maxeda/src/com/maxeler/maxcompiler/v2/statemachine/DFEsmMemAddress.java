package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.ExprUtils;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.MemoryAddress;
import com.maxeler.statemachine.statements.StatementAssign;

public final class DFEsmMemAddress extends DFEsmVariable {

	@Override
	public <E extends Enum<E>> void connect(E value) {
		throw new MaxCompilerAPIError("Cannot use an enum as a memory address.");
	}

	@Override
	public void connect(boolean value) { connect(value ? 1 : 0); }

	@Override
	public void connect(long value) {
		Utils.checkIsAllowedLiteralValue(value, m_address.getType());
		connect(BigInteger.valueOf(value));
	}

	@Override
	public void connect(BigInteger value) { assign(new Constant(value)); }

	@Override
	public void connect(DFEsmExpr expr) { assign(expr.getExpression()); }

	private void assign(Expression expr) {
		checkContextValid();

		expr = ExprUtils.implicitCast(m_address.getType(), "memory address", expr);
		m_stateMachine.addStatement(new StatementAssign(m_address, expr, _StateMachine.getBuildManager(m_stateMachine)));
	}

	@Override
	protected DFEsmExpr getDFEsmExpr() {
		checkContextValid();

		return _StateMachine.Create.DFEsmExpr(m_address);
	}

	private final StateMachineLib m_stateMachine;
	private final MemoryAddress m_address;

	DFEsmMemAddress(StateMachineLib stateMachine, MemoryAddress address) {
		m_address = address;
		m_stateMachine = stateMachine;
	}

	public int getWidth() { return m_address.getWidth(); }

	private void checkContextValid() {
		if (m_stateMachine.getContextMode() != ContextMode.NEXT_STATE)
			throw new MaxCompilerAPIError("Memory address can only be accessed inside the 'nextState' method.");
	}
}
