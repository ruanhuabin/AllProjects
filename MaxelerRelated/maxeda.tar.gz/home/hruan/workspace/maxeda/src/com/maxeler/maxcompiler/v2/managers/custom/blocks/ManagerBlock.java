package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;

public interface ManagerBlock {
	public void setClock(ManagerClock clock);
}
