package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Constant;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Control;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.IO;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Stream;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core._KernelCore;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxcompiler.v2.statemachine.kernel.KernelStateMachine;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.nodes.NodeStateMachine;

/**
 * The {@code KernelLib} class gives access to all of the Kernel Compiler
 * core features.
 */
public class KernelLib {
	private final Kernel m_design;

	private final DFEManager m_manager;

	private final KernelConfiguration m_configuration;

	final PhotonDesignData m_design_data;

	/**
	 * Provides classes and methods for creating and accessing input and output streams and scalar inputs and outputs to a Kernel.
	 */
	public final IO io;
	/**
	 * Provides methods for control flow in a Kernel.
	 */
	public final Control control;
	/**
	 * Provides methods for creating constant streams of data.
	 */
	public final Constant constant;
	/**
	 * Provides classes and methods for working with stream offsets within a Kernel.
	 */
	public final Stream stream;
	/**
	 * Provides classes and methods for creating and accessing ROMs and RAMs.
	 */
	public final Mem mem;
	/**
	 * Provides methods for optimizing designs.
	 */
	public final Optimization optimization;
	/**
	 * Provides methods for debugging designs.
	 */
	public final Debug debug;


	KernelLib(DFEManager manager, String name, KernelConfiguration configuration) {
		m_design = (Kernel)this;
		m_configuration = configuration;

		BuildManager bm = _Managers.getBuildManager(manager);
		m_design_data = new PhotonDesignData(bm,
			name,
			_Managers.getCompileManagerFactory(manager),
			_KernelConfiguration.getPhotonKernelConfig(configuration));
		bm.logProgress("Instantiating kernel \"" + name + "\"");

		io = _KernelCore.newIO(m_design);
		control = _KernelCore.newMux(m_design);
		constant = _KernelCore.newConstant(m_design);
		optimization = new _Optimization(m_design);
		stream = _KernelCore.newStream(m_design);
		mem = _KernelCore.newMem(m_design);
		debug = new Debug(m_design);

		m_manager = manager;
	}

	protected KernelLib(KernelLib owner) {
		m_design = owner.m_design;
		m_design_data = owner.m_design_data;
		m_configuration = owner.m_configuration;

		io = owner.io;
		control = owner.control;
		constant = owner.constant;
		optimization = owner.optimization;
		stream = owner.stream;
		mem = owner.mem;
		debug = new Debug(m_design);

		m_manager = owner.m_manager;
	}

	/**
	 * Logs a string message with the {@code Manager} of this {@code KernelLib} instance.
	 * <p>
	 * This will appear on {@code stdout} and in the {@code _build.log} file in the root of the build directory.
	 * @param msg String message.
	 * @param args
	 */
	public void logMsg(String msg, Object... args) {
		getManager().logMsg(msg, args);
	}

	/**
	 * Gets the {@code Manager} of this {@code KernelLib} instance.
	 */
	public DFEManager getManager() {
		return m_manager;
	}

	/**
	 * Gets the root {@code Kernel} of this {@code KernelLib} instance.
	 */
	public Kernel getKernel() {
		return m_design;
	}

	/**
	 * Creates an {@link DFEFloat} type.
	 * <p>
	 * @param exponent_bits The number of bits for the exponent.
	 * @param mantissa_bits The number of bits for the mantissa.
	 * @return The new type object.
	 */
	public static DFEFloat dfeFloat(int exponent_bits, int mantissa_bits) {
		return DFETypeFactory.dfeFloat(exponent_bits, mantissa_bits);
	}

	/**
	 * Creates an {@link DFEFix} type.
	 * <p>
	 * @param integer_bits The number of bits before the binary point.
	 * @param fraction_bits The number of bits after the binary point.
	 * @param sign_mode Sets either two's complement or unsigned mode.
	 * @return The new type object.
	 */
	public static DFEFix dfeFix(int integer_bits, int fraction_bits, SignMode sign_mode) {
		return DFETypeFactory.dfeFix(integer_bits, fraction_bits, sign_mode);
	}

	/**
	 * Creates an {@link DFEFix} type capable of representing the supplied maximum value to
	 * the precision of the specified number of bits.
	 * <p>
	 * The number of bits ({@code num_bits}) must be greater than 0.
	 * <p>
	 * In unsigned mode, a {@code num_bits} value of 1 is valid. In two's complement mode, {@code num_bits} must be greater than 1.
	 * <p>
	 * The maximum value ({@code max}) cannot be 0 in either unsigned or two's complement mode.
	 * <p>
	 * In unsigned mode, {@code max} must be greater than 0. In two's complement mode, {@code max} can be less than 0.
	 * @param num_bits The total number of bits in the fixed-point word.
	 * @param max The maximum value that the type will be able to hold.
	 * @param sign_mode Sets either two's complement or unsigned mode.
	 * @return The new type object.
	 */
	public static DFEFix dfeOffsetFix(int num_bits, double max, SignMode sign_mode) {
		return DFETypeFactory.dfeOffsetFix(num_bits, max, sign_mode);
	}
	public static DFEFix dfeOffsetFix(int num_bits, long max, SignMode sign_mode) {
		return DFETypeFactory.dfeOffsetFix(num_bits, max, sign_mode);
	}

	public static DFEFix dfeFixMax(int num_bits, double max, SignMode sign_mode) {
		return DFETypeFactory.dfeFixMax(num_bits, max, sign_mode);
	}

	public static DFEFix dfeFixMax(int num_bits, long max, SignMode sign_mode) {
		return DFETypeFactory.dfeFixMax(num_bits, max, sign_mode);
	}

	/**
	 * Creates an {@link DFEFix} type with an explicit offset.
	 * <p>
	 * The number of bits ({@code num_bits}) must be greater than 0.
	 * <p>
	 * In unsigned mode, a {@code num_bits} value of 1 is valid. In two's complement mode, {@code num_bits} must be greater than 1.
	 * @param num_bits The total number of bits in the fixed-point word.
	 * @param offset The offset of the binary point.
	 * @param sign_mode Sets either two's complement or unsigned mode.
	 * @return The new type object.
	 */
	public static DFEFix dfeOffsetFix(int num_bits, int offset, SignMode sign_mode) {
		return DFETypeFactory.dfeOffsetFix(num_bits, offset, sign_mode);
	}

	/**
	 * Creates an {@link DFERawBits} type.
	 * @param num_bits The total number of bits.
	 * @return The new type object.
	 */
	public static DFERawBits dfeRawBits(int num_bits) {
		return DFETypeFactory.dfeRawBits(num_bits);
	}

	/**
	 * This is an alias for {@code dfeFix(num_bits, 0, SignMode.UNSIGNED)}
	 * @param num_bits The total number of bits.
	 * @return The new type object.
	 */
	public static DFEFix dfeUInt(int num_bits) {
		return DFETypeFactory.dfeUInt(num_bits);
	}

	/**
	 * This is an alias for {@code dfeFix(num_bits, 0, SignMode.TWOSCOMPLEMENT)}
	 * @param num_bits The total number of bits.
	 * @return The new type object.
	 */
	public static DFEFix dfeInt(int num_bits) {
		return DFETypeFactory.dfeInt(num_bits);
	}

	/**
	 * This is an alias for {@code dfeFix(1, 0, SignMode.UNSIGNED)}
	 * @return The new type object.
	 */
	public static DFEFix dfeBool() {
		return DFETypeFactory.dfeBool();
	}

	/**
	 * Sets a group name for subsequent nodes in the graph.
	 * <p>
	 * Group names are used to give a common name to groups of nodes within the graph. This
	 * is then shown in the visual graph output from MaxCompiler. Each group also creates a separate entity
	 * in the output VHDL.
	 * <p>
	 * Groups are useful for debugging large designs and libraries.
	 * <p>
	 * Group names are not globally unique by default, so pushing, popping and pushing the same name
	 * again will add the nodes declared between each push and pop to the same group.
	 * <p>
	 * e.g. {@code pushGroup("a"); popGroup(); pushGroup("a");} results in a single group
	 * called "a".
	 *
	 * See {@link #pushGroupUnique}
	 * for a variation of this method that ensures globally unique group names.
	 * <p>
	 * Group names are pushed onto a stack and popped off using {@link #popGroup}. Successively pushed group names are nested.
	 * <p>
	 * e.g. {@code pushGroup("a"); pushGroup("b"); pushGroup("c");} will produce a hierarchy of "a/b/c".
	 * @param group_name The name for the group.
	 */
	public void pushGroup(String group_name) {
		m_design_data.pushGroup(group_name);
	}

	/**
	 * Sets a unique group name for subsequent nodes in the graph.
	 * <p>
	 * See {@link #pushGroup} for more information on group names.
	 * <p>
	 * This method will push a group name that will have a globally unique
	 * identifier appended to it to ensure that the contents of the group
	 * are only from this one instance of the push and pop of this name.
	 * <p>
	 * e.g. {@code pushGroupUnique("a"); popGroup(); pushGroupUnique("a");} results in groups named
	 * "a_1" and "a_2".
	 * @param group_name The name for the group.
	 */
	public void pushGroupUnique(String group_name) {
		m_design_data.pushGroupUnique(group_name);
	}

	/**
	 * Pops the previously pushed group name.
	 * <p>
	 * See {@link #pushGroup} for more information on group names.
	 */
	public void popGroup() {
		m_design_data.popGroup();
	}

	public void pushResetOnFlush(boolean reset_on_flush) {
		m_design_data.pushResetOnFlush(reset_on_flush);
	}

	public void popResetOnFlush() { m_design_data.popResetOnFlush(); }

	/**
	 * Returns the kernel configuration object. (Most options will be
	 * read-only!)
	 * @return the current kernel configuration
	 */
	protected KernelConfiguration getKernelConfig(){
		return m_configuration;
	}


	public SMIO addStateMachine(String name, KernelStateMachine stateMachine) {
		if (m_design_data.hasStateMachine(name))
			throw new MaxCompilerAPIError("State machine called '%s' already exists.", name);

		NodeStateMachine node = new NodeStateMachine(m_design_data, name, stateMachine);
		SMIO sm = new SMIO(this, node);
		m_design_data.addStateMachine(name, node);

		return sm;
	}
}

