package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import java.util.LinkedHashMap;
import java.util.Map;

import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;

public class Mux implements ManagerBlock {
	com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeMux m_imp;

	private final Map<Integer, String> m_inputs = new LinkedHashMap<Integer, String>();
	private int m_sel_count = 0;

	Mux(com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeMux mux) {
		m_imp = mux;
	};

	public DFELink addInput(String name) {
		int sel = m_sel_count;
		m_sel_count++;
		m_inputs.put(sel, name);
		return _CustomManagers.fromImp(m_imp.addInput(name, sel));
	}

	public DFELink getOutput() {
		return _CustomManagers.fromImp(m_imp.getOutput());
	}

	@Override
	public void setClock(ManagerClock clock) {
		m_imp.setClock(_CustomManagers.managerClockToImp(clock));
	}

	public void setWidth(int bitwidth) {
		m_imp.setBitWidth(bitwidth);
	}
}
