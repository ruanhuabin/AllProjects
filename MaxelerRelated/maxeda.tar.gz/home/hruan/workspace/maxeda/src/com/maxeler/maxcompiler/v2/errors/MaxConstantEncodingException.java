package com.maxeler.maxcompiler.v2.errors;

import com.maxeler.maxcompiler.v2.utils.Bits;


public class MaxConstantEncodingException extends MaxCompilerAPIError {
	private static final long serialVersionUID = 1L;

	private final boolean m_is_overflow;
	private final boolean m_is_underflow;
	private final boolean m_is_complete_fixed_point_underflow;
	private final boolean m_is_invalid_op;
	private final boolean m_is_negative_to_unsigned;
	private final double m_relative_error;
	private final Bits m_packed_value;

	public MaxConstantEncodingException(
		boolean is_overflow,
		boolean is_underflow,
		boolean is_complete_fixed_point_underflow,
		boolean is_invalid_op,
		boolean is_negative_to_unsigned,
		double relative_error,
		Bits packed_value)
	{
		super("Error while encoding constant:" +
			(is_overflow ? " overflow" : "") +
			(is_underflow ? " underflow" : "") +
			(is_complete_fixed_point_underflow ? " complete fixed point underflow" : "") +
			(is_invalid_op ? " invalid operation" : "") +
			(is_negative_to_unsigned ? " negative value to unsigned conversion" : ""));

		m_is_overflow = is_overflow;
		m_is_underflow = is_underflow;
		m_is_complete_fixed_point_underflow = is_complete_fixed_point_underflow;
		m_is_invalid_op = is_invalid_op;
		m_is_negative_to_unsigned = is_negative_to_unsigned;
		m_relative_error = relative_error;
		m_packed_value = packed_value;
	}

	public boolean isOverflow() {
		return m_is_overflow;
	}

	public boolean isUnderflow() {
		return m_is_underflow;
	}

	public boolean isCompleteFixedPointUnderflow() {
		return m_is_complete_fixed_point_underflow;
	}

	public boolean isInvalidOp() {
		return m_is_invalid_op;
	}

	public boolean isNegativeToUnsigned() {
		return m_is_negative_to_unsigned;
	}

	public double getRelativeError() {
		return m_relative_error;
	}

	public Bits getPackedValue() {
		return m_packed_value;
	}
}
