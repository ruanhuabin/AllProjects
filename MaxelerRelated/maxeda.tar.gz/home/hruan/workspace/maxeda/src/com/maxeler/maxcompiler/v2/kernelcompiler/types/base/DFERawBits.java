package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.utils.Bits;


// This is final because extending it really does not work in an obvious way.
// Facaded HWTypes are created at outputs from the compiler losing any
// extra meta-data/type-information you may be trying to add.
/**
 * Kernel type representing a binary word of user-defined length which does not have a specific Kernel data type.
 * <p>
 * {@code DFERawBits} streams are used to prevent invalid operations being performed
 * inadvertently on collections of bits for which operator rules are not valid.
 * <p>
 * For example, it would be invalid apply any floating-point operations to the result of {@link DFEVar#slice(int)} on a floating-point stream.
 * <p>
 * Streams of this Kernel type can be cast to any other type of the same bit-width with no hardware overhead.
 * <p>
 * {@link DFEVar} streams can contain data of Kernel type {@code DFERawBits}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public final class DFERawBits extends DFEType {
	DFERawBits(com.maxeler.photon.types.HWType imp) {
		super(imp);
		if (!(imp instanceof com.maxeler.photon.types.HWRawBits))
			throw new MaxCompilerInternalError("Not DFERawBits compatbile.");
	}

	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		if(!equals(other_type))
			throw new MaxCompilerAPIError("Cannot do " + this + ".unionWithMaxOfMaxes(" + other_type + ")");

		return this;
	}

	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return equals(other_type);
	}

	@Override
	public Bits encodeConstant(Object v) {
		if (v instanceof Bits) {
			Bits b = (Bits) v;

			if (getTotalBits() != b.getWidth())
				throw new MaxCompilerAPIError(
					"Supplied Bits must have same width of " + getTotalBits() + " as type.");

			return b;
		}
		else {
			return super.encodeConstant(v);
		}
	}

	@Override
	public String toString() {
		return "dfeRawBits(" + getTotalBits() + ")";
	}
}
