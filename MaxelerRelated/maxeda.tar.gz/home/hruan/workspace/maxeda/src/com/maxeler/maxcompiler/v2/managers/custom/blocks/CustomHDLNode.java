package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._Error;
import com.maxeler.maxcompiler.v2.managers.custom.CustomManager;
import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxcompilersim.BuildFileSimCode;
import com.maxeler.maxcompilersim.BuildFileSimCodeCSource;
import com.maxeler.maxcompilersim.BuildFileSimCodeCSource.OptimizationOptions;
import com.maxeler.maxcompilersim.SimCompilePass;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.EntityExternal;
import com.maxeler.maxdc.EntityStructuralModifier;
import com.maxeler.maxdc.IOGroup;
import com.maxeler.maxdc.IOGroupRefExt;
import com.maxeler.maxdc.LogicSource;
import com.maxeler.maxdc.MaxFileCppHeaders;
import com.maxeler.maxdc.MaxFileManager;
import com.maxeler.maxdc.Signal;
import com.maxeler.maxeleros.MappedElementInfo.Mode;
import com.maxeler.maxeleros.MappedMemInfo;
import com.maxeler.maxeleros.MappedMemoryIOGroupDef;
import com.maxeler.maxeleros.MappedMemoryInterface;
import com.maxeler.maxeleros.MappedMemoryNamer;
import com.maxeler.maxeleros.MappedRegIOGroupDef;
import com.maxeler.maxeleros.MappedRegInfo;
import com.maxeler.maxeleros.MappedRegInterface;
import com.maxeler.maxeleros.PipedComputeCtrlIOGroupDef;
import com.maxeler.maxeleros.PipedComputeCtrlInterface;
import com.maxeler.maxeleros.StreamIOGroupDef;
import com.maxeler.maxeleros.StreamingInterfaceType;
import com.maxeler.maxeleros.StreamingInterfaceTypePull;
import com.maxeler.maxeleros.StreamingInterfaceTypePush;
import com.maxeler.maxeleros.ip.MappedRegBlock;
import com.maxeler.maxeleros.managercompiler.core.SoftwareSimInfo;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.maxeleros.managercompiler.core.WrapperNode;
import com.maxeler.maxeleros.managercompiler.core.WrapperNode.IODescClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperNodeEntity;
import com.maxeler.maxeleros.managercompiler.core.WrapperNodeFormatter;
import com.maxeler.photon.core.PhotonException;

/**
 * A {@code CustomHDLNode} node is used to include an external IP block as VHDL
 * or Verilog source or a compiled netlist.
 */
public class CustomHDLNode {

	private static class SimulationSetupCall {
		String m_method;
		Object[] m_args;
	}

	private final WrapperNodeCustomVHDL m_node;

	private final List<String> m_vhdl_files = new LinkedList<String>();
	private final List<String> m_verilog_files = new LinkedList<String>();
	private final List<String> m_netlist_files = new LinkedList<String>();
	private final List<String> m_cpp_source_files = new LinkedList<String>();
	private final List<String> m_cpp_header_files = new LinkedList<String>();
	private final HashSet<String> m_file_is_resource = new HashSet<String>();

	private final String m_top_level;
	private final String m_sim_c_type;

	private final List<CustomNodeClock> m_clocks = new LinkedList<CustomNodeClock>();
	private final List<Scalar> m_scalar_inputs = new LinkedList<Scalar>();
	private final List<Scalar> m_scalar_outputs = new LinkedList<Scalar>();
	private final List<String> m_mapped_memory_interfaces = new LinkedList<String>();
	private final HashMap<String, Integer> m_mapped_mem_addresses = new HashMap<String, Integer>();

	private final Object[] m_ctor_args;
	private final List<SimulationSetupCall> m_sim_setup_calls = new LinkedList<SimulationSetupCall>();

	private CustomNodeClock m_mapped_memory_clk = null;
	private boolean m_perf_mon_enabled = false;

	/**
	 * Creats a new {@code  CustomHDLNode} instance.
	 *
	 * @param manager
	 *            The name of the Custom Manager that owns the node.
	 * @param name
	 *            A name for the new instance of the node.
	 * @param top_level
	 *            The name of the top-level entity in the external IP block.
	 */
	public CustomHDLNode(CustomManager manager, String name, String top_level) {
		this(manager, name, top_level, null);
	}

	CustomHDLNode(CustomManager manager, String name, String top_level,
		String sim_c_type, Object... ctor_args) {
		m_node = new WrapperNodeCustomVHDL(
			_CustomManagers.getWrapperDesignData(manager), name);
		m_top_level = top_level;
		m_sim_c_type = sim_c_type;
		m_ctor_args = ctor_args;
	}

	WrapperNodeCustomVHDL getImpl() {
		return m_node;
	}

	/**
	 * Adds a clock domain to the node.
	 *
	 * @param name
	 *            The name of the clock port on the external IP block.
	 * @return A new clock domain instance.
	 */
	public CustomNodeClock addClockDomain(String name) {
		CustomNodeClock clk = m_node.addClockDomainExt(name);
		m_clocks.add(clk);
		return clk;
	}

	/**
	 * Adds a stream input to the node.
	 *
	 * @param name
	 *            The name of the stream input port on the external IP block.
	 * @param width
	 *            The width of the port in bits.
	 * @param clock
	 *            The clock domain in which to add this port.
	 * @param flow_control
	 *            The interface type of this port.
	 * @param latency
	 *            The stall latency or almost empty threshold, depending on the
	 *            input stream type specified in {@code flow_control}.
	 */
	public void addInputStream(
		String name,
		int width,
		CustomNodeClock clock,
		CustomNodeFlowControl flow_control,
		int latency)
	{
		m_node.addInputStream(name, width, clock, flow_control, latency);
	}

	/**
	 * Adds a stream output to the node.
	 *
	 * @param name
	 *            The name of the stream output port on the external IP block.
	 * @param width
	 *            The width of the port in bits.
	 * @param clock
	 *            The clock domain in which to add this port.
	 * @param flow_control
	 *            The interface type of this port.
	 * @param latency
	 *            The stall latency or almost empty threshold, depending on the
	 *            output stream type specified in {@code flow_control}.
	 */
	public void addOutputStream(
		String name,
		int width,
		CustomNodeClock clock,
		CustomNodeFlowControl flow_control,
		int latency)
	{
		m_node.addOutputStream(name, width, clock, flow_control, latency);
	}

	/**
	 * Adds a scalar input to the node.
	 *
	 * @param name
	 *            The name of the scalar input port on the external IP block.
	 * @param width
	 *            The width of the port in bits.
	 */
	public void addScalarInput(String name, int width) {
		m_scalar_inputs.add(new Scalar(name, width));
	}

	/**
	 * Adds a scalar output to the node.
	 *
	 * @param name
	 *            The name of the scalar output port on the external IP block.
	 * @param width
	 *            The width of the port in bits.
	 */
	public void addScalarOutput(String name, int width) {
		m_scalar_outputs.add(new Scalar(name, width));
	}

	/**
	 * Adds a mapped memory bus connection to the node.
	 * <p>
	 * The name of the mapped memory enable port for the custom HDL node will be
	 * {@code mapped_mem_en_} with {@code name} appended.
	 *
	 * @param name
	 *            The suffix for the mapped memory bus enable port for the
	 *            external IP block.
	 */
	public void addMappedMemoryInterface(String name) {
		if(m_mapped_memory_clk == null)
			throw new MaxCompilerAPIError(
				"Need to set the clock domain to use for mapped memories using setMappedMemoryClock() before adding mapped memory interfaces.");
		m_mapped_memory_interfaces.add(name);
	}

	/**
	 * Allows the writer of the VHDL block to provide a "active" output
	 * signal to be used by the performance monitor.
	 *
	 * @param enable
	 */
	public void setPerformanceMonitoringEnabled(boolean enable) {
		m_perf_mon_enabled = enable;
	}

	/**
	 * Adds VHDL source for an external IP block to the node.
	 *
	 * @param name
	 *            Filename for the VHDL source file.
	 * @param is_on_filesystem
	 *            {@code true} if this is a path on the file system or
	 *            {@code false} if the file is part of the project.
	 */
	public void addVHDLSource(String name, boolean is_on_filesystem) {
		m_vhdl_files.add(name);
		if(!is_on_filesystem)
			m_file_is_resource.add(name);
	}

	/**
	 * Adds Verilog source for an external IP block to the node.
	 *
	 * @param name
	 *            Filename for the Verilog source file.
	 * @param is_on_filesystem
	 *            {@code true} if this is a path on the file system or
	 *            {@code false} if the file is part of the project.
	 */
	public void addVerilogSource(String name, boolean is_on_filesystem) {
		m_verilog_files.add(name);
		if(!is_on_filesystem)
			m_file_is_resource.add(name);
	}

	/**
	 * Adds EDIF or Xilinx {@code .ngc} netlist for an external IP block to the
	 * node.
	 *
	 * @param name
	 *            Filename for the netlist source file.
	 * @param is_on_filesystem
	 *            {@code true} if this is a path on the file system or
	 *            {@code false} if the file is part of the project.
	 */
	public void addNetlist(String name, boolean is_on_filesystem) {
		m_netlist_files.add(name);
		if(!is_on_filesystem)
			m_file_is_resource.add(name);
	}

	/**
	 * Adds C++ simulation source file for MaxCompiler simulation of an external
	 * IP block to the node.
	 *
	 * @param name
	 *            Filename for the C++ source file.
	 * @param is_on_filesystem
	 *            {@code true} if this is a path on the file system or
	 *            {@code false} if the file is part of the project.
	 */
	void addSimulationCppSource(String name, boolean is_on_filesystem) {
		m_cpp_source_files.add(name);
		if(!is_on_filesystem)
			m_file_is_resource.add(name);
	}

	/**
	 * Adds C++ simulation header file for MaxCompiler simulation of an external
	 * IP block to the node.
	 *
	 * @param name
	 *            Filename for the C++ header file.
	 * @param is_on_filesystem
	 *            {@code true} if this is a path on the file system or
	 *            {@code false} if the file is part of the project.
	 */
	void addSimulationCppHeader(String name, boolean is_on_filesystem) {
		m_cpp_header_files.add(name);
		if(!is_on_filesystem)
			m_file_is_resource.add(name);
	}

	void addSimulationSetupCall(String method, Object... args) {
		SimulationSetupCall call = new SimulationSetupCall();
		call.m_method = method;
		call.m_args = args;
		m_sim_setup_calls.add(call);
	}

	/**
	 * Sets the mapped memory clock for the node.
	 *
	 * @param mem_clk
	 *            The clock to use.
	 */
	public void setMappedMemoryClock(CustomNodeClock mem_clk) {
		m_mapped_memory_clk = mem_clk;
	}

	/**
	 * Enum for determining the interface type of a stream input or output to
	 * and external IP block.
	 */
	public enum CustomNodeFlowControl {
		/**
		 * The source indicates that data is ready and requires that the data be
		 * read by the sink.
		 */
		PUSH,
		/** The sink requests data from the source. */
		PULL
	};

	private static class Scalar {
		private final int m_width;
		private final String m_name;

		Scalar(String name, int width) {
			m_name = name;
			m_width = width;
		}
	}

	/**
	 * A {@code domain.CustomNodeClock} object defines a clock and, optionally,
	 * a reset, that can be passed to other methods on the custom HDL node to
	 * associate interfaces with this clock domain.
	 */
	public static class CustomNodeClock {
		private final IODescClock m_imp;
		private final String m_name;
		private String m_reset_name = null;

		private CustomNodeClock(IODescClock imp, String name) {
			m_imp = imp;
			m_name = name;
		}

		/**
		 * Associates a reset signal with this clock.
		 *
		 * @param reset_name
		 *            The name of the reset port on the external IP block.
		 */
		public void setNeedsReset(String reset_name) {
			m_imp.setNeedsReset();
			m_reset_name = reset_name;
		}

		/**
		 * Gets the name of the clock signal for this clock domain.
		 *
		 * @return Returns the name of the clock port on the external IP block
		 *         as set by the user.
		 */
		public String getName() {
			return m_name;
		}

		/**
		 * Returns {@code true} if this clock has a reset signal associate with
		 * it or {@code false} if not.
		 *
		 * @return {@code true} if this clock has a reset signal associate with
		 *         it or {@code false} if not.
		 */
		public boolean getNeedsReset() {
			return m_reset_name != null;
		}

		/**
		 * Gets the name of the reset signal for this clock domain.
		 *
		 * @return Returns the name of the reset port on the external IP block
		 *         as set by the user.
		 */
		public String getResetName() {
			return m_reset_name;
		}
	}

	private class ExternalVHDLWrapper extends EntityExternal {
		protected ExternalVHDLWrapper(BuildManager build_manager,
			String top_level) {
			super(build_manager, top_level);

			// add VHDL/Verilog files
			for (String file : m_vhdl_files) {
				if(m_file_is_resource.contains(file))
					addVHDLFromResource(EntityExternal.defaultVHDLLibrary,
						file, CustomHDLNode.this);
				else
					addVHDLFromFile(file);
			}

			for (String file : m_verilog_files)
				if(m_file_is_resource.contains(file))
					addVerilogFromResource(file, CustomHDLNode.this);
				else
					addVerilogFromFile(file);

			for (String file : m_netlist_files)
				if(m_file_is_resource.contains(file))
					addNetlistFromResource(file, CustomHDLNode.this);
				else
					addNetlistFromFile(file);
		}
	}

	public class WrapperNodeCustomVHDL extends WrapperNode {

		private final List<IODesc> m_ios = new LinkedList<IODesc>();
		protected final WrapperDesignData m_container;

		private WrapperNodeCustomVHDL(WrapperDesignData container, String name) {
			super(container, name, name);
			m_container = container;
		}

		@Override
		protected void format(
			WrapperNodeFormatter formatter,
			boolean beginFormatCalled)
		{
			if (!beginFormatCalled)
				formatter.beginFormat(this);

			if (formatter.wantCustomHdlIO()) {
				for (Scalar si: CustomHDLNode.this.m_scalar_inputs)
					formatter.formatCustomHdlScalarInput(si.m_name, si.m_width);
				for (Scalar so: CustomHDLNode.this.m_scalar_outputs)
					formatter.formatCustomHdlScalarOutput(so.m_name, so.m_width);
			}
			super.format(formatter, true);
		}

		private CustomNodeClock addClockDomainExt(String name) {
			return new CustomNodeClock(addClockDomain(name), name);
		}

		private void addInputStream(
			String name,
			int width,
			CustomNodeClock clock,
			CustomNodeFlowControl flow_control,
			int latency)
		{
			IODesc input = addInput(name,
				addWidthDomain("width_" + name, width), clock.m_imp);
			StreamingInterfaceType type = null;
			switch (flow_control) {
				case PULL:
					type = new StreamingInterfaceTypePull(1, latency);
					break;
				case PUSH:
					type = new StreamingInterfaceTypePush(latency);
					break;
			}
			// type.setHasDone(false);
			input.setStreamingInterfaceType(type);
			m_ios.add(input);
		}

		private void addOutputStream(
			String name,
			int width,
			CustomNodeClock clock,
			CustomNodeFlowControl flow_control,
			int latency)
		{
			IODesc output = addOutput(name,
				addWidthDomain("width_" + name, width), clock.m_imp);
			StreamingInterfaceType type = null;
			switch (flow_control) {
				case PULL:
					type = new StreamingInterfaceTypePull(1, latency);
					break;
				case PUSH:
					type = new StreamingInterfaceTypePush(latency);
					break;
			}
			// type.setHasDone(false);
			output.setStreamingInterfaceType(type);
			m_ios.add(output);
		}

		public void setClock(CustomNodeClock clock, ManagerClock manager_clock)
		{
			clock.m_imp.setClock(_CustomManagers
				.managerClockToImp(manager_clock));
		}

		@Override
		public WrapperNodeEntity build(
			BuildManager build_manager,
			EntityStructuralModifier mod)
		{
			return new WrapperNodeCustomVHDLEntity(build_manager, this);
		}

		@Override
		public Collection<MappedRegInfo> getMappedRegisters() {
			ArrayList<MappedRegInfo> result = new ArrayList<MappedRegInfo>();
			for (Scalar si: CustomHDLNode.this.m_scalar_inputs) {
				MappedRegInfo reg_info =
					new MappedRegInfo(this.getInstanceName(), 0.0f, si.m_name, si.m_width, Mode.HOST_WRITE_ONLY, false);
				result.add(reg_info);
			}
			for (Scalar so: CustomHDLNode.this.m_scalar_outputs) {
				MappedRegInfo reg_info =
					new MappedRegInfo(this.getInstanceName(), 0.0f, so.m_name, so.m_width, Mode.HOST_READ_ONLY, false);
				result.add(reg_info);
			}
			return Collections.unmodifiableCollection(result);
		}

		public Collection<String> getMappedMemoryInterfaces() {
			return Collections.unmodifiableCollection(m_mapped_memory_interfaces);
		}

		@Override
		public SoftwareSimInfo buildSoftwareSim() {
			BuildManager bm = getBuildManager();

			if(m_sim_c_type == null)
				throw _Error.errorAPI(bm,
					"This CustomHDLNode (%s) does not support simulation.",
					getName());

			SoftwareSimInfo info = new SoftwareSimInfo(this, m_sim_c_type,
				m_ctor_args);

			for (Scalar s : m_scalar_inputs)
				info.addMappedRegister(s.m_name, s.m_width,
					Mode.HOST_WRITE_ONLY, false);

			for (Scalar s : m_scalar_outputs)
				info.addMappedRegister(s.m_name, s.m_width,
					Mode.HOST_READ_ONLY, false);

			for (SimulationSetupCall c : m_sim_setup_calls)
				info.addAdditionalSetup(c.m_method, c.m_args);

			SimCompilePass.pushCodeBuildDir(bm);

			for (String file : m_cpp_source_files) {
				BuildFileSimCodeCSource build_file = m_file_is_resource
					.contains(file) ? new BuildFileSimCodeCSource(bm, file,
					this) : new BuildFileSimCodeCSource(bm, file, true,
					OptimizationOptions.Odefault);

				bm.addBuildFile(build_file);
			}

			MaxFileManager mfm = MaxFileManager
				.getMaxFileManager(getBuildManager());
			MaxFileCppHeaders mfch = new MaxFileCppHeaders();

			for (String file : m_cpp_header_files) {
				BuildFileSimCode build_file = m_file_is_resource.contains(file) ? new BuildFileSimCode(
					getBuildManager(), file, this) : new BuildFileSimCode(
					getBuildManager(), file, true);

				bm.addBuildFile(build_file);
				mfch.addHeader(build_file.getRelativeName());
			}

			mfm.addMaxFileDataSegment(mfch);

			SimCompilePass.popCodeBuildDir(bm);

			return info;
		}

		private class WrapperNodeCustomVHDLEntity extends WrapperNodeEntity
			implements MappedRegInterface, MappedMemoryInterface, PipedComputeCtrlInterface {

			private final MappedRegBlock m_mapped_reg;
			private final IOGroup<MappedRegIOGroupDef> m_mapped_reg_iogroup;
			private final IOGroup<MappedMemoryIOGroupDef> m_mapped_mem_iogroup;
			private final IOGroup<PipedComputeCtrlIOGroupDef> m_piped_compute_ctrl_iogroup;

			private WrapperNodeCustomVHDLEntity(BuildManager build_manager,
				WrapperNode node) {
				super(build_manager, node);

				// mapped register block
				if(hasMappedRegisters()) {
					m_mapped_reg = new MappedRegBlock(build_manager,
						getCoreVersion(), getCoreName());
					m_mapped_reg_iogroup = addIOGroupSingleUse("mapped_reg_io",
						MappedRegIOGroupDef.REGISTER());
					addChild(m_mapped_reg);
					m_mapped_reg.getMappedRegIOGroup().connect(
						m_mapped_reg_iogroup);
				} else {
					m_mapped_reg = null;
					m_mapped_reg_iogroup = null;
				}

				// mapped memories
				if(hasMappedMemories()) {
					m_mapped_mem_iogroup = addIOGroup("mapped_mem",
						MappedMemoryIOGroupDef.MEMORY());
				} else {
					m_mapped_mem_iogroup = null;
				}

				// pipelined compute controller
				if(hasPipedComputeCtrl()) {
					m_piped_compute_ctrl_iogroup = addIOGroup("piped_compute_ctrl_io",
						PipedComputeCtrlIOGroupDef.NODE());;
				} else {
					m_piped_compute_ctrl_iogroup = null;
				}

				ExternalVHDLWrapper ext = new ExternalVHDLWrapper(
					build_manager, m_top_level);

				// connect up clocks/resets
				for (CustomNodeClock clock : m_clocks) {
					ext.getEntityModifier().addInput(clock.getName(), 1);
					ext.getInput(clock.getName())
						.connect(getClock(clock.m_imp));
					if(clock.getNeedsReset()) {
						ext.getEntityModifier().addInput(clock.getResetName(),
							1);
						ext.getInput(clock.getResetName()).connect(
							getReset(clock.m_imp));
					}
				}

				for (IODesc io : m_ios) {
					IOGroup<StreamIOGroupDef> iog = getStreamIOGroup(io);
					// ext.getEntityModifier().addIOGroup(io.getName(),
					// iog.getIOGroupDef());
					// ext.getIOGroup(input.getName()).connect(input_io);

					// a hack to hide & tie off the done signal
					StreamIOGroupDef iog_def = iog.getIOGroupDef();
					if(iog_def.isOutput()) {
						if(iog_def.isPull()) {
							ext.getEntityModifier().addInput(
								io.getName() + "_read", 1);
							ext.getEntityModifier().addOutput(
								io.getName() + "_empty", 1);
							ext.getEntityModifier().addOutput(
								io.getName() + "_almost_empty", 1);

							ext.getInput(io.getName() + "_read").connect(
								iog.getInput("read"));
							iog.getOutput("empty").connect(
								ext.getOutput(io.getName() + "_empty"));
							iog.getOutput("almost_empty").connect(
								ext.getOutput(io.getName() + "_almost_empty"));
						} else {
							ext.getEntityModifier().addInput(
								io.getName() + "_stall", 1);
							ext.getEntityModifier().addOutput(
								io.getName() + "_valid", 1);

							ext.getInput(io.getName() + "_stall").connect(
								iog.getInput("stall"));
							iog.getOutput("valid").connect(
								ext.getOutput(io.getName() + "_valid"));
						}

						ext.getEntityModifier().addOutput(
							io.getName() + "_data", io.getWidth());

						iog.getOutput("data").connect(
							ext.getOutput(io.getName() + "_data"));
						iog.getOutput("done").connect(zero(1));
					} else {
						if(iog_def.isPull()) {
							ext.getEntityModifier().addOutput(
								io.getName() + "_read", 1);
							ext.getEntityModifier().addInput(
								io.getName() + "_empty", 1);
							ext.getEntityModifier().addInput(
								io.getName() + "_almost_empty", 1);

							iog.getOutput("read").connect(
								ext.getOutput(io.getName() + "_read"));
							ext.getInput(io.getName() + "_empty").connect(
								iog.getInput("empty"));
							ext.getInput(io.getName() + "_almost_empty")
								.connect(iog.getInput("almost_empty"));
						} else {
							ext.getEntityModifier().addOutput(
								io.getName() + "_stall", 1);
							ext.getEntityModifier().addInput(
								io.getName() + "_valid", 1);

							iog.getOutput("stall").connect(
								ext.getOutput(io.getName() + "_stall"));
							ext.getInput(io.getName() + "_valid").connect(
								iog.getInput("valid"));
						}

						ext.getEntityModifier().addInput(
							io.getName() + "_data", io.getWidth());

						ext.getInput(io.getName() + "_data").connect(
							iog.getInput("data"));
					}
				}

				// connect up scalar inputs
				for (Scalar sc : m_scalar_inputs) {
					ext.getEntityModifier().addInput(sc.m_name, sc.m_width);
					Signal sig = signal(sc.m_width);
					m_mapped_reg.addHostWriteableMappedReg(sc.m_name, sig,
						hasPipedComputeCtrl(), false);
					ext.getInput(sc.m_name).connect(sig);
				}

				// connect up scalar outputs
				for (Scalar sc : m_scalar_outputs) {
					ext.getEntityModifier().addOutput(sc.m_name, sc.m_width);
					m_mapped_reg.addHostReadableMappedReg(sc.m_name,
						ext.getOutput(sc.m_name), hasPipedComputeCtrl());
				}

				// connect up mapped memories
				if(hasMappedMemories()) {
					ext.getEntityModifier().addInput("mapped_mem_data_in", 36);
					ext.getEntityModifier()
						.addOutput("mapped_mem_data_out", 36);
					ext.getEntityModifier().addInput("mapped_mem_addr", 16);
					ext.getEntityModifier().addInput("mapped_mem_wr_en", 1);
					ext.getEntityModifier().addInput("mapped_mem_rd_en", 1);
					ext.getEntityModifier().addOutput("mapped_mem_ack", 1);

					ext.getInput("mapped_mem_data_in").connect(
						m_mapped_mem_iogroup.getInput("memories_data_in"));
					m_mapped_mem_iogroup.getOutput("memories_data_out")
						.connect(ext.getOutput("mapped_mem_data_out"));

					ext.getInput("mapped_mem_wr_en").connect(
						m_mapped_mem_iogroup.getInput("memories_wren"));
					ext.getInput("mapped_mem_rd_en").connect(
						m_mapped_mem_iogroup.getInput("memories_rden"));
					m_mapped_mem_iogroup.getOutput("memories_ack").connect(
						ext.getOutput("mapped_mem_ack"));

					ext.getInput("mapped_mem_addr").connect(
						m_mapped_mem_iogroup.getInput("memories_memaddr"));
				}

				// generate enable signals for each mapped memory
				for (String mem : m_mapped_memory_interfaces) {
					ext.getEntityModifier().addInput("mapped_mem_en_" + mem, 1);
					// get an address from mapped memory namer and add decode
					// logic

					MappedMemoryNamer mm_namer = MappedMemoryNamer
						.getMappedMemoryNamer(build_manager);

					int mem_id = mm_namer.makeMemoryID(getInstanceName() + "."
						+ mem);
					int m_address = mm_namer.getAddressById(mem_id);

					m_mapped_mem_addresses.put(mem, m_address);

					// decode address
					LogicSource addr_en = eq(
						m_mapped_mem_iogroup.getInput("memories_memid"),
						constant(16, mem_id));

					ext.getInput("mapped_mem_en_" + mem).connect(addr_en);
				}

				// connect up pipelined compute controller
				if(hasPipedComputeCtrl()) {
					ext.getEntityModifier().addInput("pcc_start", 1);
					ext.getEntityModifier().addOutput("pcc_finished", 1);

					ext.getInput("pcc_start").connect(m_piped_compute_ctrl_iogroup.getInput("pcc_start"));
					m_piped_compute_ctrl_iogroup.getOutput("pcc_finished").connect(ext.getOutput("pcc_finished"));
				}

				// connect up performance monitoring
				if(hasActiveOutput()) {
					ext.getEntityModifier().addOutput("active", 1);
					addOutput("active", 1).connect(ext.getOutput("active"));
				}

				// add custom VHDL wrapper
				addChild(ext, "external_vhdl_i");
			}

			@Override
			protected boolean hasMappedRegisters() {
				return (m_scalar_inputs.size() + m_scalar_outputs.size()) != 0;
			}

			@Override
			protected MappedRegInterface getMappedRegistersInterface() {
				return this;
			}

			@Override
			public MappedRegInfo[] enumerateMappedRegs() {
				return m_mapped_reg.enumerateMappedRegs();
			}

			@Override
			public String getCoreName() {
				return getInstanceName();
			}

			@Override
			public Float getCoreVersion() {
				return 0.0f;
			}

			@Override
			public IOGroupRefExt<MappedRegIOGroupDef> getMappedRegIOGroup() {
				return getIOGroup(new MappedRegIOGroupDef[0], "mapped_reg_io");
			}

			@Override
			public int getStopLatency() {
				return m_mapped_reg.getStopLatency();
			}

			@Override
			public Integer setBaseAddress(Integer base) {
				return m_mapped_reg.setBaseAddress(base);
			}

			@Override
			public void setMappedRegClockID(String clk_id) {
				m_mapped_reg.setMappedRegClockID(clk_id);
			}

			@Override
			public MappedMemInfo[] enumerateMappedMemories() {
				MappedMemInfo mems[] = new MappedMemInfo[m_mapped_memory_interfaces
					.size()];
				int i = 0;
				for (String mem_name : m_mapped_memory_interfaces) {
					MappedMemInfo info = new MappedMemInfo(getInstanceName(),
						0.0f, mem_name, 36, 0);  // set depth to zero, to indicate in maxfile that this is a Custom HDL memory

					info.setAddress(m_mapped_mem_addresses.get(mem_name));
					info.setType("hwUInt(36)");

					mems[i++] = info;
				}
				return mems;
			}

			@Override
			public IOGroupRefExt<MappedMemoryIOGroupDef> getMappedMemoryIOGroup()
			{
				return getIOGroup(new MappedMemoryIOGroupDef[0], "mapped_mem");
			}

			@Override
			public boolean hasMappedMemories() {
				return m_mapped_memory_interfaces.size() != 0;
			}

			@Override
			public MappedMemoryInterface getMappedMemoryInterface() {
				return this;
			}

			@Override
			public WrapperClock getMappedMemoryClock() {
				return m_mapped_memory_clk.m_imp.getClock();
			}

			@Override
			public boolean hasPipedComputeCtrl() {
				return m_container.getPipelinedComputeControllerEnabled();
			}

			@Override
			public PipedComputeCtrlInterface getPipedComputeCtrlInterface() {
				return this;
			}

			@Override
			public IOGroupRefExt<PipedComputeCtrlIOGroupDef> getPipedComputeCtrlIOGroup() {
				if (!hasPipedComputeCtrl())
					throw new PhotonException(this, "There is no pipelined compute controller.");

				return getIOGroup(new PipedComputeCtrlIOGroupDef[0], "piped_compute_ctrl_io");
			}

			@Override
			protected boolean hasActiveOutput() {
				return m_perf_mon_enabled;
			}

			@Override
			public IODescClock getActiveClock() {
				IODescClock fastest_clock = null;
				for (CustomNodeClock clock : m_clocks) {
					if (fastest_clock == null || fastest_clock.getClock().getRate() < clock.m_imp.getClock().getRate())
						fastest_clock = clock.m_imp;
				}
				return fastest_clock;
			}
		}

	}
}
