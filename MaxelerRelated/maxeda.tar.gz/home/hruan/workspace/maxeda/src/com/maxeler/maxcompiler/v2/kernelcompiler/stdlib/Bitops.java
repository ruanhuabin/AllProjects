package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib;

import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.fromImp;
import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.toImp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.photon.core.Var;

/**
 * Provides methods for bit-manipulation.
 */
public class Bitops {
	private final Kernel m_design;
	private final com.maxeler.photon.libs.BitopsNodeFactory m_imp;

	Bitops(Kernel design) {
		m_design = design;
		m_imp = new com.maxeler.photon.libs.BitopsNodeFactory(_Kernel.getPhotonDesignData(design));
	}

	/**
	 * Concatenates objects together from MSB to LSB.
	 */
	private DFEVar _concat(List<KernelObject<?>> as) {
		if(as.size() < 1)
			throw new MaxCompilerAPIError(m_design.getManager(), "Cannot concatenate zero thing together.");

		DFEVar cat_var = as.get(0).pack();
		for(int i = 1; i < as.size(); i++)
			cat_var = cat_var.cat(as.get(i).pack());

		return cat_var;
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M _padSignExtend(M in, int extra_bits) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(in.getNElements());
		for(int i = 0; i < in.getNElements(); i++)
			new_pipes.add(padSignExtend(in.getElement(i), extra_bits));
		return in.getType().newInstance(in.getKernel(), new_pipes);
	}

	private DFEVar _padSignExtend(DFEVar in, int extra_bits) {
		// Backwards compatibility issue: Historically padding was broken and never sign-extended
		// purely fractional fixed point numbers. We have to emulate this behaviour to stay
		// backwards compatible
		Var real_in;

		if(in.getType() instanceof DFEFix && ((DFEFix)in.getType()).getIntegerBits() == 0) {
			DFEFix type_in = (DFEFix) in.getType();
			DFEVar unsigned_in = in.cast(
				DFETypeFactory.dfeFix(0, type_in.getFractionBits(), DFEFix.SignMode.UNSIGNED));
			real_in = toImp(unsigned_in);
		} else
			real_in = toImp(in);

		Var padded = m_imp.pad(real_in, extra_bits);

		return fromImp(m_design, padded);
	}

	private DFEVar _onehotDecode(DFEVar input) {
		Var v = m_imp.onehotDecode(toImp(input));

		return _KernelBaseTypes.fromImp(m_design, v);
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M _onehotDecode(M in) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(in.getNElements());
		for(int i = 0; i < in.getNElements(); i++)
			new_pipes.add(onehotDecode(in.getElement(i)));
		return in.getType().newInstance(in.getKernel(), new_pipes);
	}

	private DFEVar _leading1Detect(DFEVar input) {
		Var pos = m_imp.leading1Detect(toImp(input));

		return _KernelBaseTypes.fromImp(m_design, pos);
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M _leading1Detect(M in) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(in.getNElements());
		for(int i = 0; i < in.getNElements(); i++)
			new_pipes.add(leading1Detect(in.getElement(i)));
		return in.getType().newInstance(in.getKernel(), new_pipes);
	}

	private DFEVar _trailing1Detect(DFEVar input) {
		Var pos = m_imp.trailing1Detect(toImp(input));

		return _KernelBaseTypes.fromImp(m_design, pos);
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M _trailing1Detect(M in) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(in.getNElements());
		for(int i = 0; i < in.getNElements(); i++)
			new_pipes.add(trailing1Detect(in.getElement(i)));
		return in.getType().newInstance(in.getKernel(), new_pipes);
	}

	private DFEVar _bitreverse(DFEVar input) {
		return _KernelBaseTypes.fromImp(m_design, m_imp.bitreverse(toImp(input)));
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M _bitreverse(M in) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(in.getNElements());
		for(int i = 0; i < in.getNElements(); i++)
			new_pipes.add(bitreverse(in.getElement(i)));
		return in.getType().newInstance(in.getKernel(), new_pipes);
	}

	/**
	 * Concatenates objects together from MSB to LSB.
	 * <p>
	 * e.g. {@code concat(&#123;a, b, c&#124;)} results in a single value, of [MSB]abc[LSB].
	 */
	public static DFEVar concat(List<KernelObject<?>> as) {
		if(as.size() < 1)
			throw new MaxCompilerAPIError("Cannot concat together 0 KernelObjects.");

		return _Kernel.getGlobalBitopsInst(as.get(0).getKernel())._concat(as);
	}

	/**
	 * Concatenates objects together from MSB to LSB.
	 * <p>
	 * e.g. {@code concat(&#123;a, b, c&#124;)} results in a single value, of [MSB]abc[LSB].
	 */
	public static DFEVar concat(KernelObject<?>... as) {
		if(as.length < 1)
			throw new MaxCompilerAPIError("Cannot concat together 0 KernelObjects.");

		return _Kernel.getGlobalBitopsInst(as[0].getKernel())._concat(Arrays.asList(as));
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M padSignExtend(M in, int extra_bits) {
		return _Kernel.getGlobalBitopsInst(in.getKernel())._padSignExtend(in, extra_bits);
	}

	public static DFEVar padSignExtend(DFEVar in, int extra_bits) {
		return _Kernel.getGlobalBitopsInst(in.getKernel())._padSignExtend(in, extra_bits);
	}

	public static DFEVar onehotDecode(DFEVar input) {
		return _Kernel.getGlobalBitopsInst(input.getKernel())._onehotDecode(input);
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M onehotDecode(M in) {
		return _Kernel.getGlobalBitopsInst(in.getKernel())._onehotDecode(in);
	}

	/**
	 * The leading 1 detect operator detects the position of the most significant "important" bit.
	 * This means that all bits to the left of this position can safely be discarded.<br>
	 * For UNSIGNED numbers, this is the most significant set bit.
	 * For TWOSCOMPLEMENT numbers, it is the least significant sign bit.
	 * i.e.
	 * <pre>
	 * leading1Detect(constant.var(dfeUInt(32), 2048)) = 2048
	 * leading1Detect(constant.var(dfeInt(32), 2048)) = 4096</pre>
	 * This function returns a bit vector with only one non-zero bit (or possibly none if an UNSIGNED
	 * number was zero). To convert this into a binary number representing the bit position use onehotDecode.
	 * @see #onehotDecode(DFEVar)
	 * @param input Bits to check
	 * @return Bit vector of the same length with the most important bit set (or none).
	 */
	public static DFEVar leading1Detect(DFEVar input) {
		return _Kernel.getGlobalBitopsInst(input.getKernel())._leading1Detect(input);
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M leading1Detect(M in) {
		return _Kernel.getGlobalBitopsInst(in.getKernel())._leading1Detect(in);
	}

	public static DFEVar trailing1Detect(DFEVar input) {
		return _Kernel.getGlobalBitopsInst(input.getKernel())._trailing1Detect(input);
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M trailing1Detect(M in) {
		return _Kernel.getGlobalBitopsInst(in.getKernel())._trailing1Detect(in);
	}

	/**
	 * Reverses the bits of the input stream.
	 * @param input The input stream.
	 * @return The resultant bit-reversed stream.
	 */
	public static DFEVar bitreverse(DFEVar input) {
		return _Kernel.getGlobalBitopsInst(input.getKernel())._bitreverse(input);
	}

	/**
	 * Perform a circular left shift
	 * @param input The input stream.
	 * @param shiftAmt Amount to shift by
	 * @return The resultant shifted stream.
	 */
	public static DFEVar circularLeftShift(DFEVar input, DFEVar shiftAmt) {
		return _Kernel.getGlobalBitopsInst(input.getKernel())._circularLeftShift(input, shiftAmt);
	}

	private DFEVar _circularLeftShift(DFEVar input, DFEVar shiftAmt) {
		return _KernelBaseTypes.fromImp(m_design, m_imp.circularLeftShift(toImp(input), toImp(shiftAmt)));
	}

	/**
	 * Perform a circular right shift
	 * @param input The input stream.
	 * @param shiftAmt Amount to shift by
	 * @return The resultant shifted stream.
	 */
	public static DFEVar circularRightShift(DFEVar input, DFEVar shiftAmt) {
		return _Kernel.getGlobalBitopsInst(input.getKernel())._circularRightShift(input, shiftAmt);
	}

	private DFEVar _circularRightShift(DFEVar input, DFEVar shiftAmt) {
		return _KernelBaseTypes.fromImp(m_design, m_imp.circularRightShift(toImp(input), toImp(shiftAmt)));
	}


	/**
	 * Reverses the bits within each pipe of a multipipe stream.
	 * @param in The input multipipe stream.
	 * @return The returned multipipe stream with each pipe bit-reversed.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M bitreverse(M in) {
		return _Kernel.getGlobalBitopsInst(in.getKernel())._bitreverse(in);
	}

}
