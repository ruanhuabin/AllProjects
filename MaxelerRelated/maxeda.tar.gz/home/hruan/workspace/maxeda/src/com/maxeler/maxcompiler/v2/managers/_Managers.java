package com.maxeler.maxcompiler.v2.managers;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.Entity;
import com.maxeler.maxeleros.platforms.BoardCapabilities;
import com.maxeler.maxeleros.platforms.MAX2Board.MAX2BoardCapabilities;
import com.maxeler.maxeleros.platforms.MAX3Board.MAX3BoardCapabilities;
import com.maxeler.photon.core.PhotonCompileManager;

public class _Managers {
	public static BuildManager getBuildManager(DFEManager manager) {
		return manager.getBuildManager();
	}

	public static void runBuild(DFEManager manager, Entity root) {
		manager.runBuild(root);
	}

	public static void setCompileManagerFactory(
		DFEManager manager,
		PhotonCompileManager.Factory compile_manager_factory)
	{
		manager.setCompileManagerFactory(compile_manager_factory);
	}

	public static PhotonCompileManager.Factory getCompileManagerFactory(DFEManager manager) {
		return manager.getCompileManangerFactory();
	}

	public static void forceBuildManager(
		DFEManager fpga_manager,
		BuildManager build_manager,
		MAXBoardModel board_model)
	{
		fpga_manager.forceBuildManager(build_manager, board_model);
	}

	public static BoardCapabilities getBoardCapabilities(MAXBoardModel max_board_model) {
		if(max_board_model instanceof MAX2BoardModel)
			return ((MAX2BoardModel)max_board_model).m_board_caps;
		else if(max_board_model instanceof MAX3BoardModel)
			return ((MAX3BoardModel)max_board_model).m_board_caps;
		else
			throw new MaxCompilerInternalError(
				"MaxBoard model of type " + max_board_model.getClass().getSimpleName() +
				" not supported.");
	}

	public static MAX2BoardCapabilities getBoardCapabilities(MAX2BoardModel max_board_model) {
		return max_board_model.m_board_caps;
	}

	public static MAX3BoardCapabilities getBoardCapabilities(MAX3BoardModel max_board_model) {
		return max_board_model.m_board_caps;
	}

	public static void logSetConsoleTag(DFEManager manager, String console_tag) {
		manager.logSetConsoleTag(console_tag);
	}

	public static void logSetLogTag(DFEManager manager, String log_tag) {
		manager.logSetLogTag(log_tag);
	}

	public static KernelConfiguration getKernelConfiguration(DFEManager manager) {
		return manager.m_kernel_configuration;
	}
}
