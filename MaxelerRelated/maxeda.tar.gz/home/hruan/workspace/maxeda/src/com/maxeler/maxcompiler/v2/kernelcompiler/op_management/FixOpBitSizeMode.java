package com.maxeler.maxcompiler.v2.kernelcompiler.op_management;

public class FixOpBitSizeMode {
	final com.maxeler.photon.op_management.TypeModeBitSize m_imp;

	FixOpBitSizeMode(com.maxeler.photon.op_management.TypeModeBitSize imp) {
		m_imp = imp;
	}

	@Override
	public String toString() {
		return m_imp.toString();
	}
}
