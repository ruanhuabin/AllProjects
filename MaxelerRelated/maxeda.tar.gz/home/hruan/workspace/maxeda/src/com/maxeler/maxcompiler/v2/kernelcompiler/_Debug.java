package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.PhotonIOInformation;

public class _Debug extends Debug {

	private static PhotonDesignData getPhotonDesignData(Kernel kernel) {
		return kernel.m_design_data;
	}

	public enum InputOutputType {Input, Output}

	public static void markControllable(Debug self, InputOutputType type, String inOutPut) {
		boolean result;
		PhotonIOInformation io = getPhotonDesignData(self.m_design).getIOInformation();
		switch (type) {
			case Input:
				result = io.markInputControllable(inOutPut);
				break;
			case Output:
				result = io.markOutputControllable(inOutPut);
				break;
			default:
				result = false;
		}
		if (!result)
			throw new MaxCompilerAPIError(self.m_design.getManager(),
				"Could not mark " + inOutPut + " as controllable");
	}


	private _Debug(Kernel design) {super(design);}
}
