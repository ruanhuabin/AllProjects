package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.CounterChain;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

public class CounterChainCoverageTest extends Kernel {

	private static final DFEType scalarType = dfeUInt(32);
    private static final int nx = 5;
    private static final int ny = 4;
	private static final int npipes = 4;
	private static final int data_len = 10;
	private static final DFEType                int_type = dfeInt(32);
	private static final DFEVectorType<DFEVar> int_pipe = new DFEVectorType<DFEVar>(int_type, npipes);
	private static Random m_random = null;
	private static long   m_seed;

	public CounterChainCoverageTest( KernelParameters parameters ) {
		super( parameters );

		DFEVar x = io.input( "x", scalarType );
		flush.whenInputFinished("x");
		DFEVar xmax = io.scalarInput("xmax", scalarType);

		CounterChain chain = control.count.makeCounterChain();
		try {
			DFEVar ccw = chain.getCurrentCounterWrap();
			ccw.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "successfully caught exception: " + e );
		}
		DFEVar ix = chain.addCounter( xmax, 1 );
		DFEVar iy = chain.addCounter( ny,   1 );

		DFEVar cwrap = chain.getCurrentCounterWrap();
		DFEVar xwrap = chain.getCounterWrap(ix);
		cwrap.watch("cwrap");
		xwrap.watch("xwrap");
		try {
			DFEVar xxwrap = chain.getCounterWrap(xmax);
			xxwrap.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "successfully caught exception: " + e );
		}

		try {
			control.count.makeCounterChain().addCounter( constant.var(dfeInt(32),10), 1 );
		} catch ( MaxCompilerAPIError e ) {
			logMsg("successfully caught exception: " + e );
		}
		io.output( "y", scalarType ).connect( x * ix.cast(scalarType) + iy.cast(scalarType) );
	}

	public static void runTest1( String main_name ) {
		String name = main_name + "_1";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		manager.setKernels( new CounterChainCoverageTest(paramsA), new CounterChainCoverageTest(paramsB) );
		resetRandom();
		manager.logMsg( "*** Using random seed = " + m_seed );

		double x[] = initToRandom( nx*ny );
		double y[] = new double[ nx*ny ];
		for ( int ix=0 ; ix<nx ; ix++ ) {
			for ( int iy=0 ; iy<ny ; iy++ ) {
				int idx = ix*ny + iy;
				y[idx]  = x[idx]*ix + iy;
			}
		}
		manager.setInputData( "x", x );
		manager.setScalarInput( "xmax", nx );
		manager.runTest();
		manager.checkOutputData( "y", y );
		System.out.println("Test 1 OK!");
	}

	private static class CounterChainCoverageTest2 extends Kernel {

		protected CounterChainCoverageTest2(KernelParameters parameters) {
			super(parameters);

			DFEVector<DFEVar>  x = io.input(  "x", int_pipe );
			DFEVector<DFEVar>  y = io.output( "y", int_pipe );
			flush.whenInputFinished("x");
			CounterChain   chain = control.count.makeCounterChain();
			DFEVar             ix = chain.addCounter(data_len, 1).cast( int_type );
			DFEVector<DFEVar> iy = chain.addCounterVect(npipes, npipes  , 1).cast( int_pipe );
			y.connect( (x * ix) + iy );

			DFEVectorType<DFEVar> vpipe = new DFEVectorType<DFEVar>(dfeUInt(3), npipes);
			DFEVector<DFEVar>     var   = constant.vect(vpipe, npipes);

			DFEVar uvmax = constant.var(dfeUInt(3), npipes);
			CounterChain c2 = control.count.makeCounterChain();
			DFEVar             ix2 = c2.addCounter(data_len, 1).cast( int_type );
			DFEVector<DFEVar> iy2 = c2.addCounterVect(npipes, uvmax, 1).cast( int_pipe );
			io.output( "y2", int_pipe ).connect( (x * ix2) + iy2 );

			CounterChain c3 = control.count.makeCounterChain();
			DFEVar             ix3 = c3.addCounter(data_len, 1).cast( int_type );
			DFEVector<DFEVar> iy3 = c3.addCounterVect(vpipe, uvmax, 1).cast( int_pipe );
			io.output( "y3", int_pipe ).connect( (x * ix3) + iy3 );

			CounterChain c4 = control.count.makeCounterChain();
			DFEVar             ix4 = c4.addCounter(data_len, 1).cast( int_type );
			DFEVector<DFEVar> iy4 = c4.addCounterVect(vpipe, npipes, 1).cast( int_pipe );
			io.output( "y4", int_pipe ).connect( (x * ix4) + iy4 );

			CounterChain c5 = control.count.makeCounterChain();
			DFEVar             ix5 = c5.addCounter(data_len, 1).cast( int_type );
			DFEVector<DFEVar> iy5 = c5.addCounterVect(var, uvmax, 1).cast( int_pipe );
			io.output( "y5", int_pipe ).connect( (x * ix5) + iy5 );

			CounterChain c6 = control.count.makeCounterChain();
			DFEVar             ix6 = c6.addCounter(data_len, 1).cast( int_type );
			DFEVector<DFEVar> iy6 = c6.addCounterVect(var, npipes, 1).cast( int_pipe );
			io.output( "y6", int_pipe ).connect( (x * ix6) + iy6 );

			DFEVar vmax = constant.var(dfeInt(8), npipes);
			try {
				CounterChain c7 = control.count.makeCounterChain();
				c7.addCounterVect(npipes, vmax, 1);
			} catch (MaxCompilerAPIError e) {
				logMsg("caught exception: " + e);
			}

			try {
				CounterChain c8 = control.count.makeCounterChain();
				c8.addCounterVect(vpipe, vmax, 1);
			} catch (MaxCompilerAPIError e) {
				logMsg("caught exception: " + e);
			}

			try {
				CounterChain c9 = control.count.makeCounterChain();
				DFEVar             ix9 = c9.addCounter(data_len, 1).cast( int_type );
				DFEVector<DFEVar> iy9 = c9.addCounterVect(npipes, npipes-1, 1).cast( int_pipe );
				DFEVector<DFEVar> y9  = (ix9 * 10) + iy9;
				ix9.watch("ix9");
				iy9.watch("iy9");
				y9.watch ( "y9");
			} catch (MaxCompilerAPIError e) {
				logMsg("caught exception: " + e);
			}
		}
	}

	public static void runTest2( String main_name ) {
		String name = main_name + "_2";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		manager.setKernels( new CounterChainCoverageTest2(paramsA), new CounterChainCoverageTest2(paramsB) );
		resetRandom();
		manager.logMsg("*** Using random seed = " + m_seed);

		double[][] x = initToRandom(data_len, npipes);
    	Bits[]    bx = new Bits[data_len];
    	for ( int i = 0 ; i < x.length ; i++ )
    		bx[i] = SimulationManager.packToBits( int_type, x[i] );

		double[][] y = new double[data_len][npipes];
    	Bits[]    by = new Bits[data_len];
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<npipes ; j++ )
				y[i][j] = ( x[i][j] * i )  +  j;
		for ( int i=0 ; i<data_len ; i++ )
    		by[i] = SimulationManager.packToBits( int_type, y[i] );

		manager.setInputDataRaw( "x", bx );
		manager.runTest();
//		for ( Bits b : manager.getOutputDataRaw("y") )
//			System.out.println( "output = " + int_pipe.decodeConstant(b) );
		manager.checkOutputDataRaw( "y",  by );
		manager.checkOutputDataRaw( "y2", by );
		manager.checkOutputDataRaw( "y3", by );
		manager.checkOutputDataRaw( "y4", by );
		manager.checkOutputDataRaw( "y5", by );
		manager.checkOutputDataRaw( "y6", by );
		System.out.println("Test 2 OK!");
	}


	private static class CounterChainCoverageTest3 extends Kernel {

		protected CounterChainCoverageTest3(KernelParameters parameters) {
			super(parameters);
			DFEVector<DFEVar> x = io.input(  "x", int_pipe );
			DFEVector<DFEVar> y = io.output( "y", int_pipe );
			flush.whenInputFinished("x");
			DFEVar             vmax = constant.var(dfeUInt(3), 5);
			DFEVector<DFEVar> tmpl = constant.vect(npipes, dfeUInt(3), 5);
			CounterChain      c2   = control.count.makeCounterChain();
			DFEVector<DFEVar> ix   = c2.addCounterVect(npipes, vmax, 1);
			DFEVector<DFEVar> iy   = c2.addCounterVect(tmpl, (vmax-1), 1);
			y.connect( (x * ix) + iy );
		}
	}

	public static void runTest3( String main_name ) {
		String name = main_name + "_3";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		resetRandom();
		manager.logMsg("*** Using random seed = " + m_seed);
		double[][] x = initToRandom(data_len, npipes);
		Bits[] bx = new Bits[data_len];
		for ( int i = 0 ; i < x.length ; i++ )
			bx[i] = SimulationManager.packToBits( int_type, x[i] );

		try {
			manager.setKernels( new CounterChainCoverageTest3(paramsA), new CounterChainCoverageTest3(paramsB) );
			manager.setInputDataRaw( "x", bx );
			manager.runTest();
			throw new RuntimeException("Should never reach here! - cannot have >1 multi-pipe counter in counter chain");
		} catch (MaxCompilerAPIError e) {
			manager.logMsg("caught exception: " + e);
		}
		System.out.println("Test 3 OK!");
	}


	public static void main(String[] args) {
    	String name = "CounterChainCoverageTest";
    	runTest1(name);
    	runTest2(name);
    	runTest3(name);
		System.out.println("All tests OK!");
    	System.exit(0);
    }

	private static double[] initToRandom( int len ) {
		double[] arr = new double[len];
		for ( int i = 0 ; i < len ; i++ )
			arr[i] = m_random.nextInt( 100 );
		return arr;
	}

	private static double[][] initToRandom( int len, int wid ) {
		double[][] arr = new double[len][wid];
		for ( int i = 0 ; i < len ; i++ )
			for ( int j = 0 ; j < wid ; j++ )
				arr[i][j] = m_random.nextInt( 100 );
		return arr;
	}

	private static void resetRandom() {
		if ( m_random == null ) {
			m_seed = System.currentTimeMillis();
		}
		m_random = new Random( m_seed );
	}

}
