package com.maxeler.maxcompiler.v2.managers;



public interface MAXBoardModel {
}
