package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import static com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType.newInstance;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._AlreadyConnectedException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

public class DFEVectorTest extends Kernel {

	private static final int                   num_elements   = 4;
	private static final int                   data_len    = 10;
	private static final DFEType                scalar_type = dfeFloat(11,53);
	private static final DFEType                int_type    = dfeInt(32);
	private static final DFEType                uint_type   = dfeUInt(32);
	private static final DFEVectorType<DFEVar> int_element    = new DFEVectorType<DFEVar>(int_type, num_elements);
	private static final DFEVectorType<DFEVar> uint_element   = new DFEVectorType<DFEVar>(uint_type, num_elements);
	private static final DFEVectorType<DFEVar> shift_element  = new DFEVectorType<DFEVar>(dfeUInt(5), num_elements);
	private static final DFEVectorType<DFEVar> float_element  = new DFEVectorType<DFEVar>(scalar_type, num_elements);
	private static final DFEVectorType<DFEVar> bool_type   = new DFEVectorType<DFEVar>(dfeBool(), num_elements);
	private static Random m_random = null;
	private static long   m_seed;


	public DFEVectorTest( KernelParameters parameters ) {
		super( parameters );

		//----- tests for casting, newInstance, miscellaneous methods...
		DFEVector<DFEVar> x = io.input( "x", float_element );
		DFEVector<DFEVar> y = io.input( "y", float_element );
		io.output( "z", float_element ).connect( x + y );
		io.output( "a", float_element ).connect( -x );

		DFEVector<DFEVar> cb  = constant.vect(num_elements, false);
		DFEVector<DFEVar> cd  = constant.vect(num_elements, 10);
		DFEVector<DFEVar> ci  = constant.vect(num_elements, dfeInt(32), 3);
		DFEVector<DFEVar> ctb = constant.vect(bool_type, true);
		DFEVector<DFEVar> ctd = constant.vect(float_element, 10.0);
		DFEVector<DFEVar> ctx = constant.vect(x, 100);
		DFEVector<DFEVar> ctbb = constant.vect(ctb, false);
		cb.watch("cb");
		cd.watch("cd");
		ci.watch("ci");
		ctb.watch("ctb");
		ctd.watch("ctd");
		ctx.watch("ctx");
		ctbb.watch("ctbb");

		DFEVector<DFEVar> a = float_element.newInstance(this);
		a.connect( x.cast( new DFEVectorType<DFEVar>(scalar_type, num_elements)) - y.cast(float_element) );
		a.watch("a");
		try {
			a.connect( x - y );
		} catch (_AlreadyConnectedException e) {
			logMsg("caught already-connected exception: " + e );
		}

		try {
			DFEVar b = (DFEVar) a.cast( dfeFloat(11, 53) );
			b.watch("b");
		} catch (MaxCompilerAPIError e) {
			logMsg("caught cast exception: " + e );
		}

		try {
			DFEVectorType<DFEVar> element2_type  = new DFEVectorType<DFEVar>(scalar_type, num_elements*2);
			DFEVector<DFEVar> b = a.cast( element2_type );
			b.watch("b");
		} catch (MaxCompilerAPIError e) {
			logMsg("caught wrong element count exception: " + e );
		}
		DFEVectorType<DFEVar> mp_type = x.getType();
		DFEVector<DFEVar> d = a.cast( mp_type );
		d.setReportOnUnused(false);
		d.getKernel().logMsg( "multielement type = " + d.getType() + ",  hash=" + d.getType().hashCode() );

		DFEVar cnst = constant.var( scalar_type, 12.34 );
		DFEVector<DFEVar> f = float_element.newInstance( this, cnst );

		DFEVector<DFEVar> g = newInstance(num_elements, cnst) + f;
		g.setReportOnUnused(false);

		try {
			ArrayList<DFEVar> hlist = new ArrayList<DFEVar>();
			hlist.add( cnst );
			hlist.add( constant.var(3.142) );
			hlist.add( constant.var( true ) );
			hlist.add( constant.var(dfeInt(32), 99) );
			DFEVector<DFEVar> p = float_element.newInstance(this, hlist);
			p.watch( "p" );
		} catch (MaxCompilerAPIError e) {
			logMsg( "caught mixed element type exception: " + e );
		}

		//----- non-concrete type?
		try {
			DFEVector<DFEVar> mp_non_concrete = (new DFEVectorType<DFEVar>(DFETypeFactory.dfeUntypedConst(), num_elements)).newInstance(this);
			mp_non_concrete.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "caught exception: " + e );
		}

		//----- null type?
		try {
			DFEVector<DFEVar> mp_null_typed = (new DFEVectorType<DFEVar>(null, num_elements)).newInstance(this);
			mp_null_typed.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "caught null type exception: " + e );
		} catch (NullPointerException e ) {
			logMsg( "caught null type exception: " + e );
		}

		//----- zero elements?
		try {
			DFEVector<DFEVar> mp_no_elements = (new DFEVectorType<DFEVar>(dfeInt(32), 0)).newInstance(this);
			mp_no_elements.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "caught zero-elements exception: " + e );
		}

	}

	private static void runTest1( String main_name ) {
		String name = main_name + "_1";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEVectorTest(paramsA), new DFEVectorTest(paramsB) );
		setUpRandom();
		manager.logMsg( "*** Using random seed = " + m_seed );
		manager.setKernelCycles( data_len );

		double x[][] = initToRandomDbl( data_len, num_elements );
		double y[][] = initToRandomDbl( data_len, num_elements );
		double z[][] = new double[data_len][num_elements];
    	for ( int i = 0 ; i < data_len ; i++ ) {
    		for ( int j = 0 ; j < num_elements ; j++ ) {
    			z[i][j] = x[i][j] + y[i][j];
    		}
    	}

    	Bits[] bx = new Bits[data_len];
    	Bits[] by = new Bits[data_len];
    	Bits[] bz = new Bits[data_len];
    	for ( int i = 0 ; i < data_len ; i++ ) {
    		bx[i] = SimulationManager.packToBits( scalar_type, x[i] );
    		by[i] = SimulationManager.packToBits( scalar_type, y[i] );
    		bz[i] = SimulationManager.packToBits( scalar_type, z[i] );
			System.out.println( "expected z = " + float_element.decodeConstant(bz[i]) );
    	}

    	manager.setInputDataRaw( "x", bx );
    	manager.setInputDataRaw( "y", by );
		manager.runTest();
		for ( Bits bits : manager.getOutputDataRaw("z") )
			System.out.println( "output z = " + float_element.decodeConstant(bits) );

		manager.checkOutputDataRaw( "z", bz );

		double[] small = x[0];
		Double[] Small = doubleToDouble(small);
		Bits bits  = float_element.encodeConstant( Small );
		Bits blist = float_element.encodeConstant( Arrays.asList(Small) );
		Bits bobj  = float_element.encodeConstant( (Object)Arrays.asList(Small) );
		manager.logMsg( "small = " + Arrays.toString(small) );
		manager.logMsg( "      = " + bits  );
		manager.logMsg( "      = " + blist );
		manager.logMsg( "      = " + bobj  );
		if ( ! bits.equals(blist) )
			throw new RuntimeException( "encodeConstant(Double[]) returns different result from encodeConstant(List<Double>)" );
		if ( ! bits.equals(bobj) )
			throw new RuntimeException( "encodeConstant(Double[]) returns different result from encodeConstant(Object)" );

		List<Bits> bit_list  = manager.getOutputDataRaw("z");
		manager.logMsg( "bit_list size =  " + bit_list.size() );
		manager.logMsg( "bit_list[0]   =  " + bit_list.get(0) );
		if ( ! bit_list.get(0).equals(bz[0]) )
			throw new RuntimeException( "encodeConstant(Double[]) returns different result from encodeConstant(List<Double>)" );
		if ( bit_list.size() != data_len )
			throw new RuntimeException( "getOutputDataRaw returning wrong size list" );

		@SuppressWarnings("unchecked")
		List<Double> dlist = float_element.decodeConstant( bit_list.get(0) );
		manager.logMsg( "dlist size =  " + dlist.size() );
		manager.logMsg( "z[0][0] = " + z[0][0] + "  =  " + dlist.get(0) );
		if ( dlist.size() != num_elements )
			throw new RuntimeException( "decodeConstant returning wrong size list" );

		try {
			ArrayList<DFEVar>  vList = new ArrayList<DFEVar>();
			DFEVector<DFEVar> mpType = newInstance(vList);
			mpType.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			manager.logMsg("successfully caught exception: " + e );
		}

    	for ( int i = 0 ; i < data_len ; i++ )
    		for ( int j = 0 ; j < num_elements ; j++ )
    			z[i][j] = -x[i][j];
    	bz = convertToBits( z, scalar_type );
		manager.checkOutputDataRaw( "a", bz );

		System.out.println("Test 1 OK!");
	}


	private static class DFEVectorTest2 extends Kernel {


		protected DFEVectorTest2(KernelParameters parameters) {
			super(parameters);

			//----- tests for arithmetic operations
			DFEVector<DFEVar> x = io.input( "x", float_element );
			DFEVector<DFEVar> y = io.input( "y", float_element );

			//----- addition
			io.output( "a", float_element ).connect( x + y );
			io.output( "b", float_element ).connect( x + constant.var(12.34) );
			io.output( "c", float_element ).connect( constant.var(12.34) + x );
			io.output( "d", float_element ).connect( x + 12.34  );
			io.output( "e", float_element ).connect( 12.34  + x );
			io.output( "f", float_element ).connect( x + 12.34f );
			io.output( "g", float_element ).connect( 12.34f + x );

			io.output( "h", float_element ).connect( x + 3  );
			io.output( "i", float_element ).connect( x + 3l );
			io.output( "j", float_element ).connect( 3  + x );
			io.output( "k", float_element ).connect( 3l + x );

			//----- subtraction
			io.output( "l", float_element ).connect( x - y );
			io.output( "m", float_element ).connect( x - constant.var(12.34) );
			io.output( "n", float_element ).connect( constant.var(12.34) - x );
			io.output( "o", float_element ).connect( x - 12.34  );
			io.output( "p", float_element ).connect( 12.34  - x );
			io.output( "q", float_element ).connect( x - 12.34f );
			io.output( "r", float_element ).connect( 12.34f - x );

			io.output( "s", float_element ).connect( x - 3  );
			io.output( "t", float_element ).connect( x - 3l );
			io.output( "u", float_element ).connect( 3  - x );
			io.output( "v", float_element ).connect( 3l - x );

			//----- multiplication
			io.output( "a2", float_element ).connect( x * y );
			io.output( "b2", float_element ).connect( x * constant.var(12.34) );
			io.output( "c2", float_element ).connect( constant.var(12.34) * x );
			io.output( "d2", float_element ).connect( x * 12.34  );
			io.output( "e2", float_element ).connect( 12.34  * x );
			io.output( "f2", float_element ).connect( x * 12.34f );
			io.output( "g2", float_element ).connect( 12.34f * x );

			io.output( "h2", float_element ).connect( x * 3  );
			io.output( "i2", float_element ).connect( x * 3l );
			io.output( "j2", float_element ).connect( 3  * x );
			io.output( "k2", float_element ).connect( 3l * x );

			//----- division
			io.output( "l2", float_element ).connect( x / y );
			io.output( "m2", float_element ).connect( x / constant.var(12.34) );
			io.output( "n2", float_element ).connect( constant.var(12.34) / x );
			io.output( "o2", float_element ).connect( x / 12.34  );
			io.output( "p2", float_element ).connect( 12.34  / x );
			io.output( "q2", float_element ).connect( x / 12.34f );
			io.output( "r2", float_element ).connect( 12.34f / x );

			io.output( "s2", float_element ).connect( x / 3  );
			io.output( "t2", float_element ).connect( x / 3l );
			io.output( "u2", float_element ).connect( 3  / x );
			io.output( "v2", float_element ).connect( 3l / x );
		}
	}

	private static void runTest2( String main_name ) {
		String name = main_name + "_2";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEVectorTest2(paramsA), new DFEVectorTest2(paramsB) );
		setUpRandom();
		manager.logMsg( "*** Using random seed = " + m_seed );
		manager.setKernelCycles( data_len );

		double x[][] = initToRandomDbl( data_len, num_elements );
		double y[][] = initToRandomDbl( data_len, num_elements );
    	Bits[] bx = new Bits[data_len];
    	Bits[] by = new Bits[data_len];
    	for ( int i = 0 ; i < data_len ; i++ ) {
    		bx[i] = SimulationManager.packToBits( scalar_type, x[i] );
    		by[i] = SimulationManager.packToBits( scalar_type, y[i] );
    	}

    	manager.setInputDataRaw( "x", bx );
    	manager.setInputDataRaw( "y", by );
		manager.runTest();

		double z[][] = new double[data_len][num_elements];

		//----- addition
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] + y[i][j];
    	manager.checkOutputDataRaw( "a", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] + 12.34;
    	manager.checkOutputDataRaw( "b", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "c", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "d", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "e", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] + 12.34f;
    	manager.checkOutputDataRaw( "f", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "g", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] + 3;
    	manager.checkOutputDataRaw( "h", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "i", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "j", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "k", convertToBits(z, scalar_type) );

		//----- subtraction
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] - y[i][j];
    	manager.checkOutputDataRaw( "l", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] - 12.34;
    	manager.checkOutputDataRaw( "m", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 12.34 - x[i][j];
    	manager.checkOutputDataRaw( "n", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] - 12.34;
    	manager.checkOutputDataRaw( "o", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 12.34 - x[i][j];
    	manager.checkOutputDataRaw( "p", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] - 12.34f;
    	manager.checkOutputDataRaw( "q", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 12.34f - x[i][j];
    	manager.checkOutputDataRaw( "r", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] - 3;
    	manager.checkOutputDataRaw( "s", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "t", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 3 - x[i][j];
    	manager.checkOutputDataRaw( "u", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "v", convertToBits(z, scalar_type) );

		//----- multiplication
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] * y[i][j];
    	manager.checkOutputDataRaw( "a2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] * 12.34;
    	manager.checkOutputDataRaw( "b2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "c2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "d2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "e2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] * 12.34f;
    	manager.checkOutputDataRaw( "f2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "g2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] * 3;
    	manager.checkOutputDataRaw( "h2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "i2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "j2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "k2", convertToBits(z, scalar_type) );

		//----- division
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] / y[i][j];
    	manager.checkOutputDataRaw( "l2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] / 12.34;
    	manager.checkOutputDataRaw( "m2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 12.34 / x[i][j];
    	manager.checkOutputDataRaw( "n2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] / 12.34;
    	manager.checkOutputDataRaw( "o2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 12.34 / x[i][j];
    	manager.checkOutputDataRaw( "p2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] / 12.34f;
    	manager.checkOutputDataRaw( "q2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 12.34f / x[i][j];
    	manager.checkOutputDataRaw( "r2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = x[i][j] / 3;
    	manager.checkOutputDataRaw( "s2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "t2", convertToBits(z, scalar_type) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = 3 / x[i][j];
    	manager.checkOutputDataRaw( "u2", convertToBits(z, scalar_type) );
    	manager.checkOutputDataRaw( "v2", convertToBits(z, scalar_type) );

		System.out.println("Test 2 OK!");
	}


	private static class DFEVectorTest3 extends Kernel {

		protected DFEVectorTest3(KernelParameters parameters) {
			super(parameters);

			//----- tests for comparison operators
			DFEVector<DFEVar> x = io.input( "x", float_element );
			DFEVector<DFEVar> y = io.input( "y", float_element );

			//----- equality
			io.output( "a", bool_type ).connect( x.eq(y) );
			io.output( "b", bool_type ).connect( x.eq(constant.var(12.34) ) );
			io.output( "c", bool_type ).connect( x.eqAsRHS(constant.var(12.34) ) );
			io.output( "d", bool_type ).connect( x.eq(12.34)  );
			io.output( "e", bool_type ).connect( x.eqAsRHS(12.34 ) );
			io.output( "f", bool_type ).connect( x.eq(12.34f) );
			io.output( "g", bool_type ).connect( x.eqAsRHS(12.34f ) );

			io.output( "h", bool_type ).connect( x.eq(3 ) );
			io.output( "i", bool_type ).connect( x.eq(3l) );
			io.output( "j", bool_type ).connect( x.eqAsRHS(3 ) );
			io.output( "k", bool_type ).connect( x.eqAsRHS(3l) );

			//----- inequality
			io.output( "a2", bool_type ).connect( x.neq(y) );
			io.output( "b2", bool_type ).connect( x.neq(constant.var(12.34) ) );
			io.output( "c2", bool_type ).connect( x.neqAsRHS(constant.var(12.34) ) );
			io.output( "d2", bool_type ).connect( x.neq(12.34)  );
			io.output( "e2", bool_type ).connect( x.neqAsRHS(12.34 ) );
			io.output( "f2", bool_type ).connect( x.neq(12.34f) );
			io.output( "g2", bool_type ).connect( x.neqAsRHS(12.34f ) );

			io.output( "h2", bool_type ).connect( x.neq(3 ) );
			io.output( "i2", bool_type ).connect( x.neq(3l) );
			io.output( "j2", bool_type ).connect( x.neqAsRHS(3 ) );
			io.output( "k2", bool_type ).connect( x.neqAsRHS(3l) );

			//----- greater than
			io.output( "a3", bool_type ).connect( x > y );
			io.output( "b3", bool_type ).connect( x > constant.var(12.34) );
			io.output( "c3", bool_type ).connect( constant.var(12.34) < x );
			io.output( "d3", bool_type ).connect( x > 12.34  );
			io.output( "e3", bool_type ).connect( 12.34 < x  );
			io.output( "f3", bool_type ).connect( x > 12.34f );
			io.output( "g3", bool_type ).connect( 12.34f < x );

			io.output( "h3", bool_type ).connect( x  > 3  );
			io.output( "i3", bool_type ).connect( x  > 3l );
			io.output( "j3", bool_type ).connect( 3  < x  );
			io.output( "k3", bool_type ).connect( 3l < x  );

			//----- greater than or equal to
			io.output( "a4", bool_type ).connect( x >= y );
			io.output( "b4", bool_type ).connect( x >= constant.var(12.34) );
			io.output( "c4", bool_type ).connect( constant.var(12.34) <= x );
			io.output( "d4", bool_type ).connect( x >= 12.34  );
			io.output( "e4", bool_type ).connect( 12.34 <= x  );
			io.output( "f4", bool_type ).connect( x >= 12.34f );
			io.output( "g4", bool_type ).connect( 12.34f <= x );

			io.output( "h4", bool_type ).connect( x  >= 3  );
			io.output( "i4", bool_type ).connect( x  >= 3l );
			io.output( "j4", bool_type ).connect( 3  <= x  );
			io.output( "k4", bool_type ).connect( 3l <= x  );

			//----- less than
			io.output( "a5", bool_type ).connect( x < y );
			io.output( "b5", bool_type ).connect( x < constant.var(12.34) );
			io.output( "c5", bool_type ).connect( constant.var(12.34) > x );
			io.output( "d5", bool_type ).connect( x < 12.34  );
			io.output( "e5", bool_type ).connect( 12.34 > x  );
			io.output( "f5", bool_type ).connect( x < 12.34f );
			io.output( "g5", bool_type ).connect( 12.34f > x );

			io.output( "h5", bool_type ).connect( x  < 3  );
			io.output( "i5", bool_type ).connect( x  < 3l );
			io.output( "j5", bool_type ).connect( 3  > x  );
			io.output( "k5", bool_type ).connect( 3l > x  );

			//----- less than or equal to
			io.output( "a6", bool_type ).connect( x <= y );
			io.output( "b6", bool_type ).connect( x <= constant.var(12.34) );
			io.output( "c6", bool_type ).connect( constant.var(12.34) >= x );
			io.output( "d6", bool_type ).connect( x <= 12.34  );
			io.output( "e6", bool_type ).connect( 12.34 >= x  );
			io.output( "f6", bool_type ).connect( x <= 12.34f );
			io.output( "g6", bool_type ).connect( 12.34f >= x );

			io.output( "h6", bool_type ).connect( x  <= 3  );
			io.output( "i6", bool_type ).connect( x  <= 3l );
			io.output( "j6", bool_type ).connect( 3  >= x  );
			io.output( "k6", bool_type ).connect( 3l >= x  );
		}
	}

	private static void runTest3( String main_name ) {
		String name = main_name + "_3";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEVectorTest3(paramsA), new DFEVectorTest3(paramsB) );
		setUpRandom();
		manager.logMsg( "*** Using random seed = " + m_seed );
		manager.setKernelCycles( data_len );

		double x[][] = initToRandomDbl( data_len, num_elements );
		double y[][] = initToRandomDbl( data_len, num_elements );
    	Bits[] bx = new Bits[data_len];
    	Bits[] by = new Bits[data_len];
    	for ( int i = 0 ; i < data_len ; i++ ) {
    		bx[i] = SimulationManager.packToBits( scalar_type, x[i] );
    		by[i] = SimulationManager.packToBits( scalar_type, y[i] );
    	}

    	manager.setInputDataRaw( "x", bx );
    	manager.setInputDataRaw( "y", by );
		manager.runTest();

		double z[][] = new double[data_len][num_elements];

		//----- equality
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] == y[i][j]) ? 1 : 0;
    	manager.checkOutputDataRaw( "a", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] == 12.34) ? 1 : 0;
    	manager.checkOutputDataRaw( "b", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "c", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "d", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "e", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] == 12.34f) ? 1 : 0;
    	manager.checkOutputDataRaw( "f", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "g", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] == 3) ? 1 : 0;
    	manager.checkOutputDataRaw( "h", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "i", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "j", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "k", convertToBits(z, dfeBool()) );

		//----- inequality
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] != y[i][j]) ? 1 : 0;
    	manager.checkOutputDataRaw( "a2", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] != 12.34) ? 1 : 0;
    	manager.checkOutputDataRaw( "b2", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "c2", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "d2", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "e2", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] != 12.34f) ? 1 : 0;
    	manager.checkOutputDataRaw( "f2", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "g2", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] != 3) ? 1 : 0;
    	manager.checkOutputDataRaw( "h2", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "i2", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "j2", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "k2", convertToBits(z, dfeBool()) );


		//----- greater than
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] > y[i][j]) ? 1 : 0;
    	manager.checkOutputDataRaw( "a3", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] > 12.34) ? 1 : 0;
    	manager.checkOutputDataRaw( "b3", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "c3", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "d3", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "e3", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] > 12.34f) ? 1 : 0;
    	manager.checkOutputDataRaw( "f3", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "g3", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] > 3) ? 1 : 0;
    	manager.checkOutputDataRaw( "h3", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "i3", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "j3", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "k3", convertToBits(z, dfeBool()) );

		//----- greater than or equal to
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] >= y[i][j]) ? 1 : 0;
    	manager.checkOutputDataRaw( "a4", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] >= 12.34) ? 1 : 0;
    	manager.checkOutputDataRaw( "b4", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "c4", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "d4", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "e4", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] >= 12.34f) ? 1 : 0;
    	manager.checkOutputDataRaw( "f4", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "g4", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] >= 3) ? 1 : 0;
    	manager.checkOutputDataRaw( "h4", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "i4", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "j4", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "k4", convertToBits(z, dfeBool()) );

		//----- less than
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] < y[i][j]) ? 1 : 0;
    	manager.checkOutputDataRaw( "a5", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] < 12.34) ? 1 : 0;
    	manager.checkOutputDataRaw( "b5", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "c5", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "d5", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "e5", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] < 12.34f) ? 1 : 0;
    	manager.checkOutputDataRaw( "f5", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "g5", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] < 3) ? 1 : 0;
    	manager.checkOutputDataRaw( "h5", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "i5", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "j5", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "k5", convertToBits(z, dfeBool()) );

		//----- less than or equal to
		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] <= y[i][j]) ? 1 : 0;
    	manager.checkOutputDataRaw( "a6", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
    			z[i][j] = (x[i][j] <= 12.34) ? 1 : 0;
    	manager.checkOutputDataRaw( "b6", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "c6", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "d6", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "e6", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] <= 12.34f) ? 1 : 0;
    	manager.checkOutputDataRaw( "f6", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "g6", convertToBits(z, dfeBool()) );

		for ( int i=0 ; i<data_len ; i++ )
    		for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (x[i][j] <= 3) ? 1 : 0;
    	manager.checkOutputDataRaw( "h6", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "i6", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "j6", convertToBits(z, dfeBool()) );
    	manager.checkOutputDataRaw( "k6", convertToBits(z, dfeBool()) );

		System.out.println("Test 3 OK!");
	}

	private static class DFEVectorTest4 extends Kernel {
		@SuppressWarnings("deprecation")
		protected DFEVectorTest4( KernelParameters parameters ) {
			super(parameters);

			//----- tests for logical operators
			DFEVector<DFEVar> x = io.input( "x", int_element );
			DFEVector<DFEVar> y = io.input( "y", int_element );

			//----- or
			io.output( "a", int_element ).connect( x | y );
			io.output( "b", int_element ).connect( x | constant.var(21845) );
			io.output( "c", int_element ).connect( constant.var(21845) | x );
			io.output( "d", int_element ).connect( x | 21845.0  );
			io.output( "e", int_element ).connect( 21845.0 | x  );
			io.output( "f", int_element ).connect( x | 21845.0f );
			io.output( "g", int_element ).connect( 21845.0f | x );

			io.output( "h", int_element ).connect( x  | 21845  );
			io.output( "i", int_element ).connect( x  | 21845l );
			io.output( "j", int_element ).connect( 21845  | x  );
			io.output( "k", int_element ).connect( 21845l | x  );

			io.output( "l", int_element ).connect( true | x  );
			io.output( "m", int_element ).connect( x | true  );

			//----- and
			io.output( "a2", int_element ).connect( x & y );
			io.output( "b2", int_element ).connect( x & constant.var(21845) );
			io.output( "c2", int_element ).connect( constant.var(21845) & x );
			io.output( "d2", int_element ).connect( x & 21845.0  );
			io.output( "e2", int_element ).connect( 21845.0 & x  );
			io.output( "f2", int_element ).connect( x & 21845.0f );
			io.output( "g2", int_element ).connect( 21845.0f & x );

			io.output( "h2", int_element ).connect( x  & 21845  );
			io.output( "i2", int_element ).connect( x  & 21845l );
			io.output( "j2", int_element ).connect( 21845  & x  );
			io.output( "k2", int_element ).connect( 21845l & x  );

			io.output( "l2", int_element ).connect( true & x  );
			io.output( "m2", int_element ).connect( x & true  );

			//----- xor
			io.output( "a3", int_element ).connect( x ^ y );
			io.output( "b3", int_element ).connect( x ^ constant.var(21845) );
			io.output( "c3", int_element ).connect( constant.var(21845) ^ x );
			io.output( "d3", int_element ).connect( x ^ 21845.0  );
			io.output( "e3", int_element ).connect( 21845.0 ^ x  );
			io.output( "f3", int_element ).connect( x ^ 21845.0f );
			io.output( "g3", int_element ).connect( 21845.0f ^ x );

			io.output( "h3", int_element ).connect( x  ^ 21845  );
			io.output( "i3", int_element ).connect( x  ^ 21845l );
			io.output( "j3", int_element ).connect( 21845  ^ x  );
			io.output( "k3", int_element ).connect( 21845l ^ x  );

			io.output( "l3", int_element ).connect( true ^ x  );
			io.output( "m3", int_element ).connect( x ^ true  );

			//----- complement
			io.output( "a4", int_element ).connect( ~x );


			//----- tests for bit-shift operators
			DFEVector<DFEVar> shift = (y - ((y >> 4) << 4)).cast( shift_element );
			io.output( "shift", shift_element ).connect( shift );

			//----- shift left
			io.output( "a5", int_element ).connect( x << shift );
			io.output( "b5", int_element ).connect( x << constant.var(4) );
			io.output( "c5", int_element ).connect( x << 4 );
			// deprecated...
			io.output( "d5", int_element ).connect( x.leftShift(shift) );
			io.output( "e5", int_element ).connect( x.leftShift( constant.var(4) ) );
			io.output( "f5", int_element ).connect( x.leftShift( 4 ) );

			//----- shift right
			io.output( "a6", int_element ).connect( x >> shift );
			io.output( "b6", int_element ).connect( x >> constant.var(4) );
			io.output( "c6", int_element ).connect( x >> 4 );
			// deprecated...
			io.output( "d6", int_element ).connect( x.rightShift(shift) );
			io.output( "e6", int_element ).connect( x.rightShift( constant.var(4) ) );
			io.output( "f6", int_element ).connect( x.rightShift( 4 ) );

			DFEVar cnst = constant.var( dfeUInt(16), 4 );
			cnst.setReportOnUnused( false );
			DFEVector<DFEVar> bad_shift = (new DFEVectorType<DFEVar>(dfeUInt(16), num_elements-1) ).newInstance(this, cnst);
			try {
				DFEVector<DFEVar> lbad = x << bad_shift;
				lbad.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg( "successfully caught exception: " + e );
			}
			try {
				DFEVector<DFEVar> rbad = x >> bad_shift;
				rbad.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg( "successfully caught exception: " + e );
			}

			//----- ternary if
			io.output( "a7", int_element ).connect( x > y ? x : y );
			io.output( "b7", int_element ).connect( x > y ? x : constant.var(int_type,4) );
			io.output( "c7", int_element ).connect( x > y ? constant.var(int_type,4) : x );
			io.output( "d7", int_element ).connect( x > y ? constant.var(int_type,1) : constant.var(int_type,-1) );
			try {
				DFEVector<DFEVar> t1 = x ? x : y;
				t1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg( "successfully caught exception: " + e );
			}
			try {
				DFEVector<DFEVar> bad_elements = (new DFEVectorType<DFEVar>(dfeUInt(16), num_elements-1) ).newInstance(this, cnst);
				DFEVector<DFEVar> t2 = x > 100 ? x : bad_elements;
				t2.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg( "successfully caught exception: " + e );
			}

		}

	}

	private static void runTest4( String main_name ) {
		String name = main_name + "_4";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEVectorTest4(paramsA), new DFEVectorTest4(paramsB) );
		setUpRandom();
		manager.logMsg( "*** Using random seed = " + m_seed );
		manager.setKernelCycles( data_len );

		double x[][] = initToRandomInt( data_len, num_elements );
		double y[][] = initToRandomInt( data_len, num_elements );
		Bits[] bx = convertToBits( x, int_type );
		Bits[] by = convertToBits( y, int_type );
		manager.setInputDataRaw( "x", bx );
		manager.setInputDataRaw( "y", by );
		manager.runTest();

		double z[][] = new double[data_len][num_elements];
		Bits[] zbits;

		//----- or
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] | (int)y[i][j];
		manager.checkOutputDataRaw( "a", convertToBits(z, int_type) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] | 21845;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "b", zbits );
		manager.checkOutputDataRaw( "c", zbits );
		manager.checkOutputDataRaw( "d", zbits );
		manager.checkOutputDataRaw( "e", zbits );
		manager.checkOutputDataRaw( "f", zbits );
		manager.checkOutputDataRaw( "g", zbits );
		manager.checkOutputDataRaw( "h", zbits );
		manager.checkOutputDataRaw( "i", zbits );
		manager.checkOutputDataRaw( "j", zbits );
		manager.checkOutputDataRaw( "k", zbits );
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] | 1;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "l", zbits );
		manager.checkOutputDataRaw( "m", zbits );

		//----- and
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] & (int)y[i][j];
		manager.checkOutputDataRaw( "a2", convertToBits(z, int_type) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] & 21845;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "b2", zbits );
		manager.checkOutputDataRaw( "c2", zbits );
		manager.checkOutputDataRaw( "d2", zbits );
		manager.checkOutputDataRaw( "e2", zbits );
		manager.checkOutputDataRaw( "f2", zbits );
		manager.checkOutputDataRaw( "g2", zbits );
		manager.checkOutputDataRaw( "h2", zbits );
		manager.checkOutputDataRaw( "i2", zbits );
		manager.checkOutputDataRaw( "j2", zbits );
		manager.checkOutputDataRaw( "k2", zbits );
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] & 1;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "l2", zbits );
		manager.checkOutputDataRaw( "m2", zbits );

		//----- xor
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] ^ (int)y[i][j];
		manager.checkOutputDataRaw( "a3", convertToBits(z, int_type) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] ^ 21845;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "b3", zbits );
		manager.checkOutputDataRaw( "c3", zbits );
		manager.checkOutputDataRaw( "d3", zbits );
		manager.checkOutputDataRaw( "e3", zbits );
		manager.checkOutputDataRaw( "f3", zbits );
		manager.checkOutputDataRaw( "g3", zbits );
		manager.checkOutputDataRaw( "h3", zbits );
		manager.checkOutputDataRaw( "i3", zbits );
		manager.checkOutputDataRaw( "j3", zbits );
		manager.checkOutputDataRaw( "k3", zbits );
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] ^ 1;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "l3", zbits );
		manager.checkOutputDataRaw( "m3", zbits );

		//----- complement
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = ~((int) x[i][j]);
		manager.checkOutputDataRaw( "a4", convertToBits(z, int_type) );

		//----- shift stream values
		double[][] shift = new double[data_len][num_elements];
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				shift[i][j] = y[i][j] % 16;

		manager.checkOutputDataRaw( "shift", convertToBits(shift, dfeUInt(5)) );
		for ( Bits b : manager.getOutputDataRaw("shift") )
			System.out.println( "shift values = " + shift_element.decodeConstant(b) );

		//----- shift left
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int)x[i][j] << (int)shift[i][j];
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "a5", zbits );
		manager.checkOutputDataRaw( "d5", zbits );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int)x[i][j] << 4;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "b5", zbits );
		manager.checkOutputDataRaw( "c5", zbits );
		manager.checkOutputDataRaw( "e5", zbits );
		manager.checkOutputDataRaw( "f5", zbits );

		//----- shift right
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int)x[i][j] >> (int)shift[i][j];
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "a6", zbits );
		manager.checkOutputDataRaw( "d6", zbits );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int)x[i][j] >> 4;
		zbits = convertToBits( z, int_type );
		manager.checkOutputDataRaw( "b6", zbits );
		manager.checkOutputDataRaw( "c6", zbits );
		manager.checkOutputDataRaw( "e6", zbits );
		manager.checkOutputDataRaw( "f6", zbits );

		//----- ternary if
		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = x[i][j] > y[i][j] ? x[i][j] : y[i][j];
		manager.checkOutputDataRaw( "a7", convertToBits(z, int_type) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = x[i][j] > y[i][j] ? x[i][j] : 4;
		manager.checkOutputDataRaw( "b7", convertToBits(z, int_type) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = x[i][j] > y[i][j] ? 4 : x[i][j];
		manager.checkOutputDataRaw( "c7", convertToBits(z, int_type) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = x[i][j] > y[i][j] ? 1 : -1;
		manager.checkOutputDataRaw( "d7", convertToBits(z, int_type) );

		System.out.println("Test 4 OK!");
	}

	private static class DFEVectorTest5 extends Kernel {

		protected DFEVectorTest5( KernelParameters parameters ) {
			super(parameters);

			//----- slice and cat tests
			DFEVector<DFEVar> x      = io.input( "x", uint_element );
			DFEVar             zero   = constant.var( dfeUInt(1), 0 );

			int nbits = uint_element.getContainedType().getTotalBits();
			DFEVectorType<DFEVar> uint_element_minus_1 = new DFEVectorType<DFEVar>( dfeUInt(nbits-1), num_elements);
			DFEVectorType<DFEVar> uint_element_plus_1  = new DFEVectorType<DFEVar>( dfeUInt(nbits+1), num_elements);

			io.output( "a", uint_element_minus_1 ).connect( x.slice(1,nbits-1).cast( uint_element_minus_1 ) );
			io.output( "b", uint_element_plus_1  ).connect( x.cat(zero).cast( uint_element_plus_1 ) );
			io.output( "c", uint_element_plus_1  ).connect( x.catAsRHS(zero).cast( uint_element_plus_1 ) );
		}

	}

	private static void runTest5( String main_name ) {
		String name = main_name + "_5";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters       paramsA = manager.makeKernelParameters_A();
		KernelParameters       paramsB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEVectorTest5(paramsA), new DFEVectorTest5(paramsB) );
		setUpRandom();
		manager.logMsg( "*** Using random seed = " + m_seed );
		manager.setKernelCycles( data_len );

		double x[][] = initToRandomInt( data_len, num_elements );
		manager.setInputDataRaw( "x", convertToBits(x,uint_type) );
		manager.runTest();

		double z[][] = new double[data_len][num_elements];

		int nbits = uint_element.getContainedType().getTotalBits();
//		DFEVectorType<DFEVar> uint_element_minus_1 = new DFEVectorType<DFEVar>( hwUInt(nbits-1), num_elements);
//		DFEVectorType<DFEVar> uint_element_plus_1  = new DFEVectorType<DFEVar>( hwUInt(nbits+1), num_elements);
//		for ( Bits b : manager.getOutputDataRaw("a") )
//			System.out.println( "sliced values = " + uint_element_minus_1.decodeConstant(b) );
//		for ( Bits b : manager.getOutputDataRaw("b") )
//			System.out.println( "cat (x.zero) values = " + uint_element_plus_1.decodeConstant(b) );
//		for ( Bits b : manager.getOutputDataRaw("c") )
//			System.out.println( "cat (zero.x) values = " + uint_element_plus_1.decodeConstant(b) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) (x[i][j] / 2);
		manager.checkOutputDataRaw( "a", convertToBits(z, dfeUInt(nbits-1) ) );

		for ( int i=0 ; i<data_len ; i++ )
			for ( int j=0 ; j<num_elements ; j++ )
				z[i][j] = (int) x[i][j] * 2;
		manager.checkOutputDataRaw( "b", convertToBits(z, dfeUInt(nbits+1) ) );

		manager.checkOutputDataRaw( "c", convertToBits(x, dfeUInt(nbits+1) ) );

		System.out.println("Test 5 OK!");
	}


	public static void main( String[] args ) {
    	String name = "DFEVectorTest";
    	runTest1( name );
    	runTest2( name );
    	runTest3( name );
    	runTest4( name );
    	runTest5( name );
		System.out.println( "All tests OK!" );
    	System.exit( 0 );
    }

	private static Bits[] convertToBits( double[][] x, DFEType hwtype ) {
    	Bits[] bx = new Bits[ x.length ];
    	for ( int i = 0 ; i < x.length ; i++ ) {
    		bx[i] = SimulationManager.packToBits( hwtype, x[i] );
    	}
		return bx;
	}

	@SuppressWarnings("unused")
	private static void printArrayValues( String title, double[][] x) {
		System.out.println( title + " = {" );
		for ( int i = 0 ; i < x.length ; i++ ) {
			for ( int j = 0 ; j <x[i].length ; j++ ) {
				System.out.printf( "    [%2d][%2d] = %f\n", i, j, x[i][j] );
			}
		}
		System.out.println( "}" );
	}

	private static Double[] doubleToDouble( double[] x ) {
		Double[] X = new Double[ x.length ];
		for ( int i = 0 ; i < x.length ; i++ ) {
			X[i] = new Double( x[i] );
		}
		return X;
	}

	private static double[][] initToRandomDbl( int len, int wid ) {
		double[][] arr = new double[len][wid];
		for ( int i = 0 ; i < len ; i++ ) {
			for ( int j = 0 ; j < wid ; j++ ) {
				arr[i][j] = m_random.nextDouble()*100.0 + 0.001; // ensure no zeroes for when using as denominator
			}
		}
//		printArrayValues("initToRandom", arr );
		return arr;
	}

	private static double[][] initToRandomInt( int len, int wid ) {
		double[][] arr = new double[len][wid];
		for ( int i = 0 ; i < len ; i++ ) {
			for ( int j = 0 ; j < wid ; j++ ) {
				arr[i][j] = m_random.nextInt( 65536 );
			}
		}
//		printArrayValues("initToRandom", arr );
		return arr;
	}

	private static void setUpRandom() {
		if ( m_random == null ) {
			m_seed = System.currentTimeMillis();
		}
		//----- re-create Random with same seed for each test
		m_random = new Random( m_seed );
	}

}
