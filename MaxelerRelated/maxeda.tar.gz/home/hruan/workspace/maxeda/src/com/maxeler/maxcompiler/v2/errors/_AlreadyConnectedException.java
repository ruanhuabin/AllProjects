package com.maxeler.maxcompiler.v2.errors;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct;

public class _AlreadyConnectedException extends MaxCompilerAPIError {
	public static final long serialVersionUID = 1L;

	public final KernelObject<?> object;
	private final String fieldName;

	public _AlreadyConnectedException(KernelObject<?> newObject, String fieldName, _AlreadyConnectedException ex) {
		super(newObject.getKernel().getManager(), "%s.%s is already connected", objectType(newObject), fieldName);
		object = newObject;
		String s = "." + fieldName;
		this.fieldName = ex.fieldName == null ? s : s + ex.fieldName;
	}

	public _AlreadyConnectedException(KernelObject<?> newObject, int index, _AlreadyConnectedException ex) {
		super(newObject.getKernel().getManager(), "%s[%d] is already connected", objectType(newObject), index);
		object = newObject;
		String s = "[" + index + "]";
		this.fieldName = ex.fieldName == null ? s : s + ex.fieldName;
	}

	public _AlreadyConnectedException(KernelObject<?> object) {
		super(object.getKernel().getManager(), "%s is already connected", objectType(object));
		this.object = object;
		fieldName = null;
	}

	private static String objectType(KernelObject<?> object) {
		if (object instanceof DFEArray<?>)
			return "array";
		if (object instanceof DFEVector<?>)
			return "pipe";
		if (object instanceof DFEStruct)
			return "struct";

		return "KernelObject";
	}

}
