package com.maxeler.maxcompiler.v2.kernelcompiler;

import java.util.HashMap;
import java.util.Map;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmInput;
import com.maxeler.photon.core.Var;
import com.maxeler.photon.nodes.NodeStateMachine;
import com.maxeler.statemachine.Utils;

public class SMIO {
	private final KernelLib m_kernelLib;
	private final NodeStateMachine m_node;
	private final Map<String, DFEVar> m_inputs = new HashMap<String, DFEVar>();

	SMIO(KernelLib kernelLib, NodeStateMachine node) {
		m_kernelLib = kernelLib;
		m_node = node;

		// workaround for the way Photon nodes are typed (see #3046): ensure
		// that all inputs to the node are connected before outputs are connected
		for (DFEsmInput input : node.getStateMachine().io.getInputs().values()) {
			String name = input.getName();
			DFEType type = _KernelBaseTypes.fromImp(Utils.convertToHWType(input.getType()));
			DFEVar v = type.newInstance(m_kernelLib);

			m_inputs.put(name, v);
			m_node.connectInput(name, _KernelBaseTypes.toImp(v));
		}
	}

	public void connectInput(String name, DFEVar input) {
		getInput(name).connect(input);
	}

	public DFEVar getInput(String name) {
		DFEVar v = m_inputs.get(name);
		if (v == null)
			throw new MaxCompilerAPIError("State machine '%s' does not have an input named '%s'.", m_node.getName(), name);
		return v;
	}

	public DFEVar getOutput(String name) {
		if (!m_node.getStateMachine().io.getOutputs().containsKey(name))
			throw new MaxCompilerAPIError("State machine '%s' does not have an output named '%s'.", m_node.getName(), name);

		Var v = m_node.connectOutput(name);
		return _KernelBaseTypes.fromImp(m_kernelLib, v);
	}

	@Override
	public String toString() { return m_node.getName(); }
}
