package com.maxeler.maxcompiler.v2.statemachine.types;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;

public final class DFEsmValueType extends DFEsmType {

	public static enum SignMode {
		Signed,
		Unsigned
	}

	private final int m_numBits;
	private final SignMode m_signMode;

	DFEsmValueType(int numBits, SignMode signMode) {
		if (signMode == null)
			throw new MaxCompilerAPIError("Parameter signMode must not be null.");
		m_numBits = numBits;
		m_signMode = signMode;
	}

	/**
	 * Is this type signed?
	 * @return {@code true} if this type is signed, otherwise {@code false}.
	 */
	public SignMode getSignMode() { return m_signMode; }

	/**
	 * Get the number of bits used by this type.
	 * @return The number of bits used by this type. This is always a positive
	 * value.
	 */
	public int getTotalBits() { return m_numBits; }

	/**
	 * Returns true if the type is boolean.
	 * @return {@code true} bitwidth == 1 && unsigned, otherwise {@code false}
	 */
	public boolean isBool() { return getTotalBits() == 1 && m_signMode == SignMode.Unsigned; }

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof DFEsmValueType))
			return false;

		DFEsmValueType t = (DFEsmValueType) o;

		return getTotalBits() == t.getTotalBits() && m_signMode == t.m_signMode;
	}

	@Override
	public int hashCode() { return getTotalBits() * 31 + (m_signMode == SignMode.Signed ? 1 : 0); }

	@Override
	public String toString() { return (m_signMode == SignMode.Signed ? "sm" : "smU") + "Int(" + getTotalBits() + ")"; }
}
