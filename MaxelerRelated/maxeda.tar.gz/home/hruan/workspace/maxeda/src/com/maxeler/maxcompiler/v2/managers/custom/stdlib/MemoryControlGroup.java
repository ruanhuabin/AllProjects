package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.maxeleros.managercompiler.libs.MemoryControllerDefinition.VirtualDIMM;
import com.maxeler.maxeleros.managercompiler.libs.MemoryControllerDefinition.VirtualDIMM.MemoryCommandDefinition;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeAddrGen;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeAddrGen1DLinear;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeAddrGen2DStrided;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeAddrGen3DBlocking;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeOutputFlexibleClock;

public class MemoryControlGroup {
	private final String m_name;
	private final ControlSource m_control_source;
	private final VirtualDIMM m_dimm;
	private final String m_string_type;
	private final Map<String, Integer> m_data_stream_id =
		new LinkedHashMap<String, Integer>();
	private String m_reg_name = "NONE";  // register prefix for address generators
	private int m_stream_count = 0;
	private final boolean m_support_single_stream_only;
	private final List<WrapperNodeOutputFlexibleClock> m_control_stream_nodes = new LinkedList<WrapperNodeOutputFlexibleClock>();
	private boolean m_is_final = false;

	private final WrapperNodeAddrGen m_addr_gen;

	public enum MemoryAccessPattern  {
		LINEAR_1D,  // new full linear 1d with wrap and pantograph support
		STRIDE_2D,
		BLOCKING_3D
	}

	abstract private class ControlSource {
		abstract MemoryCommandDefinition getCommandDefForDataStream(String data_stream_name, boolean is_read_stream);

		abstract void finalise();
	}

	public int getStreamIndexIdWithinGroup(String name) {
		if (!m_is_final)
			throw new MaxCompilerAPIError("You must call finalise() on a MemoryControlGroup before getting the index of a stream within the group.");
		if (! m_data_stream_id.containsKey(name))
			throw new MaxCompilerAPIError("MemoryControlGroup '" + m_name + "' does not contain stream '" + name + "'");
		return m_data_stream_id.get(name);
	}

	Set<String> getStreams() {
		return Collections.unmodifiableSet(m_data_stream_id.keySet());
	}

	String getControllerName() {
		return m_dimm.getName();
	}

	String getRegName() {
		return m_reg_name;
	}

	boolean isStreamSource() {
		return m_control_source instanceof StreamControlSource;
	}

	private class StreamControlSource extends ControlSource {
		private final MemoryCommandDefinition m_def;
		private final LinkedList<String> m_read_streams = new LinkedList<String>();
		private final LinkedList<String> m_write_streams = new LinkedList<String>();

		StreamControlSource(DFELink control_stream) {
			m_def = m_dimm.addCommandDefinition(m_name);
			m_control_stream_nodes.add(m_def.getNode());
			m_def.getControlStream().connect(_CustomManagers.streamToImp(control_stream));
		}

		@Override
		MemoryCommandDefinition getCommandDefForDataStream(String dataStreamName, boolean is_read_stream) {
			if (is_read_stream) {
				m_read_streams.add(dataStreamName);
			} else {
				m_write_streams.add(dataStreamName);
			}
			return m_def;
		}

		@Override
		void finalise() {
			int idx=0;
			for (String st_name : m_read_streams) {
				m_data_stream_id.put(st_name, idx++);
			}
			for (String st_name : m_write_streams) {
				m_data_stream_id.put(st_name, idx++);
			}
		}
	}

	private class Block3DControlSource extends ControlSource {
		WrapperNodeAddrGen3DBlocking m_addrgen;

		public Block3DControlSource(WrapperNodeAddrGen3DBlocking addrgen) {
			m_addrgen = addrgen;
		}

		@Override
		MemoryCommandDefinition getCommandDefForDataStream(String dataStreamName, boolean is_read_stream) {
			int index = m_addrgen.addAddrgenOutput();
			MemoryCommandDefinition def = m_dimm.addCommandDefinition(m_name + "_" + index);
			m_control_stream_nodes.add(def.getNode());
			def.getControlStream().connect(m_addrgen.getOutput(index));
			m_data_stream_id.put(dataStreamName, index);
			return def;
		}

		@Override
		void finalise() {

		}
	}

	private class Linear1DControlSource extends ControlSource {
		WrapperNodeAddrGen1DLinear m_addrgen;

		public Linear1DControlSource(WrapperNodeAddrGen1DLinear addrgen) {
			m_addrgen = addrgen;
		}

		@Override
		MemoryCommandDefinition getCommandDefForDataStream(String dataStreamName, boolean is_read_stream) {
			int index = m_addrgen.addAddrgenOutput();
			MemoryCommandDefinition def = m_dimm.addCommandDefinition(m_name + "_" + index);
			m_control_stream_nodes.add(def.getNode());
			def.getControlStream().connect(m_addrgen.getOutput(index));
			m_data_stream_id.put(dataStreamName, index);
			return def;
		}

		@Override
		void finalise() {

		}
	}


	MemoryControlGroup(String name, DFELink control_stream, VirtualDIMM dimm) {
		m_name = name;
		m_dimm = dimm;

		m_control_source = new StreamControlSource(control_stream);
		m_support_single_stream_only = false;

		m_string_type = "STREAM";
		m_addr_gen = null;
	}

	public void finalise() {
		m_control_source.finalise();
		m_is_final = true;
	}

	String getName() {
		return m_name;
	}

	MemoryCommandDefinition addDataStream(String data_stream_name, boolean is_read_stream) {
		if (m_is_final)
			throw new MaxCompilerAPIError("It is not possible to add data streams to a memory control group after calling finalise()");
		if (m_support_single_stream_only && m_stream_count > 0) {
			throw new MaxCompilerAPIError("Memory Control Group '" + m_name + "' of type '" + m_string_type + "' does not support multiple data streams.");
		}
		m_stream_count++;
		return m_control_source.getCommandDefForDataStream(data_stream_name, is_read_stream);
	}

	String getType() {
		return m_string_type;
	}

	void setCommandStreamClock(WrapperClock clk) {
		for (WrapperNodeOutputFlexibleClock node : m_control_stream_nodes)
			node.setClock(clk);
		if (m_addr_gen != null)
			m_addr_gen.setClock(clk);
	}

	MemoryControlGroup(WrapperDesignData data, String name, MemoryAccessPattern pattern, VirtualDIMM dimm) {
		m_name = name;
		m_dimm = dimm;
		m_string_type = pattern.toString();

		switch(pattern) {
			case STRIDE_2D:
				WrapperNodeAddrGen2DStrided addrgen_2d = new WrapperNodeAddrGen2DStrided(data, "addrgen_" + name);
				m_control_source = new StreamControlSource( _CustomManagers.fromImp(addrgen_2d.getOutput()));
				m_reg_name = addrgen_2d.getInstanceName() + "." + "AddrGen_" + addrgen_2d.getInstanceName();
				m_support_single_stream_only = true;
				m_addr_gen = addrgen_2d;
			break;
			case BLOCKING_3D:
				WrapperNodeAddrGen3DBlocking addrgen_3d = new WrapperNodeAddrGen3DBlocking(data, "addrgen_" + name);
				m_control_source = new Block3DControlSource(addrgen_3d);
				m_reg_name = "Block3DAddrGen.Blk3dAddrGen_" + addrgen_3d.getInstanceName();
				m_support_single_stream_only = false;
				m_addr_gen = addrgen_3d;
			break;
			case LINEAR_1D:
				WrapperNodeAddrGen1DLinear addrgen_1d = new WrapperNodeAddrGen1DLinear(data, "addrgen_" + name);
				m_control_source = new Linear1DControlSource(addrgen_1d);
				m_reg_name = "Linear1DAddrGen.Lin1dAddrGen_" + addrgen_1d.getInstanceName();
				m_support_single_stream_only = false;
				m_addr_gen = addrgen_1d;
			break;
			default:
				throw new MaxCompilerAPIError("Unknown memory access pattern");
		}
	}

}
