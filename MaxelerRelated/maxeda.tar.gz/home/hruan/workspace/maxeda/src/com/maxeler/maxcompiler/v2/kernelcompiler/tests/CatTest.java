package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.Arrays;
import java.util.List;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Bitops;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;

public class CatTest extends Kernel {

	@SuppressWarnings({"rawtypes", "unchecked"})
	protected CatTest(KernelParameters parameters) {
		super(parameters);

		DFEVar a = io.input("a", dfeUInt(4));
		DFEVar b = io.input("b", dfeUInt(4));

		io.output("ab", a.cat(b).cast(dfeUInt(8)), dfeUInt(8));
		io.output("abab", Bitops.concat(a, b, a, b).cast(dfeUInt(16)), dfeUInt(16));
		io.output("ababab", Bitops.concat( new DFEVar[]{a,b,a,b,a,b}).cast(dfeUInt(24)), dfeUInt(24));
		io.output(
			"abababab",
			Bitops.concat( ((List)Arrays.asList(new DFEVar[]{a,b,a,b,a,b,a,b}))).cast(dfeUInt(32)),
			dfeUInt(32));
	}

	public static void main(String[] args) {
		_DualSimulationManager m = new _DualSimulationManager("V1CatTest");

		m.setKernels(
			new CatTest(m.getManager_A().makeKernelParameters()),
			new CatTest(m.getManager_B().makeKernelParameters()));

		m.setInputData("a", 0xa);
		m.setInputData("b", 0xb);

		m.setKernelCycles(1);
		m.runTest();

		m.checkOutputData("ab", 0xab);
		m.checkOutputData("abab", 0xabab);
		m.checkOutputData("ababab", 0xababab);
		m.checkOutputData("abababab", 0xABABABABl);

		m.dumpOutput();

		m.logMsg("Test Okay!");
	}
}
