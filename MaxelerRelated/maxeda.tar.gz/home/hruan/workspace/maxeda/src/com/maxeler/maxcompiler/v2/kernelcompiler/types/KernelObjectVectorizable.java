package com.maxeler.maxcompiler.v2.kernelcompiler.types;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

/**
 * Interface implemented by all {@link KernelObject}s that can be used with {@code DFEVector}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public interface KernelObjectVectorizable<RealT> extends KernelObjectNotVector<RealT> {
	public RealT add(RealT rhs);
	public RealT add(double rhs);
	public RealT add(float rhs);
	public RealT add(int rhs);
	public RealT add(long rhs);
	public RealT addAsRHS(double lhs);
	public RealT addAsRHS(float lhs);
	public RealT addAsRHS(int lhs);
	public RealT addAsRHS(long lhs);

	public RealT sub(RealT rhs);
	public RealT sub(double rhs);
	public RealT sub(float rhs);
	public RealT sub(int rhs);
	public RealT sub(long rhs);
	public RealT subAsRHS(double lhs);
	public RealT subAsRHS(float lhs);
	public RealT subAsRHS(int lhs);
	public RealT subAsRHS(long lhs);

	public RealT mul(RealT rhs);
	public RealT mul(double rhs);
	public RealT mul(float rhs);
	public RealT mul(int rhs);
	public RealT mul(long rhs);
	public RealT mulAsRHS(double lhs);
	public RealT mulAsRHS(float lhs);
	public RealT mulAsRHS(int lhs);
	public RealT mulAsRHS(long lhs);

	public RealT div(RealT rhs);
	public RealT div(double rhs);
	public RealT div(float rhs);
	public RealT div(int rhs);
	public RealT div(long rhs);
	public RealT divAsRHS(double lhs);
	public RealT divAsRHS(float lhs);
	public RealT divAsRHS(int lhs);
	public RealT divAsRHS(long lhs);

	public RealT and(RealT rhs);
	public RealT and(double rhs);
	public RealT and(float rhs);
	public RealT and(int rhs);
	public RealT and(boolean rhs);
	public RealT and(long rhs);
	public RealT andAsRHS(double lhs);
	public RealT andAsRHS(float lhs);
	public RealT andAsRHS(int lhs);
	public RealT andAsRHS(boolean lhs);
	public RealT andAsRHS(long lhs);

	public RealT or(RealT rhs);
	public RealT or(double rhs);
	public RealT or(float rhs);
	public RealT or(int rhs);
	public RealT or(boolean rhs);
	public RealT or(long rhs);
	public RealT orAsRHS(double lhs);
	public RealT orAsRHS(float lhs);
	public RealT orAsRHS(int lhs);
	public RealT orAsRHS(boolean lhs);
	public RealT orAsRHS(long lhs);

	public RealT xor(RealT rhs);
	public RealT xor(double rhs);
	public RealT xor(float rhs);
	public RealT xor(int rhs);
	public RealT xor(boolean rhs);
	public RealT xor(long rhs);
	public RealT xorAsRHS(double lhs);
	public RealT xorAsRHS(float lhs);
	public RealT xorAsRHS(int lhs);
	public RealT xorAsRHS(boolean lhs);
	public RealT xorAsRHS(long lhs);

	public RealT lt(RealT rhs);
	public RealT lt(double rhs);
	public RealT lt(float rhs);
	public RealT lt(int rhs);
	public RealT lt(long rhs);
	public RealT ltAsRHS(double lhs);
	public RealT ltAsRHS(float lhs);
	public RealT ltAsRHS(int lhs);
	public RealT ltAsRHS(long lhs);

	public RealT lte(RealT rhs);
	public RealT lte(double rhs);
	public RealT lte(float rhs);
	public RealT lte(int rhs);
	public RealT lte(long rhs);
	public RealT lteAsRHS(double lhs);
	public RealT lteAsRHS(float lhs);
	public RealT lteAsRHS(int lhs);
	public RealT lteAsRHS(long lhs);

	public RealT gt(RealT rhs);
	public RealT gt(double rhs);
	public RealT gt(float rhs);
	public RealT gt(int rhs);
	public RealT gt(long rhs);
	public RealT gtAsRHS(double lhs);
	public RealT gtAsRHS(float lhs);
	public RealT gtAsRHS(int lhs);
	public RealT gtAsRHS(long lhs);

	public RealT gte(RealT rhs);
	public RealT gte(double rhs);
	public RealT gte(float rhs);
	public RealT gte(int rhs);
	public RealT gte(long rhs);
	public RealT gteAsRHS(double lhs);
	public RealT gteAsRHS(float lhs);
	public RealT gteAsRHS(int lhs);
	public RealT gteAsRHS(long lhs);

	/**
	 * Tests whether the current value in this stream is equal to the current value in stream {@code rhs}.
	 * @param rhs The stream to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eq(RealT rhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eq(double rhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eq(float rhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eq(int rhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eq(long rhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eq(boolean rhs);

	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eqAsRHS(double lhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eqAsRHS(float lhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eqAsRHS(int lhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eqAsRHS(long lhs);
	/**
	 * Tests whether the current value in this stream is equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are the same.
	 */
	public RealT eqAsRHS(boolean lhs);

	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the current value in stream {@code rhs}.
	 * @param rhs The stream to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neq(RealT rhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neq(double rhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neq(float rhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neq(int rhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neq(long rhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code rhs}.
	 * @param rhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neq(boolean rhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neqAsRHS(double lhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neqAsRHS(float lhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neqAsRHS(int lhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neqAsRHS(long lhs);
	/**
	 * Tests whether the current value in this stream is <em>not</em> equal to the value of the Java variable {@code lhs}.
	 * @param lhs The Java variable to compare against.
	 * @return An {@link DFEVar} stream of Boolean values, {@code true} indicating that the two values are <em>not</em> the same.
	 */
	public RealT neqAsRHS(boolean lhs);

	/*
	 * Generally RHS will be LSBs. Null should be handled and may result
	 * in a type change in the output. If null is not supported
	 * BitopsNodeFactory.concat() will not work.
	 */
	public RealT cat(RealT rhs);
	public RealT shiftLeft(DFEVar rhs);
	public RealT shiftLeft(int shift_amt);
	public RealT shiftRight(DFEVar rhs);
	public RealT shiftRight(int shift_amt);
	public RealT rotateLeft(DFEVar rhs);
	public RealT rotateLeft(int shift_amt);
	public RealT rotateRight(DFEVar rhs);
	public RealT rotateRight(int shift_amt);

	/**
	 * Inverts all the bits in this stream (~).
	 * <p>
	 * The {@code ~} operator is overloaded to call this method.
	 * <p>
	 * The output stream is of Kernel type {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits}.
	 */
	public RealT complement();

	/**
	 * Performs <em>arithmetic</em> (two's complement) negation (-) of the data in the stream.
	 * <p>
	 * The {@code -} operator is overloaded to call this method.
	 * <p>
	 * The output stream is of Kernel type {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits}.
	 */
	public RealT neg();
	public <T extends KernelObject<T>> T ternaryIf(T true_cond, T false_cond);
	public RealT slice(int base, int width);

	public KernelTypeVectorizable<RealT> getType();
}
