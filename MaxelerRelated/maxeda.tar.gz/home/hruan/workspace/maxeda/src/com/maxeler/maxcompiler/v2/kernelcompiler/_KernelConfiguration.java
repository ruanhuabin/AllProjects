package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.photon.configuration.MaxBoardModel;
import com.maxeler.photon.configuration.PhotonKernelConfiguration;
import com.maxeler.photon.configuration.PhotonKernelConfiguration.BuildTarget;

public final class _KernelConfiguration extends KernelConfiguration {

	public _KernelConfiguration() {
		super(PhotonKernelConfiguration.create());
	}

	public _KernelConfiguration(PhotonKernelConfiguration config) {
		super(config);
	}

	public static PhotonKernelConfiguration getPhotonKernelConfig(KernelConfiguration c) {
		if (c == null)
			return null;
		return c.m_configuration;
	}

	public static void setBoardModel(KernelConfiguration c, MaxBoardModel boardModel) {
		if (boardModel != null && c != null)
			c.m_configuration.setMaxBoard(boardModel);
	}

	public static void setBuildTarget(KernelConfiguration c, BuildTarget bt) {
		c.m_configuration.setBuildTarget(bt);
	}

}
