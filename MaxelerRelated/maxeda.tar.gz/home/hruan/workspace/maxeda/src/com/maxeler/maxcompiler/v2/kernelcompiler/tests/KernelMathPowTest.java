package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxblox.funceval.MathPow;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

public class KernelMathPowTest extends Kernel {

	public KernelMathPowTest(KernelParameters parameters, double base, DFEFloat inputType, DFEFloat outputType) {
		super(parameters);

		DFEVar x = io.input("x", inputType);

		io.output("exp", outputType) <== MathPow.pow(x, outputType, base);
	}

	/**
	 * Return next smallest value after x that has same number of bits set
	 * @param x
	 * @return
	 */
	private static long snoob(long x, int bit_width) {
		long mask = (1L << bit_width)-1;
		long smallest = (x & -x)&mask;
		long ripple = (x + smallest)&mask;
		long ones = x ^ ripple;
		ones = (ones >> 2)/smallest;
		return ripple | ones;
	}

	private static Bits getLargestValueBits(DFEFloat type) {
		Bits b = new Bits(type.getTotalBits());
		b.setBits(0);
		b.setBits(type.getMantissaBits()-1, type.getExponentBits(), (1L << type.getExponentBits())-2);
		return b;
	}

	private static Bits getSmallestValueBits(DFEFloat type) {
		Bits b = new Bits(type.getTotalBits());
		b.setBits(0);
		b.setBits(type.getMantissaBits()-1, 1, 1);
		return b;
	}

	private static double getLargestValue(DFEFloat type) {
		return type.decodeConstant(getLargestValueBits(type));
	}

	private static double getSmallestValue(DFEFloat type) {
		return type.decodeConstant(getSmallestValueBits(type));
	}

	private static double getUlpValue(DFEFloat type) {
		return Math.pow(2.0, 1-type.getMantissaBits());
	}

	private static void getInputData(DFEFloat type, int numBits, ArrayList<Bits> ar, boolean withNans) {
		int totBits = type.getTotalBits();

		if(numBits == 0) {
			Bits bits = new Bits(totBits, 0);
			if(withNans || !Double.isNaN(type.decodeConstant(bits))) {
				ar.add(bits);
			}
			Bits neg = new Bits(totBits, ~(0L));
			if(withNans || !Double.isNaN(type.decodeConstant(neg))) {
				ar.add(neg);
			}
		} else {
			long x = (1L << numBits) -1;
			boolean is = true;
			while(is) {
				Bits bits = new Bits(totBits, x);
				if(withNans || !Double.isNaN(type.decodeConstant(bits))) {
					ar.add(bits);
				}
				Bits neg = new Bits(totBits, ~x);
				if(withNans || !Double.isNaN(type.decodeConstant(neg))) {
					ar.add(neg);
				}
				long y = snoob(x, totBits);
				is = y > x;
				x = y;
			}
		}
	}

	static int test_count = 0;
	private static void test(double base, DFEFloat inputType, DFEFloat outputType, double maxUlpErrors) {
		String test_string = String.format("Testing: (%.16g, %s, %s)", base, inputType.toString(), outputType.toString());
		System.out.println(test_string);

		double smallestValue = getSmallestValue(outputType);
		double largestValue  = getLargestValue(outputType);
		double ulpValue      = getUlpValue(outputType);

		System.out.println("largestValue " + largestValue + " smallestValue " + smallestValue + " ulpValue " + ulpValue);

		SimulationManager manager = new SimulationManager("KernelMathPowTest" + test_count++);
		KernelMathPowTest kernel_a = new KernelMathPowTest(manager.makeKernelParameters(), base, inputType, outputType);
		manager.setKernel(kernel_a);

		ArrayList<Bits> data = new ArrayList<Bits>();
		for(int i = 0; i < 4; ++i) {
			getInputData(inputType, i, data, false);
		}

		manager.setInputDataRaw("x", data);
		manager.setKernelCycles(data.size());
		System.out.println("Num cycles: " + data.size());
		manager.runTest();

		List<Double> output = manager.getOutputData("exp");

		double log = Math.log(base);
		double max_error_rel = -1;
		double error_x = 0, error_hw = 0, error_sw = 0;
		Bits error_bits = null;
		for(int i = 0; i < data.size(); ++i) {
			double x = inputType.decodeConstant(data[i]);
			double exp_hw = output[i];
			double exp_sw = Math.exp(x*log);
			if(exp_sw > largestValue) {
				exp_sw = Double.POSITIVE_INFINITY;
			} else {
				exp_sw = outputType.decodeConstant(outputType.encodeConstant(Math.exp(x*log)));
			}
			double error_abs = Math.abs(exp_sw-exp_hw);
			double error_rel = error_abs/exp_sw;
			// over-ride the relative error for special cases
			if(Double.isInfinite(exp_sw)) {
				if(Double.isInfinite(exp_hw))
					error_rel = 0;
				else if(exp_hw == largestValue)
					error_rel = smallestValue;
				else
					error_rel = 1;
			} else if(Double.isInfinite(exp_hw)) {
				if(Double.isInfinite(exp_sw))
					error_rel = 0;
				else if(exp_sw == largestValue)
					error_rel = smallestValue;
				else
					error_rel = 1;
			}
			if(exp_sw == 0 || exp_hw == 0) {
				error_rel = error_abs;
			}
			if(error_rel > max_error_rel) {
				max_error_rel = error_rel;
				error_x = x;
				error_sw = exp_sw;
				error_hw = exp_hw;
				error_bits = data[i];
			}
		}

		String stars = "\n\n*******************************************************************\n\n";

		double max_allowed_error = maxUlpErrors*ulpValue;

		System.out.println(stars);
		System.out.printf("MAX: x %22.16g\t\tsw %22.16g\t\thw %22.16g\t\terror_rel %22.16g\t\tmax_allowed_error %22.16g\t\tbits %s",
			error_x, error_sw, error_hw, max_error_rel, max_allowed_error, error_bits.toString());
		System.out.println();
		if(max_error_rel < max_allowed_error) {
			System.out.println("TEST_PASSED " + test_string);
		} else {
			System.out.println("TEST FAILED");
			throw new RuntimeException("TEST FAILED " + test_string);
		}
		System.out.println(stars);


	}

	private static class Pair<A, B> {
		A a;
		B b;

		Pair(A a, B b) {
			this.a = a;
			this.b = b;
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		Pair[] tests = {
			new Pair<DFEFloat, Double>(Kernel.dfeFloat(7,  17), 2.),
			new Pair<DFEFloat, Double>(Kernel.dfeFloat(8,  24), 2.),
			new Pair<DFEFloat, Double>(Kernel.dfeFloat(7,  41), 2.),
			new Pair<DFEFloat, Double>(Kernel.dfeFloat(11, 46), 8.)
			};

		for(Pair<DFEFloat, Double> p : tests) {
			test(2.0   , p.a, p.a, p.b);
			test(Math.E, p.a, p.a, p.b);
		}
	}
}
