package com.maxeler.maxcompiler.v2.managers.engine_interfaces;
import com.maxeler.utils.EnumTranslator;

public enum ArrayOrdering {
	ColumnMajor, /**< C */
	RowMajor; /** FORTRAN, Matlab */

	static com.maxeler.maxeleros.managercompiler.software.modeinfo.ArrayOrdering toMaxelerOS(ArrayOrdering t)
	{
		return EnumTranslator.convert(
			t,
			com.maxeler.maxeleros.managercompiler.software.modeinfo.ArrayOrdering.class);
	}

	static ArrayOrdering fromMaxelerOS(com.maxeler.maxeleros.managercompiler.software.modeinfo.ArrayOrdering t)
	{
		return EnumTranslator.convert(t, ArrayOrdering.class);
	}

}
