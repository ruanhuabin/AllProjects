package com.maxeler.maxcompiler.v2.managers.engine_interfaces;

import com.maxeler.utils.EnumTranslator;

public class InterfaceParamArray {

	private final  com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParamArray m_impl;


	InterfaceParamArray(com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParamArray impl) {
		m_impl = impl;
	}


	com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParamArray getImpl() {
		return m_impl;
	}


	/**
	 * @return the CPU type of the InterfaceParam
	 */
	public CPUTypes getType() {
		return EnumTranslator.convert(m_impl.getType(), CPUTypes.class);
	}


	/**
	 * get a single element of the InterfaceParamArray
	 */
	public InterfaceParam get(int index) {
		return new InterfaceParam( m_impl.get(index) );
	}

	/**
	 * get a single element of the InterfaceParamArray
	 */
	public InterfaceParam get(InterfaceParam mp) {
		return new InterfaceParam( m_impl.get(mp.getImpl()) );
	}


	/**
	 * Set the maximum size of a InterfaceParamArray.
	 * <p>
	 * This is necessary when a InterfaceParamArray is indexed using <b>InterfaceParam</b>;
	 * when <b>integers</b> are used to index a InterfaceParamArray, the maximum size can
	 * be inferred from the maximum index used.
	 * @param maxSize the required size of the InterfaceParamArray.
	 */
	public void setMaxSize(int maxSize) {
		m_impl.setMaxSize(maxSize);
	}

}
