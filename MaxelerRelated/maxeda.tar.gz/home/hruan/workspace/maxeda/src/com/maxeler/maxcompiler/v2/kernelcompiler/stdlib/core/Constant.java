package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArrayType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplexType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStructType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.maxcompiler.v2.utils._Utils;
import com.maxeler.photon.core.Node;
import com.maxeler.photon.nodes.NodeConstantRawBits;

/**
 * Contains methods for creating constant streams of data.
 * <p>
 * {@code var} creates a stream of DFEVar values.
 * <p>
 * {@code vect} creates a vector stream.
 * <p>
 * {@code struct} creates a stream of {@link DFEStruct}s.
 * <p>
 * {@code cplx} creates a stream of {@link DFEComplex} values.
 * <p>
 * {@code array} creates a stream of {@link DFEArray}s.
 */
public class Constant {
	private final Kernel m_design;

	Constant(Kernel design) {
		m_design = design;
	}

	/**
	 * Creates a stream of an {@code DFEVar} constant of type {@code type}.
	 * @param type The type of the data in the stream.
	 * @param bits The value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVar var(DFEType type, Bits bits) {
		if(type.getTotalBits() != bits.getWidth())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Width of type " + type + " not equal to width of bits (" + bits + ")");

		if(!type.isConcreteType())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Type " + type + " not allowed when making constant from bits.");

		com.maxeler.utils.Bits bits_imp = _Utils.toImp(bits);
		if (!bits_imp.isAllBinary())
			throw new MaxCompilerAPIError(m_design.getManager(), "Bit string for constant (%s) contains bits which are not '0' or '1'.", bits);

		Node const_node = new NodeConstantRawBits(
			_Kernel.getPhotonDesignData(m_design),
			bits_imp,
			_KernelBaseTypes.toImp(type),
			false);

		return _KernelBaseTypes.fromImp(m_design, const_node.connectOutput("value"));
	}

	/**
	 * Creates a stream of a Boolean constant.
	 * @param value The Boolean constant.
	 * @return The output stream of constants.
	 */
	public DFEVar var(boolean value) {
		return DFETypeFactory.dfeBool().newInstance(m_design, value);
	}

	/**
	 * Creates a stream of an untyped {@code DFEVar} constant.
	 * @param value The Boolean constant.
	 * @return The output stream of constants.
	 */
	public DFEVar var(double value) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, value);
	}

	/**
	 * Creates a stream of an {@code DFEVar} constant of type {@code type}.
	 * @param type The type of the data in the stream.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVar var(DFEType type, double value) {
		return type.newInstance(m_design, value);
	}

	/**
	 * Creates a multipipe stream of a Boolean constant.
	 * @param n_elements The number of pipes.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVector<DFEVar> vect(int n_elements, boolean value) {
		return
			new DFEVectorType<DFEVar>(
				DFETypeFactory.dfeBool(),
				n_elements)
			.newInstance(m_design)
			.connect(var(value));
	}

	/**
	 * Creates a multipipe stream of an untyped {@code DFEVar} constant.
	 * @param n_elements The number of pipes.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVector<DFEVar> vect(int n_elements, double value) {
		return
			new DFEVectorType<DFEVar>(
				DFETypeFactory.dfeUntypedConst(),
				n_elements)
			.newInstance(m_design)
			.connect(var(value));
	}

	/**
	 * Creates a multipipe stream of an {@code DFEVar} constant of type {@code type}.
	 * @param n_elements The number of pipes.
	 * @param type The type of the data in the stream.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVector<DFEVar> vect(int n_elements, DFEType type, double value) {
		return
			new DFEVectorType<DFEVar>(
				type,
				n_elements)
			.newInstance(m_design)
			.connect(var(type, value));
	}

	/**
	 * Creates a multipipe stream of type {@code template_mp_type} of a Boolean constant.
	 * <p>
	 * The contained type in {@code template_mp_type} must be a Boolean {@code DFEType}, otherwise MaxCompiler
	 * will throw an exception.
	 * @param template_vect_type The multipipe type of the stream.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M vect(T template_vect_type, boolean value) {
		if(!(template_vect_type.getContainedType() instanceof DFEType) ||
			!((DFEType)template_vect_type.getContainedType()).isBool())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Cannot make a multi-pipe constant boolean from multi-pipe type: " + template_vect_type);

		return template_vect_type.newInstance(m_design, var(value));
	}

	/**
	 * Creates a multipipe stream of the type of object {@code template_mp} of a Boolean constant.
	 * <p>
	 * The contained type in {@code template_mp} must be a Boolean {@code DFEType}, otherwise MaxCompiler
	 * will throw an exception.
	 * @param template_vect_object The multipipe object from which the type of the stream will be inferred.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M vect(M template_vect_object, boolean value) {
		return vect(template_vect_object.getType(), value);
	}

	/**
	 * Creates a multipipe stream of type {@code template_mp_type} of an {@code DFEVar} constant.
	 * <p>
	 * The contained type in {@code template_mp_type} must be an {@code DFEType}, otherwise MaxCompiler
	 * will throw an exception.
	 * @param template_vect_type The multipipe type of the stream.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M vect(T template_vect_type, double value) {
		if( !(template_vect_type.getContainedType() instanceof DFEType) )
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Cannot make a multi-pipe constant from multi-pipe type: " + template_vect_type);

		return template_vect_type.newInstance(m_design, var( (DFEType)template_vect_type.getContainedType(), value));
	}

	/**
	 * Creates a multipipe stream of the type of object {@code template_mp} of an {@code DFEVar} constant.
	 * <p>
	 * The contained type in {@code template_mp} must be an {@code DFEType}, otherwise MaxCompiler
	 * will throw an exception.
	 * @param template_vect_object The multipipe object from which the type of the stream will be inferred.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M vect(M template_vect_object, double value) {
		return vect(template_vect_object.getType(), value);
	}

	/**
	 * Creates a stream of a {@code DFEComplex} constant.
	 * @param real The real value of the constant.
	 * @param imaginary The imaginary value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEComplex cplx(double real, double imaginary) {
		return cplx(DFETypeFactory.dfeUntypedConst(), real, imaginary);
	}

	/**
	 * Creates a stream of a {@code DFEComplex} constant with real and imaginary parts of type {@code type}.
	 * @param type The type of the real and imaginary parts of the complex number.
	 * @param real The real value of the constant.
	 * @param imaginary The imaginary value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEComplex cplx(DFEType type, double real, double imaginary) {
		DFEComplex inst =	new DFEComplexType(type, type).newInstance(m_design);

		inst.setReal(var(type, real));
		inst.setImaginary(var(type, imaginary));

		return inst;
	}

	/**
	 * Creates a stream of a {@code DFEComplex} constant of type {@code type}.
	 * @param type The type of the complex number.
	 * @param real The real value of the constant.
	 * @param imaginary The imaginary value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEComplex cplx(DFEComplexType type, double real, double imaginary) {
		DFEComplex inst =	type.newInstance(m_design);

		inst.setReal(var((DFEType)type.getRealType(), real));
		inst.setImaginary(var((DFEType)type.getImaginaryType(), imaginary));

		return inst;
	}

	/**
	 * Creates a stream of a {@code DFEComplex} constant of the type of the object {@code template_object}.
	 * @param template_object The complex number object from which to infer the type of the stream.
	 * @param real The real value of the constant.
	 * @param imaginary The imaginary value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEComplex cplx(DFEComplex template_object, double real, double imaginary) {
		DFEComplexType type = template_object.getType();

		return cplx(type, real, imaginary);
	}

	/**
	 * Creates a stream of a {@code DFEArray} of constants of type {@code type}.
	 * @param type The type of the elements in the array.
	 * @param values The constant values for the array.
	 * @return The output stream of constants.
	 */
	public DFEArray<DFEVar> array(DFEType type, double... values) {
		DFEArray<DFEVar> inst = new DFEArrayType<DFEVar>(type, values.length).newInstance(m_design);

		for(int i = 0; i < values.length; i++)
			inst.connect(i, var(type, values[i]));

		return inst;
	}

	/**
	 * Creates a stream of a {@code DFEArray} of untyped constants.
	 * <p>
	 * The elements of the array in the output stream are untyped, so either need to be cast to a type or used in an operation with a typed stream.
	 * @param values The constant values for the array.
	 * @return The output stream of constants.
	 */
	public DFEArray<DFEVar> array(double... values) {
		return array(DFETypeFactory.dfeUntypedConst(), values);
	}

	/**
	 * Creates a stream of a {@code DFEArray} of Boolean constants.
	 * @param values The constant Boolean values for the array.
	 * @return The output stream of constants.
	 */
	public DFEArray<DFEVar> array(boolean... values) {
		DFEArray<DFEVar> inst = new DFEArrayType<DFEVar>(DFETypeFactory.dfeBool(), values.length).newInstance(m_design);

		for(int i = 0; i < values.length; i++)
			inst.connect(i, var(values[i]));

		return inst;
	}

	private enum StructFieldValueType {BOOLEAN, DOUBLE};

	/**
	 * Represents a value to be stored in a field in a {@link DFEStruct}.
	 */
	public static class StructFieldValue {
		private final StructFieldValueType m_type;
		private final String m_field;
		private double m_double_value;
		private boolean m_bool_value;

		public StructFieldValue(String field, boolean value) {
			m_type = StructFieldValueType.BOOLEAN;
			m_field = field;
			m_bool_value = value;
		}

		public StructFieldValue(String field, double value) {
			m_type = StructFieldValueType.DOUBLE;
			m_field = field;
			m_double_value = value;
		}
	}

	/**
	 * Creates a constant Boolean value object for a field in a {@link DFEStruct}.
	 * @param field The name of the field in the structure.
	 * @param value The constant value for the field.
	 * @return A value structure for a {@link DFEStruct} field containing the constant.
	 */
	public static StructFieldValue sfv(String field, boolean value) {
		return new StructFieldValue(field, value);
	}

	/**
	 * Creates a constant value object for a field in a {@link DFEStruct}.
	 * @param field The name of the field in the structure.
	 * @param value The constant value for the field.
	 * @return A value structure for a {@link DFEStruct} field containing the constant.
	 */
	public static StructFieldValue sfv(String field, double value) {
		return new StructFieldValue(field, value);
	}

	/**
	 * Creates a stream of {@link DFEStruct}s with constant values in each of their fields.
	 * <p>
	 * Example usage:<br>
	 * <code>
	 * DFEStructType type = new DFEStructType(<br>
	 *     sft("a", dfeBool(),<br>
	 *     sft("b", dfeFloat(8, 24))<br>
	 * );<br>
	 * constant.struct(type, sfv("a", true), sfv("b", 20));
	 * </code>
	 * @param struct_type The type of the {@code DFEStruct}.
	 * @param field_values The constant values for each of the fields in the {@code DFEStruct}.
	 * @return The output stream of constants.
	 * @see #sfv(String, boolean)
	 * @see #sfv(String, double)
	 */
	public DFEStruct struct(DFEStructType struct_type, StructFieldValue... field_values) {
		if(field_values.length != struct_type.getNumberOfFields())
			throw new MaxCompilerAPIError(m_design.getManager(),"Incorrect number of field values specified for struct constant");

		DFEStruct res = struct_type.newInstance(m_design);

		for(StructFieldValue sfv : field_values) {
			KernelType<?> field_type = struct_type.getTypeForField(sfv.m_field);
			switch(sfv.m_type)
			{
				case BOOLEAN:
					if(!(field_type instanceof DFEType) ||
						(((DFEType)field_type).isConcreteType() &&
						!((DFEType)field_type).isBool()))
						throw new MaxCompilerAPIError(m_design.getManager(),
							"Required type for field '" + sfv.m_field + "' is " +
							field_type +
							" which is not compatible with boolean value specified.");

					res.set(sfv.m_field, var(sfv.m_bool_value));
					break;

				case DOUBLE:
					if(!(field_type instanceof DFEType))
						throw new MaxCompilerAPIError(m_design.getManager(),
							"Required type for field '" + sfv.m_field + "' is " +
							field_type +
							" which is not compatible with numeric value specified.");

					if( ((DFEType)field_type).isBool() &&
					    (sfv.m_double_value != 1.0 && sfv.m_double_value != 0.0))
						throw new MaxCompilerAPIError(m_design.getManager(),
							"Required field '" + sfv.m_field + "' is boolean but value " +
							"specified is " + sfv.m_double_value);

					res.set(sfv.m_field, var((DFEType)field_type, sfv.m_double_value));
					break;
			}
		}

		return res;
	}

	/**
	 * Creates a stream of {@code 0}s of any type.
	 * @param type The type of the data in the output stream.
	 * @return The output stream of {@code 0}s.
	 */
	public <T extends KernelObject<T>> T zero(KernelType<T> type) {
		Bits zero_bits = new Bits( type.getTotalBits() );
		zero_bits.setOthers(0);
		DFEVar zero_var = var(DFETypeFactory.dfeRawBits(zero_bits.getWidth()), zero_bits);
		return type.unpack(zero_var);
	}
}
