package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxConstantEncodingException;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.utils.Box;

/**
 * An array-like type for streams.
 * <p>
 * Each stream cycle, new values stream through every element of the array.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFEArrayType<ContainedT extends KernelObjectNotVector<ContainedT>> extends
	KernelTypeVectorizable<DFEArray<ContainedT>>
{
	private final int m_size;
	private final KernelType<ContainedT> m_contained_type;

	/**
	 * Creates a new {@code DFEArrayType} of the specified size and contained Kernel type.
	 * @param contained_type The Kernel type of the contained data.
	 * @param size The number of elements in the array type.
	 */
	public DFEArrayType(KernelType<ContainedT> contained_type, int size) {
		if(size < 1)
			throw new MaxCompilerAPIError("Cannot make a DFEArrayType of size < 1.");

		m_contained_type = contained_type;
		m_size = size;
	}

	@Override
	protected int realGetTotalBits() {
		return m_size * m_contained_type.getTotalBits();
	}

	@Override
	protected DFEArray<ContainedT> realUnpack(DFEVar src) {
		List<ContainedT> contained_elements =
			new ArrayList<ContainedT>(m_size);

		int base = 0;
		for(int i = 0; i < m_size; i++) {
			contained_elements.add(
				m_contained_type.unpack(
					src.slice(base, m_contained_type.getTotalBits())));

			base += m_contained_type.getTotalBits();
		}

		return new DFEArray<ContainedT>(
			contained_elements,
			this,
			new DFEArrayDoubtType(m_contained_type.getFullTypeWithoutDoubtInfo().getDoubtType(), m_size));
	}

	@Override
	protected DFEArray<ContainedT> realUnpackFromList(List<DFEVar> primitives) {
		List<ContainedT> contained_elements =
			new ArrayList<ContainedT>(m_size);

		DoubtType contained_doubt_type = null;

		int base = 0;
		for(int i = 0; i < m_size; i++) {
			int n_sub_elements = m_contained_type.getTotalPrimitives();
			List<DFEVar> sub_elements = primitives.subList(base, base + n_sub_elements);
			ContainedT element = m_contained_type.unpackFromList(sub_elements);
			contained_elements.add( element );
			contained_doubt_type = element.getDoubtType();

			base += m_contained_type.getTotalPrimitives();
		}

		return
			new DFEArray<ContainedT>(
				contained_elements,
				this,
				new DFEArrayDoubtType(contained_doubt_type, m_size));
	}

	@Override
	public DFEArray<ContainedT> newInstance(KernelLib design, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEArrayDoubtType))
			throw new MaxCompilerAPIError(design.getManager(),
				"DFEArrayType instances can only be made using DFEArrayDoubtType objects.");

		List<ContainedT> sourceless_elements =
			new ArrayList<ContainedT>(m_size);

		for(int i = 0; i < m_size; i++)
			sourceless_elements.add(m_contained_type.newInstance(design,((DFEArrayDoubtType)doubt_type).getContainedDoubtType()));

		return new DFEArray<ContainedT>(sourceless_elements, this, (DFEArrayDoubtType)doubt_type);
	}

	/**
	 * Returns the number of elements in the array type.
	 */
	public int getSize() {
		return m_size;
	}

	/**
	 * Gets the Kernel type of the data contained in the array type.
	 */
	public KernelType<ContainedT> getContainedType() {
		return m_contained_type;
	}

	/**
	 * Creates a stream of an array of constants.
	 * @param contained_elements A {@code List} containing the values of the constants.
	 * @return The output stream of constants.
	 */
	public static <T extends KernelObjectNotVector<T>> DFEArray<T> newInstance(
		List<T> contained_elements)
	{
		if(contained_elements.size() < 1)
			throw new MaxCompilerAPIError(
				"Cannot pre-init instance of DFEArray with less than 1 data item.");

		int size = contained_elements.size();

		KernelType<T> contained_type = contained_elements.get(0).getType();
		DFEArrayType<T> new_type =
			new DFEArrayType<T>(contained_type, size);

		return
			new DFEArray<T>(
				contained_elements,
				new_type,
				new DFEArrayDoubtType(contained_type.getFullTypeWithoutDoubtInfo().getDoubtType(), size));
	}

	/**
	 * Creates a stream of an array of constants.
	 * @param contained_elements An array containing the values of the constants.
	 * @return The output stream of constants.
	 */
	public static <T extends KernelObjectNotVector<T>> DFEArray<T> newInstance(
		T[] contained_elements)
	{
		return newInstance(Arrays.asList(contained_elements));
	}

	@Override
	public boolean equals(Object other_type) {
		return
			(other_type instanceof DFEArrayType) &&
			((DFEArrayType<?>)other_type).m_size == m_size &&
			((DFEArrayType<?>)other_type).m_contained_type.equals(m_contained_type);
	}

	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return
			(other_type instanceof DFEArrayType) &&
			((DFEArrayType<?>)other_type).m_size == m_size &&
			((DFEArrayType<?>)other_type).m_contained_type.equalsIgnoreMax(m_contained_type);
	}

	@Override
	public int hashCode() {
		return m_size * m_contained_type.hashCode();
	}

	/**
	 * Decode a constant value encoded using Bits into a {@code List} of values of the contained type.
	 * @param raw_bits The value to decode.
	 * @return The decoded array.
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public List decodeConstant(Bits raw_bits) {
		assertConcrete("decode constant");

		List sim_elements =	new ArrayList(m_size);

		int base = 0;
		for(int i = 0; i < m_size; i++) {
			Bits element_bits = raw_bits.getBitsRaw(base, m_contained_type.getTotalBits());
			Object decoded;

			if (m_contained_type instanceof DFERawBits)
				decoded = element_bits;
			else
				decoded = m_contained_type.decodeConstant(element_bits);

			sim_elements.add(decoded);

			base += m_contained_type.getTotalBits();
		}

		return sim_elements;
	}

	/**
	 * Encodes a {@code List} of constants into a single {@link Bits} value using this Kernel type scheme.
	 * @param value_list The constant values to encode.
	 * @return The encoded constant.
	 */
	public <T> Bits encodeConstant(List<T> value_list) {
		assertConcrete("encode constant");

		Bits res = new Bits(0);
		MaxConstantEncodingException caught_exception = null;

		if(value_list.size() != m_size)
			throw new MaxCompilerAPIError(
				"Size of list for DFEArray constant does not match size of array." +
				"List size: " + value_list.size() + ", DFEArray size: " + m_size);

		for(int i = 0; i < m_size; i++) {
			Bits bits;
			try {
				bits = m_contained_type.encodeConstant(value_list.get(i));
			}
			catch (MaxConstantEncodingException e) {
				bits = e.getPackedValue();
				caught_exception = e;
			}

			res = res.concat(bits);
		}

		if (caught_exception != null) {
			throw new MaxConstantEncodingException(
				caught_exception.isOverflow(),
				caught_exception.isUnderflow(),
				caught_exception.isCompleteFixedPointUnderflow(),
				caught_exception.isInvalidOp(),
				caught_exception.isNegativeToUnsigned(),
				caught_exception.getRelativeError(),
				res);
		}

		return res;
	}

	/**
	 * Encodes an array of constants into a single {@link Bits} value using this Kernel type scheme.
	 * @param value_array The constant values to encode.
	 * @return The encoded constant.
	 */
	public <T> Bits encodeConstant(T[] value_array) {
		assertConcrete("encode constant");

		Bits res = new Bits(0);
		MaxConstantEncodingException caught_exception = null;

		if(value_array.length != m_size)
			throw new MaxCompilerAPIError(
				"Size of array for DFEArray constant does not match size of array." +
				"Array size: " + value_array.length + ", DFEArray size: " + m_size);

		for(Object o : value_array) {
			Bits bits;
			try {
				bits = m_contained_type.encodeConstant(o);
			}
			catch (MaxConstantEncodingException e) {
				bits = e.getPackedValue();
				caught_exception = e;
			}

			res = res.concat(bits);
		}

		if (caught_exception != null) {
			throw new MaxConstantEncodingException(
				caught_exception.isOverflow(),
				caught_exception.isUnderflow(),
				caught_exception.isCompleteFixedPointUnderflow(),
				caught_exception.isInvalidOp(),
				caught_exception.isNegativeToUnsigned(),
				caught_exception.getRelativeError(),
				res);
		}

		return res;
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value using this Kernel type scheme.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(double... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value using this Kernel type scheme.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(float... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value using this Kernel type scheme.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(long... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value using this Kernel type scheme.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(int... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value using this Kernel type scheme.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(boolean... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a {@code List} or an array of constant values into a single {@link Bits} value using this Kernel type scheme.
	 * @param value The object containing the constant values to encode.
	 * @return The encoded constant.
	 */
	@Override
	public Bits encodeConstant(Object value) {
		assertConcrete("encode constant");

		if(value.getClass().isArray())
			return encodeConstant((Object[])value);

		if(value instanceof List<?>)
			return encodeConstant((List<?>)value);

		throw new MaxCompilerAPIError(
			"DFEArray constants must be List or Array type," +
			" not: " + value.getClass().getSimpleName());
	}

	/**
	 * Returns a string containing the Kernel type information.
	 * <p>
	 * The returned string is of the form:
	 * <p>
	 * <code>
	 * {DFEArrayType: [array_size] x [contained_type]}
	 * </code>
	 * <p>
	 * e.g.
	 * <p>
	 * <code>
	 * DFEArrayType t = new DFEArrayType(dfeUInt(32), 16);<br>
	 * System.out.println(t.toString());
	 * </code>
	 * <p>
	 * prints:
	 * <p>
	 * <code>
	 * {DFEArray: 16 x dfeFix(32, 0, UNSIGNED)}
	 * </code>
	 */
	@Override
	public String toString() {
		return "{DFEArrayType: " + m_size + " x " + m_contained_type + "}";
	}

	@Override
	public boolean isConcreteType() {
		return m_contained_type.isConcreteType();
	}

	@Override
	public int getTotalPrimitives() {
		return m_size * m_contained_type.getTotalPrimitives();
	}

	@Override
	protected DFEArray<ContainedT> realUnpackWithDoubt(
		DFEVar src,
		DoubtType doubt_type)
	{
		if(!(doubt_type instanceof DFEArrayDoubtType))
			throw new MaxCompilerAPIError(
				"DFEArray can only be unpacked with doubt using a DFEArrayDoubtType object.");

		DFEArrayDoubtType karray_doubt_type =
			(DFEArrayDoubtType)doubt_type;

		DoubtType contained_doubt_type =
			karray_doubt_type.getContainedDoubtType();

		List<ContainedT> contained_elements =
			new ArrayList<ContainedT>(m_size);

		int base = 0;
		int width = m_contained_type.getTotalBits() + contained_doubt_type.getTotalBits();

		for(int i = 0; i < m_size; i++) {
			contained_elements.add(
				m_contained_type.unpackWithDoubt(
					src.slice(base, width),
					contained_doubt_type));

			base += width;
		}

		return new DFEArray<ContainedT>(contained_elements, this, karray_doubt_type);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public DFEArrayFullType getFullTypeWithoutDoubtInfo() {
		return new DFEArrayFullType(
			new DFEArrayDoubtType(
				m_contained_type.getFullTypeWithoutDoubtInfo().getDoubtType(), m_size),
			this);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public DFEArrayFullType getFullTypeWithDoubtInfo() {
		return new DFEArrayFullType(
			new DFEArrayDoubtType(
				m_contained_type.getFullTypeWithDoubtInfo().getDoubtType(), m_size),
			this);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		DFEArrayType<ContainedT> foo = (DFEArrayType<ContainedT>)other_type;

		return
			new DFEArrayType(
				m_contained_type.unionWithMaxOfMaxes(foo.m_contained_type),
				m_size);
	}
}
