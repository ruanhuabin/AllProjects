package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.statemachine.stdlib.Mem.DualPortRAMMode;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.memory.MappedRAM;

public abstract class DFEsmMappedRAM extends DFEsmMem{

	DFEsmMappedRAM(int numPorts, String name, Latency latency, DFEsmValueType type,
		DualPortRAMMode port0_mode, DualPortRAMMode port1_mode, int depth) {
		super(new MappedRAM(numPorts, name, latency.getCycles(), type, port0_mode, port1_mode, depth));
	}


	final MappedRAM getMappedRAM() { return (MappedRAM) m_mem; }

	public final String getName() { return getMappedRAM().getName(); }

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof DFEsmMappedRAM))
			return false;

		DFEsmMappedRAM m = (DFEsmMappedRAM) o;

		return m_mem.equals(m.m_mem);
	}

	@Override
	public int hashCode() { return m_mem.hashCode(); }

	@Override
	public String toString() { return "mappedRAM(" + getNumPorts() + ", " + getName() + ", " + getType() + ", " + getDepth() + ")"; }

}
