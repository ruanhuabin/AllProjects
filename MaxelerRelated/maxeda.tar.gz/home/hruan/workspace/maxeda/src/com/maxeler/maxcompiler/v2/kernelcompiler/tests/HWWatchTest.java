package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.standard.Manager;
import com.maxeler.maxcompiler.v2.managers.standard.Manager.IOType;

public class HWWatchTest extends Kernel {
	private static final DFEType dataType = dfeUInt(32);

	public HWWatchTest(KernelParameters parameters) {
		super(parameters);

		DFEVar a = io.input("input_a", dataType).dfeWatch("a");
		DFEVar b = io.input("input_b", dataType).dfeWatch("b");
		DFEVar c = a + b;
		c.dfeWatch("c");

		io.output("output", c, dataType);
	}

	private static void buildHardware() {
		Manager manager = new Manager(new _EngineParameters(HWWatchTest.class.getSimpleName(), MAX2BoardModel.MAX24412C, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
		manager.setKernel(new HWWatchTest(manager.makeKernelParameters("HWWatch")));
		manager.setEnableStreamStatusBlocks(true);
		manager.setIO(IOType.ALL_CPU);
		manager.build();
	}

//	private static void simulate() {
//		_SimulationManager sim = new _SimulationManager(HWWatchTest.class.getSimpleName() + "_sim", SimulationParams.HDLSIM);
//		sim.setKernel(new HWWatchTest(sim.makeKernelParameters(HWWatchTest.class.getSimpleName())));
//		sim.build();
//
//		double[] inputA = new double[2 * 17];
//		double[] inputB = new double[inputA.length];
//		for (int i = 0; i < inputA.length; ++i) {
//			inputA[i] = 2 * i;
//			inputB[i] = 2 * i + 1;
//		}
//
//		sim.enableSimGUI();
//		sim.setInputData("input_a", inputA);
//		sim.setInputData("input_b", inputB);
//		sim.setScalarInput("hw_watch_first_cycle", 0);
//		sim.setScalarInput("hw_watch_last_cycle", 1024);
//		sim.setKernelCycles(inputA.length);
//		sim.run();
//
//		for (int i = 0; i < 32; ++i) {
//			double a = sim.getMappedRam("watch_a", i);
//
//			sim.logMsg("watch_a @ %d = %g", i, a);
//		}
//	}

	public static void main(String[] args) {
//		simulate();
		buildHardware();
	}
}
