package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxConstantEncodingException;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * A C-struct-like type for streams.
 * <p>
 * This type allows related data to be grouped together into a single stream. Each stream cycle,
 * new values are written into every field of the structure.
 * <p>
 * Each field is a stream of its own Kernel type and is accessed via its name, represented by a {@code String}.
 * <p>
 * The {@code []} operator is overloaded for {@code DFEStruct} to take the name of a field as a {@code String} and return
 * the appropriate data from the structure.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFEStructType extends KernelTypeVectorizable<DFEStruct> {
	private final LinkedHashMap<String, KernelType<? extends KernelObjectNotVector<?>>> m_field_types =
		new LinkedHashMap<String, KernelType<? extends KernelObjectNotVector<?>>>();

	private boolean m_is_concrete;

	// only valid if m_is_concrete == true
	private final int m_width;

	private final int m_total_primitives;

	/**
	 * Represents a field in a structure.
	 * <p>
	 * Can be created using {@link DFEStructType#sft(String, KernelType)}. To do this, use a static
	 * import of {@code com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStructType.sft} in your
	 * Java source.
	 */
	public static class StructFieldType {
		private final String m_field_name;
		private final KernelType<? extends KernelObjectNotVector<?>> m_type;

		/**
		 * Constructs a new field with a given name and Kernel type.
		 * @param field_name The name of the field.
		 * @param type The Kernel type for the field.
		 */
		public StructFieldType(String field_name, KernelType<? extends KernelObjectNotVector<?>> type) {
			m_field_name = field_name;
			m_type = type;
		}

		/**
		 * Returns the name of the field and its Kernel type.
		 */
		@Override
		public String toString() { return m_field_name + ":" + m_type; }
	}

	/**
	 * Creates a new {@code StructFieldType} object with the given name and Kernel type.
	 * @param field_name The name of the field.
	 * @param type The Kernel type.
	 * @return The new field object.
	 */
	public static StructFieldType sft(
		String field_name,
		KernelType<? extends KernelObjectNotVector<?>> type)
	{
		return new StructFieldType(field_name, type);
	}

	/**
	 * Constructs a new {@code DFEStructType} with a variable number of fields.
	 * @param fields The fields that this type will contain.
	 */
	public DFEStructType(StructFieldType... fields) {
		if(fields.length < 1)
			throw new MaxCompilerAPIError("Cannot make a DFEStructType with no fields.");

		int width = 0;
		int total_primitives = 0;
		m_is_concrete = true;
		for(StructFieldType sft : fields) {
			if(sft.m_type.isConcreteType())
				width += sft.m_type.getTotalBits();
			else
				m_is_concrete = false;
			total_primitives += sft.m_type.getTotalPrimitives();
			if (m_field_types.put(sft.m_field_name, sft.m_type) != null)
				throw new MaxCompilerAPIError("DFEStructType may not contain duplicate field '%s'.", sft.m_field_name);
		}
		m_width = width;
		m_total_primitives = total_primitives;
	}

	private boolean equals(Object other_type, boolean ignore_max) {
		if(!(other_type instanceof DFEStructType))
			return false;

		// The name-sorting + comparisons below catch subtle programming
		// errors where two structs have been defined in different places
		// with different orders.

		ArrayList<String> names_1 =
			new ArrayList<String>(m_field_types.keySet());
		ArrayList<String> names_2 =
			new ArrayList<String>(((DFEStructType)other_type).m_field_types.keySet());
		boolean same_pre_sort = names_1.equals(names_2);
		Collections.sort(names_1);
		Collections.sort(names_2);
		boolean same_post_sort = names_1.equals(names_2);

		if(!same_post_sort)
			return false;

		if(!same_pre_sort)
			throw new MaxCompilerAPIError(
				"Two structs have identical field names but in a different order, type: " + this);

		Iterator<KernelType<? extends KernelObjectNotVector<?>>> type_i1 =
			m_field_types.values().iterator();
		Iterator<KernelType<? extends KernelObjectNotVector<?>>> type_i2 =
			((DFEStructType)other_type).m_field_types.values().iterator();

		while(type_i1.hasNext()) {
			if(ignore_max) {
				if( ! type_i1.next().equalsIgnoreMax(type_i2.next()) )
					return false;
			} else {
				if( ! type_i1.next().equals(type_i2.next()) )
					return false;
			}
		}

		return true;
	}

	@Override
	@edu.umd.cs.findbugs.annotations.SuppressWarnings("EQ_UNUSUAL")
	public boolean equals(Object other_type) {
		return equals(other_type, false);
	}

	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return equals(other_type, true);
	}

	@Override
	public int hashCode() {
		return m_field_types.hashCode();
	}

	/**
	 * Returns the Kernel type of the named field.
	 * @param field_name The name of the field.
	 * @return The Kernel type of the field.
	 */
	public KernelType<?> getTypeForField(String field_name) {
		KernelType<?> type = m_field_types.get(field_name);
		if(type == null)
			throw new MaxCompilerAPIError("No such field in " + this + ": " + field_name);

		return type;
	}

	/**
	 * Returns the bit position (i.e. offset from the least significant bit) of
	 * the specified field.
	 * @param field_name The name of the field.
	 * @return The offset of the specified field within the type.
	 */
	public int getPositionForField(String field_name) {
		int pos = 0;
		boolean found_field = false;

		for (Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> field : m_field_types.entrySet()) {
			if (field_name.equals(field.getKey())) {
				found_field = true;
				break;
			}

			pos += field.getValue().getTotalBits();
		}

		if (!found_field)
			throw new MaxCompilerAPIError("Field '%s' is not specified for DFEStruct type %s.", field_name, this);

		return pos;
	}

	/**
	 * Returns a {@code Set} of the {@code String} names of the fields in the structure.
	 */
	public Set<String> getFieldNames() {
		return Collections.unmodifiableSet(m_field_types.keySet());
	}

	/**
	 * Returns a {@code String} containing a list of the names and corresponding Kernel types of the fields in the structure.
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{DFEStructType => ");
		boolean first = true;
		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> field_type : m_field_types.entrySet()) {
			if(first)
				first = false;
			else
				sb.append(", ");
			sb.append(field_type.getKey() + " : " + field_type.getValue());
		}
		sb.append("}");

		return sb.toString();
	}

	@Override
	protected int realGetTotalBits() {
		return m_width;
	}

	@Override
	public int getTotalPrimitives() {
		return m_total_primitives;
	}

	@Override
	public DFEStruct newInstance(KernelLib design, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEStructDoubtType))
			throw new MaxCompilerAPIError(design.getManager(),
				"DFEStruct can only be constructed using a DFEStructDoubtType object.");

		LinkedHashMap<String, KernelObjectNotVector<?>> field_instances =
			new LinkedHashMap<String, KernelObjectNotVector<?>>();

		Map<String, DoubtType> field_doubt_type = ((DFEStructDoubtType)doubt_type).getFieldDoubtTypes();

		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> type : m_field_types.entrySet())
			field_instances.put(type.getKey(), type.getValue().newInstance(design, field_doubt_type.get(type.getKey())));

		return new DFEStruct(this, field_instances, (DFEStructDoubtType)doubt_type);
	}

	@Override
	protected DFEStruct realUnpack(DFEVar src) {
		LinkedHashMap<String, KernelObjectNotVector<?>> field_instances =
			new LinkedHashMap<String, KernelObjectNotVector<?>>();

		int base = 0;
		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> type : m_field_types.entrySet()) {
			int bitwidth = type.getValue().getTotalBits();
			KernelObjectNotVector<?> field_value =
				type.getValue().unpack( src.slice(base, bitwidth));
			field_instances.put(type.getKey(), field_value);


			base += bitwidth;
		}

		return new DFEStruct(this, field_instances, getFullTypeWithoutDoubtInfo().getDoubtType());
	}

	/**
	 * Decodes a {@code Bits} value to a {@code Map} of field name {@code String}s and values.
	 */
	@Override
	protected DFEStruct realUnpackFromList(List<DFEVar> primitives) {
		LinkedHashMap<String, KernelObjectNotVector<?>> field_instances =
			new LinkedHashMap<String, KernelObjectNotVector<?>>();

		Map<String, DoubtType> doubt_type = new HashMap<String, DoubtType>();

		int base = 0;
		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> type : m_field_types.entrySet()) {
			int n_sub_primitives = type.getValue().getTotalPrimitives();
			List<DFEVar> sub_primitives = primitives.subList(base, base + n_sub_primitives);
			KernelObjectNotVector<?> field_value =
				type.getValue().unpackFromList(sub_primitives);
			field_instances.put(type.getKey(), field_value);
			doubt_type.put(type.getKey(), field_value.getDoubtType());

			base += n_sub_primitives;
		}

		return new DFEStruct(this, field_instances, new DFEStructDoubtType(doubt_type));
	}

	@Override
	public Map<String, Object> decodeConstant(Bits raw_bits) {
		assertConcrete("decode constant");

		LinkedHashMap<String, Object> field_sim_objs =
			new LinkedHashMap<String, Object>();

		int base = 0;
		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> type : m_field_types.entrySet()) {
			int bitwidth = type.getValue().getTotalBits();
			Bits element_bits = raw_bits.getBitsRaw(base, bitwidth);
			Object decoded;

			if (type.getValue() instanceof DFERawBits)
				decoded = element_bits;
			else
				decoded = type.getValue().decodeConstant(element_bits);

			field_sim_objs.put(
				type.getKey(),
				decoded);

			base += bitwidth;
		}

		return field_sim_objs;
	}

	/**
	 * Encodes a {@code Map} object representing the values in a {@code DFEStruct} as a single {@code Bits} value.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Bits encodeConstant(Object value) {
		assertConcrete("encode constant");

		if(!(value instanceof Map))
			throw new MaxCompilerAPIError("DFEStruct encodeConstant must take Map type.");

		return encodeConstant((Map<String, Object>)value);
	}

	/**
	 * Encodes a {@code Map} object representing the values in a {@code DFEStruct} as a single {@code Bits} value.
	 */

	public Bits encodeConstant(Map<String, Object> value) {
		assertConcrete("encode constant");

		Bits res = new Bits(0);
		MaxConstantEncodingException caught_exception = null;

		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> type : m_field_types.entrySet()) {
			Bits bits;
			try {
				bits = type.getValue().encodeConstant(value.get(type.getKey()));
			}
			catch (MaxConstantEncodingException e) {
				bits = e.getPackedValue();
				caught_exception = e;
			}

			res = res.concat(bits);
		}

		if (caught_exception != null) {
			throw new MaxConstantEncodingException(
				caught_exception.isOverflow(),
				caught_exception.isUnderflow(),
				caught_exception.isCompleteFixedPointUnderflow(),
				caught_exception.isInvalidOp(),
				caught_exception.isNegativeToUnsigned(),
				caught_exception.getRelativeError(),
				res);
		}

		return res;
	}

	/**
	 * Gets the number of fields in the structure.
	 */
	public int getNumberOfFields() {
		return m_field_types.size();
	}

	@Override
	public boolean isConcreteType() {
		return m_is_concrete;
	}

	@Override
	protected DFEStruct realUnpackWithDoubt(
		DFEVar src,
		DoubtType doubt_type)
	{
		if(!(doubt_type instanceof DFEStructDoubtType))
			throw new MaxCompilerAPIError(
				"DFEStruct can only be unpacked with doubt using a DFEStructDoubtType object.");

		LinkedHashMap<String, KernelObjectNotVector<?>> field_instances =
			new LinkedHashMap<String, KernelObjectNotVector<?>>();

		Map<String, DoubtType> field_doubt_type =
			((DFEStructDoubtType)doubt_type).getFieldDoubtTypes();

		int base = 0;
		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> type : m_field_types.entrySet()) {
			DoubtType filed_doubt_type = field_doubt_type.get(type.getKey());
			int bitwidth = type.getValue().getTotalBits() + filed_doubt_type.getTotalBits();
			field_instances.put(
				type.getKey(),
				type.getValue().unpackWithDoubt(
					src.slice(base, bitwidth),
					filed_doubt_type));

			base += bitwidth;
		}

		return new DFEStruct(this, field_instances, (DFEStructDoubtType)doubt_type);
	}

	@SuppressWarnings("unchecked")
	@Override
	public DFEStructFullType getFullTypeWithoutDoubtInfo() {
		Map<String, DoubtType> field_doubt_type = new HashMap<String, DoubtType>();

		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> field : m_field_types.entrySet())
			field_doubt_type.put(
				field.getKey(),
				field.getValue().getFullTypeWithoutDoubtInfo().getDoubtType());

		return new DFEStructFullType(new DFEStructDoubtType(field_doubt_type), this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public DFEStructFullType getFullTypeWithDoubtInfo() {
		Map<String, DoubtType> field_doubt_type = new HashMap<String, DoubtType>();

		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> field : m_field_types.entrySet())
			field_doubt_type.put(
				field.getKey(),
				field.getValue().getFullTypeWithDoubtInfo().getDoubtType());

		return new DFEStructFullType(new DFEStructDoubtType(field_doubt_type), this);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		StructFieldType[] sfts = new StructFieldType[m_field_types.size()];
		DFEStructType foo = (DFEStructType)other_type;

		int i = 0;
		for(Map.Entry<String, KernelType<? extends KernelObjectNotVector<?>>> field : m_field_types.entrySet()) {
			KernelType<?> other_field_type =
				foo.m_field_types.get(field.getKey());

			KernelType<?> union_field_type =
				field.getValue().unionWithMaxOfMaxes(other_field_type);

			sfts[i++] = sft(
				field.getKey(),
				(KernelType<? extends KernelObjectNotVector<?>>) union_field_type);
		}

		return new DFEStructType(sfts);
	}
}
