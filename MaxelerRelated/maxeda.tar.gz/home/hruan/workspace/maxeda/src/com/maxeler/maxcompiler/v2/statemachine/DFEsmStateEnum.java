package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmEnumType;
import com.maxeler.maxcompiler.v2.statemachine.types._DFEsmTypeFactory;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.NextStateValue;
import com.maxeler.statemachine.expressions.StateEnum;
import com.maxeler.statemachine.statements.StatementAssign;

public final class DFEsmStateEnum<E extends Enum<E>> extends DFEsmEnum<E> {
	private class Assigner extends DFEsmVariable {
		private final StateMachineLib m_stateMachine;

		public Assigner(StateMachineLib stateMachine) { m_stateMachine = stateMachine; }

		@Override
		public <F extends Enum<F>> void connect(F value) {
			final DFEsmEnumType type = getType();
			if (!Utils.canRepresent(value, type))
				throw new MaxCompilerAPIError("Cannot use enum '%s' (of type %s) for state with enum type %s.", value, value.getClass(), type.getEnumClass());

			assign(new Constant(value));
		}

		@Override
		public void connect(boolean value) {
			throw new MaxCompilerAPIError("Cannot assign boolean '%b' to enum state.", value);
		}

		@Override
		public void connect(long value) {
			throw new MaxCompilerAPIError("Cannot assign integer '%d' to enum state.", value);
		}

		@Override
		public void connect(BigInteger value) {
			throw new MaxCompilerAPIError("Cannot assign integer '%d' to enum state.", value);
		}

		@Override
		public void connect(DFEsmExpr expr) { assign(expr.getExpression()); }

		private void assign(Expression expr) {
			checkContextValid(m_stateMachine);

			m_stateMachine.addStatement(new StatementAssign(getState(), expr, _StateMachine.getBuildManager(m_stateMachine)));
		}

		@Override
		protected DFEsmExpr getDFEsmExpr() {
			checkContextValid(m_stateMachine);

			return _StateMachine.Create.DFEsmExpr( new NextStateValue(getState()) );
		}
	}

	public final DFEsmVariable next;

	DFEsmStateEnum(StateMachineLib stateMachine, Class<E> enumClass, String stateID, E defaultValue) {
		super(new StateEnum(_DFEsmTypeFactory.dfeEnum(enumClass), stateID, defaultValue));
		next = new Assigner(stateMachine);
	}

	StateEnum getState() { return (StateEnum) getExpression(); }

	private void checkContextValid(StateMachineLib stateMachine) {
		if (stateMachine.getContextMode() != ContextMode.NEXT_STATE)
			throw new MaxCompilerAPIError("The next value of state variables can only be accessed inside the 'nextState' method.");
	}
}
