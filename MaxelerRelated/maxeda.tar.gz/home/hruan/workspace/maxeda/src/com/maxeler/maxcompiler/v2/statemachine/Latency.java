package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;

public enum Latency {
	ONE_CYCLE (1),
	TWO_CYCLES (2),
	THREE_CYCLES (3);

	private final int m_cycles;
	private Latency(int cycles) {
		m_cycles = cycles;
	}
	public int getCycles() {
		return m_cycles;
	}


	public static Latency get(int latency) {
		switch (latency) {
			case 1:
				return ONE_CYCLE;
			case 2:
				return TWO_CYCLES;
			case 3:
				return THREE_CYCLES;
			default:
				throw new MaxCompilerAPIError("Unknown latency: " + latency);
		}
	}
}
