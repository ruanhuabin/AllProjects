package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;

public class _IO extends IO {

	public _IO(Kernel design) { super(design); }

	public void applyIOConstraints() { super.applyIOConstraints(); }

}
