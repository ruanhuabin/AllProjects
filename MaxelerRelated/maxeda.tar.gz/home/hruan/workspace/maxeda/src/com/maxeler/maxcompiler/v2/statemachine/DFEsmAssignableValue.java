package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.ExprUtils;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.expressions.AssignableValue;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.statements.StatementAssign;
import com.maxeler.utils.MaxCompilerHide;

public final class DFEsmAssignableValue extends DFEsmValue {

	private final StateMachineLib m_stateMachine;
	private final ContextMode m_context;
	private boolean m_initialized; // this is not foolproof but better than nothing (misses out on IF/ELSE partial initialisations)


	@MaxCompilerHide
	DFEsmAssignableValue(
		StateMachineLib stateMachine,
		DFEsmValueType type,
		String stateID)
	{
		super(new AssignableValue(type,stateID));
		m_stateMachine = stateMachine;
		m_context = m_stateMachine.getContextMode();
		m_initialized = false;
		if (m_context != ContextMode.NEXT_STATE && m_context != ContextMode.OUTPUT)
			throw new MaxCompilerAPIError("DFEsmAssignableValues can only be declared inside the next_state or output-function method.");
	}

	private AssignableValue getLocalVar() {
		return (AssignableValue) getExpression();
	}

	private void assign(Expression expr) {
		if (m_stateMachine.getContextMode() != m_context)
			throw new MaxCompilerAPIError("DFEsmAssignableValues can only be assigned to inside the context (next-state/output function) " +
					"they are declared in.");

		expr = ExprUtils.implicitCast(getType(), "assignable variable", expr);
		m_initialized = true;
		m_stateMachine.addStatement(new StatementAssign(getLocalVar(), expr, _StateMachine.getBuildManager(m_stateMachine)));
	}

	@Override
	Expression getExpression() {
		if (!m_initialized)
			throw new MaxCompilerAPIError("Trying to read an uninitialised DFEsmAssignableValue.");
		if (m_stateMachine.getContextMode() != ContextMode.CODEGEN && m_stateMachine.getContextMode() != m_context)
			throw new MaxCompilerAPIError("DFEsmAssignableValues can only be read inside the context (next-state/output function) " +
					"they are declared in.");
		return super.getExpression();
	}


	public void connect(BigInteger value) {
		assign(new Constant(value));
	}
	public void connect(DFEsmExpr expr){
		assign(expr.getExpression());
	}

	public void connect(boolean value) {
		connect(value ? 1 : 0);
	}

	public void connect(long value) {
		Utils.checkIsAllowedLiteralValue(value, getType());
		connect(BigInteger.valueOf(value));
	}
}
