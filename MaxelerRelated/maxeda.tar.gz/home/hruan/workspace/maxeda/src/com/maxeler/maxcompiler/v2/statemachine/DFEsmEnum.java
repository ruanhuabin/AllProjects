package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmEnumType;
import com.maxeler.maxcompiler.v2.statemachine.types._TypeHelper;
import com.maxeler.statemachine.expressions.BinaryOp;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.BinaryOp.Operation;

public abstract class DFEsmEnum<E extends Enum<E>> extends DFEsmExpr {
	DFEsmEnum(Expression expr) { super(expr); }

	private DFEsmValue binOp(BinaryOp.Operation op, E value) {
		final DFEsmEnumType type = getType();
		if (! _TypeHelper.getEnumClass(type).equals(value.getClass()))
			throw new MaxCompilerAPIError("Cannot use enum %s in expression with type %s.", value, type);

		Constant rhs = new Constant(value);
		return new DFEsmValue(new BinaryOp(op, getExpression(), rhs));
	}

	private DFEsmValue binOp(BinaryOp.Operation op, DFEsmEnum<E> expr) {
		return new DFEsmValue(new BinaryOp(op, getExpression(), expr.getExpression()));
	}

	public DFEsmValue eq(E value) { return binOp(Operation.EQUAL, value); }
	public DFEsmValue eq(DFEsmEnum<E> value) { return binOp(Operation.EQUAL, value); }

	public DFEsmValue neq(E value) { return binOp(Operation.NOT_EQUAL, value); }
	public DFEsmValue neq(DFEsmEnum<E> value) { return binOp(Operation.NOT_EQUAL, value); }

	@Override
	public DFEsmEnumType getType() { return (DFEsmEnumType) getExpression().getType(); }
}
