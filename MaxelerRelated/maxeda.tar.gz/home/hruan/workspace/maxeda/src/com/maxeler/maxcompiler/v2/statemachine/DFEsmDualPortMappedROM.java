package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.memory.MappedROM;
import com.maxeler.statemachine.memory.MemoryElement;

/**
 * @see DFEsmSinglePortROM
 */
public final class DFEsmDualPortMappedROM extends DFEsmMappedROM {
	public final DFEsmMemAddress addressA;
	public final DFEsmMemAddress addressB;
	public final DFEsmValue dataOutA;
	public final DFEsmValue dataOutB;

	DFEsmDualPortMappedROM(StateMachineLib stateMachine, String name, Latency latency, DFEsmValueType type, int depth) {
		super(2, name, latency, type, depth);

		MappedROM rom = getMappedROM();

		MemoryElement.Port port0 = rom.getPort(0);
		addressA = new DFEsmMemAddress(stateMachine, port0.address);
		dataOutA = new DFEsmValue(port0.dataOut);

		MemoryElement.Port port1 = rom.getPort(1);
		addressB = new DFEsmMemAddress(stateMachine, port1.address);
		dataOutB = new DFEsmValue(port1.dataOut);
	}
}
