package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import com.maxeler.maxeleros.ip.MemoryControllerPro.DDRAddressBitSwapBase;

public class _MemoryControllerConfig {

	public static void setDDRAddressBitSwap(MemoryControllerConfig config, DDRAddressBitSwapBase addr_swap) {
		config.setDDRAddressBitSwap(addr_swap);
	}

	public static DDRAddressBitSwapBase getDDRAddressBitSwap(MemoryControllerConfig config) {
		return config.getDDRAddressBitSwap();
	}

	public static int getArbitrationModeVhdlValue(MemoryControllerConfig config) {
		return config.getArbitrationMode().m_vhdl_value;
	}
}
