package com.maxeler.maxcompiler.v2.managers.engine_interfaces;

public class ArrayShape {

	private final com.maxeler.maxeleros.managercompiler.software.modeinfo.ArrayShape m_impl;

	public ArrayShape(com.maxeler.maxeleros.managercompiler.software.modeinfo.ArrayShape impl)
	{
		m_impl = impl;
	}

	com.maxeler.maxeleros.managercompiler.software.modeinfo.ArrayShape getImpl() {
		return m_impl;
	}
}
