package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import static com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStructType.sft;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * A complex number Kernel type.
 * <p>
 * A complex number is made up of a real and and imaginary part and can be written in the form <em>a + bi</em>, where <em>a</em> and <em>b</em> are real
 * numbers and <em>i</em> represents the imaginary unit <img src="{@docRoot}/resources/imaginary_unit.gif">.
 * <p>
 * The Kernel types for <em>a</em> and <em>b</em> can be different.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFEComplexType extends KernelTypeVectorizable<DFEComplex> {
	private final DFEStructType m_struct_type;

	private DFEComplexType(DFEStructType struct_type) {
		m_struct_type = struct_type;
	}

	/**
	 * Creates a new complex Kernel type with the same Kernel type for both the real and imaginary parts.
	 * @param type The Kernel type for both parts.
	 */
	public DFEComplexType(DFEType type) {
		this(type, type);
	}

	/**
	 * Gets the Kernel type of the real part of the complex number.
	 */
	public KernelType<?> getRealType() {
		return m_struct_type.getTypeForField("real");
	}

	/**
	 * Gets the Kernel type of the imaginary part of the complex number.
	 */
	public KernelType<?> getImaginaryType() {
		return m_struct_type.getTypeForField("imaginary");
	}

	/**
	 * Creates a new complex Kernel type with different Kernel types for the real and imaginary parts.
	 * @param real_type The Kernel type for the real part.
	 * @param imaginary_type The Kernel type for the imaginary part.
	 */
	public DFEComplexType(DFEType real_type, DFEType imaginary_type) {
		this(
			new DFEStructType(
				sft("real", real_type),
				sft("imaginary", imaginary_type)));
	}

	@Override
	protected int realGetTotalBits() {
		return m_struct_type.getTotalBits();
	}

	/**
	 * Creates a new {@link DFEComplex} stream with real and imaginary parts coming from
	 * two {@code DFEVar} streams.
	 * @param design The Kernel instance.
	 * @param real Input stream for the real part.
	 * @param imaginary Input stream for the imaginary part.
	 * @return The new complex number stream.
	 */
	public static DFEComplex newInstance(KernelLib design, DFEVar real, DFEVar imaginary) {
		DFEComplexType new_type =
			new DFEComplexType(real.getType(), imaginary.getType());

		boolean new_has_doubt_info =
			real.getDoubtType().union(imaginary.getDoubtType()).hasDoubtInfo();

		DFEComplexFullType new_full_type = new_has_doubt_info ?
			new_type.getFullTypeWithDoubtInfo() : new_type.getFullTypeWithoutDoubtInfo();

		DFEComplex new_inst = new_full_type.newInstance(design);
		new_inst.setImaginary(imaginary);
		new_inst.setReal(real);

		return new_inst;
	}

	@Override
	public boolean equals(Object other_type) {
		return
			(other_type instanceof DFEComplexType) &&
			((DFEComplexType)other_type).m_struct_type.equals(m_struct_type);
	}

	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return
			(other_type instanceof DFEComplexType) &&
			((DFEComplexType)other_type).m_struct_type.equalsIgnoreMax(m_struct_type);
	}

	@Override
	public int hashCode() {
		return m_struct_type.hashCode();
	}

	/**
	 * A Java representation of a constant complex number value.
	 */
	public static class ConstantValue {
		private final double m_real;
		private final double m_imag;

		/**
		 * Creates a new constant complex number value.
		 * @param real The constant for the real part.
		 * @param imaginary The constant for the imaginary part.
		 */
		public ConstantValue(double real, double imaginary) {
			m_real = real;
			m_imag = imaginary;
		}

		/**
		 * Gets the real part of the constant.
		 */
		public double getReal() {
			return m_real;
		}

		/**
		 * Gets the imaginary part of the constant.
		 */
		public double getImaginary() {
			return m_imag;
		}

		/**
		 * Returns a string with the real and imaginary parts of the constant.
		 */
		@Override
		public String toString() {
			return "{" + m_real + ", " + m_imag + "}";
		}
	}

	@Override
	public ConstantValue decodeConstant(Bits raw_bits) {
		assertConcrete("decode constant");

		Map<String, Object> struct_data = m_struct_type.decodeConstant(raw_bits);

		ConstantValue sv =
			new ConstantValue(
				(Double)struct_data.get("real"),
				(Double)struct_data.get("imaginary"));

		return sv;
	}

	/**
	 * Encodes constants for the real and imaginary parts into {@link Bits}.
	 * @param real The value to encode for the real part.
	 * @param imaginary The value to encode for the imaginary part.
	 */
	public Bits encodeConstant(double real, double imaginary) {
		assertConcrete("encode constant");

		Map<String, Double> struct_value = new HashMap<String, Double>();
		struct_value.put("real", real);
		struct_value.put("imaginary", imaginary);

		return m_struct_type.encodeConstant(struct_value);
	}

	/**
	 * Encodes a Java complex constant into {@link Bits}.
	 * @param value The value to encode.
	 */
	public Bits encodeConstant(ConstantValue value) {
		return encodeConstant(value.getReal(), value.getImaginary());
	}

	/**
	 * Encodes a constant into {@link Bits}.
	 * <p>
	 * {@code value} must be either an instance of {@code Bits} or {@link ConstantValue}.
	 * @param value The value to encode.
	 */
	@Override
	public Bits encodeConstant(Object value) {
		assertConcrete("encode constant");

		if (value instanceof Bits) {
			Bits bvalue = (Bits) value;
			if (bvalue.getWidth() != this.getTotalBits())
				throw new MaxCompilerAPIError("Size mismatch");
			return bvalue;
		}
		if(!(value instanceof ConstantValue))
			throw new MaxCompilerAPIError("Parameter must be of type ConstantValue.");

		return encodeConstant((ConstantValue)value);
	}

	/**
	 * Returns a string containing the Kernel type information.
	 * <p>
	 * The returned string is of the form:
	 * <p>
	 * <code>
	 * {DFEComplexType: [real_type], [imaginary_type]}
	 * </code>
	 */
	@Override
	public String toString() {
		return
			"{DFEComplexType: " +
			m_struct_type.getTypeForField("real") + ", " +
			m_struct_type.getTypeForField("imaginary") + "}";
	}


	@Override
	public boolean isConcreteType() {
		return m_struct_type.isConcreteType();
	}


	@Override
	public int getTotalPrimitives() {
		return m_struct_type.getTotalPrimitives();
	}

	@Override
	protected DFEComplex realUnpack(DFEVar src) {
		DFEStruct struct_data = m_struct_type.unpack(src);

		return new DFEComplex(struct_data, this);
	}

	@Override
	protected DFEComplex realUnpackFromList(List<DFEVar> primitives) {
		DFEStruct struct_data = m_struct_type.unpackFromList(primitives);

		return new DFEComplex(struct_data, this);
	}

	@Override
	protected DFEComplex realUnpackWithDoubt(DFEVar src, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEComplexDoubtType))
			throw new MaxCompilerAPIError(
				"DFEComplex can only be unpacked with doubt using " +
				"a DFEComplexDoubtType object.");

		return
			new DFEComplex(
				m_struct_type.unpackWithDoubt(
					src,
					((DFEComplexDoubtType)doubt_type).getDFEStructDoubtType()),
				this);
	}

	@Override
	public DFEComplex newInstance(KernelLib design, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEComplexDoubtType))
			throw new MaxCompilerAPIError(design.getManager(),
				"DFEComplexType instances can only be made using DFEComplexDoubtType objects.");

		DFEStruct struct_data =
			m_struct_type.newInstance(design, ((DFEComplexDoubtType)doubt_type).getDFEStructDoubtType());

		return new DFEComplex(struct_data, this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public DFEComplexFullType getFullTypeWithoutDoubtInfo() {
		return new DFEComplexFullType(
			new DFEComplexDoubtType(
				m_struct_type.getFullTypeWithoutDoubtInfo().getDoubtType()),
			this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public DFEComplexFullType getFullTypeWithDoubtInfo() {
		return new DFEComplexFullType(
			new DFEComplexDoubtType(
				m_struct_type.getFullTypeWithDoubtInfo().getDoubtType()),
			this);
	}

	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		DFEComplexType foo = (DFEComplexType)other_type;

		return new DFEComplexType((DFEStructType)m_struct_type.unionWithMaxOfMaxes(foo.m_struct_type));
	}
}
