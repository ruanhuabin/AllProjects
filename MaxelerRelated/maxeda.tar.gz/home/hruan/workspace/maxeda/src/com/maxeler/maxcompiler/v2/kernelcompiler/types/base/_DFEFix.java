package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import com.maxeler.utils.numeric.BigFloat;

public class _DFEFix {
	public static BigFloat getMax(DFEFix type) {
		com.maxeler.photon.types.HWOffsetFix imp = (com.maxeler.photon.types.HWOffsetFix) type.m_imp;
		return imp.getMax();
	}
}
