package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxConstantEncodingException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.maxcompiler.v2.utils._Utils;
import com.maxeler.photon.NumberPacker;
import com.maxeler.photon.NumberPacker.PackError;
import com.maxeler.photon.NumberPacker.PackResult;
import com.maxeler.photon.libs.CoreNodeFactory;
import com.maxeler.photon.libs.DoubtBitOpFactory;
import com.maxeler.photon.nodes.NodeConstant;
import com.maxeler.photon.nodes.NodeConstantDouble;
import com.maxeler.photon.nodes.NodeConstantRawBits;

/**
 * All primitive types in MaxCompiler inherit from {@code DFEType}.
 * <p>
 * {@link DFEVar} streams contain data of a Kernel type derived from {@code DFEType}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public abstract class DFEType extends KernelTypeVectorizable<DFEVar> {
	com.maxeler.photon.types.HWType m_imp;

	DFEType(com.maxeler.photon.types.HWType imp) {
		m_imp = imp;
	}

	private CoreNodeFactory coreNodeFactory(Kernel design) {
		return new CoreNodeFactory(_Kernel.getPhotonDesignData(design));
	}

	private DoubtBitOpFactory doubtBitOpFactory(Kernel design) {
		return new DoubtBitOpFactory(_Kernel.getPhotonDesignData(design));
	}

	@Override
	public boolean equals(Object other_type) {
		if(!(other_type instanceof DFEType))
			return false;
		return m_imp.equals(((DFEType)other_type).m_imp);
	}

	@Override
	public int hashCode(){
		return toString().hashCode();
	}

	@Override
	public abstract String toString();

	@Override
	protected int realGetTotalBits() {
		return m_imp.getTotalBits();
	}

	@Override
	public boolean isConcreteType() {
		return m_imp.isConcreteType();
	}

	/**
	 * Returns {@code true} if this type is an unsigned integer type.
	 */
	public boolean isUInt() {
		return m_imp.isUInt();
	}

	/**
	 * Returns {@code true} if this type is a signed integer type.
	 */
	public boolean isInt() {
		return m_imp.isInt();
	}

	/**
	 * Returns {@code true} if this type is a Boolean integer type.
	 */
	public boolean isBool() {
		return m_imp.isBool();
	}

	@Override
	public DFEVar newInstance(KernelLib design, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEDoubtType))
			throw new MaxCompilerAPIError(
				"DFEType instances can only be made using DFEDoubtType objects.");

		return new DFEVar(design.getKernel(), this, (DFEDoubtType)doubt_type);
	}

	/**
	 * Creates a constant stream of this Kernel type.
	 * @param design The Kernel instance.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVar newInstance(KernelLib design, double value) {
		NodeConstant constant;
		if(this instanceof DFEUntypedConst)
			constant = new NodeConstantDouble(_Kernel.getPhotonDesignData(design.getKernel()), value, false);
		else
			constant = new NodeConstantRawBits(_Kernel.getPhotonDesignData(design.getKernel()), value, m_imp, false);
		return _KernelBaseTypes.fromImp(design, constant.connectOutput("value"));
	}

	/**
	 * Creates a constant stream of this Kernel type.
	 * @param design The Kernel instance.
	 * @param value The value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVar newInstance(KernelLib design, int value) {
		return newInstance(design, (double)value);
	}

	/**
	 * Creates a constant stream of this Kernel type.
	 * @param design The Kernel instance.
	 * @param value The Boolean value of the constant.
	 * @return The output stream of constants.
	 */
	public DFEVar newInstance(KernelLib design, boolean value) {
		return newInstance(design, value ? 1.0 : 0.0);
	}

	@Override
	protected DFEVar realUnpack(DFEVar src) {
		if(!_KernelBaseTypes.toImp(src).hasTypeInfo())
			throw new MaxCompilerAPIError(
				"Cannot unpack source, DFEVar has no type information.");

		if(!src.getType().isConcreteType())
			throw new MaxCompilerAPIError(
				"Can only unpack sources with concrete types, not: " + src.getType());

		Kernel design = src.getKernel();

		if(src.getType().equals(this))
			return src;
		else
			return
				_KernelBaseTypes.fromImp(
					design,
					coreNodeFactory(design).reinterpretCast(_KernelBaseTypes.toImp(src),m_imp));
	}

	@Override
	public Double decodeConstant(Bits v) {
		assertConcrete("decode constant");
		return NumberPacker.unpackToDouble(m_imp, _Utils.toImp(v));
	}

	/**
	 * Encodes a Java value to {@link Bits} using the specification of this Kernel type.
	 * @see #encodeConstant(Object)
	 */
	public Bits encodeConstant(double v) {
		assertConcrete("encode constant");
		PackResult result = NumberPacker.packToBits(m_imp, v);

		if (result.isSeriousError())
			throw new MaxConstantEncodingException(
				result.error_type == PackError.OVERFLOW,
				result.error_type == PackError.UNDERFLOW,
				result.error_type == PackError.COMPLETE_FIXED_POINT_UNDERFLOW,
				result.error_type == PackError.INVALID_OP,
				result.error_type == PackError.NEGATIVE_TO_UNSIGNED,
				result.error_relative,
				_Utils.fromImp(result.value));

		return _Utils.fromImp(result.value);
	}

	/**
	 * Encodes a Java value to {@link Bits} using the specification of this Kernel type.
	 * @see #encodeConstant(Object)
	 */
	public Bits encodeConstant(float v) {
		return encodeConstant((double)v);
	}

	/**
	 * Encodes a Java value to {@link Bits} using the specification of this Kernel type.
	 * @see #encodeConstant(Object)
	 */
	public Bits encodeConstant(long v) {
		PackResult result = NumberPacker.packToBits(m_imp, v);

		if (result.isSeriousError())
			throw new MaxConstantEncodingException(
				result.error_type == PackError.OVERFLOW,
				result.error_type == PackError.UNDERFLOW,
				result.error_type == PackError.COMPLETE_FIXED_POINT_UNDERFLOW,
				result.error_type == PackError.INVALID_OP,
				result.error_type == PackError.NEGATIVE_TO_UNSIGNED,
				result.error_relative,
				_Utils.fromImp(result.value));

		return _Utils.fromImp(result.value);
	}

	/**
	 * Encodes a Java value to {@link Bits} using the specification of this Kernel type.
	 * @see #encodeConstant(Object)
	 */
	public Bits encodeConstant(int v) {
		return encodeConstant((double)v);
	}

	/**
	 * Encodes a Java value to {@link Bits} using the specification of this Kernel type.
	 * @see #encodeConstant(Object)
	 */
	public Bits encodeConstant(boolean v) {
		return encodeConstant(v ? 1.0 : 0.0);
	}

	@Override
	public Bits encodeConstant(Object v) {
		double real_v;
		if(v instanceof Double)
			real_v = (Double)v;
		else if(v instanceof Float)
			real_v = (Float)v;
		else if(v instanceof Integer)
			real_v = (Integer)v;
		else if(v instanceof Long)
			real_v = (Long)v;
		else if(v instanceof Boolean) {
			if ((Boolean)v)
				real_v = 1.0;
				else real_v = 0.0;
		} else
			throw new MaxCompilerAPIError(
				"Parameter must be instance of Double, Float, Integer, Long, or Boolean.");

		return encodeConstant(real_v);
	}

	@Override
	public int getTotalPrimitives() {
		return 1;
	}

	@Override
	protected DFEVar realUnpackWithDoubt(DFEVar src, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEDoubtType))
			throw new MaxCompilerAPIError(
				"unpackWithDoubt on DFEVar must be called with a DFEDoubtType object.");

		if(((DFEDoubtType)doubt_type).hasDoubtInfo()) {
			src = _KernelBaseTypes.fromImp(src.getKernel(),
				(doubtBitOpFactory(src.getKernel()).makeDoubtImplicit(src.m_imp)));
		}

		return realUnpack(src);
	}

	@Override
	public DFEVar realUnpackFromList(List<DFEVar> primitives) {
		if(!primitives.get(0).getType().equals(this))
			throw new MaxCompilerAPIError(
				"Primitive supplied is of type " + primitives.get(0).getType() +
				" which is not compatible with type: " + this);

		return primitives.get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public DFEFullType getFullTypeWithoutDoubtInfo() {
		return new DFEFullType(DFETypeFactory.dfeDoubtType(false), this);
	}

	@SuppressWarnings("unchecked")
	@Override
	public DFEFullType getFullTypeWithDoubtInfo() {
		return new DFEFullType(DFETypeFactory.dfeDoubtType(true), this);
	}
}
