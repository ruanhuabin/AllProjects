package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory.dfeBool;

import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * This is the base class for all multipipe types.
 * <p>
 * See {@link DFEVectorType} for a concrete multipipe type for use in Kernels.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 * @param <ContainedT> Type of an individual pipe.
 * @param <VectRealT> The actual multi-pipe type.
 * @param <CompareT> Multi-pipe comparison type.
 */
public abstract class DFEVectorTypeBase<
		ContainedT extends KernelObjectVectorizable<ContainedT>,
		VectRealT extends DFEVectorBase<ContainedT, VectRealT, ?, ?>,
		CompareT extends DFEVectorBase<DFEVar, CompareT, ?, ?>
	>
	extends KernelType<VectRealT>
{
	protected final DFEArrayType<ContainedT> m_pipe_type;
	protected final DFEArrayType<DFEVar> m_compare_type;

	/**
	 * @param contained_type Type of an individual pipe.
	 * @param num_pipes The number of pipes. Must be greater than 0.
	 */
	protected DFEVectorTypeBase(KernelTypeVectorizable<ContainedT> contained_type, int num_pipes) {
		m_pipe_type = new DFEArrayType<ContainedT>(contained_type, num_pipes);
		m_compare_type = new DFEArrayType<DFEVar>(dfeBool(), num_pipes);
	}

	@Override
	protected int realGetTotalBits() {
		return m_pipe_type.getTotalBits();
	}

	@Override
	public int getTotalPrimitives() {
		return m_pipe_type.getTotalPrimitives();
	}

	@Override
	protected abstract VectRealT realUnpackFromList(List<DFEVar> primitives);

	@Override
	protected abstract VectRealT realUnpack(DFEVar src);

	@Override
	protected VectRealT realUnpackWithDoubt(DFEVar src, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEVectorDoubtType))
			throw new MaxCompilerAPIError(
				"DFEVector-derived instances can only be unpacked using " +
				"DFEVectorDoubtType objects.");

		return realUnpackWithDoubt(src, (DFEVectorDoubtType)doubt_type);
	}

	protected abstract VectRealT realUnpackWithDoubt(DFEVar src, DFEVectorDoubtType doubt_type);

	@Override
	public final VectRealT newInstance(KernelLib design, DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEVectorDoubtType))
			throw new MaxCompilerAPIError(design.getManager(),
				"DFEVector-derived instances can only be made using " +
				"DFEVectorDoubtType objects.");

		return newInstance(design, (DFEVectorDoubtType)doubt_type);
	}

	public abstract VectRealT newInstance(KernelLib design, DFEVectorDoubtType doubt_type);

	public abstract VectRealT newInstance(KernelLib design, ContainedT v);

	public abstract VectRealT newInstance(KernelLib design, List<ContainedT> pipes);

	protected abstract CompareT newCompareInstance(KernelLib design);

	public int getNElements() {
		return m_pipe_type.getSize();
	}

	public KernelTypeVectorizable<ContainedT> getContainedType() {
		return (KernelTypeVectorizable<ContainedT>)m_pipe_type.getContainedType();
	}

	@SuppressWarnings({"rawtypes"})
	@Override
	public boolean equals(Object other_type) {
		return
			(other_type instanceof DFEVectorTypeBase) &&
			m_pipe_type.equals(((DFEVectorTypeBase)other_type).m_pipe_type);
	}

	@SuppressWarnings({"rawtypes"})
	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return
			(other_type instanceof DFEVectorTypeBase) &&
			m_pipe_type.equalsIgnoreMax(((DFEVectorTypeBase)other_type).m_pipe_type);
	}

	@Override
	public int hashCode() {
		return m_pipe_type.hashCode();
	}

	@SuppressWarnings({"rawtypes"})
	@Override
	public List decodeConstant(Bits raw_bits) {
		return m_pipe_type.decodeConstant(raw_bits);
	}

	@Override
	public Bits encodeConstant(Object value) {
		return m_pipe_type.encodeConstant(value);
	}

	/**
	 * Encodes a {@code List} of constant values representing each pipe in the stream into a single {@link Bits} value.
	 * @param value_list The object containing the constant values to encode.
	 * @return The encoded constant.
	 */
	public <T> Bits encodeConstant(List<T> value_list) {
		return m_pipe_type.encodeConstant(value_list);
	}

	/**
	 * Encodes an array of constant values representing each pipe in the stream into a single {@link Bits} value.
	 * @param value_array The object containing the constant values to encode.
	 * @return The encoded constant.
	 */
	public <T> Bits encodeConstant(T[] value_array) {
		return m_pipe_type.encodeConstant(value_array);
	}

	@Override
	public boolean isConcreteType() {
		return m_pipe_type.isConcreteType();
	}

	@Override
	public String toString() {
		return
			"{" + getClass().getSimpleName() + ": " +
			m_pipe_type.getSize() + " x " + m_pipe_type.getContainedType() + "}";
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public abstract DFEVectorFullTypeBase getFullTypeWithoutDoubtInfo();

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public abstract DFEVectorFullTypeBase getFullTypeWithDoubtInfo();
}
