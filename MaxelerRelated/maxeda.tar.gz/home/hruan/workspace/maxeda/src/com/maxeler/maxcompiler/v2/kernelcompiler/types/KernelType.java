package com.maxeler.maxcompiler.v2.kernelcompiler.types;

import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * The base class of all <em>Kernel types</em> in MaxCompiler.
 * <p>
 * Every {@link KernelObject} has an object of type {@code KernelType} which represents
 * the type of the data in the referenced stream.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public abstract class KernelType<InstanceT> {
	/**
	 * Returns {@code true} if this type is not untyped (see {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEUntypedConst}).
	 */
	abstract public boolean isConcreteType();

	/**
	 * Internal method.
	 */
	abstract protected int realGetTotalBits();

	/**
	 * Gets the total number of bits contained in the type.
	 * @return The number of bits in the type.
	 */
	public final int getTotalBits() {
		assertConcrete("get total bits");

		return realGetTotalBits();
	}

	/**
	 * Internal method.
	 */
	abstract protected InstanceT realUnpack(DFEVar src);

	/**
	 * The reverse of the {@code pack} method.
	 * @param src The source stream reference to unpack.
	 * @return The unpacked stream.
	 */
	public final InstanceT unpack(DFEVar src) {
		assertConcrete("unpack");

//		if(!(src.getType() instanceof DFERawBits))
//			throw new MaxCompilerAPIError(
//				"Cannot unpack from var of type " + src.getType() + " must be DFERawBits.");

		if(src.getType().getTotalBits() != realGetTotalBits())
			throw new MaxCompilerAPIError(src.getKernel().getManager(),
				"Supplied source is " + src.getType().getTotalBits() +
				" bits wide which is not compatible with type " + this);

		return realUnpack(src);
	}

	abstract protected InstanceT realUnpackWithDoubt(
		DFEVar src,
		DoubtType doubt_type);
	public final InstanceT unpackWithDoubt(DFEVar src, DoubtType doubt_type) {
		assertConcrete("unpack with doubt");

		if(src.getType().getTotalBits() != (realGetTotalBits() + doubt_type.getTotalBits()))
			throw new MaxCompilerAPIError(src.getKernel().getManager(),
				"Supplied source is " + src.getType().getTotalBits() +
				" bits wide which is not compatible with type " + this +
				" with doubt type " + doubt_type);

		return realUnpackWithDoubt(src, doubt_type);
	}

	abstract public int getTotalPrimitives();

	abstract protected InstanceT realUnpackFromList(List<DFEVar> primitives);
	public InstanceT unpackFromList(List<DFEVar> primitives) {
		if(primitives.size() != getTotalPrimitives())
			throw new MaxCompilerAPIError(
				"Primitive list " + primitives + " is incompatible with type " + this);

		return realUnpackFromList(primitives);
	}

	// Note we don't include "real" + abstract pairs for these
	// as derived types want to change the return type of
	// decodeCostant() and provide multiple encodeConstant()
	// methods with different signatures.

	/**
	 * Encodes a Java value to {@link Bits} using the specification of this Kernel type.
	 * @param value The value to encode.
	 */
	abstract public Bits encodeConstant(Object value );

	/**
	 * Decodes a set of {@link Bits} to a Java object. The bits are interpreted using the specification of this Kernel type.
	 * @param raw_bits The constant to decode.
	 */
	abstract public Object decodeConstant(Bits raw_bits);

	/**
	 * Creates a <em>source-less</em> stream reference of this type.
	 * @param design
	 */
	final public InstanceT newInstance(KernelLib design) {
		return getFullTypeWithoutDoubtInfo().newInstance(design);
	}

	abstract public InstanceT newInstance(KernelLib design, DoubtType doubt_type);

	/**
	 * Tests if this type is the same as another type.
	 * @param other_type The type to compare with.
	 */
	@Override
	abstract public boolean equals(Object other_type);

	abstract public boolean equalsIgnoreMax(KernelType<?> other_type);

	/**
	 * INTERNAL FUNCTION, DO NOT USE.
	 */
	public final KernelType<?> unionWithMaxOfMaxes(KernelType<?> other_type) {
		if( ! other_type.equalsIgnoreMax(other_type) )
			throw new MaxCompilerAPIError(
				"Can only get a unionWithMaxOfMaxes with identical type classes: "
				+ this + ".unionWithMaxOfMaxes(" + other_type + ")");

		return realUnionWithMaxOfMaxes(other_type);
	}

	/**
	 * INTERNAL FUNCTION, DO NOT USE.
	 */
	abstract protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type);


	/**
	 * Returns the type as a string.
	 */
	@Override
	abstract public String toString();

	/**
	 * Internal method.
	 */
	protected void assertConcrete(String what) {
		if(!isConcreteType())
			throw new MaxCompilerAPIError(
				"Cannot " + what + " as type " + this + " is not concrete.");
	}

	abstract public <FullTypeT extends FullType<DoubtType, KernelType<InstanceT>, InstanceT>> FullTypeT getFullTypeWithoutDoubtInfo();
	abstract public <FullTypeT extends FullType<DoubtType, KernelType<InstanceT>, InstanceT>> FullTypeT getFullTypeWithDoubtInfo();
}
