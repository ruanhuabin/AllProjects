package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.utils.MathUtils;

/**
 * Package private class. The customer facing interface is
 * 		DFEVar KernelMath.modulo(DFEVar input, int base);
 * @param owner
 */
class _ModuloLib extends KernelLib {
	_ModuloLib(KernelLib owner) {
		super(owner);
	}

	/**
	 * Organize inputs into a tree with look up tables. If the base is small enough,
	 * the tables will be implemented using LUTs. Otherwise this will be using BRAMs, which is
	 * a bad idea.
	 *
	 * @param input
	 * @param base
	 * @return
	 */
	private DFEVar treeResolve(List<DFEVar> input, int base) {
		if(input.size() == 1)
			return input.get(0);
		else {
			DFEVar left = treeResolve(input.subList(0, (input.size() / 2)), base);
			DFEVar right = treeResolve(input.subList(input.size() / 2, input.size()), base);
			int addressWidth = left.getType().getTotalBits() * 2;
			int tableDepth = 1 << addressWidth;
			double[] modResultTable = new double[tableDepth];
			int inputRange = 1 << (addressWidth / 2);
			for (int i = 0; i < inputRange; i++) {
				for (int j = 0; j < inputRange; j++) {
					modResultTable[((i << left.getType().getTotalBits()) + j)] = (i + j) % base;
				}
			}
			DFEVar address = Bitops.concat(left, right).cast(dfeUInt(addressWidth));
			return mem.rom(address, left.getType(), modResultTable);
		}
	}

	private int getLeftZeroCount(int n) {
		if(n < 0) {
			throw new MaxCompilerInternalError("Error in ModuloFactory. Please report this.");
		}
		int c = 0;
		while(n != 0) {
			n /= 2;
			c ++;
		}
		return 32 - c;
	}

	DFEVar modulo(DFEVar input, int base) {
		DFEType inputType = input.getType();

		if(base == 1) {
			return Kernel.dfeUInt(1).newInstance(input.getKernel(), 0);
		}

		if(!(inputType.isUInt()) && !(inputType.isInt()))
			throw new MaxCompilerAPIError(
				"Only supporting integers as input");
		if(base <= 0) {
			throw new MaxCompilerAPIError(
				"Base should be a positive number but got " + base);
		}
		if(inputType.decodeConstant(inputType.encodeConstant(base)) != base) {
			throw new MaxCompilerAPIError(
				"Base cannot be represented using type of input. Base = " + base + ", type of input = " + inputType.toString());
		}

		// We choose between three methods to implement the modulo:
		// * if the base is an exact power of two, we use casting and slicing
		// * if the base is small enough, we use look up tables
		// * otherwise we use KernelMath.divMod

		int lzc = getLeftZeroCount(base);
		if(base == 1 << (32-lzc-1)) {
			// we have an exact power of two
			int width = 32-lzc-1;
			return input.cast(dfeRawBits(inputType.getTotalBits())).slice(0, width).cast(dfeUInt(width));
		}
		int numBits = inputType.getTotalBits();
		int modResultWidth = MathUtils.bitsToAddress(base);
		boolean isSigned = inputType.isInt();
		if(modResultWidth < 4) {
			ArrayList<DFEVar> firstLevelResults = new ArrayList<DFEVar>();
			for (long i = 0; i < numBits; i += 6) {
				int sliceSize = (int) Math.min(6, numBits - i);
				DFEVar slice6 = input.slice((int) i, sliceSize).cast(dfeUInt(sliceSize));
				int tableDepth = 1 << sliceSize;
				double[] modResultTable = new double[tableDepth];
				if(i+6 < numBits || !isSigned) {
					for (long k = 0; k < tableDepth; k++) {
						modResultTable[(int) k] = (k << i) % base;
					}
				} else {
					long negMod = base - ( (1<<(sliceSize-1)) % base);
					for (long k = 0; k < tableDepth/2; k++) {
						modResultTable[(int) k] = (k << i) % base;
						modResultTable[(int) k + tableDepth/2] = ( negMod + (k << i) ) % base;
					}
				}
				firstLevelResults.add(mem.rom(slice6, dfeUInt(modResultWidth), modResultTable));
			}
			return treeResolve(firstLevelResults, base);
		} else {
			if(isSigned) {
				// divMod cannot handle signed numbers, so we need to work around that
				int totalBits = inputType.getTotalBits();
				long negMod = - (1L << (totalBits-1)) % base;
				if(negMod < 0)
					negMod += base;
				DFEVar isNeg = input.slice(totalBits-1).cast(dfeBool());
				DFEVar in_posPart = input.slice(0, totalBits-1);
				DFEFix posType = dfeUInt(totalBits);
				DFEVar posPart = dfeRawBits(1).newInstance(this, 0).cat(in_posPart).cast(posType);
				input = posPart + (isNeg ? posType.newInstance(this, negMod) : 0) ;
			}
			return KernelMath.divMod(input, dfeUInt(MathUtils.bitsToRepresentUnsigned(base)).newInstance(this, base)).getRemainder();
		}
	}
}