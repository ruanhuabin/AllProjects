package com.maxeler.maxcompiler.v2.managers.custom;

import java.util.Arrays;
import java.util.List;

import com.maxeler.maxdc.BuildManager;

public class _HDLTestBench extends HDLTestBench {

	public _HDLTestBench(String build_name, _ManagerSimulator sim) {
		super(build_name, sim);
	}

	@Override
	public BuildManager getBuildManager() {
		return super.getBuildManager();
	}

	@Override
	public void barWrite(int bar, long data, long addr) {
		super.barWrite(bar, data, addr);
	}

	@Override
	public void barRead(int bar, long addr, int tag) {
		super.barRead(bar, addr, tag);
	}

	@Override
	public void barMemoryWrite(int bar, List<Long> data, long addr) {
		super.barMemoryWrite(bar, data, addr);
	}

	// length in qwords
	@Override
	public void barMemoryRead(int bar, long addr, int len, int tag) {
		super.barMemoryRead(bar, addr, len, tag);
	}

	@Override
	public void toggleSFABits(List<Integer> bits_to_toggle, boolean remote) {
		super.toggleSFABits(bits_to_toggle, remote);
	}

	public List<Long> getOutputData(int output) {
		return getOutputData("" + output);
	}

	public void setManager(CustomManager manager) {
		m_manager = manager;
		m_manager_regs = manager;
	}

	public void setMappedRegister(String name, long value) {
		setScalarInputsGroup(Arrays.asList(new ScalarInput(name, value)));
	}

	@Override
	public void setMappedMemory(String name, long addr, List<Long> data, boolean assert_stop) {
		super.setMappedMemory(name, addr, data, assert_stop);
	}

	public void streamFromCPU(int id, List<Long> data) {
		m_cmds.add(new SFH(id, data));
	}

	public void waitInterrupt(int int_num) {
		m_cmds.add(new WaitInt(int_num));
	}

	public enum InterruptFlags {
		SFH_FLAG (0x0), STH_FLAG (0x1), MEM_FLAG (0x2), POWER_FLAG (0x3);
		private final int m_flag;
		InterruptFlags(int flag) {
			m_flag = flag;
		}
		public int getFlag() {
			return m_flag;
		}
	};

	@Override
	public void waitInterrupt(long one_hot_int, int timeout, InterruptFlags flag) {
		super.waitInterrupt(one_hot_int, timeout, flag);
	}

	public void syncStreamToCPU(int id, int timeout) {
		m_cmds.add(new SyncSTH(id, timeout));
	}


	public void syncStreamFromCPU(int id, int timeout) {
		m_cmds.add(new SyncSFH(id, timeout));
	}

	public void streamToCPU(int id, int size_in_quads) {
		m_cmds.add(new STH(id, size_in_quads));
	}

	@Override
	public void setForwardedManager(CustomManager manager) {
		super.setForwardedManager(manager);
	}

	@Override
	public void slaveStreamFromCPU(String name, List<Long> data) {
		super.slaveStreamFromCPU(name, data);
	}

	@Override
	public void slaveStreamToCPU(String name, int size_in_quads) {
		super.slaveStreamToCPU(name, size_in_quads);
	}


	public void syncSlaveStreamFromCPU(String name) {
		super.syncSlaveStreamFromCPU(name, 1000);	// Default timeout 1ms

	}

	@Override
	public void syncSlaveStreamFromCPU(String name, int timeout_us) {
		super.syncSlaveStreamFromCPU(name, timeout_us);
	}

	public void syncSlaveStreamToCPU(String name) {
		super.syncSlaveStreamToCPU(name, 1000);		// Default timeout 1ms

	}

	@Override
	public void syncSlaveStreamToCPU(String name, int timeout_us) {
		super.syncSlaveStreamToCPU(name, timeout_us);

	}

	@Override
	// This configure all buffers to the max size and set config_valid to 1
	public void setupSlaveStreamFromCPU(String name, boolean release) {
		super.setupSlaveStreamFromCPU(name, release);
	}

	@Override
	// This configure all buffers to the max size and set config_valid to 1
	public void setupSlaveStreamToCPU(String name, boolean release) {
		super.setupSlaveStreamToCPU(name, release);
	}
}
