package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.buffer.DFEsmFifo;

public final class _Buffer {
	private _Buffer() {}

	public static Buffer create(StateMachineLib owner) {return new Buffer(owner);}

	public static List<DFEsmFifo> getFifos(Buffer buf) {return buf.getFifos();}
}
