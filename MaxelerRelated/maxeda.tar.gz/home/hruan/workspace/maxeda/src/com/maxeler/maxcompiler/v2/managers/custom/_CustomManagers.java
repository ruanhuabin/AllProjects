package com.maxeler.maxcompiler.v2.managers.custom;

import com.maxeler.maxcompiler.v0.kernelcompiler.KernelDesign;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.KernelBlock;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.utils.EnumTranslator;

public class _CustomManagers {

	public enum OptimizationTarget { AREA, BANDWIDTH };

	public static com.maxeler.maxeleros.managercompiler.core.WrapperClock managerClockToImp(ManagerClock clock) {
		return clock.toImp();
	}

	public static com.maxeler.maxeleros.managercompiler.core.Stream streamToImp(DFELink stream) {
		return stream.toImp();
	}

	public static DFELink addFWStreamToCompute(CustomManager manager, String name) {
		return manager.addFWStreamToCompute(name);
	}

	public static DFELink addFWStreamFromCompute(CustomManager manager, String name) {
		return manager.addFWStreamFromCompute(name);
	}

	public static DFELink addStreamToFile(CustomManager manager, String file_name, int bit_width) {
		return manager.addStreamToFile(file_name, bit_width);
	}

	public static DFELink addStreamFromFile(CustomManager manager, String file_name, int bit_width) {
		return manager.addStreamToFile(file_name, bit_width);
	}

	public static WrapperDesignData getWrapperDesignData(CustomManager design) {
		return design.getWrapperDesignData();
	}

	public static com.maxeler.maxeleros.managercompiler.core.WrapperClock getStreamClock(CustomManager design) {
		return design.getStreamClock();
	}

	public static ManagerClock getStreamClockAsManagerClock(CustomManager design) {
		return new ManagerClock(design.getStreamClock());
	}

	public static KernelBlock addV0Kernel(CustomManager manager, KernelDesign kernel) {
		return manager.addKernel(kernel);
	}

	public static String getStreamName(DFELink stream) {
		return stream.getName();
	}

	public static void setStreamBufferSpaceRequirement(DFELink stream, int buffer_space) {
		stream.setBufferSpaceRequirement(buffer_space);
	}

	public static void setStreamHysteresis(DFELink stream, int hysteresis) {
		stream.setIOHysteresis(hysteresis);
	}

	public static DFELink fromImp(com.maxeler.maxeleros.managercompiler.core.Stream stream) {
		return new DFELink(stream);
	}

	public static ManagerClock fromImp(com.maxeler.maxeleros.managercompiler.core.WrapperClock clk) {
		return new ManagerClock(clk);
	}

	public static void setOptimizationTarget(DFELink stream, OptimizationTarget opt) {
		_CustomManagers.streamToImp(stream).setOptimizationTarget(EnumTranslator.convert(opt, com.maxeler.maxeleros.managercompiler.core.Stream.StreamOptimize.class));
	}
}
