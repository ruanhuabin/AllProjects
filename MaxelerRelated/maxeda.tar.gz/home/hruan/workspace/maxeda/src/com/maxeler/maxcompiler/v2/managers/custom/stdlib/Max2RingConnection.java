package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

public enum Max2RingConnection implements MaxRingConnection {
	FPGA_ON_LOCAL_CARD,
	FPGA_ON_REMOTE_CARD
}
