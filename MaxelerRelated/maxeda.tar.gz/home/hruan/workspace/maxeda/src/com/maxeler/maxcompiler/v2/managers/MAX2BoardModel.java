package com.maxeler.maxcompiler.v2.managers;

import com.maxeler.maxeleros.platforms.MAX2Board.MAX2BoardCapabilities;


public enum MAX2BoardModel implements MAXBoardModel {
	/** MAX2 Rev A, Virtex-5 LX110T, 12GB RAM (6x 2GB SODIMMs) */
	MAX2116A (MAX2BoardCapabilities.MAX2116A),
	/** MAX2 Rev A, Virtex-5 LX330T, 12GB RAM (6x 2GB SODIMMs) */
	MAX2336A (MAX2BoardCapabilities.MAX2336A),
	/** MAX2 Rev B, Virtex-5 LX110T, 12GB RAM (6x 2GB SODIMMs) */
	MAX2116B (MAX2BoardCapabilities.MAX2116B),
	/** MAX2 Rev B, Virtex-5 LX330T, 12GB RAM (6x 2GB SODIMMs) */
	MAX2336B (MAX2BoardCapabilities.MAX2336B),
	/** MAX2 Rev B, Virtex-5 SX240T, 12GB RAM (6x 2GB SODIMMs) */
	MAX2446B (MAX2BoardCapabilities.MAX2446B),
	/** MAX2 Rev B, Virtex-5 LX220T, 12GB RAM (6x 2GB SODIMMs) */
	MAX2226B (MAX2BoardCapabilities.MAX2226B),
	/** MAX2 Rev C, Virtex-5 SX240T, 12GB RAM (6x 2GB SODIMMs) */
	MAX2446C (MAX2BoardCapabilities.MAX2446C),
	/** MAX2 Rev C, Virtex-5 SX240T, 24GB RAM (6x 4GB SODIMMs) */
	MAX24412C(MAX2BoardCapabilities.MAX24412C);
	final MAX2BoardCapabilities m_board_caps;

	private MAX2BoardModel(MAX2BoardCapabilities board_caps) {
		m_board_caps = board_caps;
	}
}
