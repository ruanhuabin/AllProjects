package com.maxeler.maxcompiler.v2.managers.standard;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler._KernelConfiguration;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.managers.BuildConfig;
import com.maxeler.maxcompiler.v2.managers.SimulationParams;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.photon.configuration.PhotonKernelConfiguration.BuildTarget;
import com.maxeler.utils.SafeExceptionThread;

public class _DualSimulationManager {
	public enum DualSimMode {
		SEQUENTIAL, PARALLEL, A_ONLY, B_ONLY
	}

	static final SimulationParams s_simparams_a = SimulationParams.BITACCURATE;
	static final SimulationParams s_simparams_b = SimulationParams.HDLSIM;

	private final String m_name;
	private final DualSimMode m_mode;
	private final _SimulationManager m_manager_a;
	private final _SimulationManager m_manager_b;
	private final Set<String> m_manual_compare = new HashSet<String>();

	private final KernelConfiguration m_kernel_configuration = new _KernelConfiguration();
	private boolean m_config_is_immutable = false;
	private boolean m_is_manager_a_config_set = false;
	private boolean m_is_manager_b_config_set = false;

	public _DualSimulationManager(String name) {
		this(name, DualSimMode.SEQUENTIAL);
	}

	public _DualSimulationManager(String name, DualSimMode mode) {
		m_mode = mode;
		m_name = name;

		if (m_mode != DualSimMode.B_ONLY) {
			m_manager_a = new _SimulationManager(name+"_"+s_simparams_a, s_simparams_a);

			if (m_mode != DualSimMode.A_ONLY)
				_Managers.logSetConsoleTag(m_manager_a, s_simparams_a.toString());
		}
		else
			m_manager_a = null;

		if (m_mode != DualSimMode.A_ONLY) {
			m_manager_b = new _SimulationManager(name+"_"+s_simparams_b, s_simparams_b);

			if (m_mode != DualSimMode.B_ONLY)
				_Managers.logSetConsoleTag(m_manager_b, s_simparams_b.toString());
		}
		else
			m_manager_b = null;
	}

	public _SimulationManager getManager_A() {
		return (m_mode != DualSimMode.B_ONLY) ? m_manager_a : m_manager_b;
	}

	public _SimulationManager getManager_B() {
		return (m_mode != DualSimMode.A_ONLY) ? m_manager_b : m_manager_a;
	}

	/**
	 * Manually instruct {@link _DualSimulationManager} to compare the output of both
	 * simulation methods for a specified stream in a specified range. Once a manual
	 * comparison has taken place, no automatic comparisons will be perforemd.
	 *
	 * @param output_name	The stream to check
	 * @param start			The first valid element, indexed from zero
	 * @param end			The index one after the last element
	 */
	public void compareStreams(String output_name, int start, int end) {
		m_manual_compare.remove(output_name);
		compareStreamOutput(output_name, start, end);
		m_manual_compare.add(output_name);
	}

	private void execute(String name, Runnable task_a, Runnable task_b) {
		switch (m_mode) {
			case SEQUENTIAL:
				task_a.run();
				task_b.run();
				break;

			case PARALLEL:
				parallelExecute(name, task_a, task_b);
				break;

			case A_ONLY:
				task_a.run();
				break;

			case B_ONLY:
				task_b.run();
				break;
		}
	}

	@edu.umd.cs.findbugs.annotations.SuppressWarnings("DM_EXIT")
	private void parallelExecute(String name, Runnable task_a, Runnable task_b) {
		SafeExceptionThread thread_a = new SafeExceptionThread(task_a, name+"_"+s_simparams_a);
		SafeExceptionThread thread_b = new SafeExceptionThread(task_b, name+"_"+s_simparams_b);

		thread_a.start();
		thread_b.start();

		try {
			thread_a.join();
			thread_b.join();
		} catch (InterruptedException e) {
			System.err.println("Unexpected exception while waiting for thread completion: " + e.toString());
			e.printStackTrace();
			System.exit(1);
		}

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);

		if (thread_a.hadException()) {
			pw.println("\n\n>>>>>>>>");
			pw.println("Caught an exception during execution of " + thread_a.getName() + ":");
			thread_a.getException().printStackTrace(pw);
			pw.print("<<<<<<<<");
		}

		if (thread_b.hadException()) {
			pw.println("\n\n>>>>>>>>");
			pw.println("Caught an exception during execution of " + thread_b.getName() + ":");
			thread_b.getException().printStackTrace(pw);
			pw.print("<<<<<<<<");
		}

		pw.flush(); pw.close(); sw.flush();
		String err = sw.toString();
		if (err.length() > 0)
			throw new RuntimeException(err+"\n");
	}

	private void compareMappedRam(String name, int address) {
		if (m_mode == DualSimMode.A_ONLY || m_mode == DualSimMode.B_ONLY)
			return;

		double value_a = m_manager_a.getMappedRam(name, address);
		double value_b = m_manager_b.getMappedRam(name, address);
		if (Double.isNaN(value_a) != Double.isNaN(value_b))
			throw new RuntimeException("Received non-matching mapped RAM data for '" + name + "' at address " + address + "(" + value_a + " vs. " + value_b + ")");

		if (Double.isNaN(value_a))
			return;

		if (value_a != value_b)
			throw new RuntimeException("Received non-matching mapped RAM data for '" + name + "' at address " + address + "(" + value_a + " vs. " + value_b + ")");
	}

	private void compareStateMachineMappedRam(String state_machine_name, String name, int address) {
		if (m_mode == DualSimMode.A_ONLY || m_mode == DualSimMode.B_ONLY)
			return;

		double value_a = m_manager_a.getStateMachineMappedRam(state_machine_name, name, address);
		double value_b = m_manager_b.getStateMachineMappedRam(state_machine_name, name, address);
		if (Double.isNaN(value_a) != Double.isNaN(value_b))
			throw new RuntimeException("Received non-matching state machine mapped RAM data for state machine "+state_machine_name
				+" '" + name + "' at address " + address + "(" + value_a + " vs. " + value_b + ")");

		if (Double.isNaN(value_a))
			return;

		if (value_a != value_b)
			throw new RuntimeException("Received non-matching mapped RAM data for '" + name + "' at address " + address + "(" + value_a + " vs. " + value_b + ")");
	}

	private void compareStateMachineScalarOutput(String sm_name, String name) {
		if (m_mode == DualSimMode.A_ONLY || m_mode == DualSimMode.B_ONLY)
			return;

		Bits bits_a = m_manager_a.getStateMachineScalarOutputRaw(sm_name, name);
		Bits bits_b = m_manager_b.getStateMachineScalarOutputRaw(sm_name, name);

		if (! bits_a.equals(bits_b)) {
			System.err.println(s_simparams_a + ".scalarOutput(" + name + "):\t" + bits_a.valueAsHexString() + ", " + bits_a.valueAsBinary());
			System.err.println(s_simparams_b + ".scalarOutput(" + name + "):\t" + bits_b.valueAsHexString() + ", " + bits_b.valueAsBinary());
			throw new RuntimeException("Received non-matching bits for scalar output " + name);
		}
	}

	private void compareScalarOutput(String name) {
		if (m_mode == DualSimMode.A_ONLY || m_mode == DualSimMode.B_ONLY)
			return;

		Bits bits_a = m_manager_a.getScalarOutputRaw(name);
		Bits bits_b = m_manager_b.getScalarOutputRaw(name);

		if (! bits_a.equals(bits_b)) {
			System.err.println(s_simparams_a + ".scalarOutput(" + name + "):\t" + bits_a.valueAsHexString() + ", " + bits_a.valueAsBinary());
			System.err.println(s_simparams_b + ".scalarOutput(" + name + "):\t" + bits_b.valueAsHexString() + ", " + bits_b.valueAsBinary());
			throw new RuntimeException("Received non-matching bits for scalar output " + name);
		}
	}

	private void compareStreamOutput(String output_name) {
		compareStreamOutput(output_name, "data", 0, -1);
	}

	private void compareStreamOutput(String output_name, int start, int end) {
		compareStreamOutput(output_name, "data", start, end);
	}

	private void compareStreamOutput(String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name, 0, -1);
	}

	private void compareStreamOutput(String group_name, String stream_name, int start, int end) {
		if (m_manual_compare.contains(group_name))
			return;

		if (m_mode == DualSimMode.A_ONLY || m_mode == DualSimMode.B_ONLY)
			return;

		Bits[] bits_a = m_manager_a.getOutputDataRawArray(group_name, stream_name);
		Bits[] bits_b = m_manager_b.getOutputDataRawArray(group_name, stream_name);

		if (bits_a.length != bits_b.length)
			throw new RuntimeException("Received outputs of non-matching length for stream output " + group_name + "." + stream_name);

		if (end < 0)
			end = bits_a.length;

		for (int i=start; i<end; i++)
			if (! bits_a[i].equals(bits_b[i])) {
				try {	// We don't want to fail here
					dumpOutput();
				} catch (Exception e) { }

				throw new RuntimeException("Received non-matching bits at element " + i + " of stream output " + group_name + "." + stream_name);
			}
	}

	public void setKernels(final Kernel kernel_a, final Kernel kernel_b) {
		Runnable setter_a = new Runnable() {
			@Override
			public void run() {
				m_manager_a.setKernel(kernel_a);
			}
		};

		Runnable setter_b = new Runnable() {
			@Override
			public void run() {
				m_manager_b.setKernel(kernel_b);
			}
		};

		execute("setKernel", setter_a, setter_b);
	}

	public void setMappedRom(String name, int address, double value) {
		if(m_manager_a != null) m_manager_a.setMappedRom(name, address, value);
		if(m_manager_b != null) m_manager_b.setMappedRom(name, address, value);
	}

	public void setMappedRom(String name, double... values) {
		if(m_manager_a != null) m_manager_a.setMappedRom(name, values);
		if(m_manager_b != null) m_manager_b.setMappedRom(name, values);
	}

	public void setMappedRom(String name, int address, Bits value) {
		if(m_manager_a != null) m_manager_a.setMappedRom(name, address, value);
		if(m_manager_b != null) m_manager_b.setMappedRom(name, address, value);
	}

	public void setMappedRom(String name, Bits... values) {
		if(m_manager_a != null) m_manager_a.setMappedRom(name, values);
		if(m_manager_b != null) m_manager_b.setMappedRom(name, values);
	}

	public void setMappedRam(String name, double... values) {
		if (m_manager_a != null) m_manager_a.setMappedRam(name, values);
		if (m_manager_b != null) m_manager_b.setMappedRam(name, values);
	}

	public void setMappedRam(String name, int address, Bits value) {
		if(m_manager_a != null) m_manager_a.setMappedRam(name, address, value);
		if(m_manager_b != null) m_manager_b.setMappedRam(name, address, value);
	}

	public void setMappedRam(String name, Bits... values) {
		if(m_manager_a != null) m_manager_a.setMappedRam(name, values);
		if(m_manager_b != null) m_manager_b.setMappedRam(name, values);
	}

	public void setMappedRam(String name, int address, double value) {
		if(m_manager_a != null) m_manager_a.setMappedRam(name, address, value);
		if(m_manager_b != null) m_manager_b.setMappedRam(name, address, value);
	}

	public void setStateMachineMappedRom(String stateMachineName, String name, int address, double value) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRom(stateMachineName, name, address, value);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRom(stateMachineName, name, address, value);
	}

	public void setStateMachineMappedRom(String stateMachineName, String name, double... values) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRom(stateMachineName, name, values);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRom(stateMachineName, name, values);
	}

	public void setStateMachineMappedRom(String stateMachineName, String name, int address, Bits value) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRom(stateMachineName, name, address, value);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRom(stateMachineName, name, address, value);
	}

	public void setStateMachineMappedRom(String stateMachineName, String name, Bits... values) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRom(stateMachineName, name, values);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRom(stateMachineName, name, values);
	}

	public void setStateMachineMappedRam(String stateMachineName, String name, int address, double value) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRam(stateMachineName, name, address, value);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRam(stateMachineName, name, address, value);
	}

	public void setStateMachineMappedRam(String stateMachineName, String name, double... values) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRam(stateMachineName, name, values);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRam(stateMachineName, name, values);
	}

	public void setStateMachineMappedRam(String stateMachineName, String name, int address, Bits value) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRam(stateMachineName, name, address, value);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRam(stateMachineName, name, address, value);
	}

	public void setStateMachineMappedRam(String stateMachineName, String name, Bits... values) {
		if(m_manager_a != null) m_manager_a.setStateMachineMappedRam(stateMachineName, name, values);
		if(m_manager_b != null) m_manager_b.setStateMachineMappedRam(stateMachineName, name, values);
	}

	public void setScalarInput(String name, double value) {
		if(m_manager_a != null) m_manager_a.setScalarInput(name, value);
		if(m_manager_b != null) m_manager_b.setScalarInput(name, value);
	}

	public void setScalarInput(String name, Bits value) {
		if(m_manager_a != null) m_manager_a.setScalarInput(name, value);
		if(m_manager_b != null) m_manager_b.setScalarInput(name, value);
	}

	public void setStateMachineScalarInput(String stateMachineName, String name, double value) {
		if(m_manager_a != null) m_manager_a.setStateMachineScalarInput(stateMachineName, name, value);
		if(m_manager_b != null) m_manager_b.setStateMachineScalarInput(stateMachineName, name, value);
	}

	public void setStateMachineScalarInput(String stateMachineName, String name, Bits value) {
		if(m_manager_a != null) m_manager_a.setStateMachineScalarInput(stateMachineName, name, value);
		if(m_manager_b != null) m_manager_b.setStateMachineScalarInput(stateMachineName, name, value);
	}

	public double getMappedRam(String name, int address) {
		compareMappedRam(name, address);
		_SimulationManager manager = (m_manager_a != null) ? m_manager_a : m_manager_b;

		return manager.getMappedRam(name, address);
	}

	public Bits getMappedRamRaw(String name, int address) {
		compareMappedRam(name, address);
		_SimulationManager manager = (m_manager_a != null) ? m_manager_a : m_manager_b;

		return manager.getMappedRamRaw(name, address);
	}

	public double getScalarOutput(String name) {
		compareScalarOutput(name);
		return (m_manager_a != null)
			? m_manager_a.getScalarOutput(name)
			: m_manager_b.getScalarOutput(name);
	}

	public Bits getScalarOutputRaw(String name) {
		compareScalarOutput(name);
		return (m_manager_a != null)
			? m_manager_a.getScalarOutputRaw(name)
			: m_manager_b.getScalarOutputRaw(name);
	}

	public double getStateMachineMappedRam(String state_machine_name, String name, int address) {
		compareStateMachineMappedRam(state_machine_name, name, address);
		return (m_manager_a != null)
			? m_manager_a.getStateMachineMappedRam(state_machine_name, name, address)
			: m_manager_b.getStateMachineMappedRam(state_machine_name, name, address);
	}

	public Bits getStateMachineMappedRamRaw(String state_machine_name, String name, int address) {
		compareStateMachineMappedRam(state_machine_name, name, address);
		return (m_manager_a != null)
			? m_manager_a.getStateMachineMappedRamRaw(state_machine_name, name, address)
			: m_manager_b.getStateMachineMappedRamRaw(state_machine_name, name, address);
	}

	public double getStateMachineScalarOutput(String state_machine_name, String name) {
		compareStateMachineScalarOutput(state_machine_name, name);
		return (m_manager_a != null)
			? m_manager_a.getStateMachineScalarOutput(state_machine_name, name)
			: m_manager_b.getStateMachineScalarOutput(state_machine_name, name);
	}

	public Bits getStateMachineScalarOutputRaw(String state_machine_name, String name) {
		compareStateMachineScalarOutput(state_machine_name, name);
		return (m_manager_a != null)
			? m_manager_a.getStateMachineScalarOutputRaw(state_machine_name, name)
			: m_manager_b.getStateMachineScalarOutputRaw(state_machine_name, name);
	}

	public void setStreamOffsetParam(String name, int value) {
		if(m_manager_a != null) m_manager_a.setStreamOffsetParam(name, value);
		if(m_manager_b != null) m_manager_b.setStreamOffsetParam(name, value);
	}

	public int getOffsetAutoLoopSize(String name) {
		if (m_mode == DualSimMode.A_ONLY || m_mode == DualSimMode.B_ONLY)
			return (m_manager_a != null)
				? m_manager_a.getOffsetAutoLoopSize(name)
				: m_manager_b.getOffsetAutoLoopSize(name);

		int val_a = m_manager_a.getOffsetAutoLoopSize(name);
		int val_b = m_manager_b.getOffsetAutoLoopSize(name);

		if (val_a != val_b) {
			System.err.println(s_simparams_a + ".offsetAutoLoopSize(" + name + "):\t" + val_a);
			System.err.println(s_simparams_b + ".offsetAutoLoopSize(" + name + "):\t" + val_b);
			throw new RuntimeException("Received non-matching values for OffsetAutoLoop " + name);
		}

		return val_a;
	}

	public int getStreamDistance(String name) {
		if (m_mode == DualSimMode.A_ONLY || m_mode == DualSimMode.B_ONLY)
			return (m_manager_a != null)
				? m_manager_a.getStreamDistance(name)
				: m_manager_b.getStreamDistance(name);

		int val_a = m_manager_a.getStreamDistance(name);
		int val_b = m_manager_b.getStreamDistance(name);

		if (val_a != val_b) {
			System.err.println(s_simparams_a + ".streamDistance(" + name + "):\t" + val_a);
			System.err.println(s_simparams_b + ".streamDistance(" + name + "):\t" + val_b);
			throw new RuntimeException("Received non-matching values for stream distance measurement " + name);
		}

		return val_a;
	}

	public void setInputDataRaw(String group_name, String stream_name, List<Bits> data) {
		if(m_manager_a != null) m_manager_a.setInputDataRaw(group_name, stream_name, data);
		if(m_manager_b != null) m_manager_b.setInputDataRaw(group_name, stream_name, data);
	}

	public void setInputDataRaw(String group_name, String stream_name, Bits... data) {
		if(m_manager_a != null) m_manager_a.setInputDataRaw(group_name, stream_name, data);
		if(m_manager_b != null) m_manager_b.setInputDataRaw(group_name, stream_name, data);
	}

	public void setInputDataRaw(String input_name, Bits... data) {
		if(m_manager_a != null) m_manager_a.setInputDataRaw(input_name, data);
		if(m_manager_b != null) m_manager_b.setInputDataRaw(input_name, data);
	}

	public void setInputDataRaw(String input_name, List<Bits> data) {
		if(m_manager_a != null) m_manager_a.setInputDataRaw(input_name, data);
		if(m_manager_b != null) m_manager_b.setInputDataRaw(input_name, data);
	}

	public void setInputDataLong(String group_name,	String stream_name,	long... data) {
		if(m_manager_a != null) m_manager_a.setInputDataLong(group_name, stream_name, data);
		if(m_manager_b != null) m_manager_b.setInputDataLong(group_name, stream_name, data);
	}

	public void setInputDataLong(String input_name, long... data) {
		if(m_manager_a != null) m_manager_a.setInputDataLong(input_name, data);
		if(m_manager_b != null) m_manager_b.setInputDataLong(input_name, data);
	}

	public void setInputData(String group_name,	String stream_name,	double... data) {
		if(m_manager_a != null) m_manager_a.setInputData(group_name, stream_name, data);
		if(m_manager_b != null) m_manager_b.setInputData(group_name, stream_name, data);
	}

	public void setInputData(String group_name,String stream_name, List<Double> data) {
		if(m_manager_a != null) m_manager_a.setInputData(group_name, stream_name, data);
		if(m_manager_b != null) m_manager_b.setInputData(group_name, stream_name, data);
	}

	public void setInputData(String input_name, double... data) {
		if(m_manager_a != null) m_manager_a.setInputData(input_name, data);
		if(m_manager_b != null) m_manager_b.setInputData(input_name, data);
	}

	public void setInputData(String input_name, List<Double> data) {
		if(m_manager_a != null) m_manager_a.setInputData(input_name, data);
		if(m_manager_b != null) m_manager_b.setInputData(input_name, data);
	}

	public void ioForceDisabled(String io_name, boolean disabled) {
		setScalarInput("io_" + io_name + "_force_disabled", disabled ? 1 : 0);
	}

	public <T> List<T> getOutputData(KernelType<?> type, String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name);
		List<T> result;

		if (m_manager_a != null)
			result = m_manager_a.getOutputData(type, group_name, stream_name);
		else
			result = m_manager_b.getOutputData(type, group_name, stream_name);
		return result;
	}

	public <T> List<T> getOutputData(KernelType<?> type, String output_name) {
		compareStreamOutput(output_name);

		List<T> result;
		if (m_manager_a != null)
			result = m_manager_a.getOutputData(type, output_name);
		else
			result = m_manager_b.getOutputData(type, output_name);
		return result;
	}

	public List<Double> getOutputData(String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputData(group_name, stream_name)
			: m_manager_b.getOutputData(group_name, stream_name);
	}

	public List<Double> getOutputData(String output_name) {
		compareStreamOutput(output_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputData(output_name)
			: m_manager_b.getOutputData(output_name);
	}

	public double[] getOutputDataArray(String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataArray(group_name, stream_name)
			: m_manager_b.getOutputDataArray(group_name, stream_name);
	}

	public double[] getOutputDataArray(String output_name) {
		compareStreamOutput(output_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataArray(output_name)
			: m_manager_b.getOutputDataArray(output_name);
	}

	public List<Long> getOutputDataLong(String output_name) {
		compareStreamOutput(output_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataLong(output_name)
			: m_manager_b.getOutputDataLong(output_name);
	}

	public long[] getOutputDataLongArray(String output_name) {
		compareStreamOutput(output_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataLongArray(output_name)
			: m_manager_b.getOutputDataLongArray(output_name);
	}

	public List<Long> getOutputDataLong(String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataLong(group_name, stream_name)
			: m_manager_b.getOutputDataLong(group_name, stream_name);
	}

	public long[] getOutputDataLongArray(String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataLongArray(group_name, stream_name)
			: m_manager_b.getOutputDataLongArray(group_name, stream_name);
	}

	public List<Bits> getOutputDataRaw(String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataRaw(group_name, stream_name)
			: m_manager_b.getOutputDataRaw(group_name, stream_name);
	}

	public Bits[] getOutputDataRawArray(String group_name, String stream_name) {
		compareStreamOutput(group_name, stream_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataRawArray(group_name, stream_name)
			: m_manager_b.getOutputDataRawArray(group_name, stream_name);
	}

	public List<Bits> getOutputDataRaw(String output_name) {
		compareStreamOutput(output_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataRaw(output_name)
			: m_manager_b.getOutputDataRaw(output_name);
	}

	public Bits[] getOutputDataRawArray(String output_name) {
		compareStreamOutput(output_name);
		return (m_manager_a != null)
			? m_manager_a.getOutputDataRawArray(output_name)
			: m_manager_b.getOutputDataRawArray(output_name);
	}

	public void checkOutputDataRange(String group_name,	String stream_name,	int start,
		int end, double... values)
	{
		compareStreamOutput(group_name, stream_name, start, end);
		if(m_manager_a != null) m_manager_a.checkOutputDataRange(group_name, stream_name, start, end, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRange(group_name, stream_name, start, end, values);
	}

	public void checkOutputDataRange(String output_name, int start,	int end,
		double... values)
	{
		compareStreamOutput(output_name, start, end);
		if(m_manager_a != null) m_manager_a.checkOutputDataRange(output_name, start, end, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRange(output_name, start, end, values);
	}

	public void checkOutputData(String group_name, String stream_name, double... values) {
		compareStreamOutput(group_name, stream_name);
		if(m_manager_a != null) m_manager_a.checkOutputData(group_name, stream_name, values);
		if(m_manager_b != null) m_manager_b.checkOutputData(group_name, stream_name, values);
	}

	public void checkOutputData(String output_name, double... values) {
		compareStreamOutput(output_name);
		if(m_manager_a != null) m_manager_a.checkOutputData(output_name, values);
		if(m_manager_b != null) m_manager_b.checkOutputData(output_name, values);
	}

	public void checkOutputDataRaw(String output_name, Bits... values) {
		compareStreamOutput(output_name);
		if(m_manager_a != null) m_manager_a.checkOutputDataRaw(output_name, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRaw(output_name, values);
	}

	public void checkOutputDataRaw(String group_name, String stream_name, Bits... values) {
		compareStreamOutput(group_name, stream_name);
		if(m_manager_a != null) m_manager_a.checkOutputDataRaw(group_name, stream_name, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRaw(group_name, stream_name, values);
	}

	public void checkOutputDataRangeRaw(String output_name, int start,	int end, Bits... values) {
		compareStreamOutput(output_name, start, end);
		if(m_manager_a != null) m_manager_a.checkOutputDataRangeRaw(output_name, start, end, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRangeRaw(output_name, start, end, values);
	}

	public void checkOutputDataRangeRaw(String group_name, String stream_name, int start, int end, Bits... values) {
		compareStreamOutput(group_name, stream_name, start, end);
		if(m_manager_a != null) m_manager_a.checkOutputDataRangeRaw(group_name, stream_name, start, end, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRangeRaw(group_name, stream_name, start, end, values);
	}


	public void checkOutputDataRangeLong(String group_name,	String stream_name,	int start,
		int end, long... values)
	{
		compareStreamOutput(group_name, stream_name, start, end);
		if(m_manager_a != null) m_manager_a.checkOutputDataRangeLong(group_name, stream_name, start, end, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRangeLong(group_name, stream_name, start, end, values);
	}

	public void checkOutputDataRangeLong(String output_name, int start,	int end, long... values) {
		compareStreamOutput(output_name, start, end);
		if(m_manager_a != null) m_manager_a.checkOutputDataRangeLong(output_name, start, end, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataRangeLong(output_name, start, end, values);
	}

	public void checkOutputDataLong(String group_name, String stream_name, long... values) {
		compareStreamOutput(group_name, stream_name);
		if(m_manager_a != null) m_manager_a.checkOutputDataLong(group_name, stream_name, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataLong(group_name, stream_name, values);
	}

	public void checkOutputDataLong(String name, long... values) {
		compareStreamOutput(name);
		if(m_manager_a != null) m_manager_a.checkOutputDataLong(name, values);
		if(m_manager_b != null) m_manager_b.checkOutputDataLong(name, values);
	}

	public void dumpOutput() {
		if (m_manager_a != null) {
			System.out.println("Dumping output for run A (" + s_simparams_a + "):");
			m_manager_a.dumpOutput();
			System.out.println();
		}

		if (m_manager_b != null) {
			System.out.println("Dumping output for run B (" + s_simparams_b + "):");
			m_manager_b.dumpOutput();
		}
	}

	public void runTest() {
		build();
		run();
	}

	public void build() {
		Runnable builder_a = new Runnable() {
			@Override
			public void run() {
				m_manager_a.build();
			}
		};

		Runnable builder_b = new Runnable() {
			@Override
			public void run() {
				m_manager_b.build();
			}
		};

		execute("build", builder_a, builder_b);
	}

	public void run(final String name) {
		Runnable runner_a = new Runnable() {
			@Override
			public void run() {
				m_manager_a.run( (name==null) ? s_simparams_a.toString() : name+"_"+s_simparams_a );
			}
		};

		Runnable runner_b = new Runnable() {
			@Override
			public void run() {
				m_manager_b.run( (name==null) ? s_simparams_b.toString() : name+"_"+s_simparams_b );
			}
		};

		execute("run", runner_a, runner_b);
	}

	public void run() { run(null); }

	public void setKernelCycles(long cycles) {
		if(m_manager_a != null) m_manager_a.setKernelCycles(cycles);
		if(m_manager_b != null) m_manager_b.setKernelCycles(cycles);
	}

	// Methods from _SimulationManager

	public void enableSimOnCluster() {
		if(m_manager_a != null) m_manager_a.enableSimOnCluster();
		if(m_manager_b != null) m_manager_b.enableSimOnCluster();
	}

	public void enableSimGUI() {
		if(m_manager_a != null) m_manager_a.enableSimGUI();
		if(m_manager_b != null) m_manager_b.enableSimGUI();
	}

	public void dumpExceptions() {
		if (m_manager_a != null) {
			System.out.println("Dumping exceptions for run A (" + s_simparams_a + "):");
			m_manager_a.dumpExceptions();
			System.out.println();
		}

		if (m_manager_b != null) {
			System.out.println("Dumping exceptions for run B (" + s_simparams_b + "):");
			m_manager_b.dumpExceptions();
		}
	}

	// Methods from DFEManager

	public KernelParameters makeKernelParameters_A() {
		return makeKernelParameters_A(null);
	}

	public KernelParameters makeKernelParameters_A(String kernel_name) {
		if (!m_config_is_immutable) {
			m_kernel_configuration.setImmutable();
			m_config_is_immutable = true;
		}

		if(m_manager_a != null && m_mode != DualSimMode.B_ONLY) {
			if (!m_is_manager_a_config_set) {
				KernelConfiguration conf_a_new = new KernelConfiguration(m_kernel_configuration);

				BuildTarget target;
				if (s_simparams_a == SimulationParams.BITACCURATE)
					target = BuildTarget.MAXCOMPILERSIM_JAVA_DRIVEN;
				else if (s_simparams_a == SimulationParams.HDLSIM)
					target = BuildTarget.HDL_SIM;
				else
					throw new MaxCompilerInternalError(m_manager_a, "Unimplemented SimulationParams '" + s_simparams_a + "'");

				_KernelConfiguration.setBuildTarget(conf_a_new, target);
				m_manager_a.setCurrentKernelConfig(conf_a_new);
				m_is_manager_a_config_set = true;
			}
			return kernel_name == null ?
				m_manager_a.makeKernelParameters() : m_manager_a.makeKernelParameters(kernel_name+"_"+s_simparams_a);
		}
		else {
			return kernel_name == null ?
				makeKernelParameters_B(m_name + "_Kernel_A") : makeKernelParameters_B(kernel_name+"_A");
		}
	}

	public KernelParameters makeKernelParameters_B() {
		return makeKernelParameters_B(null);
	}

	public KernelParameters makeKernelParameters_B(String kernel_name) {
		if (!m_config_is_immutable) {
			m_kernel_configuration.setImmutable();
			m_config_is_immutable = true;
		}

		if(m_manager_b != null && m_mode != DualSimMode.A_ONLY) {
			if (!m_is_manager_b_config_set) {
				KernelConfiguration conf_b_new = new KernelConfiguration(m_kernel_configuration);

				BuildTarget target;
				if (s_simparams_b == SimulationParams.BITACCURATE)
					target = BuildTarget.MAXCOMPILERSIM_JAVA_DRIVEN;
				else if (s_simparams_b == SimulationParams.HDLSIM)
					target = BuildTarget.HDL_SIM;
				else
					throw new MaxCompilerInternalError(m_manager_b, "Unimplemented SimulationParams '" + s_simparams_a + "'");

				_KernelConfiguration.setBuildTarget(conf_b_new, target);

				m_manager_b.setCurrentKernelConfig(conf_b_new);
				m_is_manager_b_config_set = true;
			}
			return kernel_name == null ?
				m_manager_b.makeKernelParameters() : m_manager_b.makeKernelParameters(kernel_name+"_"+s_simparams_b);
		}
		else {
			return kernel_name == null ?
				makeKernelParameters_A(m_name + "_Kernel_B") : makeKernelParameters_A(kernel_name+"_B");
		}
	}

	public void logMsg(String msg, Object... args) {
		if(m_manager_a != null) m_manager_a.logMsg(msg, args);
		if(m_manager_b != null) m_manager_b.logMsg(msg, args);
	}

	public void logWarning(String msg, Object... args) {
		if(m_manager_a != null) m_manager_a.logWarning(msg, args);
		if(m_manager_b != null) m_manager_b.logWarning(msg, args);
	}

	public void logError(String msg, Object... args) {
		if (m_manager_a != null) m_manager_a.logError(msg, args);
		if (m_manager_b != null) m_manager_b.logError(msg, args);
	}

	public void setParameter(String name, String value) {
		if(m_manager_a != null) m_manager_a.setParameter(name, value);
		if(m_manager_b != null) m_manager_b.setParameter(name, value);
	}

	public void addMaxFileConstant(String name, int value) {
		if(m_manager_a != null) m_manager_a.addMaxFileConstant(name, value);
		if(m_manager_b != null) m_manager_b.addMaxFileConstant(name, value);
	}

	public boolean isTargetSimulation() {
		return true;
	}

	public String getName() {
		switch (m_mode) {
			case A_ONLY:
				return m_manager_a.getName();

			case B_ONLY:
				return m_manager_b.getName();

			default:
				return "A_" + m_manager_a.getName() + "__B_" + m_manager_b.getName();
		}
	}

	public void setBuildConfig(BuildConfig build_config) {
		if(m_manager_a != null) m_manager_a.setBuildConfig(build_config);
		if(m_manager_b != null) m_manager_b.setBuildConfig(build_config);
	}

	public BuildConfig getBuildConfig_A() {
		return (m_mode != DualSimMode.B_ONLY) ? m_manager_a.getBuildConfig() : m_manager_b.getBuildConfig();
	}

	public BuildConfig getBuildConfig_B() {
		return (m_mode != DualSimMode.A_ONLY) ? m_manager_b.getBuildConfig() : m_manager_a.getBuildConfig();
	}

	public KernelConfiguration getDefaultKernelConfig() {
		return m_kernel_configuration;
	}

	public void setTerminationCount(String outputName, int dataLength) {
		if(m_manager_a != null) m_manager_a.setTerminationCount(outputName, dataLength);
		if(m_manager_b != null) m_manager_b.setTerminationCount(outputName, dataLength);
	}
}
