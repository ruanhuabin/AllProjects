package com.maxeler.maxcompiler.v2.kernelcompiler.types;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

/**
 * Utility class which can be extended when a new KernelObject is pipeable
 * but only implements a subset of functions in KernelPipeable.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public abstract class KernelObjectVectorizableNull<RealT> implements KernelObjectVectorizable<RealT> {
	@Override
	public RealT add(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'add' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT and(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'and' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT cat(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'cat' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT div(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'div' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT eq(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'eq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT gt(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'gt' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT gte(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'gte' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT shiftLeft(DFEVar rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'leftShift' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT shiftLeft(int shift_amt) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'leftShift' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT lt(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lt' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT lte(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lte' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT mul(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'mul' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT neg() {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'neg' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT neq(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'neq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT complement() {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'complement' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT or(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'or' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT rotateLeft(DFEVar rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'rotateLeft' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT rotateLeft(int shift_amt) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'rotateLeft' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT rotateRight(DFEVar rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'rotateRight' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT rotateRight(int shift_amt) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'rotateRight' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT shiftRight(DFEVar rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'rightShift' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT shiftRight(int shift_amt) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'rightShift' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT slice(int base, int width) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'slice' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT sub(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'sub' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public <T extends KernelObject<T>> T ternaryIf(T true_cond, T false_cond) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'ternaryIf' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT xor(RealT rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'xor' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT add(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'add' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT add(float rhs) {
		return add((double)rhs);
	}

	@Override
	public RealT add(int rhs) {
		return add((long)rhs);
	}

	@Override
	public RealT add(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'add' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT addAsRHS(double lhs) {
		return add(lhs);
	}

	@Override
	public RealT addAsRHS(float lhs) {
		return add(lhs);
	}

	@Override
	public RealT addAsRHS(int lhs) {
		return add(lhs);
	}

	@Override
	public RealT addAsRHS(long lhs) {
		return add(lhs);
	}

	@Override
	public RealT and(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'and' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT and(float rhs) {
		return and((double)rhs);
	}

	@Override
	public RealT and(int rhs) {
		return and((long)rhs);
	}

	@Override
	public RealT and(boolean rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'and' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT and(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'and' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT andAsRHS(double lhs) {
		return and(lhs);
	}

	@Override
	public RealT andAsRHS(float lhs) {
		return and(lhs);
	}

	@Override
	public RealT andAsRHS(int lhs) {
		return and(lhs);
	}

	@Override
	public RealT andAsRHS(boolean lhs) {
		return and(lhs);
	}

	@Override
	public RealT andAsRHS(long lhs) {
		return and(lhs);
	}

	@Override
	public RealT div(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'div' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT div(float rhs) {
		return div((double)rhs);
	}

	@Override
	public RealT div(int rhs) {
		return div((long)rhs);
	}

	@Override
	public RealT div(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'div' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT divAsRHS(double lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'div' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT divAsRHS(float lhs) {
		return divAsRHS((double)lhs);
	}

	@Override
	public RealT divAsRHS(int lhs) {
		return divAsRHS((long)lhs);
	}

	@Override
	public RealT divAsRHS(long lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'div' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT eq(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'eq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT eq(float rhs) {
		return eq((double)rhs);
	}

	@Override
	public RealT eq(int rhs) {
		return eq((long)rhs);
	}

	@Override
	public RealT eq(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'eq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT eq(boolean rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'eq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT eqAsRHS(double lhs) {
		return eq(lhs);
	}

	@Override
	public RealT eqAsRHS(float lhs) {
		return eq(lhs);
	}

	@Override
	public RealT eqAsRHS(int lhs) {
		return eq(lhs);
	}

	@Override
	public RealT eqAsRHS(long lhs) {
		return eq(lhs);
	}

	@Override
	public RealT eqAsRHS(boolean lhs) {
		return eq(lhs);
	}

	@Override
	public RealT gt(double rhs) {
		return ltAsRHS(rhs);
	}

	@Override
	public RealT gt(float rhs) {
		return ltAsRHS(rhs);
	}

	@Override
	public RealT gt(int rhs) {
		return ltAsRHS(rhs);
	}

	@Override
	public RealT gt(long rhs) {
		return ltAsRHS(rhs);
	}

	@Override
	public RealT gtAsRHS(double lhs) {
		return lt(lhs);
	}

	@Override
	public RealT gtAsRHS(float lhs) {
		return lt(lhs);
	}

	@Override
	public RealT gtAsRHS(int lhs) {
		return lt(lhs);
	}

	@Override
	public RealT gtAsRHS(long lhs) {
		return lt(lhs);
	}

	@Override
	public RealT gte(double rhs) {
		return lteAsRHS(rhs);
	}

	@Override
	public RealT gte(float rhs) {
		return lteAsRHS(rhs);
	}

	@Override
	public RealT gte(int rhs) {
		return lteAsRHS(rhs);
	}

	@Override
	public RealT gte(long rhs) {
		return lteAsRHS(rhs);
	}

	@Override
	public RealT gteAsRHS(double lhs) {
		return lte(lhs);
	}

	@Override
	public RealT gteAsRHS(float lhs) {
		return lte(lhs);
	}

	@Override
	public RealT gteAsRHS(int lhs) {
		return lte(lhs);
	}

	@Override
	public RealT gteAsRHS(long lhs) {
		return lte(lhs);
	}

	@Override
	public RealT lt(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lt' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT lt(float rhs) {
		return lt((double)rhs);
	}

	@Override
	public RealT lt(int rhs) {
		return lt((long)rhs);
	}

	@Override
	public RealT lt(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lt' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT ltAsRHS(double lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lt' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT ltAsRHS(float lhs) {
		return ltAsRHS((double)lhs);
	}

	@Override
	public RealT ltAsRHS(int lhs) {
		return ltAsRHS((long)lhs);
	}

	@Override
	public RealT ltAsRHS(long lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lt' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT lte(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lte' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT lte(float rhs) {
		return lte((double)rhs);
	}

	@Override
	public RealT lte(int rhs) {
		return lte((long)rhs);
	}

	@Override
	public RealT lte(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lte' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT lteAsRHS(double lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lte' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT lteAsRHS(float lhs) {
		return lteAsRHS((double)lhs);
	}

	@Override
	public RealT lteAsRHS(int lhs) {
		return lteAsRHS((long)lhs);
	}

	@Override
	public RealT lteAsRHS(long lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'lte' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT mul(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'mul' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT mul(float rhs) {
		return mul((double)rhs);
	}

	@Override
	public RealT mul(int rhs) {
		return mul((double)rhs);
	}

	@Override
	public RealT mul(long rhs) {
		return mul((double)rhs);
	}

	@Override
	public RealT mulAsRHS(double lhs) {
		return mul(lhs);
	}

	@Override
	public RealT mulAsRHS(float lhs) {
		return mul(lhs);
	}

	@Override
	public RealT mulAsRHS(int lhs) {
		return mul(lhs);
	}

	@Override
	public RealT mulAsRHS(long lhs) {
		return mul(lhs);
	}

	@Override
	public RealT neq(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'neq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT neq(float rhs) {
		return neq((double)rhs);
	}

	@Override
	public RealT neq(int rhs) {
		return neq((long)rhs);
	}

	@Override
	public RealT neq(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'neq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT neq(boolean rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'neq' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT neqAsRHS(double lhs) {
		return neq(lhs);
	}

	@Override
	public RealT neqAsRHS(float lhs) {
		return neq(lhs);
	}

	@Override
	public RealT neqAsRHS(int lhs) {
		return neq(lhs);
	}

	@Override
	public RealT neqAsRHS(long lhs) {
		return neq(lhs);
	}

	@Override
	public RealT neqAsRHS(boolean lhs) {
		return neq(lhs);
	}

	@Override
	public RealT or(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'or' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT or(float rhs) {
		return or((double)rhs);
	}

	@Override
	public RealT or(int rhs) {
		return or((long)rhs);
	}

	@Override
	public RealT or(boolean rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'or' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT or(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'or' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT orAsRHS(double lhs) {
		return or(lhs);
	}

	@Override
	public RealT orAsRHS(float lhs) {
		return or(lhs);
	}

	@Override
	public RealT orAsRHS(int lhs) {
		return or(lhs);
	}

	@Override
	public RealT orAsRHS(boolean lhs) {
		return or(lhs);
	}

	@Override
	public RealT orAsRHS(long lhs) {
		return or(lhs);
	}

	@Override
	public RealT sub(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'sub' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT sub(float rhs) {
		return sub((double)rhs);
	}

	@Override
	public RealT sub(int rhs) {
		return sub((long)rhs);
	}

	@Override
	public RealT sub(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'sub' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT subAsRHS(double lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'sub' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT subAsRHS(float lhs) {
		return subAsRHS((double)lhs);
	}

	@Override
	public RealT subAsRHS(int lhs) {
		return subAsRHS((long)lhs);
	}

	@Override
	public RealT subAsRHS(long lhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'sub' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT xor(double rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'xor' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT xor(float rhs) {
		return xor((double)rhs);
	}

	@Override
	public RealT xor(int rhs) {
		return xor((long)rhs);
	}

	@Override
	public RealT xor(boolean rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'xor' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT xor(long rhs) {
		throw new MaxCompilerAPIError(getKernel().getManager(), "Op 'xor' not supported for type " + getClass().getSimpleName() + ".");
	}

	@Override
	public RealT xorAsRHS(double lhs) {
		return xor(lhs);
	}

	@Override
	public RealT xorAsRHS(float lhs) {
		return xor(lhs);
	}

	@Override
	public RealT xorAsRHS(int lhs) {
		return xor(lhs);
	}

	@Override
	public RealT xorAsRHS(boolean lhs) {
		return xor(lhs);
	}

	@Override
	public RealT xorAsRHS(long lhs) {
		return xor(lhs);
	}

	public DFEVar pack() {
		if(getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use pack() on this stream as it contains doubt " +
				"information. If you want to explicitly discard this information " +
				"use packWithoutDoubt(), otherwise use packWithDoubt().");

		return packWithoutDoubt();
	}

	@Override
	public RealT addDoubtInfo() {
		return castDoubtType( getType().getFullTypeWithDoubtInfo().getDoubtType() );
	}

	@Override
	public RealT removeDoubtInfo() {
		return castDoubtType( getType().getFullTypeWithoutDoubtInfo().getDoubtType() );
	}
}
