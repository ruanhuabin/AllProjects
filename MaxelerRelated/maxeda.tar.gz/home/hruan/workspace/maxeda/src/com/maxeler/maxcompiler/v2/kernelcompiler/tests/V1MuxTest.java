package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;

public class V1MuxTest extends Kernel {

	private V1MuxTest(KernelParameters parameters) {
		super(parameters);

		flush.whenInputFinished("sel");

		DFEType ot = dfeUInt(32);
		DFEVar sel = io.input("sel", dfeUInt(2));
		DFEVar value = io.output("value", ot);

		value.connect(
			control.mux(
				sel,
				constant.var(ot, 10),
				constant.var(ot, 20),
				constant.var(ot, 30)) );

		value.watch("value");
	}

	public static void main(String[] args) {
		SimulationManager sm = new SimulationManager("V1MuxTest");

		sm.setKernel( new V1MuxTest(sm.makeKernelParameters()) );
		sm.setInputData("sel", 0, 1, 2, 3);
		sm.runTest();

		// Last value is actually X but we can't check for this directly...
		sm.checkOutputData("value", 10, 20, 30, 0);
	}
}
