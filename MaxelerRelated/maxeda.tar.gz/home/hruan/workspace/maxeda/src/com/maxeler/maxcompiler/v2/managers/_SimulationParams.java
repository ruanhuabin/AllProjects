package com.maxeler.maxcompiler.v2.managers;

import com.maxeler.photon.compile_managers.JavaSimCompileManager;

public class _SimulationParams extends SimulationParams {

	public _SimulationParams(JavaSimCompileManager.Factory build_method) {
		super(build_method);
	}

	public static JavaSimCompileManager.Factory getCompileManagerFactory(
		SimulationParams sim_params)
	{
		return sim_params.m_compile_manager_factory;
	}
}
