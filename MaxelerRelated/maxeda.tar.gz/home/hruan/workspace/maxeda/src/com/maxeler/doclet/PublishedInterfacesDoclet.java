package com.maxeler.doclet;

import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.ConstructorDoc;
import com.sun.javadoc.Doclet;
import com.sun.javadoc.FieldDoc;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.ProgramElementDoc;
import com.sun.javadoc.RootDoc;

public class PublishedInterfacesDoclet extends Doclet {
	/** Command-line options for the Doclet. */
	private enum CommandLineOptions implements Utils.CommandLineOption {
		PUBLISHED_FILE,
		DEPRECATED_FILE,
		HIDDEN_FILE;

		private final String m_optionName;

		private CommandLineOptions() { m_optionName = "-" + name().toLowerCase(); }

		@Override
		public String optionName() { return m_optionName; }
	}

	private static class ClassMembers {
		private final SortedMap<String, String> m_published = new TreeMap<String, String>();
		private final SortedMap<String, String> m_deprecated = new TreeMap<String, String>();
		private final SortedMap<String, String> m_hidden = new TreeMap<String, String>();

		public SortedMap<String, String> getPublished() { return Collections.unmodifiableSortedMap(m_published); }

		public SortedMap<String, String> getDeprecated() { return Collections.unmodifiableSortedMap(m_deprecated); }

		public SortedMap<String, String> getHidden() { return Collections.unmodifiableSortedMap(m_hidden); }

		public void addMember(FieldDoc field) { addMember(field, "field"); }

		public void addMember(ConstructorDoc constructor) { addMember(constructor, "constructor"); }

		public void addMember(MethodDoc method) { addMember(method, "method"); }

		private void addMember(ProgramElementDoc member, String type) {
			SortedMap<String, String> m = null;

			switch (Utils.getVisibility(member)) {
				case PUBLISHED:
					m = m_published;
					break;
				case DEPRECATED:
					m = m_deprecated;
					break;
				case HIDDEN:
					m = m_hidden;
					break;
				case INTERNAL:
					// ignore
					break;
				default:
					throw new AssertionError("Unknown visibility: " + Utils.getVisibility(member));
			}

			if (m != null)
				m.put(member.name(), type);
		}
	}

	private static final java.util.Comparator<ClassDoc> classComparator = new java.util.Comparator<ClassDoc>() {
		@Override
		public int compare(ClassDoc o1, ClassDoc o2) {
			return o1.qualifiedTypeName().compareToIgnoreCase(o2.qualifiedTypeName());
		}
	};

	/**
	 * Main method for Doclet execution.
	 * <p>
	 * Called by the {@code javadoc} utility.
	 */
	public static boolean start(RootDoc root) {
		final File publishedFile = new File(Utils.getOption(CommandLineOptions.PUBLISHED_FILE, root.options()));
		final File deprecatedFile = new File(Utils.getOption(CommandLineOptions.DEPRECATED_FILE, root.options()));
		final File hiddenFile = new File(Utils.getOption(CommandLineOptions.HIDDEN_FILE, root.options()));

		try {
			final PrintStream published = new PrintStream(publishedFile);
			final PrintStream deprecated = new PrintStream(deprecatedFile);
			final PrintStream hidden = new PrintStream(hiddenFile);
			final ClassDoc[] sortedClasses = root.classes();
			Arrays.sort(sortedClasses, classComparator);

			for (ClassDoc c : sortedClasses) {
				switch (Utils.getVisibility(c)) {
					case PUBLISHED:
						showClass(c, published, deprecated, hidden);
						break;
					case DEPRECATED:
						deprecated.println(c.qualifiedTypeName() + ",class");
						break;
					case HIDDEN:
						hidden.println(c.qualifiedTypeName() + ",class");
						break;
					case INTERNAL:
						// ignore
						break;
					default:
						throw new AssertionError("Unknown visibility: " + Utils.getVisibility(c));
				}
			}

			published.close();
			hidden.close();

			return true;
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Called by the {@code javadoc} utility.
	 */
	public static int optionLength(String option) {
		for (CommandLineOptions validOption : CommandLineOptions.values()) {
			if (option.equals(validOption.m_optionName))
				return 2;
		}

		return 0;
	}

	public static void showClass(ClassDoc c, PrintStream published, PrintStream deprecated, PrintStream hidden) {
		final ClassMembers members = new ClassMembers();

		// show visible fields
		for (FieldDoc field : c.fields())
			members.addMember(field);

		// show visible constructors
		for (ConstructorDoc constructor : c.constructors())
			members.addMember(constructor);

		// show visible methods
		for (MethodDoc method : c.methods())
			members.addMember(method);

		// add member visibility to the reports
		for (Map.Entry<String, String> member : members.getPublished().entrySet())
			published.println(c.qualifiedTypeName() + "." + member.getKey() + "," + member.getValue());
		for (Map.Entry<String, String> member : members.getDeprecated().entrySet())
			deprecated.println(c.qualifiedTypeName() + "." + member.getKey() + "," + member.getValue());
		for (Map.Entry<String, String> member : members.getHidden().entrySet())
			hidden.println(c.qualifiedTypeName() + "." + member.getKey() + "," + member.getValue());
	}
}
