package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.List;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Reductions;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

public class ExampleMP extends Kernel {
	private static final DFEVectorType<DFEVar> mp_type =
		new DFEVectorType<DFEVar>(dfeFix(16, 16, SignMode.TWOSCOMPLEMENT), 2);

	public ExampleMP(KernelParameters manager) {
		super(manager);

		flush.whenInputFinished("mp_in1");

		DFEVector<DFEVar> mp_in1 = io.input("mp_in1", mp_type);
		DFEVector<DFEVar> mp_in2 = io.input("mp_in2", mp_type);
		DFEVector<DFEVar> mp_out = io.output("mp_out", mp_type);

		DFEVector<DFEVar> v = mp_in1 + mp_in2;
		mp_out.connect(v);

		DFEVar max_out = io.scalarOutput("max_out", mp_type.getContainedType());

		max_out.connect( Reductions.streamMax(v, constant.var(true)) );
	}

	public static void main(String[] args) {
		SimulationManager manager =
			new SimulationManager("ExampleMP");

		KernelParameters parameters =
			manager.makeKernelParameters();
		manager.setKernel( new ExampleMP(parameters) );

		// Input two values each of two pipes: (1,2), (3, 4)
		manager.setInputDataRaw(
			"mp_in1",
			mp_type.encodeConstant(new Double[] {1.0, 2.0}),
			mp_type.encodeConstant(new Double[] {3.0, 4.0}));

		// Input two values each of two pipes: (5, 6), (7, 1)
		manager.setInputDataRaw(
			"mp_in2",
			mp_type.encodeConstant(new Double[] {5.0, 6.0}),
			mp_type.encodeConstant(new Double[] {7.0, 1.0}));

		manager.runTest();

		// Output to stdout:
		// [6.0, 8.0]
		// [10.0, 5.0]
		List<Bits> output = manager.getOutputDataRaw("mp_out");
		for(Bits out_bits : output)
			System.out.println(mp_type.decodeConstant(out_bits));

		// Output to stdout:
		// 10.0
		System.out.println( manager.getScalarOutput("max_out") );
	}
}
