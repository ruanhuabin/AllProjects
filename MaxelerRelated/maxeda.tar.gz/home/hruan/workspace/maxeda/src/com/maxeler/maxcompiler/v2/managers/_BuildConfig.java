package com.maxeler.maxcompiler.v2.managers;

import com.maxeler.maxdc.xilinx.BuildFileUCF;


public class _BuildConfig extends BuildConfig {
	public _BuildConfig(Level level) {
		super(level);
	}

	public void setEnableChipscopeInserter(boolean v) {
		m_enable_chipscope_inserter = v;
	}

	public static void setEnableGenMaxFile(BuildConfig b, boolean v) {
		b.setEnableGenMaxFile(v);
	}

	public void setEnablePhysicalSynthesis(boolean enable) {
		m_physical_synthesis = enable;
	}

	public void addExternalUCFFile(BuildFileUCF ucf_file) {
		m_external_ucf_files.add(ucf_file);
	}
}
