package com.maxeler.maxcompiler.v2.kernelcompiler;

import static com.maxeler.utils.EnumTranslator.convert;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.photon.configuration.PhotonKernelConfiguration;
import com.maxeler.utils.MaxCompilerHide;

public class KernelConfiguration {
	/**
	 * {@link Kernel} options related to optimization.
	 */
	public static class OptimizationOptions {
		/**
		 * Behaviour for optimization of DSP multiply-addition chains.
		 */
		public enum DSPMulAddChainBehaviour {
			/** Do not optimize multiply-addition chains. */
			IGNORE,
			/**
			 * Optimise multiply-addition chains but do not use the pre-adder
			 * functionality of the DSP, if available.
			 */
			OPTIMISE_IGNORE_PREADDER,
			/**
			 * Optimise multiply-addition chains (including pre-adder
			 * functionality of the DSP, if available).
			 */
			OPTIMISE
		}

		private final PhotonKernelConfiguration m_configuration;
		private final PhotonKernelConfiguration.KernelOptimizations m_optimizations;

		private OptimizationOptions(PhotonKernelConfiguration config) {
			m_configuration = config;
			m_optimizations = config.optimizations();
		}

		/**
		 * Enable or disable optimization of 2 addition operations into a single
		 * (3 input) addition.
		 * @param enabled If {@code true} then this optimization is enabled,
		 * otherwise it is disabled.
		 * @see #getTriAddsEnabled()
		 */
		public void setTriAddsEnabled(boolean enabled) {
			m_optimizations.setTriAddsEnabled(enabled);
		}

		/**
		 * Determine if tri-add optimizations have been enabled.
		 * @return {@code true} if tri-add optimizations have been enabled,
		 * otherwise {@code false}.
		 * @see #setTriAddsEnabled(boolean)
		 */
		public boolean getTriAddsEnabled() { return m_optimizations.getTriAddsEnabled(); }

		/**
		 * @deprecated Replaced by {@link #getTriAddsEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean areTriAddsEnabled() {
			return getTriAddsEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #setConditionalArithmeticEnabled(boolean)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setCondAddsEnabled(boolean enabled) {
			setConditionalArithmeticEnabled(enabled);
		}

		/**
		 * @deprecated Replaced by {@link #getConditionalArithmeticEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean areCondAddsEnabled() {
			return getConditionalArithmeticEnabled();
		}

		/**
		 * Enable or disable optimization of conditional arithmetic.
		 * <p>
		 * Conditional arithmetic can optimize statements such as:
		 * <pre>{@code (cond ? a : 0) + b}</pre>
		 * @param enabled If {@code true} then this optimization is enabled,
		 * otherwise it is disabled.
		 * @see #getConditionalArithmeticEnabled()
		 */
		public void setConditionalArithmeticEnabled(boolean enabled) {
			m_optimizations.setConditionalArithmeticEnabled(enabled);
		}

		/**
		 * Determine if optimization of conditional arithmetic has been enabled.
		 * @return {@code true} if optimization of conditional arithmetic has been enabled,
		 * otherwise {@code false}.
		 * @see #setConditionalArithmeticEnabled(boolean)
		 */
		public boolean getConditionalArithmeticEnabled() {
			return m_optimizations.getConditionalArithmeticEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #setConditionalArithmeticEnabled(boolean)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setCondAddSubsEnabled(boolean enabled) {
			setConditionalArithmeticEnabled(enabled);
		}

		/**
		 * @deprecated Replaced by {@link #getConditionalArithmeticEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean getCondAddSubsEnabled() { return getConditionalArithmeticEnabled(); }

		/**
		 * @deprecated Replaced by {@link #getConditionalArithmeticEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean areCondAddSubsEnabled() {
			return getConditionalArithmeticEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #setConditionalArithmeticEnabled(boolean)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setCondSubsEnabled(boolean enabled) {
			setConditionalArithmeticEnabled(enabled);
		}

		/**
		 * @deprecated Replaced by {@link #getConditionalArithmeticEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean getCondSubsEnabled() { return getConditionalArithmeticEnabled(); }

		/**
		 * @deprecated Replaced by {@link #getConditionalArithmeticEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean areCondSubsEnabled() {
			return getConditionalArithmeticEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #setTriAddsEnabled(boolean)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setCondTriAddsEnabled(boolean enabled) {
			setTriAddsEnabled(enabled);
		}

		/**
		 * @deprecated Replaced by {@link #getTriAddsEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean getCondTriAddsEnabled() {
			return getTriAddsEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #getTriAddsEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean areCondTriAddsEnabled() {
			return getTriAddsEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #setDSPMulAddChainBehavior}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setDspMulAddChainBehavior(DSPMulAddChainBehaviour newValue) {
			m_optimizations.setDspMulAddChainBehavior(
				convert(
					newValue,
					com.maxeler.photon.configuration.PhotonKernelConfiguration.KernelOptimizations.DSPMulAddChainBehaviour.class
				)
			);
		}

		/**
		 * Set the behaviour of the DSP multiply-addition chain optimization.
		 * <p>
		 * This option can optimize chains of arithmetic expressions such as
		 * <code>a &times; b &plusmn; c</code>.
		 * <p>
		 * The default behaviour is {@link DSPMulAddChainBehaviour#OPTIMISE_IGNORE_PREADDER}.
		 * @param behaviour The new optimization behaviour.
		 * @see DSPMulAddChainBehaviour
		 * @see #getDSPMulAddChainBehavior()
		 */
		public void setDSPMulAddChainBehavior(DSPMulAddChainBehaviour behaviour) {
			if (behaviour == null)
				throw MaxCompilerAPIError.nullParam("behaviour");

			m_optimizations.setDspMulAddChainBehavior(
				convert(
					behaviour,
					com.maxeler.photon.configuration.PhotonKernelConfiguration.KernelOptimizations.DSPMulAddChainBehaviour.class
				)
			);
		}

		/**
		 * Get the current behaviour of the DSP multiply-addition chain optimization.
		 * @see #setDSPMulAddChainBehavior(DSPMulAddChainBehaviour)
		 */
		public DSPMulAddChainBehaviour getDSPMulAddChainBehavior() {
			return convert(
				m_optimizations.getDspMulAddChainBehavior(),
				DSPMulAddChainBehaviour.class
			);
		}

		/**
		 * @deprecated Replaced by {@link #setFIFOCoalescingEnabled(boolean)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setFifoCoalescingEnabled(boolean enabled) {
			setFIFOCoalescingEnabled(enabled);
		}

		/**
		 * Enable or disable FIFO coalescing.
		 * <p>
		 * By default this option is <em>enabled</em>.
		 * @param enabled If {@code true} then this optimization is enabled,
		 * otherwise it is disabled.
		 * @see #getFIFOCoalescingEnabled()
		 */
		public void setFIFOCoalescingEnabled(boolean enabled) {
			m_optimizations.setFIFOCoalescingEnabled(enabled);
		}

		/**
		 * Determine whether the FIFO coalescing optimization is enabled or
		 * disabled.
		 * @return {@code true} if this optimization is enabled, otherwise
		 * {@code false}.
		 * @see #setFIFOCoalescingEnabled(boolean)
		 */
		public boolean getFIFOCoalescingEnabled() {
			return m_optimizations.isFIFOCoalescingEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #getFIFOCoalescingEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean isFifoCoalescingEnabled() {
			return getFIFOCoalescingEnabled();
		}

		/**
		 * Enable or disable optimization of floating-point multiplication by
		 * constants which are a power of 2.
		 * <p>
		 * This optimizations is <em>enabled</em> by default.
		 * @param enabled If {@code true} then this optimization is enabled,
		 * otherwise it is disabled.
		 * @see #getOptimizePowerTwoFloatMultEnabled()
		 */
		public void setOptimizePowerTwoFloatMultEnabled(boolean enabled) {
			m_optimizations.setOptimizePowerTwoFloatMultEnabled(enabled);
		}

		/**
		 * Determine if the optimization of floating-point multiplication by
		 * constants which are a power of 2 is enabled or disabled.
		 * @return {@code true} if this optimization is enabled, otherwise
		 * {@code false}.
		 * @see #setOptimizePowerTwoFloatMultEnabled(boolean)
		 */
		public boolean getOptimizePowerTwoFloatMultEnabled() {
			return m_optimizations.isOptimizePowerTwoFloatMultEnabled();
		}

		/**
		 * @deprecated Replaced by {@link #getOptimizePowerTwoFloatMultEnabled()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public boolean isOptimizePowerTwoFloatMultEnabled() {
			return getOptimizePowerTwoFloatMultEnabled();
		}

		/**
		 * Set the threshold at which a FIFO in the {@link Kernel} will be
		 * implemented as a block RAM instead of an SRL.
		 * <p>
		 * FIFOs which have a width &times; depth less than the threshold will
		 * be implemented using SRLs.
		 * <p>
		 * The default threshold is 2080.
		 * @param threshold The total number of bits (i.e. width &times; depth)
		 * at which a FIFO will be implemented as a block RAM instead of an
		 * SRL. This value must not be negative.
		 * @see #getFIFOImplementationBRAMThreshold()
		 */
		public void setFIFOImplementationBRAMThreshold(int threshold) {
			if (threshold < 0)
				throw new MaxCompilerAPIError("BRAM threshold must be 0 or greater, not %d.", threshold);

			m_configuration.setBRAMBitsThreshold(threshold);
		}

		/**
		 * Get the threshold at which a FIFO in the {@link Kernel} will be
		 * implemented as a block RAM instead of an SRL.
		 * @return The total number of bits (i.e. width &times; depth) at which
		 * a FIFO will be implemented as a block RAM instead of an SRL.
		 * @see #setFIFOImplementationBRAMThreshold(int)
		 */
		public int getFIFOImplementationBRAMThreshold() {
			return m_configuration.getBRAMBitsThreshold();
		}

		/**
		 * Set the threshold for when to ROMs will be implemented using block
		 * RAM hardware.
		 * <p>
		 * If the width &times; depth of a ROM (e.g. as created via {@link com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem#rom})
		 * is greater than the specified threshold then it is created using
		 * block RAMs, otherwise it is created using LUTs.
		 * <p>
		 * Note that this does not apply to mapped ROMs (e.g. as created via
		 * {@link com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem#romMapped}).
		 * <p>
		 * The default threshold is 2080.
		 * @param threshold The total number of bits (i.e. width &times; depth)
		 * at which a ROM will be implemented using block RAMs instead of LUTs.
		 * @see #getROMImplementationBRAMThreshold()
		 */
		public void setROMImplementationBRAMThreshold(int threshold) {
			m_configuration.setROMImplementationBRAMBitsThreshold(threshold);
		}

		/**
		 * Get the threshold at which a ROM in the {@link Kernel} will be
		 * implemented as a block RAM instead LUTs.
		 * <p>
		 * Note that the this does not apply to mapped ROMs.
		 * @return The total number of bits (i.e. width &times; depth) at which
		 * a FIFO will be implemented using block RAMs instead of LUTs.
		 * @see #setROMImplementationBRAMThreshold(int)
		 */
		public int getROMImplementationBRAMThreshold() { return m_configuration.getROMImplementationBRAMBitsThreshold(); }

		/**
		 * Set the number of pipelining stages to use for the clock enable signal.
		 * <p>
		 * The default number of pipelining stages is 2.
		 * @param pipelining The number of pipelining stages to use. This must
		 * be greater than or equal to 2.
		 * @see #getCEPipelining()
		 */
		public void setCEPipelining(int pipelining) {
			if (pipelining < 0)
				throw new MaxCompilerAPIError("Number of CE pipelining stages must be >= 0, not %d.", pipelining);

			m_configuration.setCEPipelining(pipelining);
		}

		/**
		 * Get the number of pipelining stages to use for the clock enable signal.
		 * @see #setCEPipelining(int)
		 */
		public int getCEPipelining() {
			return m_configuration.getCEPipelining();
		}

		/**
		 * Enable or disable clock phase partitioning.
		 * <p>
		 * By default, this optimization is <em>disabled</em>.
		 * @param enabled If {@code true} then this optimization is enabled,
		 * otherwise it is disabled.
		 * @see #getClockPhasePartitioningEnabled()
		 */
		public void setClockPhasePartitioningEnabled(boolean enabled) {
			m_configuration.setClockPhasePartitioningEnabled(enabled);
		}

		/**
		 * Determine if clock phase partitioning is enabled or disabled.
		 * @return {@code true} if clock phase partitioning is enabled, otherwise
		 * {@code false}.
		 * @see #setClockPhasePartitioningEnabled(boolean)
		 */
		public boolean getClockPhasePartitioningEnabled() {
			return m_configuration.isClockPhasePartitioningEnabled();
		}

		/**
		 * Set the maximum amount of imbalance tolerated between the 2 clock phases when kernels are partitioned.
		 * 0.0 means require an exact 50/50 partitioning between phases and 1.0 means no balance required.
		 * @see #getClockPhaseBalanceThreshold()
		 */
		public void setClockPhaseBalanceThreshold(double threshold) {
			m_configuration.setClockPhaseBalanceThreshold(threshold);
		}

		/**
		 * @see #setClockPhaseBalanceThreshold(double)
		 */
		public double getClockPhaseBalanceThreshold() {
			return m_configuration.getClockPhaseBalanceThreshold();
		}

		/**
		 * @deprecated Replaced by {@link #setFIFOImplementationBRAMThreshold(int)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setBRAMBitsThreshold(int value) {
			m_configuration.setBRAMBitsThreshold(value);
		}

		/**
		 * @deprecated Replaced by {@link #getFIFOImplementationBRAMThreshold()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public int getBRAMBitsThreshold() { return m_configuration.getBRAMBitsThreshold(); }

		/**
		 * Specify the number of partitions for the clock enable signal.
		 * <p>
		 * Note that the value that is specify is actually the base 2 logarithm of
		 * the number of partitions, i.e. specifying a value of 3 will result
		 * in 2<sup>3</sup> = 8 partitions.
		 * @param num_partitions_log2 The number of partitions to use for the
		 * clock enable signal.
		 * @see #getCEReplicationNumPartitions()
		 */
		public void setCEReplicationNumPartitions(int num_partitions_log2) {
			m_configuration.setCEReplicationEnabled(num_partitions_log2);
		}

		/**
		 * Get the number of partitions for the clock enable signal.
		 * @return The base 2 logarithm of the number of partitions, i.e. a
		 * value of 3 indicates that 2<sup>3</sup> = 8 partitions are being
		 * used.
		 * @see #setCEReplicationNumPartitions(int)
		 */
		public int getCEReplicationNumPartitions() {
			return m_configuration.getCEReplicationLog2NumPartitions();
		}

		/**
		 * Set the number of attempts with different random seeds that will be
		 * used to partition the kernel into 2 clock phases.
		 * <p>
		 * Increasing this number will increase compilation time.
		 * @param retries The number of retry attempts.
		 * @see #getClockPhaseRetries()
		 */
		public void setClockPhaseRetries(int retries) {
			if (retries < 1)
				throw new MaxCompilerAPIError("Number of retries must be > 0, not %d.", retries);

			m_configuration.setClockPhasingRetries(retries);
		}

		/**
		 * Get the number of attempts that will be used to partition the kernel
		 * into 2 clock phases.
		 * @see #setClockPhaseRetries(int)
		 */
		public int getClockPhaseRetries() { return m_configuration.getClockPhasingRetries(); }

		/**
		 * Enable or disable the use of a global clock buffer to distribute the control enable (CE) signal.
		 * Enabling this may improve the clock frequency achievable by large kernels.
		 * <p>Default: false</p>
		 * @param enabled If {@code true} then the global clock buffer is enabled,
		 * otherwise it is disabled.
		 * @see #getUseGlobalClockBuffer()
		 */
		public void setUseGlobalClockBuffer(boolean enabled) {
			m_optimizations.setBUFGCEEnabled(enabled);
		}

		/**
		 * Determine if the global clock buffer is being used to distribute the control enable (CE) signal.
		 * @return {@code true} if the global clock buffer is being used,
		 * otherwise {@code false}.
		 * @see #setUseGlobalClockBuffer(boolean)
		 */
		public boolean getUseGlobalClockBuffer() { return m_optimizations.isBUFGCEEnabled(); }

		// FIXME: temporary, will be renamed with overhaul of packet processing infrastructure
		@MaxCompilerHide
		public void setNumberOfPacketsInFlight(int numPackets) {
			m_configuration.setNumberOfPhotonStateMachines(numPackets);
		}

		// FIXME: temporary, will be renamed with overhaul of packet processing infrastructure
		@MaxCompilerHide
		public int getNumberOfPacketsInFlight() { return m_configuration.getNumberOfPhotonStateMachines(); }
	}

	/**
	 * {@link Kernel} options related to simulation.
	 */
	public static class SimulationOptions {
		@Deprecated
		@MaxCompilerHide
		public enum SimRAMAddressCollisionBehaviour {
			EXCEPTION,
			WARNING,
			IGNORE
		};

		@Deprecated
		@MaxCompilerHide
		public enum SimRAMOutOfBoundsAccessBehaviour {
			EXCEPTION,
			WARNING,
			IGNORE
		};

		/**
		 * Specifies the behaviour of MaxCompiler simulation when a problem is
		 * encountered.
		 */
		public enum SimulationBehaviour {
			/** The problem is silently ignored. */
			IGNORE,
			/** The problem generates a warning. */
			WARNING,
			/** The problem generates an exception and terminates the simulation. */
			EXCEPTION;
		}

		private final PhotonKernelConfiguration.SimulationCodegen m_options;

		private SimulationOptions(PhotonKernelConfiguration config) {
			m_options = config.simulation();
		}

		/**
		 * @deprecated Replaced by {@link #setSimProgressMessageFrequency(int)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setProgressReportMessageFrequency(int frequency) {
			setSimProgressMessageFrequency(frequency);
		}

		/**
		 * Specify how often simulation generates a progress message.
		 * <p>
		 * Specifying a frequency of 0 disable progress reporting. The default
		 * message frequency is 0 (i.e. disabled).
		 * @param frequency How often progress should be reported, in cycles. The
		 * value 0 disables reporting. Negative values are invalid.
		 * @see #getSimProgressMessageFrequency()
		 */
		public void setSimProgressMessageFrequency(int frequency) {
			if (frequency < 0)
				throw new MaxCompilerAPIError("Report frequency must be 0 or greater, not %d.", frequency);

			m_options.setProgressReportMessageFrequency(frequency);
		}

		/**
		 * Get the frequency of progress messages for simulation.
		 * @return The current progress frequency (in cycles).
		 * @see #setSimProgressMessageFrequency(int)
		 */
		public int getSimProgressMessageFrequency() {
			return m_options.getSimProgressReportMessageFrequency();
		}

		/**
		 * @deprecated Replaced by {@link #setRAMAddressCollisionBehaviour(SimulationBehaviour)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setRamAddressCollisionBehaviour( SimRAMAddressCollisionBehaviour mode) {
			setRAMAddressCollisionBehaviour(
				convert(
					mode,
					SimulationBehaviour.class
				)
			);
		}

		/**
		 * @deprecated Replaced by {@link #getRAMAddressCollisionBehaviour()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public SimRAMAddressCollisionBehaviour getRamAddressCollisionBehaviour() {
			return convert(
				getRAMAddressCollisionBehaviour(),
				SimRAMAddressCollisionBehaviour.class
			);
		}

		/**
		 * Specify the behaviour when a RAM address collision occurs in simulation.
		 * <p>
		 * The default behaviour is {@link SimulationBehaviour#EXCEPTION}.
		 * @param behaviour The new behaviour to apply.
		 * @see #getRAMAddressCollisionBehaviour()
		 */
		public void setRAMAddressCollisionBehaviour(SimulationBehaviour behaviour) {
			if (behaviour == null)
				throw MaxCompilerAPIError.nullParam("behaviour");

			m_options.setRamAddressCollisionBehaviour(
				convert(
					behaviour,
					com.maxeler.photon.configuration.PhotonKernelConfiguration.SimulationCodegen.SimRAMAddressCollisionBehaviour.class
				)
			);
		}

		/**
		 * Get the behaviour when a RAM address collision occurs in simulation.
		 * @return The currently specified behaviour.
		 * @see #setRAMAddressCollisionBehaviour(SimulationBehaviour)
		 */
		public SimulationBehaviour getRAMAddressCollisionBehaviour() {
			return convert(
				m_options.getRamAddressCollisionBehaviour(),
				SimulationBehaviour.class
			);
		}

		/**
		 * @deprecated Replaced by {@link #setRAMOutOfBoundsBehaviour(SimulationBehaviour)}.
		 */
		@Deprecated
		@MaxCompilerHide
		public void setRamOutOfBoundsBehaviour(SimRAMOutOfBoundsAccessBehaviour mode) {
			m_options.setRamOutOfBoundsBehaviour(
				convert(
					mode,
					com.maxeler.photon.configuration.PhotonKernelConfiguration.SimulationCodegen.SimRAMOutOfBoundsAccessBehaviour.class
				)
			);
		}

		/**
		 * @deprecated Replaced by {@link #getRAMOutOfBoundsBehaviour()}.
		 */
		@Deprecated
		@MaxCompilerHide
		public SimRAMOutOfBoundsAccessBehaviour getRamOutOfBoundsBehaviour() {
			return convert(
				m_options.getRamOutOfBoundsBehaviour(),
				SimRAMOutOfBoundsAccessBehaviour.class
			);
		}

		/**
		 * Specify the behaviour when a RAM is written at an invalid address in
		 * simulation.
		 * <p>
		 * The default behaviour is {@link SimulationBehaviour#EXCEPTION}.
		 * @param behaviour The new behaviour to apply.
		 * @see #getRAMOutOfBoundsBehaviour()
		 */
		public void setRAMOutOfBoundsBehaviour(SimulationBehaviour behaviour) {
			if (behaviour == null)
				throw MaxCompilerAPIError.nullParam("behaviour");

			m_options.setRamOutOfBoundsBehaviour(
				convert(
					behaviour,
					com.maxeler.photon.configuration.PhotonKernelConfiguration.SimulationCodegen.SimRAMOutOfBoundsAccessBehaviour.class
				)
			);
		}

		/**
		 * Get the behaviour when a RAM is written with an invalid address in
		 * simulation.
		 * @return The currently specified behaviour.
		 * @see #setRAMOutOfBoundsBehaviour(SimulationBehaviour)
		 */
		public SimulationBehaviour getRAMOutOfBoundsBehaviour() {
			return convert(
				m_options.getRamOutOfBoundsBehaviour(),
				SimulationBehaviour.class
			);
		}
	}

	/**
	 * {@link Kernel} options related to compiler warnings.
	 */
	public static class WarningOptions {
		/** The behaviour to apply to a MaxCompiler warning. */
		public enum WarningBehaviour {
			/** The specified warning is ignored. */
			IGNORE,
			/**
			 * Generate a warning error message but allow compilation to
			 * continue.
			 */
			WARNING,
			/**
			 * The specified warning is treated as an error (this results in
			 * termination of the compilation process).
			 */
			ERROR
		}

		/** Warnings generated by MaxCompiler. */
		public enum Warning {
			/** Specifies all available warnings. */
			ALL,
			/**
			 * Warnings due to the encoding of numerical constants.
			 * <p>
			 * For example, this may occur when a numeric constant
			 * is encoded with a {@link KernelType} which does not have sufficient
			 * precision to preserve the value.
			 */
			CONSTANT_ENCODING,
			/**
			 * Warnings due to specifying an ambiguous write mode for a
			 * dual-port RAM.
			 */
			DUAL_PORT_RAM_WRITE_MODE,
			/**
			 * Warnings due to elements connected to a {@link Kernel} output
			 * being optimized away.
			 */
			OUTPUT_ALWAYS_ZERO,
			/** Warnings due to unnconnected elements in a {@link Kernel} design. */
			UNCONNECTED_DESIGN_ELEMENT,
			/**
			 * Warnings due to negation of an {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode#UNSIGNED} type
			 * when the result type does not support negative values.
			 */
			UNSIGNED_NEGATION_IN_NON_BITGROWTH_MODE,
			/**
			 * Warnings due to a design element that cannot be used to generate
			 * hardware.
			 */
			INVALID_DESIGN_ELEMENT
		}

		private final PhotonKernelConfiguration.Warnings m_options;

		private WarningOptions(PhotonKernelConfiguration config) {
			m_options = config.warnings();
		}

		/**
		 * Specify how a particular warning generated by MaxCompiler should be
		 * handled.
		 * <p>
		 * The behaviour of warnings in a particular region of code can also be
		 * controlled via the {@link com.maxeler.maxcompiler.v2.kernelcompiler.Debug#pushWarningBehaviour(com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning, com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.WarningBehaviour)}
		 * and {@link com.maxeler.maxcompiler.v2.kernelcompiler.Debug#popWarningBehaviour(com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning)}
		 * methods.
		 * @param warning The warning to set the behaviour of.
		 * @param behaviour The behaviour to apply to the specified warning.
		 * @see #getWarningBehaviour(Warning)
		 * @see com.maxeler.maxcompiler.v2.kernelcompiler.Debug#pushWarningBehaviour(com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning, com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.WarningBehaviour)
		 * @see com.maxeler.maxcompiler.v2.kernelcompiler.Debug#popWarningBehaviour(com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning)
		 */
		public void setWarningBehaviour(Warning warning, WarningBehaviour behaviour) {
			if (warning == null)
				throw MaxCompilerAPIError.nullParam("warning");
			if (behaviour == null)
				throw MaxCompilerAPIError.nullParam("behaviour");

			if (warning == Warning.ALL) {
				for (Warning w : Warning.values()) {
					if (w == Warning.ALL)
						continue;
					m_options.setBehaviour(
						convert(w, com.maxeler.photon.core.Warning.class),
						convert(behaviour, com.maxeler.photon.core.WarningBehaviour.class)
					);
				}
			}
			else {
				m_options.setBehaviour(
					convert(warning, com.maxeler.photon.core.Warning.class),
					convert(behaviour, com.maxeler.photon.core.WarningBehaviour.class)
				);
			}
		}

		/**
		 * Retrieve the behaviour that will be used to handle a particular
		 * warning generated by MaxCompiler.
		 * @param warning The {@link com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning} to query.
		 * @return The behaviour associated with the specified warning.
		 * @see #setWarningBehaviour(com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning,com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.WarningBehaviour)
		 * @see com.maxeler.maxcompiler.v2.kernelcompiler.Debug#pushWarningBehaviour(com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning, com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.WarningBehaviour)
		 * @see com.maxeler.maxcompiler.v2.kernelcompiler.Debug#popWarningBehaviour(com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning)
		 */
		public WarningBehaviour getWarningBehaviour(Warning warning) {
			if (warning == null)
				throw MaxCompilerAPIError.nullParam("warning");

			com.maxeler.photon.core.WarningBehaviour behaviour = m_options.getBehaviour(
				convert(
					warning,
					com.maxeler.photon.core.Warning.class
				)
			);

			return convert(behaviour, WarningBehaviour.class);
		}
	}

	/**
	 * {@link Kernel} options related to debugging.
	 */
	public static class DebugOptions {
		public enum HWHierarchyMode {
			HARD,
			SOFT,
			UNSET;
		}

		private final PhotonKernelConfiguration m_configuration;

		private DebugOptions(PhotonKernelConfiguration configuration) {
			m_configuration = configuration;
		}

		/**
		 * Enable or disable kernel profiling.
		 * <p>
		 * Kernel profiling is <em>disabled</em> by default.
		 * @param enabled If {@code true} then kernel profiling is enabled,
		 * otherwise it is disabled.
		 * @see #getKernelProfilerEnabled()
		 */
		public void setKernelProfilerEnabled(boolean enabled) {
			m_configuration.setKernelProfilerEnabled(enabled);
		}

		/**
		 * Determine if kernel profiling is enabled or disabled.
		 * @return {@code true} if kernel profiling is enabled, otherwise {@code false}.
		 * @see #setKernelProfilerEnabled(boolean)
		 */
		public boolean getKernelProfilerEnabled() {
			return m_configuration.getKernelProfilerEnabled();
		}

		/**
		 * Enable or disable the removal of data-path related nodes.
		 * <p>
		 * This option is <em>disabled</em> by default.
		 * @param enabled If {@code true} then data-path nodes are removed from
		 * the design, otherwise they remain in the design.
		 * @see #getDummyBuildEnabled()
		 */
		public void setDummyBuildEnabled(boolean enabled) {
			m_configuration.setDummyBuildEnabled(enabled);
		}

		/**
		 * Determine if data-path nodes have been removed.
		 * @return {@code true} if data-paths have been removed from the design,
		 * otherwise {@code false}.
		 * @see #setDummyBuildEnabled(boolean)
		 */
		public boolean getDummyBuildEnabled() {
			return m_configuration.isDummyBuildEnabled();
		}

		/**
		 * Generate DOT graphs containing the neighbourhood of a set of Photon nodes.
		 * <p>
		 * Value: a string containing 1 or more comma-separated node specifications.
		 * A node specification consists of either:
		 * <ul>
		 * <li>an integer, specifying the node's ID, or</li>
		 * <li>a Java class name specifying a subclass of Node. If the class
		 * is in the {@code com.maxeler.photon.nodes} namespace then you may specify
		 * just the class name (e.g. {@code NodeFIFO}), otherwise you must specify
		 * the full class name including the package (e.g.
		 * {@code com.maxeler.project.SomeNode}).</li>
		 * </ul>
		 * <p>
		 * The node specification may optionally be followed by a colon ':' and an
		 * integer representing the distance (in graph edges).
		 * @see #getDumpNeighboursString()
		 * @exclude
		 */
		@MaxCompilerHide
		public void setDumpNeighboursString(String value) {
			if (value == null)
				throw MaxCompilerAPIError.nullParam("value");

			m_configuration.setDumpNeighboursString(value);
		}

		/**
		 * @see #setDumpNeighboursString(String)
		 * @exclude
		 */
		@MaxCompilerHide
		public String getDumpNeighboursString() {
			return m_configuration.getDumpNeighboursString();
		}

		/**
		 * Set whether the hierarchy in the generated HDL for this kernel
		 * will be preserved during synthesis.
		 * <p>
		 * This option is set to {@link HWHierarchyMode#UNSET} by default.
		 * @see #getHWHierarchyMode()
		 */
		public void setHWHierarchyMode(HWHierarchyMode mode) {
			if (mode == null)
				throw MaxCompilerAPIError.nullParam("mode");

			m_configuration.setHWHierarchyMode(
				convert(mode, com.maxeler.photon.hw.HWHierarchyMode.class)
			);
		}

		/**
		 * @see #setHWHierarchyMode(HWHierarchyMode)
		 */
		public HWHierarchyMode getHWHierarchyMode() {
			return convert(
				m_configuration.getHWHierarchyMode(),
				HWHierarchyMode.class
			);
		}

		/**
		 * Specify the depth of the RAMs used to hold data for hardware watches.
		 * <p>
		 * Increasing this number will use more block RAM resources. The default
		 * depth is 512.
		 * @param depth The RAM depth to use for hardware watches.
		 * @see #getHardwareDebugDepth()
		 */
		public void setHardwareDebugDepth(int depth) {
			if (depth <= 0)
				throw new MaxCompilerAPIError("Depth must be greater than 0, not %d.", depth);

			m_configuration.setHardwareDebugDepth(depth);
		}

		/**
		 * Get the depth of the RAMs used to hold data for hardware watches.
		 * @see #setHardwareDebugDepth(int)
		 */
		public int getHardwareDebugDepth() {
			return m_configuration.getHardwareDebugDepth();
		}

		/**
		 * Enable annotation of source code with maximum latency path through all nodes
		 * created for each line. Resultant annotations will appear in the build
		 * director under <code>src_latency/</code>.
		 * <p>
		 * By default latency annotation is not performed.
		 * </p>
		 */
		public void setEnableLatencyAnnotation(boolean b) {
			m_configuration.setEnableLatencyAnnotation(b);
		}

		/**
		 * If used with latency annotation, lines affecting an arbitrary longest path
		 * between the named input and output pair are annotated with an '*' in source.
		 */
		public void setEnableLongestPathAnnotation(String input_name, String output_name) {
			m_configuration.setLongestPathLatencyAnnotation(input_name, output_name);
		}

		/**
		 * Returns true if latency annotation is to be performed.
		 *
		 * @see #setEnableLatencyAnnotaiton(boolean)
		 */
		public boolean getEnableLatencyAnnotation() {
			return m_configuration.getEnableLatencyAnnotation();
		}
	}

	final PhotonKernelConfiguration m_configuration;
	/**
	 * {@link Kernel} options related to optimization.
	 */
	public final OptimizationOptions optimization;

	/**
	 * {@link Kernel} options related to simulation.
	 */
	public final SimulationOptions simulation;

	/**
	 * {@link Kernel} options related to warnings generated by the compiler.
	 */
	public final WarningOptions warnings;

	/**
	 * {@link Kernel} options related to debugging.
	 */
	public final DebugOptions debug;

	KernelConfiguration(PhotonKernelConfiguration config) {
		m_configuration = config;

		optimization = new OptimizationOptions(m_configuration);
		simulation = new SimulationOptions(m_configuration);
		warnings = new WarningOptions(m_configuration);
		debug = new DebugOptions(m_configuration);
	}

	/**
	 * Create a mutable copy of a {@link KernelConfiguration} from an existing
	 * object.
	 * @param configuration The {@code KernelConfiguration} to copy.
	 */
	public KernelConfiguration(KernelConfiguration configuration) {
		this(configuration.m_configuration.getMutableCopy());
	}

	/**
	 * @deprecated Replaced By {@link DebugOptions#setKernelProfilerEnabled(boolean)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setKernelProfilerEnabled(boolean enabled) {
		debug.setKernelProfilerEnabled(enabled);
	}

	/**
	 * @deprecated Replaced by {@link DebugOptions#getKernelProfilerEnabled()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public boolean getKernelProfilerEnabled() {
		return debug.getKernelProfilerEnabled();
	}

	/**
	 * @deprecated No replacement (functionality is obsolete).
	 */
	@Deprecated
	@MaxCompilerHide
	public void setShadowMappedRegistersEnabled(boolean enabled) {
		m_configuration.setShadowMappedRegistersEnabled(enabled);
	}

	/**
	 * @deprecated No replacement (functionality is obsolete).
	 */
	@Deprecated
	@MaxCompilerHide
	public boolean areShadowMappedRegistersEnabled() {
		return m_configuration.areShadowMappedRegistersEnabled();
	}

	/**
	 * @deprecated No replacement (functionality is obsolete).
	 */
	@Deprecated
	@MaxCompilerHide
	public void setCEReplicationEnabled(boolean enabled) {
		m_configuration.setCEReplicationEnabled(enabled);
	}

	/**
	 * @deprecated No replacement (functionality is obsolete).
	 */
	@Deprecated
	@MaxCompilerHide
	public boolean isCEReplicationEnabled() {
		return m_configuration.isCEReplicationEnabled();
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setCEReplicationNumPartitions(int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setCEReplicationEnabled(int log2NumPartitions) {
		optimization.setCEReplicationNumPartitions(log2NumPartitions);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setClockPhasingRetries(int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setClockPhasingRetries(int retries) {
		optimization.setClockPhaseRetries(retries);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#getCEReplicationNumPartitions()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public int getCEReplicationLog2NumPartitions() {
		return optimization.getCEReplicationNumPartitions();
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setClockPhaseBalanceThreshold(double)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setClockPhaseBalanceThreshold(float threshold) {
		optimization.setClockPhaseBalanceThreshold(threshold);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#getClockPhaseBalanceThreshold()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public float getClockPhaseBalanceThreshold() {
		return (float) optimization.getClockPhaseBalanceThreshold();
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setClockPhasePartitioningEnabled(boolean)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setClockPhasePartitioningEnabled(boolean enabled) {
		optimization.setClockPhasePartitioningEnabled(enabled);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#getClockPhasePartitioningEnabled()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public boolean isClockPhasePartitioningEnabled() {
		return optimization.getClockPhasePartitioningEnabled();
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setCEPipelining(int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setControlPipelining(int pipelining) {
		optimization.setCEPipelining(pipelining);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#getCEPipelining()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public int getControlPipelining() {
		return optimization.getCEPipelining();
	}

	/**
	 * @deprecated Replaced by {@link DebugOptions#setDummyBuildEnabled(boolean)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setDummyBuildEnabled(boolean enabled) {
		debug.setDummyBuildEnabled(enabled);
	}

	/**
	 * @deprecated Replaced by {@link DebugOptions#getDummyBuildEnabled()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public boolean isDummyBuildEnabled() {
		return debug.getDummyBuildEnabled();
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setFIFOSRLDepthThreshold(int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setFIFOSRLDepthThreshold(int thresholdDepth) {
		throw new MaxCompilerAPIError("FIFO SRL depth threshold functionality is no longer implemented.");
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#getFIFOSRLDepthThreshold()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public int getFIFOSRLDepthThreshold() {
		throw new MaxCompilerAPIError("FIFO SRL depth threshold functionality is no longer implemented.");
	}

	/**
	 * @deprecated No replacement (functionality is obsolete).
	 */
	@Deprecated
	@MaxCompilerHide
	public void setAddChainMaxPreadderFanout(int max) {
		throw new MaxCompilerAPIError("DSP add chain max preadder fanout functionality is no longer implemented.");
	}

	/**
	 * @deprecated No replacement (functionality is obsolete).
	 */
	@Deprecated
	@MaxCompilerHide
	public int getAddChainMaxPreadderFanout() {
		throw new MaxCompilerAPIError("DSP add chain max preadder fanout functionality is no longer implemented.");
	}

	/**
	 * @deprecated Replaced by {@link DebugOptions#setDumpNeighboursString(String)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setDumpNeighboursString(String value) {
		debug.setDumpNeighboursString(value);
	}

	/**
	 * @deprecated Replaced by {@link DebugOptions#getDumpNeighboursString()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public String getDumpNeighboursString() {
		return debug.getDumpNeighboursString();
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setBRAMBitsThreshold(int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setBRAMBitsThreshold(int value) {
		optimization.setBRAMBitsThreshold(value);
	}

	/**
	 * Load a {@link KernelConfiguration} from a file (as previously saved by
	 * {@link #saveToFile(String)}.
	 * @param fileName Name of the file to load the {@code KernelConfiguration}
	 * from.
	 * @return A {@code KernelConfiguration} corresponding to the contents of
	 * the specified file.
	 * @see #saveToFile(String)
	 */
	public static KernelConfiguration loadFromFile(String fileName) {
		return new _KernelConfiguration(
			PhotonKernelConfiguration.load(fileName, PhotonKernelConfiguration.class)
		);
	}

	/**
	 * Serialize this configuration to a file.
	 * @param fileName Name of the file to save to.
	 * @see KernelConfiguration#loadFromFile(String)
	 */
	public void saveToFile(String fileName) {
		m_configuration.saveToFile(fileName);
	}

	/**
	 * Sets the current configuration immutable.
	 * This is automatically called in makeKernelParameters.
	 */
	public void setImmutable() {
		m_configuration.setImmutable();
	}

	/**
	 * @deprecated Replaced by {@link KernelConfiguration#KernelConfiguration(KernelConfiguration)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public KernelConfiguration getMutableCopy() {
		return new KernelConfiguration(this);
	}

	public KernelConfiguration getImmutableCopy() {
		KernelConfiguration result = new KernelConfiguration(this);
		result.setImmutable();
		return result;
	}

	/**
	 * @deprecated Replaced by {@link #simulation}.
	 */
	@Deprecated
	@MaxCompilerHide
	public SimulationOptions simulation() {
		return simulation;
	}

	/**
	 * @deprecated Replaced by {@link #optimization}.
	 */
	@Deprecated
	@MaxCompilerHide
	public OptimizationOptions optimizations() {
		return optimization;
	}

	/**
	 * @deprecated Replaced by {@link #warnings}.
	 */
	@Deprecated
	@MaxCompilerHide
	public WarningOptions warnings() {
		return warnings;
	}
}
