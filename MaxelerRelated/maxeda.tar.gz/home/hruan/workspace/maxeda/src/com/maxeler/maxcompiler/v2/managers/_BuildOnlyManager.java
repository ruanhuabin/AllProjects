package com.maxeler.maxcompiler.v2.managers;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.Entity;
import com.maxeler.photon.compile_managers.HDLSimCompileManager;
import com.maxeler.photon.compile_managers.MaxDCCompileManager;
import com.maxeler.photon.core.PhotonCompileManager;

public class _BuildOnlyManager extends DFEManager {
	private Entity m_root_entity;

	public _BuildOnlyManager(
		String build_name,
		boolean is_simulation,
		PhotonCompileManager.Factory compile_manager_factory)
	{
		super(build_name, is_simulation, null);

		_Managers.setCompileManagerFactory(this, compile_manager_factory);
	}

	public _BuildOnlyManager(String build_name, boolean is_simulation) {
		this(
			build_name,
			is_simulation,
			is_simulation ?
				new HDLSimCompileManager.Factory() :
				new MaxDCCompileManager.Factory());
	}

	public _BuildOnlyManager(BuildManager build_manager) {
		super(build_manager);

		_Managers.setCompileManagerFactory(
			this,
			build_manager.isTargetSimulation() ?
				new HDLSimCompileManager.Factory() :
				new MaxDCCompileManager.Factory());
	}

	public void setRootEntity(Entity entity) {
		m_root_entity = entity;
	}

	@Override
	public BuildManager getBuildManager() {
		return super.getBuildManager();
	}

	@Override
	protected void realBuild() {
		if(m_root_entity == null)
			throw new MaxCompilerAPIError(this, "Must call setRootEntity() before calling build().");

		runBuild(m_root_entity);
	}
}
