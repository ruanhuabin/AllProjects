package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmType;
import com.maxeler.statemachine.expressions.Expression;

public abstract class DFEsmExpr {

	private final Expression m_expr;

	DFEsmExpr(Expression expr) { m_expr = expr; }

	Expression getExpression() { return m_expr; }

	/**
	 * Get the type of this expression.
	 * @return An {@link DFEsmType} representing the type of this expression.
	 */
	public DFEsmType getType() { return m_expr.getType(); /*do not call getExpression here, see DFEsmAssignableValue.getExpression*/}

	@Override
	public String toString() { return m_expr.toString(); /*do not call getExpression here, see DFEsmAssignableValue.getExpression*/}
}
