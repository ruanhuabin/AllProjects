package com.maxeler.maxcompiler.v2.statemachine.kernel;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmInput;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmOutput;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachine;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.Lib;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.maxdc.VHDLNameManager;
import com.maxeler.statemachine.expressions.ControlSignal;
import com.maxeler.statemachine.expressions.ReadableKernelControlSignal;
import com.maxeler.statemachine.expressions.Stream;

/**
 * A library for creating input and output streams to and from a
 * {@link StateMachine}.
 */
public final class KernelIO extends Lib {
	/** Default latency of outputs and scalar outputs. */
	private static final int s_defaultOutputLatency = 0;

	/** Set containing names of all inputs and outputs. */
	private final Set<String> m_names = new HashSet<String>();
	private final Map<String, DFEsmInput> m_inputs = new TreeMap<String, DFEsmInput>();
	private final Map<String, DFEsmOutput> m_outputs = new TreeMap<String, DFEsmOutput>();
	private final Map<String, DFEsmInput> m_scalarInputs = new TreeMap<String, DFEsmInput>();
	private final Map<String, DFEsmOutput> m_scalarOutputs = new TreeMap<String, DFEsmOutput>();

	KernelIO(KernelStateMachine stateMachine) { super (stateMachine); }

	private void checkName(String name) {
		if (!VHDLNameManager.isLegalVHDLName(name))
			throw new MaxCompilerAPIError("Invalid name '%s'.", name);
		if (m_names.contains(name))
			throw new MaxCompilerAPIError("Name '%s' has already been used.", name);
	}

	/**
	 * Create an input stream to the state machine.
	 * @param name The name of the input.
	 * @param type The type of data for the input.
	 * @return An input with the specified type.
	 */
	public DFEsmInput input(String name, DFEsmValueType type) {
		if (name == null)
			throw MaxCompilerAPIError.nullParam("name");
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		checkName(name);
		checkIsInConstructor();

		DFEsmInput input = _StateMachine.Create.DFEsmInput(name, type, Stream.StreamType.STREAM);

		m_inputs.put(name, input);
		m_names.add(name);
		return input;
	}

	/**
	 * Create an output from the state machine.
	 * <p>
	 * Note that this will create an output with the default latency (0 cycles).
	 * @param name The name of the input.
	 * @param type The type of data for the input.
	 * @return An output with the specified type.
	 * @see #output(String, DFEsmValueType, int)
	 */
	public DFEsmOutput output(String name, DFEsmValueType type) { return output(name, type, s_defaultOutputLatency); }

	/**
	 * Create an output from the state machine.
	 * @param name The name of the input.
	 * @param type The type of data for the input.
	 * @param latency The latency of the output (in cycles). This value must be
	 * >= 0.
	 * @return An output with the specified type and latency.
	 * @see #output(String, DFEsmValueType)
	 */
	public DFEsmOutput output(String name, DFEsmValueType type, int latency) {
		if (name == null)
			throw MaxCompilerAPIError.nullParam("name");
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		checkName(name);
		checkIsInConstructor();
		if (latency < 0)
			throw new MaxCompilerAPIError("Latency for output '%s' must be at least 0, not %d.", name, latency);

		DFEsmOutput output = _StateMachine.Create.DFEsmOutput(getStateMachine(), name, type, Stream.StreamType.STREAM, latency);

		m_outputs.put(name, output);
		m_names.add(name);
		return output;
	}

	/**
	 * Create a scalar input to the state machine.
	 * @param name The name of the scalar input.
	 * @param type The type of data for the scalar input.
	 * @return A scalar input with the specified name and type.
	 * @see #scalarOutput(String, DFEsmValueType)
	 * @see #scalarOutput(String, DFEsmValueType, int)
	 */
	public DFEsmInput scalarInput(String name, DFEsmValueType type) {
		if (name == null)
			throw MaxCompilerAPIError.nullParam("name");
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		checkName(name);
		checkIsInConstructor();

		DFEsmInput input = _StateMachine.Create.DFEsmInput(name, type, Stream.StreamType.REGISTER);

		m_scalarInputs.put(name, input);
		m_names.add(name);
		return input;
	}

	/**
	 * Create a scalar output from the state machine.
	 * <p>
	 * Note that this will create a scalar output with the default latency (0
	 * cycles).
	 * @param name The name of the scalar output.
	 * @param type The type of data for the scalar output.
	 * @return A scalar output with the specified name and type.
	 * @see #scalarOutput(String, DFEsmValueType, int)
	 * @see #scalarInput(String, DFEsmValueType)
	 */
	public DFEsmOutput scalarOutput(String name, DFEsmValueType type) { return scalarOutput(name, type, s_defaultOutputLatency); }

	/**
	 * Create a scalar output from the state machine.
	 * @param name The name of the scalar output.
	 * @param type The type of data for the scalar output.
	 * @param latency The latency of the scalar output (in cycles). This value
	 * must be >= 0.
	 * @return A scalar output with the specified name, type and latency.
	 * @see #scalarOutput(String, DFEsmValueType)
	 * @see #scalarInput(String, DFEsmValueType)
	 */
	public DFEsmOutput scalarOutput(String name, DFEsmValueType type, int latency) {
		if (name == null)
			throw MaxCompilerAPIError.nullParam("name");
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		checkName(name);
		checkIsInConstructor();
		if (latency < 0)
			throw new MaxCompilerAPIError("Latency for output '%s' must be at least 0, not %d.", name, latency);

		DFEsmOutput output = _StateMachine.Create.DFEsmOutput(getStateMachine(), name, type, Stream.StreamType.REGISTER, latency);

		m_scalarOutputs.put(name, output);
		m_names.add(name);
		return output;
	}

	/**
	 * Returns a flag that indicates whether the input of the state machine is
	 * valid. The input will become invalid once the kernel starts flushing.
	 *
	 * @return A value that indicates whether the input of the state machine is valid.
	 */
	public DFEsmValue isInputValid() {
		DFEsmValue result = _StateMachine.Create.DFEsmValue(new ReadableKernelControlSignal(getStateMachine(), ControlSignal.KERNEL_INPUT_VALID));
		return result;
	}

	public Map<String, DFEsmInput> getInputs() { return Collections.unmodifiableMap(m_inputs); }

	public Map<String, DFEsmOutput> getOutputs() { return Collections.unmodifiableMap(m_outputs); }

	public Map<String, DFEsmInput> getScalarInputs() { return Collections.unmodifiableMap(m_scalarInputs); }

	public Map<String, DFEsmOutput> getScalarOutputs() { return Collections.unmodifiableMap(m_scalarOutputs); }
}
