package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;


public abstract class DFEsmVariable {
	/**
	 * @exclude
	 * Use the ExcludeDoclet to exclude getDFEsmExpr from the Java Doc.
	 */
	protected abstract DFEsmExpr getDFEsmExpr(); // return value is an Expression wrapped in a _StateMachine._SMExpr
	                                       // This is done so that DFEsmVariable does not contain any ref. to
	                                       // internal state machine classes....

	public abstract <E extends Enum<E>> void connect(E value);
	public void connect(boolean value) { connect(value ? 1 : 0); }
	// this needs to call Utils.checkIsAllowedLiteralValue!
	public abstract void connect(long value);
	public abstract void connect(BigInteger value);
	public abstract void connect(DFEsmExpr expr);
}
