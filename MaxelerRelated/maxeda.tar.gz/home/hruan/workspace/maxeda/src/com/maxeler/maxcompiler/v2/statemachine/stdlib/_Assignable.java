package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.DFEsmAssignableEnum;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmAssignableValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;

public final class _Assignable {
	private _Assignable() {}

	public static Assignable create(StateMachineLib owner) { return new Assignable(owner); }
	public static List<DFEsmAssignableValue> getAssignableValues(Assignable s) { return s.getAssignableValues(); }
	public static List<DFEsmAssignableEnum<?>> getAssignableEnums(Assignable s) { return s.getAssignableEnums(); }
}
