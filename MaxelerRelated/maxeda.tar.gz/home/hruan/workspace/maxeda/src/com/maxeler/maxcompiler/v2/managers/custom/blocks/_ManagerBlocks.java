package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import java.util.Collection;
import java.util.Map;

import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeDemux;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeFanout;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeMux;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodePhoton;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeStateMachine;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeV0Photon;

public class _ManagerBlocks {
	public static Demux demux(WrapperNodeDemux demux) {
		return new Demux(demux);
	}

	public static void setDemuxBitwidth(Demux demux, int width) {
		demux.m_imp.setBitWidth(width);
	}

	public static Fanout fanout(WrapperNodeFanout fanout) {
		return new Fanout(fanout);
	}

	public static KernelBlock kernel(
		WrapperNodePhoton photon,
		Collection<WrapperNodeStateMachine> arbitrators,
		Map<String, WrapperNodeStateMachine> non_blockers
	) {
		return new KernelBlock(photon, arbitrators, non_blockers);
	}

	public static StateMachineBlock stateMachine(WrapperNodeStateMachine node) {
		return new StateMachineBlock(node);
	}

	public static KernelBlock kernel(WrapperNodeV0Photon photon) {
		return new _KernelBlockV0(photon);
	}

	public static Mux mux(WrapperNodeMux mux) {
		return new Mux(mux);
	}

	public static CustomHDLBlock customVHDLBlock(CustomHDLNode node) {
		return new CustomHDLBlock(node);
	}
}
