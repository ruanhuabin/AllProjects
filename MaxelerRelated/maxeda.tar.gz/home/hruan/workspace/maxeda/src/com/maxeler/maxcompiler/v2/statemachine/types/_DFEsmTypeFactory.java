package com.maxeler.maxcompiler.v2.statemachine.types;

public final class _DFEsmTypeFactory {
	private _DFEsmTypeFactory() {}

	public static <E extends Enum<?>> DFEsmEnumType dfeEnum(Class<E> enumClass) {
		return DFEsmTypeFactory.dfeEnum(enumClass);
	}

	public static DFEsmUntypedConst dfeUntypedConst() { return DFEsmTypeFactory.dfeUntypedConst(); }
}
