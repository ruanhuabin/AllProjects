package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.FullType;

public class DFEFullType extends FullType<DFEDoubtType, DFEType, DFEVar> {
	public DFEFullType(DFEDoubtType doubt_type, DFEType kernel_type) {
		super(doubt_type, kernel_type);
	}
}
