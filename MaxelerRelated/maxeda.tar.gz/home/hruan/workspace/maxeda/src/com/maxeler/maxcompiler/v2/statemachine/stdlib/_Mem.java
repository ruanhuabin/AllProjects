package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.List;
import java.util.Map;

import com.maxeler.maxcompiler.v2.statemachine.DFEsmMappedRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmMappedROM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmROM;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;

public final class _Mem {
	private _Mem(){}

	public static Mem create(StateMachineLib stateMachine) {return new Mem(stateMachine);}

	public static List<DFEsmROM> getROMs(Mem m) { return m.getROMs();}
	public static Map<String, DFEsmMappedROM> getMappedROMs(Mem m) { return m.getMappedROMs(); }
	public static Map<String, DFEsmMappedRAM> getMappedRAMs(Mem m) { return m.getMappedRAMs(); }
	public static List<DFEsmRAM> getRAMs(Mem m) { return m.getRAMs(); }
}
