package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;
import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.stdlib.Mem.DualPortRAMMode;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.StateMachineInfo;
import com.maxeler.statemachine.expressions.AssignableEnum;
import com.maxeler.statemachine.expressions.AssignableValue;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.StateEnum;
import com.maxeler.statemachine.expressions.StateInteger;
import com.maxeler.statemachine.expressions.Stream;
import com.maxeler.statemachine.expressions.StreamInput;
import com.maxeler.statemachine.expressions.StreamOutput;
import com.maxeler.statemachine.memory.MappedRAM;
import com.maxeler.statemachine.memory.MappedROM;
import com.maxeler.statemachine.memory.RAM;
import com.maxeler.statemachine.memory.ROM;
import com.maxeler.statemachine.shift.BarrelShifter;
import com.maxeler.statemachine.statements.Statement;

public final class _StateMachine {

	private static final class _DFEsmExpr extends DFEsmExpr {
		public _DFEsmExpr(Expression toWrap) {
			super(toWrap);
		}
	}

	public static final class Create {
		private Create(){}

		public static DFEsmInput DFEsmInput(String name, DFEsmValueType type, Stream.StreamType streamType) {
			return new DFEsmInput(name,type,streamType);
		}

		public static DFEsmOutput DFEsmOutput(StateMachineLib stateMachine, String name, DFEsmValueType type, Stream.StreamType streamType, int latency) {
			return new DFEsmOutput(stateMachine, name, type, streamType, latency);
		}

		public static<E extends Enum<E>> DFEsmStateEnum<E> DFEsmStateEnum(StateMachineLib stateMachine, Class<E> enumClass, String stateID, E defaultValue) {
			return new DFEsmStateEnum<E>(stateMachine,enumClass,stateID,defaultValue);
		}

		public static DFEsmStateValue DFEsmStateValue(StateMachineLib stateMachine, DFEsmValueType type, String stateID, BigInteger defaultValue) {
			return new DFEsmStateValue(stateMachine, type, stateID, defaultValue);
		}

		public static DFEsmDualPortMappedROM DFEsmDualPortMappedROM(StateMachineLib stateMachine, String name, Latency latency, DFEsmValueType type, int depth) {
			return new DFEsmDualPortMappedROM(stateMachine, name, latency, type, depth);
		}

		public static DFEsmSinglePortROM DFEsmSinglePortROM(
			StateMachineLib mStateMachine,
			Latency latency,
			DFEsmValueType type,
			int romID,
			List<BigInteger> contents)
		{
			return new DFEsmSinglePortROM(mStateMachine, latency, type, romID, contents);
		}

		public static DFEsmDualPortROM DFEsmDualPortROM(
			StateMachineLib mStateMachine,
			Latency latency,
			DFEsmValueType type,
			int romID,
			List<BigInteger> contents)
		{
			return new DFEsmDualPortROM(mStateMachine, latency, type, romID, contents);
		}

		public static DFEsmSinglePortMappedROM DFEsmSinglePortMappedROM(
			StateMachineLib mStateMachine,
			String name,
			Latency latency,
			DFEsmValueType type,
			int depth)
		{
			return new DFEsmSinglePortMappedROM(mStateMachine, name, latency, type, depth);
		}

		public static DFEsmSinglePortRAM DFEsmSinglePortRAM(
			StateMachineLib mStateMachine,
			Latency latency,
			DFEsmValueType type,
			DualPortRAMMode realPortMode,
			int ramID,
			int depth)
		{
			return new DFEsmSinglePortRAM(mStateMachine, latency, type, realPortMode, ramID, depth);
		}

		public static DFEsmDualPortRAM DFEsmDualPortRAM(
			StateMachineLib mStateMachine,
			Latency latency,
			DFEsmValueType type,
			DualPortRAMMode portMode0,
			DualPortRAMMode portMode1,
			int ramID,
			int depth)
		{
			return new DFEsmDualPortRAM(mStateMachine, latency, type, portMode0, portMode1, ramID, depth);
		}

		public static DFEsmDualPortMappedRAM DFEsmDualPortMappedRAM(
			String name,
			StateMachineLib mStateMachine,
			Latency latency,
			DFEsmValueType type,
			DualPortRAMMode portMode0,
			DualPortRAMMode portMode1,
			int ramID,
			int depth)
		{
			return new DFEsmDualPortMappedRAM(name, mStateMachine, latency, type, portMode0, portMode1, ramID, depth);
		}

		public static DFEsmSinglePortMappedRAM DFEsmSinglePortMappedRAM(
			String name,
			StateMachineLib mStateMachine,
			Latency latency,
			DFEsmValueType type,
			DualPortRAMMode portMode,
			int ramID,
			int depth)
		{
			return new DFEsmSinglePortMappedRAM(name, mStateMachine, latency, type, portMode, ramID, depth);
		}

		public static DFEsmValue DFEsmValue(Constant constant) {
			return new DFEsmValue(constant);
		}

		public static DFEsmValue DFEsmValue(Expression expr) {
			return new DFEsmValue(expr);
		}

		public static DFEsmExpr DFEsmExpr(Expression exprToWrap) {
			return new _DFEsmExpr(exprToWrap);
		}

		public static DFEsmAssignableValue DFEsmLocalValue(
			StateMachineLib stateMachine,
			DFEsmValueType type,
			String localVarID)
		{
			return new DFEsmAssignableValue(stateMachine, type, localVarID);
		}

		public static <E extends Enum<E>> DFEsmAssignableEnum<E> DFEsmAssignableEnum(
			StateMachineLib stateMachine,
			Class<E> type,
			String varId)
		{
			return new DFEsmAssignableEnum<E>(
				stateMachine, type, varId);
		}
	}

	private _StateMachine(){}

	public static void addStatement(StateMachineLib lib, Statement statement) {lib.addStatement(statement);}

	public static ContextMode getContextMode(StateMachine s) { return s.getContextMode(); }

	public static Expression getExpression(DFEsmExpr expr) {return expr.getExpression();}

	public static Expression getExpression(DFEsmVariable var) {return var.getDFEsmExpr().getExpression();}

	public static StateInteger toImp(DFEsmStateValue state) { return state.getState(); }

	public static StateEnum toImp(DFEsmStateEnum<?> state) { return state.getState(); }

	public static StreamInput toImp(DFEsmInput input) { return input.getInput(); }

	public static StreamOutput toImp(DFEsmOutput output) { return output.getOutput(); }

	public static StateMachineInfo getInfo(StateMachineLib stateMachine) { return stateMachine.getInfo(); }

	public static ROM toImp(DFEsmROM rom) { return rom.getROM(); }

	public static MappedROM toImp(DFEsmMappedROM rom) { return rom.getMappedROM(); }

	public static MappedRAM toImp(DFEsmMappedRAM ram) { return ram.getMappedRAM(); }

	public static RAM toImp(DFEsmRAM ram) { return ram.getRAM(); }

	public static BarrelShifter toImp(_DFEsmShifter shifter) { return shifter.getShifter(); }

	public static BuildManager getBuildManager(StateMachineLib stateMachine) {return stateMachine.m_build_manager;}

	public static void nextState(StateMachine sm) {sm.nextState();}

	public static void outputFunction(StateMachine sm) {sm.outputFunction();}

	public static AssignableValue toImp(DFEsmAssignableValue v) {
		return (AssignableValue) v.getExpression();
	}
	public static AssignableEnum<?> toImp(DFEsmAssignableEnum<?> v) {
		return (AssignableEnum<?>) v.getExpression();
	}
}
