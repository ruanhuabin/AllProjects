package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;

public class _KernelBaseTypes {
	public static DFEType fromImp(com.maxeler.photon.types.HWType imp) {
		if(imp instanceof com.maxeler.photon.types.HWFloat)
			return new DFEFloat(imp);

		if(imp instanceof com.maxeler.photon.types.HWOffsetFix)
			return new DFEFix(imp);

		if(imp instanceof com.maxeler.photon.types.HWRawBits)
			return new DFERawBits(imp);

		if(imp instanceof com.maxeler.photon.types.HWUntypedConst)
			return new DFEUntypedConst(imp);

		throw new MaxCompilerInternalError("Unknown internal DFEType instance (" + imp.getClass() + ")");
	}

	public static com.maxeler.photon.types.HWType toImp(DFEType t) {
		return t.m_imp;
	}

	public static DFEVar fromImp(KernelLib data, com.maxeler.photon.core.Var imp) {
		return new DFEVar(data.getKernel(), imp);
	}

	public static com.maxeler.photon.core.Var toImp(DFEVar v) {
		if(v == null)
			return null;
		else
			return v.m_imp;
	}
}
