package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._AlreadyConnectedException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Constant;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStructType;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * Test class to exercise as much as possible of the DFEStruct class; refer to nightly tests' EMMA output for coverage statistics.
 *
 * @author kate
 */
public class DFEStructTest extends Kernel {

	private static Random m_random = null;
	private static long   m_seed;

	private static final DFEFloat     floatType   = dfeFloat( 11, 53 );
	private static final DFEStructType complexType = new DFEStructType( DFEStructType.sft("real", floatType), DFEStructType.sft("imag", floatType) );
	private static final DFEStructType revCplxType = new DFEStructType( DFEStructType.sft("imag", floatType), DFEStructType.sft("real", floatType) );
	private static final DFEStructType simpleType  = new DFEStructType( DFEStructType.sft("simple", floatType) );


	public DFEStructTest( KernelParameters parameters ) {
		super( parameters );

		//----- DFEStruct-related methods in Constant (use watches to suppress whingeing about unread variables)
		DFEStructType constType = new DFEStructType( DFEStructType.sft("dble", floatType), DFEStructType.sft("bool", dfeBool() ) );
		DFEStruct cnst = constant.struct( constType, Constant.sfv("dble",123.456), Constant.sfv("bool", false) );
		cnst.watch( "cnst" );

		try {
			DFEStruct cnst1 = constant.struct( constType, Constant.sfv("dble",false), Constant.sfv("bool", true) );
			cnst1.watch( "cnst1" );
		} catch (MaxCompilerAPIError e) {
			getKernel().logMsg( "***** Successfully caught error: \n" + e + "\n*****");
		}

		try {
			DFEStruct cnst2 = constant.struct( constType, Constant.sfv("dble",123.456) );
			cnst2.watch( "cnst2" );
		} catch (MaxCompilerAPIError e) {
			getKernel().logMsg( "***** Successfully caught error: \n" + e + "\n*****");
		}

		try {
			DFEStruct cnst3 = constant.struct( constType, Constant.sfv("dble",1.2), Constant.sfv("bool",3.4) );
			cnst3.watch( "cnst3" );
			getKernel().logMsg( "***** allowed 'bool' field to take a double value... ");
		} catch (MaxCompilerAPIError e) {
			getKernel().logMsg( "***** Successfully caught error: \n" + e + "\n*****");
		}


		//----- exercise various DFEStructType members...
		logMsg( "complexType has " + complexType.getNumberOfFields() + " fields: " + complexType );
		for ( String str : complexType.getFieldNames() ) {
			logMsg( "    complexType field = '" + str + "'" );
		}

		//----- create a struct with no fields
		try {
			DFEStructType emptyType = new DFEStructType();
			getKernel().logMsg( "***** Failed to catch error from emptyType" + emptyType.toString() );
		} catch (MaxCompilerAPIError e) {
			getKernel().logMsg( "***** Successfully caught error: \n" + e + "\n*****");
		}

		//----- create a struct with a non-concrete component
		DFEStructType nonConcreteType   = new DFEStructType( DFEStructType.sft("one", floatType), DFEStructType.sft("two", DFETypeFactory.dfeUntypedConst() ) );
		DFEStruct     nonConcreteStruct = nonConcreteType.newInstance(this);
		logMsg( "created nonConcrete instance " + nonConcreteStruct );

		//----- read input from driver
		DFEStruct a   = io.input( "a", complexType );
		DFEVar   aRe = a.get( "real" );
		DFEVar   aIm = a.get( "imag" );
		flush.whenInputFinished( "a" );
		a.watch( "a" );
		DFEVar   var = constant.var( floatType, 3.0 );
		DFEStruct b   = complexType.newInstance(this);

		//----- try assigning a complex struct to a float field
		try {
			b.set( "real", a );
			b.getKernel().logMsg( "***** Failed to catch error from: b.set( \"real\", a )" );
		} catch (MaxCompilerAPIError e) {
			b.getKernel().logMsg( "***** Successfully caught error: b.set( \"real\", a )\n" + e + "\n*****");
		}
		b.set( "real", aIm + var );
		b.set( "imag", aRe + var );
		io.output( "t1", complexType ).connect( b );
		b = a.cast( complexType );

		//----- try assigning to an already connected field
		try {
			b.set( "real", aIm );
			b.getKernel().logMsg( "***** Failed to catch error from: b.set( \"real\", aIm + var )" );
		} catch (_AlreadyConnectedException e) {
			b.getKernel().logMsg( "***** Successfully caught error: b.set( \"real\", aIm + var )\n" + e + "\n*****");
		}
		io.output( "t2", complexType ).connect( b );


		DFEStruct c   = simpleType.newInstance(this);
		c.set( "simple", var );
		c.setReportOnUnused( false );

		//----- try assigning to a non-existent field
		try {
			c.set( "real", var );
			c.getKernel().logMsg( "***** Failed to catch error from: c.set(\"real\",var)" );
		} catch (MaxCompilerAPIError e) {
			c.getKernel().logMsg( "***** Successfully caught error: c.set(\"real\",var)\n" + e + "\n*****");
		}

		//----- try an impossible cast
		try {
			c = b.cast( simpleType );
			c.getKernel().logMsg( "***** Failed to catch error from: c = b.cast(simpleType)" );
		} catch (MaxCompilerAPIError e) {
			c.getKernel().logMsg( "***** Successfully caught error: c = b.cast(simpleType)\n" + e + "\n*****");
		}

		try {
			DFEVar e = (DFEVar) b.cast( floatType );
			getKernel().logMsg( "***** Failed to catch error from: DFEVar e = (DFEVar)b.cast(floatType)" );
			e.watch( "e" );
		} catch (MaxCompilerAPIError e) {
			getKernel().logMsg( "***** Successfully caught error: DFEVar e = (DFEVar)b.cast(floatType)\n" + e + "\n*****");
		}

		//----- exercise code that checks for two identical fields in reverse order
		DFEStruct f = revCplxType.newInstance(this);
		try {
			f = revCplxType.equals(complexType) ? a : a.cast(revCplxType);
			getKernel().logMsg( "***** Failed to catch error: f = extraType.equals(complexType)");
		} catch (MaxCompilerAPIError e ) {
			getKernel().logMsg( "***** Successfully caught error: f = extraType.equals(complexType)\n" + e + "\n*****");
		}
		f = a.cast(revCplxType);
		f.getKernel().logMsg( "extraType.hashCode  =  " + revCplxType.hashCode() );
		io.output("f", revCplxType ).connect(f);

		if ( ! complexType.equals(simpleType) ) {
			logMsg( "DFEStructType<<<<<" + complexType + ">>>>>   !=   DFEStructType<<<<<" + simpleType + ">>>>>" );
		}

	}

	private static int runTest1( String main_name ) {
		String                 name        = main_name + "_1";
		_DualSimulationManager manager     = new _DualSimulationManager(name);
		KernelParameters       parametersA = manager.makeKernelParameters_A();
		KernelParameters       parametersB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEStructTest(parametersA), new DFEStructTest(parametersB) );
		checkRandomSet();
		manager.logMsg( "=====  Using Random seed = " + m_seed  + "  =====" );

		int len = 3;
		double[] inA_re = initToRandom( len );
		double[] inA_im = initToRandom( len );
		for ( int i = 0 ; i < len ; i++ )
			System.out.println( "Test1: input data    inA[" + i + "]  =  { " + inA_re[i] + ", " + inA_im[i] + " }" );

		manager.setInputDataRaw( "a", encodeValues(inA_re, inA_im) );
		manager.runTest();

		double[] re = new double[len];
		double[] im = new double[len];
		for ( int i = 0 ; i < len ; i++ ) {
			re[i] = inA_im[i] + 3;
			im[i] = inA_re[i] + 3;
		}
		checkResult( manager.getOutputDataRaw("t1"), re, im, "Test1: swap re,im values" );

		//----- exercise DFEStructType encode/decode methods...
		HashMap<String,Double> hm = new HashMap<String, Double>();
		hm.put( "real", 1.0 );
		hm.put( "imag", 1.0 );
		Bits b1 = complexType.encodeConstant( hm );
		manager.logMsg( "Test1: value (1,1) encodes to " + b1.toString() );

		try {
			Bits b2 = complexType.encodeConstant( new Double(10) );
			manager.logMsg( "failed to catch exception setting b2 = " + b2.toString() );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "Test1: successfully caught exception: " + e );
		}

		Bits[] bits = manager.getOutputDataRawArray( "t2" );
		for ( int i = 0 ; i < bits.length ; i++ ) {
			Map<String, Object> cnum =  complexType.decodeConstant( bits[i] );
			manager.logMsg( "Test1: t2 output[" + i + "] = { "	+ cnum.get("real") + ", " + cnum.get("imag") + " }" );
		}

		return 0;
	}

	/**
	 * This is run by the nightly tests.
	 * @param args - not used.
	 */
	public static void main(String[] args) {
		String name = "DFEStructTest";
		runTest1( name );
		runTest2( name );
		runTest3( name );
		System.out.println( "     ***** Reached here, so everything passed! *****" );
		System.exit(0);
	}

	//----------------------------------------------------------------------------------------------------

	private static class DFEStructTest2 extends Kernel {
		//----- test connecting up incompatible DFEStruct types
		protected DFEStructTest2( KernelParameters parameters ) {
			super( parameters );
			DFEStruct a = io.input( "a", complexType );
			io.output( "simple", simpleType ).connect( a );
		}
	}

	private static void runTest2( String main_name ) {
		String name = main_name + "_2";
		_DualSimulationManager manager     = new _DualSimulationManager(name);
		KernelParameters       parametersA = manager.makeKernelParameters_A();
		KernelParameters       parametersB = manager.makeKernelParameters_B();
		checkRandomSet();
		manager.logMsg( "=====  Using Random seed = " + m_seed  + "  =====" );
		try {
			int len = 3;
			manager.setKernels( new DFEStructTest2(parametersA), new DFEStructTest2(parametersB) );
			manager.setInputDataRaw( "a", encodeValues( initToRandom(len), initToRandom(len) ) );
			manager.runTest();
			manager.getOutputDataRaw( "simple" );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "*****  Test2: caught exception: \n" + e + getStack(e) + "*****" );
		}
	}

	//----------------------------------------------------------------------------------------------------

	private static class DFEStructTest3 extends Kernel {
		//----- test non-concrete types
		protected DFEStructTest3( KernelParameters parameters ) {
			super( parameters );
			DFEStructType nonConcreteType = new DFEStructType( DFEStructType.sft( "one", floatType),
			                                               DFEStructType.sft( "two", DFETypeFactory.dfeUntypedConst() ) );
			DFEStruct nonConcrete  = nonConcreteType.newInstance(this);
			DFEStruct complexInput = io.input( "a", complexType );
			nonConcrete.set( "one", complexInput.get("real") );
			DFEVar var = nonConcrete.pack();
			var.watch("var");
			io.output( "x", nonConcreteType ).connect( nonConcrete );
		}
	}

	private static void runTest3( String main_name ) {
		String name = main_name + "_3";
		_DualSimulationManager manager     = new _DualSimulationManager(name);
		KernelParameters       parametersA = manager.makeKernelParameters_A();
		KernelParameters       parametersB = manager.makeKernelParameters_B();
		checkRandomSet();
		manager.logMsg( "=====  Using Random seed = " + m_seed  + "  =====" );
		try {
			int len = 3;
			manager.setKernels( new DFEStructTest3(parametersA), new DFEStructTest3(parametersB) );
			manager.setInputDataRaw( "a", encodeValues( initToRandom(len), initToRandom(len) ) );
			manager.runTest();
			manager.getOutputDataRaw( "x" );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "***** Test3: caught exception: \n" + e + getStack(e) + "*****" );
		}
	}

	//----------------------------------------------------------------------------------------------------

	private static void checkRandomSet() {
		if ( m_random == null ) {
			m_seed   = System.currentTimeMillis();
			m_random = new Random( m_seed );
		}
	}

	private static String getStack( Throwable t ) {
		StringBuilder sb = new StringBuilder();
		for ( StackTraceElement ste : t.getStackTrace() )
			sb.append( "    " + ste.toString() + "\n" );
		return sb.toString();
	}

	private static final double  err_threshold = 1.e-14;
	private static final boolean full_printout = true;

	/**
	 * compares all the simulation results against required values, and throws an exception if they don't match.
	 * @param output is the simulation output
	 * @param re are the real components of the required values
	 * @param im are the imaginary components of the required values
	 * @param name is the name of the test
	 */
	@edu.umd.cs.findbugs.annotations.SuppressWarnings("UCF_USELESS_CONTROL_FLOW_NEXT_LINE")
	private static void checkResult( List<Bits> output, double[] re, double[] im, String name )
	{
		System.out.println( "    Test: " + name );
		double[] sim = SimulationManager.unpackFromBits( floatType, output );
		for ( int i = 0 ; i < output.size() ; i++ ) {
			boolean isOK   = isWithinThreshold( sim[2*i],re[i]) && isWithinThreshold(sim[2*i+1],im[i]);
			String  status = isOK ? "pass" : "fail";
			if ( !isOK || full_printout )
				System.out.println( i + ":  " + status + " :" +
						"   Simulation = { " + sim[2*i] + ", " + sim[2*i+1] + " }," +
						"  \t required = { " + re[i]    + ", " + im[i]      + " }" );
			if ( !isOK )
				throw new RuntimeException( "Test failed" );
		}
	}

	/**
	 * checks whether two values are within a given threshold of each other
	 * @param v1 is the first value, e.g. as returned by the simulator
	 * @param v2 is the second value, e.g. as calculated as the required value
	 * @return true = values match to within threshold; false = values differ
	 */
	private static boolean isWithinThreshold( double v1, double v2 ) {
		boolean isOK = true;
		if ( Math.abs(v1) > err_threshold )
			isOK = Math.abs((v2 - v1) / v1) < err_threshold;
		else if ( Math.abs(v2) > err_threshold )
			isOK = Math.abs((v2 - v1) / v2) < err_threshold;

		if (!isOK)
			System.out.println( "    threshold test failed comparing  " + v1 + "  vs  " + v2 );
		return isOK;
	}

	/**
	 * initialize an array with random values with the range 0 to 100.
	 * @param len is the length of the array
	 * @return the array of random values
	 */
	private static double[] initToRandom( int len ) {
		double[] arr = new double[len];
		for ( int i = 0 ; i < len ; i++ )
			arr[i] = m_random.nextDouble() * 100.0;
		return arr;
	}

	/**
	 * encodes arrays of real and imaginary values into a Bits List, ready for sending to simulator.
	 * @param re is the array of real components
	 * @param im is the array of imaginary components
	 * @return is the encoded List of values
	 */
	private static ArrayList<Bits> encodeValues( double[] re, double[] im ) {
		ArrayList<Bits> encoded = new ArrayList<Bits>();
		for ( int i = 0 ; i < re.length ; i++ ) {
			encoded.add( SimulationManager.packToBits( floatType, re[i], im[i] ) );
		}
		return encoded;
	}

}
