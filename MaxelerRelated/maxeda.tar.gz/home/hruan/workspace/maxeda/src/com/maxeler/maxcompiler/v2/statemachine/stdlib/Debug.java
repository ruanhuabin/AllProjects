package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._Error;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmExpr;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmVariable;
import com.maxeler.maxcompiler.v2.statemachine.StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmEnumType;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.MaxFileManager;
import com.maxeler.statemachine.StateMachineInternalException;
import com.maxeler.statemachine.expressions.EnumToString;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.StateMachineName;
import com.maxeler.statemachine.statements.SimPrintf;
import com.maxeler.utils.string.FormatStringParser;
import com.maxeler.utils.string.FormatStringParser.FormatCSpec;
import com.maxeler.utils.string.FormatStringParser.FormatString;
import com.maxeler.utils.string.FormatStringParser.Style;
import com.maxeler.utils.string.SafeString;

public final class Debug extends Lib {

	private final BuildManager m_manager;
	final List<DFEsmEnumType> m_enumsStringConversionNeeded;


	Debug(StateMachineLib owner) {
		super(owner);
		m_manager = _StateMachine.getBuildManager(owner);
		m_enumsStringConversionNeeded = new ArrayList<DFEsmEnumType>();
	}


	/**
	 * Prints a message to the standard debug output stream.
	 * @param message Message to print out (may include C-like format tags). Must not be null.
	 * @param args Arguments for format tags.
	 */
	public final void printf(String message, Object... args) {
		printf("", message, args);
	}

	private static enum SMCustomTags {
		StateMachine
	};
	private static class CustomTagMapEntry {
		public final String toReplace;
		public final int position;
		public String cFlag;
		public CustomTagMapEntry (String toReplace, int position) {
			this.toReplace = toReplace;
			this.position = position;
		}
	}

	/**
	 * Prints a message to a named debug output stream.
	 * @param stream_name Name of the output stream. Must not be null.
	 * @param message Message to write to the stream. Must not be null.
	 * @param args Arguments for the format tags in message.
	 */
	public final void printf(String stream_name, String message, Object... args) {
		// Check Preconditions
		if (stream_name == null || message == null)
			throw _Error.errorAPI(m_manager, "Parameters stream_name, condition, and message must not be null.");

		// grab optional arguments (we don't support float/double..)
		List<Expression> arguments = new ArrayList<Expression>();
		final FormatStringParser fmtStrParser = new FormatStringParser(message, SMCustomTags.class);
		List<CustomTagMapEntry> customTags = new ArrayList<CustomTagMapEntry>();

		for (int i = 0; i < args.length; i++) {
			if(args[i] == null)
				throw _Error.errorAPI(m_manager, "simPrintf data argument %d is null.", i);

			FormatString fmtStr;
			try {
				fmtStr = fmtStrParser.getNextFormatString();
			} catch (FormatStringParser.FormatException error) {
				throw new MaxCompilerAPIError(m_manager, error.getMessage());
			}

			while (fmtStr.isCustomStyle()) {
				SMCustomTags tag = fmtStr.getCustomTag(SMCustomTags.class);
				CustomTagMapEntry tagMapEntry = new CustomTagMapEntry(tag.name(),fmtStrParser.getCurrentFormatStringNumber());
				switch (tag) {
					case StateMachine:
						arguments.add( new StateMachineName() );
						tagMapEntry.cFlag = "%s";
						break;
					default:
						throw _Error.errorInternal(m_manager,"Unknown printf format string.");
				}
				customTags.add(tagMapEntry);
				try {
					fmtStr = fmtStrParser.getNextFormatString();
				} catch (FormatStringParser.FormatException error) {
					throw new MaxCompilerAPIError(m_manager, error.getMessage());
				}
			}

			final String errorMsg =
				"Type of argument " + (i + 1) + " ('%s') " +
				"not compatible with formatting spec ('" + fmtStr.toString() + "').";

			if(args[i] instanceof Byte) {
				if (! fmtStr.checkByte())
					throw _Error.errorAPI(m_manager, errorMsg, "byte");
				arguments.add( _StateMachine.getExpression(getStateMachine().constant.value(StateMachine.dfeInt(8), (Byte)args[i])) );
			} else if(args[i] instanceof Short) {
				if (! fmtStr.checkShort())
					throw _Error.errorAPI(m_manager, errorMsg, "short");
				arguments.add( _StateMachine.getExpression(getStateMachine().constant.value(StateMachine.dfeInt(16), (Short)args[i])) );
			} else if(args[i] instanceof Integer) {
				if (! fmtStr.checkInteger())
					throw _Error.errorAPI(m_manager, errorMsg, "integer");
				arguments.add( _StateMachine.getExpression(getStateMachine().constant.value(StateMachine.dfeInt(32), (Integer)args[i])) );
			} else if(args[i] instanceof Long) {
				if (! fmtStr.checkLong())
					throw _Error.errorAPI(m_manager, errorMsg, "long");
				arguments.add( _StateMachine.getExpression(getStateMachine().constant.value(StateMachine.dfeInt(64), (Long)args[i])) );
			} else if(args[i] instanceof DFEsmExpr) {
				final DFEsmExpr tmp = (DFEsmExpr) args[i];
				if (! fmtStr.checkSMExpr(tmp))
					throw _Error.errorAPI(m_manager, errorMsg, tmp.getType().toString());
				if (fmtStr.isCStyle() && fmtStr.getCSpec() == FormatCSpec.s) {
					if (! (tmp.getType() instanceof DFEsmEnumType))
						throw new StateMachineInternalException("Unexpected argument type: " + tmp.getType().toString());

					if (!m_enumsStringConversionNeeded.contains(tmp.getType()))
						m_enumsStringConversionNeeded.add((DFEsmEnumType)tmp.getType());
					arguments.add(new EnumToString(_StateMachine.getExpression(tmp)));
				} else {
					arguments.add( _StateMachine.getExpression(tmp) );
				}
			} else if(args[i] instanceof DFEsmVariable) {
				final Expression tmp = _StateMachine.getExpression((DFEsmVariable) args[i]);
				if (! fmtStr.checkSMVariable(tmp))
					throw _Error.errorAPI(m_manager, errorMsg, tmp.getType().toString());
				if (fmtStr.isCStyle() && fmtStr.getCSpec() == FormatCSpec.s) {
					if (! (tmp.getType() instanceof DFEsmEnumType))
						throw new StateMachineInternalException("Unexpected argument type: " + tmp.getType().toString());

					if (!m_enumsStringConversionNeeded.contains(tmp.getType()))
						m_enumsStringConversionNeeded.add((DFEsmEnumType)tmp.getType());
					arguments.add(new EnumToString(tmp));
				} else {
					arguments.add(tmp);
				}
			} else {
				throw _Error.errorAPI(m_manager,
					"simPrintf data argument %d is of an unsupported type.\n" +
					"Supported types are: byte, short, int, long, DFEsmValue/DFEsmEnum, and DFEsmVariable\n",
					i+1, args[i].getClass().getName());
			}
		}
		try {
			fmtStrParser.checkNoMoreFormatStringsLeft();
		} catch (FormatStringParser.FormatException error) {
			throw new MaxCompilerAPIError(m_manager, error.getMessage());
		}

		if (customTags.size() > 0) {
			if (fmtStrParser.getStyle() == Style.BOOST) {
				for (CustomTagMapEntry tag: customTags) {
					final String customTag = "%"+tag.toReplace+"%";
					message = message.replaceFirst(customTag, "%" + tag.position + "%");
				}
			} else {
				for (CustomTagMapEntry tag: customTags) {
					final String customTag = "%"+tag.toReplace+"%";
					message = message.replaceAll(customTag, tag.cFlag);
				}
			}
		}

		SimPrintf node =
			new SimPrintf(
				new SafeString(stream_name),
				new SafeString(message),
				arguments,
				_StateMachine.getBuildManager(getStateMachine()));
		_StateMachine.addStatement(getStateMachine(), node);

		/* set a MaxFile constant, so that SLiC can tell that this design uses debug.printf. */
		MaxFileManager mfm = MaxFileManager.getMaxFileManager(
			_StateMachine.getBuildManager(getStateMachine()) );
		if (mfm != null) {
			String name = com.maxeler.maxcompiler.v2.kernelcompiler.Debug.m_maxfileConst;
			if (!mfm.constantIsAlreadyUsed(name)) {
				mfm.addMaxFileConstant(false, name, 1);
			}
		}

	}
}
