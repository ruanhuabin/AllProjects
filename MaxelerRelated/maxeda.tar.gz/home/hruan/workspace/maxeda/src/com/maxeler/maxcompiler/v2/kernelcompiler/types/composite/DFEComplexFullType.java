package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.FullType;

public class DFEComplexFullType extends FullType<DFEComplexDoubtType, DFEComplexType, DFEComplex> {
	public DFEComplexFullType(DFEComplexDoubtType doubt_type, DFEComplexType kernel_type) {
		super(doubt_type, kernel_type);
	}
}
