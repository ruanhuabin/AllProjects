package com.maxeler.maxcompiler.v2.errors;

import java.util.Arrays;

import com.maxeler.maxdc.BuildManager;

public class _Error {
	public static MaxCompilerAPIError errorAPI(BuildManager build_manager, String format, Object...args) {
		MaxCompilerAPIError ex = new MaxCompilerAPIError(build_manager, format, args);

		return cleanStackTrace(ex);
	}

	public static MaxCompilerInternalError errorInternal(BuildManager build_manager, String format, Object...args) {
		MaxCompilerInternalError ex = new MaxCompilerInternalError(build_manager, format, args);

		return cleanStackTrace(ex);
	}

	private static <T extends Throwable> T cleanStackTrace(T ex) {
		// remove the first line of the stack trace so that the user is
		// blissfully unaware of the existence of the _Error class
		StackTraceElement[] oldStack = ex.getStackTrace();
		ex.setStackTrace(Arrays.copyOfRange(oldStack, 1, oldStack.length));

		return ex;
	}
}
