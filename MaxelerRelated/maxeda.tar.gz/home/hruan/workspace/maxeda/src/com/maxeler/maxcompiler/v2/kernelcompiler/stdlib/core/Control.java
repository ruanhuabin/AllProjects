package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.photon.core.Node;
import com.maxeler.photon.core.Var;
import com.maxeler.photon.nodes.NodeConstant;
import com.maxeler.photon.nodes.NodeMux;

/**
 * Contains methods for control flow in a Kernel.
 * <p>
 * A multiplexer takes a list of input streams and outputs one of the streams
 * selected by the user.
 * <p>
 * There are two types of multiplexer available: binary and one-hot.
 * <p>
 * <h3>Binary multiplexers</h3>
 * The select value is an integer representing an index into the list of input streams. The type of the
 * select value must be an integer exactly large enough to of select the number of inputs.
 * <p>
 * A select value of {@code 0x0} selects stream {@code 0} from the list of inputs,
 * value {@code 0x1} selects stream {@code 1}, {@code 0x2} stream {@code 2} etc.
 * <p>
 * <b>Note</b>: passing a value for the select argument that is beyond the range of the inputs
 * will result in undefined behavior.
 * <h3>One-hot multiplexers</h3>
 * The select value has a bit to select each input stream: only one bit can be high, or "hot", at any time.
 * The type of the select value must be either an unsigned integer {@code DFEFix} or {code DFERawBits} of
 * with the same number of bits as there are inputs to the multiplexer.
 * <p>
 * A select value {@code 0x1} selects stream {@code 0} from the list of inputs,
 * value {@code 0x2} selects stream {@code 1}, {@code 0x4} stream {@code 2} etc.
 * <p>
 * <b>Note</b>: passing a value for the select argument contains more than one bit set to {@code 1} will result in undefined behavior.
 * <p>
 * <h3>Multiplexing multipipe inputs</h3>
 * For a multipipe type with {@code N} pipes, a multipipe stream of select values and a list of multipipe inputs are
 * provided as arguments. The output is a multipipe stream with {@code N} pipes. For each pipe in the output stream,
 * index {@code n}, the corresponding select value, {@code select[n]}, selects the {@code n}th pipe from the {@code select[n]}th input stream.
 * <p> i.e <code> output[n] = inputs[select[n]][n] </code>
 */
public class Control {
	private final Kernel m_design;

	/**
	 * {@link Count} object for creating counters.
	 */
	public Count count;

	Control(Kernel design) {
		m_design = design;
		count = new Count(design);
	}

	/**
	 * Binary-encoded multiplexer for 2 or more multipipe inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Index for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		S extends DFEVectorBase<DFEVar, S, ?, ?>
	>
	M mux(S select, List<M> inputs) {
		return _mux(false, select, inputs);
	}

	/**
	 * Binary-encoded multiplexer for 2 or more multipipe inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Index for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		S extends DFEVectorBase<DFEVar, S, ?, ?>
	>
	M mux(S select, M... inputs) {
		return _mux(false, select, Arrays.asList(inputs));
	}

	/**
	 * Binary-encoded multiplexer for 2 or more {@link KernelObject} inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Index for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <T extends KernelObject<T>> T mux(DFEVar select, T... inputs) {
		return _mux(false, select,  Arrays.asList(inputs));
	}

	/**
	 * Binary-encoded multiplexer for 2 or more {@link KernelObject} inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Index for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <T extends KernelObject<T>> T mux(DFEVar select, List<T> inputs) {
		return _mux(false, select, inputs);
	}

	/**
	 * One-hot-encoded multiplexer for 2 or more multipipe inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Multipipe stream of one-hot values for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		S extends DFEVectorBase<DFEVar, S, ?, ?>
	>
	M oneHotMux(S select, List<M> inputs) {
		return _mux(true, select, inputs);
	}

	/**
	 * One-hot-encoded multiplexer for 2 or more multipipe inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Multipipe stream one-hot values for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		S extends DFEVectorBase<DFEVar, S, ?, ?>
	>
	M oneHotMux(S select, M... inputs) {
		return _mux(true, select, Arrays.asList(inputs));
	}

	/**
	 * One-hot-encoded multiplexer for 2 or more {@link KernelObject} inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Stream of one-hot values for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <T extends KernelObject<T>> T oneHotMux(DFEVar select, T... inputs) {
		return _mux(true, select, Arrays.asList(inputs));
	}

	/**
	 * One-hot-encoded multiplexer for 2 or more {@link KernelObject} inputs.
	 * <p>
	 * See the {@link Control} class description for information on multiplexers.
	 * @param select Stream of one-hot values for the input to select.
	 * @param inputs List of inputs from which to select.
	 * @return Output stream containing values from the selected input.
	 */
	public <T extends KernelObject<T>> T oneHotMux(DFEVar select, List<T> inputs) {
		return _mux(true, select, inputs);
	}

	private <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		S extends DFEVectorBase<DFEVar, S, ?, ?>
	>
	M _mux(boolean one_hot, S sel, List<M> inputs)
	{
		if(inputs.isEmpty())
			throw new MaxCompilerAPIError(m_design.getManager(), "Cannot mux zero inputs.");
		if(sel.getNElements() == 0)
			throw new MaxCompilerAPIError(m_design.getManager(), "Cannot multi-pipe mux multi-pipes with zero pipes.");

		for(M input : inputs)
			if(input.getNElements() != sel.getNElements())
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Multi-pipe mux select source does not have an equal " +
					"number of pipes as all inputs.");

		final M template = inputs.get(0);
		List<P> new_pipes = new ArrayList<P>(template.getNElements());
		for(int i = 0; i < template.getNElements(); i++) {
			List<P> pipe_inputs = new ArrayList<P>();
			for(M input : inputs)
				pipe_inputs.add(input.getElement(i));

			P muxed = _mux(one_hot, sel.getElement(i), pipe_inputs);

			new_pipes.add(muxed);
		}

		return template.getType().newInstance(template.getKernel(), new_pipes);
	}

	private <T extends KernelObject<T>> String typesForInputs(List<T> inputs) {
		StringBuilder sb = new StringBuilder("[");

		boolean first = true;
		for(T input : inputs) {
			if(first)
				first = false;
			else
				sb.append(", ");
			sb.append(input.getType().toString());
		}

		sb.append("]");

		return sb.toString();
	}

	@SuppressWarnings("unchecked")
	private <T extends KernelObject<T>> T _mux(boolean one_hot, DFEVar select, List<T> inputs) {
		if(inputs.size() < 1)
			throw new MaxCompilerAPIError(m_design.getManager(), "Cannot mux zero inputs.");


		if(select.getType().isConcreteType()) {
			if(!(select.getType().isUInt() || select.getType() instanceof DFERawBits))
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Type of select input must be unsigned integer (with an offset of 0) or raw bits, not "
						+ select.getType());

			int select_bits = select.getType().getTotalBits();
			if(one_hot) {
				if(inputs.size() != select_bits)
					throw new MaxCompilerAPIError(m_design.getManager(),
						"One-hot muxes must have as many inputs as bits in the select input. "
							+ "Currently " + inputs.size() + " inputs for "
							+ select_bits + " bits of select");
			} else {
				if(select_bits >= Integer.SIZE - 1)
					throw new MaxCompilerAPIError(m_design.getManager(),
						"Too many bits in select type (%d). Must be less than %d.",
						select_bits, Integer.SIZE - 1);

				int selectable_inputs = 1 << select_bits;
				if(inputs.size() > selectable_inputs)
					throw new MaxCompilerAPIError(m_design.getManager(),
						"Mux select type is "
						+ select.getType() + " which allows a maximum of "
						+ selectable_inputs + " inputs, but " + inputs.size()
						+ " inputs were provided.");
			}

		} else if(!one_hot) {
			// simplify graph now and don't wait for optimisation graph pass (is that really such a good idea?)
			Node src_node = _KernelBaseTypes.toImp(select).getSrcNode();
			if(src_node instanceof NodeConstant && ((NodeConstant)src_node).canGetValueAsDouble()) {
				double n = ((NodeConstant)src_node).getValueAsDouble();
				double rn = Math.round(n);
				if(n != rn || n < 0 || n > inputs.size())
					throw new MaxCompilerAPIError(m_design.getManager(), "Select input to mux is constant but invalid: " + n);

				return inputs.get((int)n);
			}
		}

		// Assert all inputs types are the same (or untyped-const) and
		// work out what this common "overall" type is.
		// It is ok to have all mux inputs as untyped only as long as the select is
		// untyped too.
		List<List<DFEVar>> input_prims = new ArrayList<List<DFEVar>>();
		KernelType<T> overall_type = null;
		for(T input : inputs) {
			List<DFEVar> this_input_prims = input.packToList();
			input_prims.add(this_input_prims);

			if(overall_type == null) {
				overall_type = input.getType();
				continue;
			}
			if(input.getType().isConcreteType()) {
				if(!overall_type.isConcreteType()) {
					overall_type = input.getType();
				} else {
					if(!overall_type.equalsIgnoreMax(input.getType())) {
						throw new MaxCompilerAPIError(m_design.getManager(),
							"All inputs to mux must be either untyped constants or identical. " +
							"Input types to this mux are :" + typesForInputs(inputs));
					}
					overall_type = (KernelType<T>)overall_type.unionWithMaxOfMaxes(input.getType());
				}
			}
		}

		if(select.getType().isConcreteType() && !overall_type.isConcreteType()) {
			throw new MaxCompilerAPIError(m_design.getManager(),
				"If select type is concrete, then at least one input of mux must be concrete as well.");
		}

		int prims_per_input = overall_type.getTotalPrimitives();

		// Mux each set of primitives covering all inputs one at a time
		List<DFEVar> mux_out_vars = new ArrayList<DFEVar>();
		for(int prim = 0; prim < prims_per_input; prim++) {
			NodeMux mux_node = new NodeMux(
				_Kernel.getPhotonDesignData(m_design),
				_Kernel.getPhotonDesignData(m_design).getGroupPath(),
				inputs.size(),
				one_hot,
				null);

			mux_node.connectInput("sel", _KernelBaseTypes.toImp(select));
			for(int input = 0; input < inputs.size(); input++) {
				DFEVar input_prim = input_prims.get(input).get(prim);
				mux_node.connectInput("option" + input, _KernelBaseTypes.toImp(input_prim));
			}

			Var result = mux_node.connectOutput("result");
			mux_out_vars.add(_KernelBaseTypes.fromImp(m_design, result));
		}

		return overall_type.unpackFromList(mux_out_vars);
	}
}

