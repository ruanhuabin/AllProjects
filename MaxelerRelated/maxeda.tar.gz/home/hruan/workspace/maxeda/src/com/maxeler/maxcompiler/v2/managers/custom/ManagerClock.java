package com.maxeler.maxcompiler.v2.managers.custom;

import com.maxeler.maxeleros.managercompiler.core.WrapperClock;

public class ManagerClock {
	private final com.maxeler.maxeleros.managercompiler.core.WrapperClock m_imp;

	ManagerClock(WrapperClock imp) {
		m_imp = imp;
	}

	WrapperClock toImp() {
		return m_imp;
	}
}
