package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core._KernelCore;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxdc.MaxFileManager;
import com.maxeler.maxdc.MaxFileXMacros;
import com.maxeler.photon.core.Node;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.PhotonIOInformation;
import com.maxeler.photon.nodes.NodeFlush;
import com.maxeler.photon.nodes.NodeInput;
import com.maxeler.photon.nodes.NodeOutput;

/**
 * Controls how a Kernel operates when all data has been processed.
 *
 */
public class Flush {
	// Interfaces can't have package visibility methods but
	// abstract classes can have package visibility abstract methods.
	abstract class FlushStrategey {
		abstract Node getFlushSourceNode(PhotonDesignData data_imp, DFEVar current_cycle_count);
	}

	class FlushOnInputFinished extends FlushStrategey {
		private final String m_input_name;

		private FlushOnInputFinished(String input_name) {
			m_input_name = input_name;
		}

		@Override
		Node getFlushSourceNode(PhotonDesignData data_imp, DFEVar current_cycle_count) {
			NodeInput input_node =
				_KernelCore.getInputNode(m_design.io, m_input_name);

			if(input_node == null)
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Cannot find input '" + m_input_name + "' needed for flushing.");

			return input_node;
		}
	}

	abstract class FlushOnTrigger extends FlushStrategey {
		abstract DFEVar getTriggerVar(DFEVar current_cycle_count);

		@Override
		Node getFlushSourceNode(PhotonDesignData data_imp, DFEVar current_cycle_count) {
			NodeFlush flush_node = new NodeFlush(data_imp);
			flush_node.connectInput(
				"start",
				_KernelBaseTypes.toImp(getTriggerVar(current_cycle_count)));

			return flush_node;
		}
	}

	class FlushDisabled extends FlushOnTrigger {
		@Override
		DFEVar getTriggerVar(DFEVar current_cycle_count) {
			return m_design.constant.var(false);
		}
	}

	class FlushOnUserTrigger extends FlushOnTrigger {
		private final DFEVar m_trigger;

		private FlushOnUserTrigger(DFEVar trigger) {
			m_trigger = trigger;
		}

		@Override
		DFEVar getTriggerVar(DFEVar current_cycle_count) {
			return m_trigger;
		}
	}

	class FlushHostControlled extends FlushOnTrigger {
		@Override
		DFEVar getTriggerVar(DFEVar current_cycle_count) {
			// Contribute to the list of host controlled kernels in the MaxFile.
			MaxFileManager maxfile_man = MaxFileManager.getMaxFileManager(
				_Managers.getBuildManager(m_design.getManager()));
			MaxFileXMacros host_controlled_list_mgxm = new MaxFileXMacros("KERNEL_HOST_CONTROLLED");
			host_controlled_list_mgxm.addMacro(m_design.getName(), m_design.getName());
			maxfile_man.addMaxFileDataSegment(host_controlled_list_mgxm);

			// Create "pre-defined" register to be set by maxlib.
			DFEVar cycle_count = m_design.io.scalarInput(
				"run_cycle_count",
				KernelLib.dfeUInt(PhotonDesignData.runCycleCounterBits)
			);

			return current_cycle_count.eq(cycle_count);
		}
	}

	FlushStrategey m_flush_strategy;
	private final Kernel m_design;

	Flush(Kernel design) {
		m_design = design;
		hostControlled();
	}

	void setupPhotonFlush(DFEVar current_cycle) {
		if(m_flush_strategy == null)
			throw new MaxCompilerAPIError(m_design.getManager(),
				"No flushing strategy specified. " +
				"Please call one of the KernelDesign.flush* methods to set one.");

		PhotonDesignData data_imp = _Kernel.getPhotonDesignData(m_design);
		data_imp.setFlushSource(m_flush_strategy.getFlushSourceNode(data_imp, current_cycle));
	}

	public void hostControlled() {
		m_flush_strategy = new FlushHostControlled();
	}

	public void disabled() {
		m_flush_strategy = new FlushDisabled();
	}

	public void whenInputFinished(String inputName) {
		if (inputName == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "inputName");

		if (m_design.getKernelConfig().optimization.getCEPipelining() <= 1)
			throw new MaxCompilerAPIError(m_design.getManager(), "Flushing when input has finished is not supported for kernels with CE pipelining < 2 (current CE pipelining = %d).", m_design.getKernelConfig().optimization.getCEPipelining());
		m_flush_strategy = new FlushOnInputFinished(inputName);
	}

	public void onTrigger(DFEVar trigger) {
		if (trigger == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "trigger");

		m_flush_strategy = new FlushOnUserTrigger(trigger);
	}

	public void disableInput(String inputName, DFEVar disableTrigger) {
		if (inputName == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "inputName");
		if (disableTrigger == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "disableTrigger");

		PhotonDesignData data_imp = _Kernel.getPhotonDesignData(m_design);
		data_imp.setDisableInput(inputName, _KernelBaseTypes.toImp(disableTrigger));
	}

	public void allowOutputBeforeFlush(String outputName) {
		if (outputName == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "outputName");

		PhotonIOInformation ioInfo = _Kernel.getPhotonDesignData(m_design).getIOInformation();
		NodeOutput output = ioInfo.getOutputNode(outputName);
		if (output == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Output with name '%s' does not exist in kernel '%s'.", outputName, m_design.getName());

		ioInfo.addOutputAllowedBeforeFlush(output);
	}
}
