package com.maxeler.maxcompiler.v2;

import java.util.IdentityHashMap;

import com.maxeler.maxcompiler.v0.kernelcompiler.core.KernelDesignData;
import com.maxeler.maxcompiler.v0.kernelcompiler.core.Var;
import com.maxeler.maxcompiler.v0.kernelcompiler.core._KernelCore;
import com.maxeler.maxcompiler.v0.kernelcompiler.types._KernelTypes;
import com.maxeler.maxcompiler.v0.managercompiler._V1BridgeManager;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.photon.core.PhotonDesignData;

public class _V0V2Bridge {
	/**
	 * Create a V0 compatible manager from a V1 manager. This is suitable for using
	 * V0 kernel cores in a V1 Manager design.
	 */
	public static com.maxeler.maxcompiler.v0.managercompiler.Manager manager(DFEManager v1_manager) {
		return new _V1BridgeManager(v1_manager);
	}

	// We cache newly created v0 design data so the interpreter gets re-used,
	// potentially allowing interaction between v0 kernels which communicate
	// via interpreter variables.
	private static IdentityHashMap<PhotonDesignData, KernelDesignData> m_kernel_design_cache =
		new IdentityHashMap<PhotonDesignData, KernelDesignData>();

	public static KernelDesignData
		kernelDesignData(com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib v1_design)
	{
		PhotonDesignData photon_data = _Kernel.getPhotonDesignData(v1_design.getKernel());
		KernelDesignData v0_data =
			m_kernel_design_cache.get(photon_data);
		if(v0_data == null) {
			v0_data = _KernelCore.makeKernelDesignData(photon_data, manager(v1_design.getManager()), v1_design.getKernel().getName());
			m_kernel_design_cache.put(photon_data, v0_data);
		}

		return v0_data;
	}

	public static Var var(DFEVar hw_var) {
		return _KernelCore.fromImp( _KernelBaseTypes.toImp(hw_var) );
	}

	public static DFEVar dfeVar(com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib v1_design, Var var) {
		return _KernelBaseTypes.fromImp(v1_design, _KernelCore.toImp(var));
	}

	public static com.maxeler.maxcompiler.v0.kernelcompiler.types.HWType dfeType(DFEType type) {
		return _KernelTypes.fromImp( _KernelBaseTypes.toImp(type) );
	}

	public static DFEType hwType(com.maxeler.maxcompiler.v0.kernelcompiler.types.HWType type) {
		return _KernelBaseTypes.fromImp( _KernelTypes.toImp(type) );
	}
}