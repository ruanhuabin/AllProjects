package com.maxeler.maxcompiler.v2.managers.standard;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.MAX3BoardModel;
import com.maxeler.maxcompiler.v2.managers.custom.CustomManager;

public class _Manager extends Manager {

	private boolean m_use_native_float_types_in_sim = false;

	public _Manager(String buildName, MAX2BoardModel boardModel) {
		super(new _EngineParameters(buildName, boardModel, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
	}
	public _Manager(String buildName, MAX3BoardModel boardModel) {
		super(new _EngineParameters(buildName, boardModel, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
	}

	@Override
	public void setEnableAddressGeneratorsInSlowClock(boolean enable_slow_clock) {
		super.setEnableAddressGeneratorsInSlowClock(enable_slow_clock);
	}

	public void setEnableNativeTypesForSimulation(boolean value) {
		m_use_native_float_types_in_sim = value;
	}

	@Override
	void configureFullManager(CustomManager manager_design) {
		((CustomManager._Config)manager_design.config).simulation.setUseNativeFloatTypes(m_use_native_float_types_in_sim);
		super.configureFullManager(manager_design);
	}

}
