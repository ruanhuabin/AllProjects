package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM.RamInput;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM.RamValue;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM.WriteEnableAssigner;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.Mem.DualPortRAMMode;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmEnumType;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmTypeFactory;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmUntypedConst;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.ExprUtils;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.MemoryDataIn;
import com.maxeler.statemachine.expressions.MemoryDataOut;
import com.maxeler.statemachine.expressions.MemoryWriteEnable;
import com.maxeler.statemachine.memory.MappedRAM;
import com.maxeler.statemachine.memory.MemoryElement;
import com.maxeler.statemachine.statements.StatementAssign;

public class DFEsmDualPortMappedRAM extends DFEsmMappedRAM {

	private final class DualPortRamDataAssigner extends RamInput {
		private final DualPortRAMMode m_port_mode;
		private final MemoryDataIn m_data_in_expr;
		private final RamValue m_data_out;

		private DualPortRamDataAssigner(
			StateMachineLib s,
			DualPortRAMMode mode,
			MemoryDataIn dataInExpr,
			RamValue data)
		{
			super(s);
			m_port_mode = mode;
			m_data_in_expr = dataInExpr;
			m_data_out = data;
		}

		@Override
		protected void assign(Expression expr) {
			checkContextValid();

			if (m_port_mode == DualPortRAMMode.READ_ONLY)
				throw new MaxCompilerAPIError("Cannot assign data to a read-only port.");

			expr = ExprUtils.implicitCast(m_data_out.getType(), "RAM data", expr);
			m_stateMachine.addStatement(new StatementAssign((MemoryDataOut)m_data_out.getExpression(), expr, _StateMachine.getBuildManager(m_stateMachine)));
		}

		@Override
		protected DFEsmValueType getType() {
			return m_data_out.getType();
		}

		@Override
		protected DFEsmExpr getDFEsmExpr() {
			checkContextValid();

			return _StateMachine.Create.DFEsmExpr(m_data_in_expr);
		}
	}

	private final class DualPortRamWriteEnableAssigner extends WriteEnableAssigner {
		private final DualPortRAMMode m_port_mode;

		private DualPortRamWriteEnableAssigner(
			StateMachineLib s,
			DualPortRAMMode mode,
			MemoryWriteEnable writeEnable
		) {
			super (s, writeEnable); m_port_mode = mode;
		}

		@Override
		protected void assign(Expression expr) {
			checkContextValid();

			if (m_port_mode == DualPortRAMMode.READ_ONLY)
				throw new MaxCompilerAPIError("Cannot assign data to a read-only port.");

			if (expr.getType() instanceof DFEsmEnumType)
				throw new MaxCompilerAPIError("Cannot assign enums to the write enable port.");
			if ((expr.getType() instanceof DFEsmValueType) && ( !((DFEsmValueType)expr.getType()).isBool() ))
				throw new MaxCompilerAPIError("Cannot assign non-boolean integer value to write enable port.");
			if (expr.getType() instanceof DFEsmUntypedConst)
				expr = ExprUtils.implicitCast(DFEsmTypeFactory.dfeBool(), "Write Enable", expr);
			m_stateMachine.addStatement(new StatementAssign(m_writeEnable, expr, _StateMachine.getBuildManager(m_stateMachine)));
		}

		@Override
		protected DFEsmExpr getDFEsmExpr() {
			checkContextValid();

			return _StateMachine.Create.DFEsmExpr(m_writeEnable);
		}
	}


	public final DFEsmMemAddress addressA;
	public final DFEsmVariable writeEnableA;
	public final DFEsmVariable dataInA;
	public final DFEsmValue dataOutA;

	public final DFEsmMemAddress addressB;
	public final DFEsmVariable writeEnableB;
	public final DFEsmVariable dataInB;
	public final DFEsmValue dataOutB;

	DFEsmDualPortMappedRAM(String name, StateMachineLib stateMachine, Latency latency, DFEsmValueType type,
		DualPortRAMMode portMode0, DualPortRAMMode portMode1,int ram_id, int depth) {
		super(2, name, latency, type, portMode0, portMode1, depth);

		MappedRAM ram = getMappedRAM();

		MemoryElement.Port port0 = ram.getPort(0);
		addressA = new DFEsmMemAddress(stateMachine, port0.address);
		dataOutA = new RamValue(port0.dataOut);
		dataInA = new DualPortRamDataAssigner(stateMachine, portMode0, port0.dataIn, (RamValue)dataOutA);
		writeEnableA = new DualPortRamWriteEnableAssigner(stateMachine, portMode0, port0.write_enable);

		MemoryElement.Port port1 = ram.getPort(1);
		addressB = new DFEsmMemAddress(stateMachine, port1.address);
		dataOutB = new RamValue(port1.dataOut);
		dataInB = new DualPortRamDataAssigner(stateMachine, portMode1, port1.dataIn, (RamValue)dataOutB);
		writeEnableB = new DualPortRamWriteEnableAssigner(stateMachine, portMode1, port1.write_enable);
	}
}
