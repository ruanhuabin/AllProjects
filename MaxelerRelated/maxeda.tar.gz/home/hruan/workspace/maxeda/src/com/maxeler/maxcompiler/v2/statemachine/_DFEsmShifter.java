package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.photon.hw.Shifter;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.ExprUtils;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.Variable;
import com.maxeler.statemachine.shift.BarrelShifter;
import com.maxeler.statemachine.statements.StatementAssign;

public final class _DFEsmShifter {
	private static class WrapperInput extends DFEsmValue {
		protected WrapperInput(Expression expr) {
			super(expr);
		}
	}

	private class WrapperOutput extends DFEsmVariable {
		private final String m_description;
		private final Variable m_variable;
		private final DFEsmValueType m_type;

		public WrapperOutput(String description, Variable variable, DFEsmValueType type) {
			m_description = description;
			m_variable = variable;
			m_type = type;
		}

		@Override
		protected DFEsmExpr getDFEsmExpr() { return _StateMachine.Create.DFEsmExpr(m_variable); }

		@Override
		public <E extends Enum<E>> void connect(E value) {
			throw new MaxCompilerAPIError("Cannot assign an enum as %s.", m_description);
		}

		@Override
		public void connect(long value) {
			Utils.checkIsAllowedLiteralValue(value, m_type);
			connect(BigInteger.valueOf(value));
		}

		@Override
		public void connect(BigInteger value) {
			assign(new Constant(value));
		}

		@Override
		public void connect(DFEsmExpr expr) { assign(expr.getExpression()); }

		private void assign(Expression expr) {
			if (m_stateMachineLib.getContextMode() != ContextMode.NEXT_STATE)
				throw new MaxCompilerAPIError("Shift variables can only be assigned inside the 'nextState' method.");

			expr = ExprUtils.implicitCast(m_type, m_description, expr);
			m_stateMachineLib.addStatement(new StatementAssign(m_variable, expr, _StateMachine.getBuildManager(m_stateMachineLib)));
		}
	}

	private final StateMachineLib m_stateMachineLib;
	private final BarrelShifter m_shifter;

	public final DFEsmVariable dataIn;
	public final DFEsmVariable shiftAmount;
	public final DFEsmValue dataOut;

	public _DFEsmShifter(StateMachineLib stateMachineLib, DFEsmValueType dataType, DFEsmValueType shiftType, Shifter.ShiftDirection direction, boolean circular, int id) {
		m_stateMachineLib = stateMachineLib;
		m_shifter = new BarrelShifter(dataType, shiftType, direction, circular, id);

		dataIn = new WrapperOutput("shift data", m_shifter.shiftInput, m_shifter.dataType);
		shiftAmount = new WrapperOutput("shift amount", m_shifter.shiftAmount, m_shifter.shiftType);

		dataOut = new WrapperInput(m_shifter.shiftResult);
	}

	public int getLatency() { return m_shifter.latency; }

	BarrelShifter getShifter() { return m_shifter; }
}
