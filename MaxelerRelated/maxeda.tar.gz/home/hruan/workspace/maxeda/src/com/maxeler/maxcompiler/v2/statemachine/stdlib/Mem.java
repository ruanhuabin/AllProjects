package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.Latency;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmDualPortMappedRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmDualPortMappedROM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmDualPortRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmDualPortROM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmMappedRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmMappedROM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmROM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmSinglePortMappedRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmSinglePortMappedROM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmSinglePortRAM;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmSinglePortROM;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.StateMachineInternalException;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.memory.MemoryElement;
import com.maxeler.statemachine.utils.IntegerList;

public final class Mem extends Lib {
	/**
	 * Port type for a single-port RAM.
	 */
	public enum SinglePortRAMMode {
		/**
		 * Data is read from the current address before being written (i.e. the
		 * output data is the previous contents of the RAM).
		 */
		READ_FIRST,
		/**
		 * Data is written to the current address before being read (i.e. the
		 * output data is the same as the data being written).
		 */
		WRITE_FIRST
	}

	/**
	 * Port type for a dual-port RAM.
	 */
	public enum DualPortRAMMode {
		/** Data can only be read from this port, not written. */
		READ_ONLY,
		/** Data can only be written to this port, not read. */
		WRITE_ONLY,
		/**
		 * Data can be both read from and written to this port. Output data is
		 * read from the current address before being overwritten.
		 */
		RW_READ_FIRST,
		/**
		 * Data can be both read from and written to this port. The output data
		 * is the same as the data being written.
		 */
		RW_WRITE_FIRST
	}

	/** Default latency of all memory elements. */
	private static final Latency s_defaultLatency = Latency.get(MemoryElement.minLatency);

	/** All ROMs that have been created. */
	private final List<DFEsmROM> m_roms = new ArrayList<DFEsmROM>();
	/** All mapped ROMs that have been created. */
	private final Map<String, DFEsmMappedROM> m_mappedROMs = new TreeMap<String, DFEsmMappedROM>();
	/** All RAMs that have been created. */
	private final List<DFEsmRAM> m_rams = new ArrayList<DFEsmRAM>();

	private final Map<String, DFEsmMappedRAM> m_mappedRAMs = new TreeMap<String, DFEsmMappedRAM>();

	Mem(StateMachineLib stateMachine) { super(stateMachine); }

	/**
	 * Create a single-port ROM with {@code int} data.
	 * <p>
	 * Note that this creates a ROM with the default latency (1 cycle).
	 * @param type The type of data in the ROM.
	 * @param contents The contents of the ROM. This must be at least 1 value.
	 * @return A single-port ROM with the specified type and contents.
	 * @see #rom(DFEsmValueType, Latency, int...)
	 * @see #rom(DFEsmValueType, long...)
	 * @see #rom(DFEsmValueType, Latency, long...)
	 */
	DFEsmSinglePortROM rom(DFEsmValueType type, int... contents) {
		return rom(type, s_defaultLatency, contents);
	}

	/**
	 * Create a single-port ROM with {@code int} data.
	 * @param type The type of data in the ROM.
	 * @param latency The latency of the ROM in cycles. This must be between 1
	 * and 3 (inclusive).
	 * @param contents The contents of the ROM. This must be at least 1 value.
	 * @return A single-port ROM with the specified type and contents.
	 * @see #rom(DFEsmValueType, int...)
	 * @see #rom(DFEsmValueType, long...)
	 * @see #rom(DFEsmValueType, Latency, long...)
	 */
	public DFEsmSinglePortROM rom(DFEsmValueType type, Latency latency, int... contents) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (contents == null)
			throw MaxCompilerAPIError.nullParam("contents");
		checkIsInConstructor();

		return rom(type, latency, IntegerList.fromArray(type, contents));
	}

	DFEsmSinglePortROM rom(DFEsmValueType type, long... contents) {
		return rom(type, s_defaultLatency, contents);
	}

	public DFEsmSinglePortROM rom(DFEsmValueType type, Latency latency, long... contents) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (contents == null)
			throw MaxCompilerAPIError.nullParam("contents");
		checkIsInConstructor();

		return rom(type, latency, IntegerList.fromArray(type, contents));
	}

	public DFEsmSinglePortROM rom(DFEsmValueType type, Latency latency, List<BigInteger> contents) {
		if (type.getTotalBits() > 64)
			throw new MaxCompilerAPIError("ROMs with data types larger than 64 bits are not currently supported.");
		if (contents.size() == 0)
			throw new MaxCompilerAPIError("Must supply 1 or more values to initialise ROM.");
		checkIsInConstructor();

		int badIndex = Utils.canRepresent(contents, type);
		if (badIndex != -1)
			throw new MaxCompilerAPIError("Cannot represent ROM value %s with type %s.", contents.get(badIndex), type);

		int romID = m_roms.size();
		DFEsmSinglePortROM r = _StateMachine.Create.DFEsmSinglePortROM(getStateMachine(), latency, type, romID, contents);
		m_roms.add(r);

		return r;
	}

	DFEsmDualPortROM romDualPort(DFEsmValueType type, int... contents) { return romDualPort(type, s_defaultLatency, contents); }

	public DFEsmDualPortROM romDualPort(DFEsmValueType type, Latency latency, int... contents) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (contents == null)
			throw MaxCompilerAPIError.nullParam("contents");
		checkIsInConstructor();

		return romDualPort(type, latency, IntegerList.fromArray(type, contents));
	}

	DFEsmDualPortROM romDualPort(DFEsmValueType type, long... contents) { return romDualPort(type, s_defaultLatency, contents); }

	public DFEsmDualPortROM romDualPort(DFEsmValueType type, Latency latency, long... contents) {
		if (latency.getCycles() < MemoryElement.minLatency || latency.getCycles() > MemoryElement.maxLatency)
			throw new MaxCompilerAPIError("ROM latency must be between %d and %d inclusive, not %d.", MemoryElement.minLatency, MemoryElement.maxLatency, latency);
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (contents == null)
			throw MaxCompilerAPIError.nullParam("contents");
		checkIsInConstructor();

		return romDualPort(type, latency, IntegerList.fromArray(type, contents));
	}

	public DFEsmDualPortROM romDualPort(DFEsmValueType type, Latency latency, List<BigInteger> contents) {
		if (type.getTotalBits() > 64)
			throw new MaxCompilerAPIError("ROMs with data types larger than 64 bits are not currently supported.");
		if (contents.size() == 0)
			throw new MaxCompilerAPIError("Must supply 1 or more values to initialise ROM.");
		checkIsInConstructor();

		int badIndex = Utils.canRepresent(contents, type);
		if (badIndex != -1)
			throw new MaxCompilerAPIError("Cannot represent ROM value %s with type %s.", contents.get(badIndex), type);

		int romID = m_roms.size();
		DFEsmDualPortROM r = _StateMachine.Create.DFEsmDualPortROM(getStateMachine(), latency, type, romID, contents);
		m_roms.add(r);

		return r;
	}

	/**
	 * Create a single-port mapped ROM.
	 * <p>
	 * Note that this creates a mapped ROM with the default latency (1 cycle).
	 * @param name The name of the mapped ROM. This must not be the same as the
	 * name of any other mapped ROM.
	 * @param type The type of data in the ROM.
	 * @param depth The number of elements in the ROM.
	 * @return mapped ROM
	 * @see #romMapped(String, DFEsmValueType, int, Latency)
	 * @see #romMappedDualPort(String, DFEsmValueType, int)
	 * @see #romMappedDualPort(String, DFEsmValueType, int, Latency)
	 */
	DFEsmSinglePortMappedROM romMapped(String name, DFEsmValueType type, int depth) {
		return romMapped(name, type, depth, s_defaultLatency);
	}

	public DFEsmSinglePortMappedROM romMapped(String name, DFEsmValueType type, int depth, Latency latency) {
		if (latency.getCycles() < MemoryElement.minLatency || latency.getCycles() > MemoryElement.maxLatency)
			throw new MaxCompilerAPIError("ROM latency must be between %d and %d inclusive, not %d.", MemoryElement.minLatency, MemoryElement.maxLatency, latency);
		if (depth <= 0)
			throw new MaxCompilerAPIError("ROM depth must be greater than 0 (not %d).", depth);
		if (m_mappedROMs.containsKey(name))
			throw new MaxCompilerAPIError("Mapped ROM named '%s' already exists.", name);
		checkIsInConstructor();

		DFEsmSinglePortMappedROM r = _StateMachine.Create.DFEsmSinglePortMappedROM(getStateMachine(), name, latency, type, depth);
		m_mappedROMs.put(name, r);

		return r;
	}

	DFEsmDualPortMappedROM romMappedDualPort(String name, DFEsmValueType type, int depth) {
		return romMappedDualPort(name, type, depth, s_defaultLatency);
	}

	public DFEsmDualPortMappedROM romMappedDualPort(String name, DFEsmValueType type, int depth, Latency latency) {
		if (latency.getCycles() < MemoryElement.minLatency || latency.getCycles() > MemoryElement.maxLatency)
			throw new MaxCompilerAPIError("ROM latency must be between %d and %d inclusive, not %d.", MemoryElement.minLatency, MemoryElement.maxLatency, latency);
		if (depth <= 0)
			throw new MaxCompilerAPIError("ROM depth must be greater than 0 (not %d).", depth);
		if (m_mappedROMs.containsKey(name))
			throw new MaxCompilerAPIError("Mapped ROM named '%s' already exists.", name);
		checkIsInConstructor();

		DFEsmDualPortMappedROM r = _StateMachine.Create.DFEsmDualPortMappedROM(getStateMachine(), name, latency, type, depth);
		m_mappedROMs.put(name, r);

		return r;
	}

	/**
	 * Create a single-port RAM.
	 * <p>
	 * Note that this creates a RAM with the default latency (1 cycle).
	 * @param type The type of data in the RAM.
	 * @param depth The number of elements in the RAM.
	 * @param portMode The type of RAM port.
	 * @return single port RAM
	 * @see #ram(DFEsmValueType, int, SinglePortRAMMode, Latency)
	 * @see #ramDualPort(DFEsmValueType, int, DualPortRAMMode, DualPortRAMMode)
	 * @see #ramDualPort(DFEsmValueType, int, DualPortRAMMode, DualPortRAMMode, Latency)
	 */
	DFEsmSinglePortRAM ram(DFEsmValueType type, int depth, SinglePortRAMMode portMode) {
		return ram(type, depth, portMode, s_defaultLatency);
	}

	/**
	 * Create a single-port RAM with a particular latency.
	 * @param type The type of data in the RAM.
	 * @param depth The number of elements in the RAM.
	 * @param latency The latency of the RAM in cycles. This must be between 1
	 * and 3 (inclusive).
	 * @param portMode The type of RAM port.
	 * @return single port RAM
	 * @see #ram(DFEsmValueType, int, SinglePortRAMMode)
	 * @see #ramDualPort(DFEsmValueType, int, DualPortRAMMode, DualPortRAMMode, Latency)
	 */
	public DFEsmSinglePortRAM ram(DFEsmValueType type, int depth, SinglePortRAMMode portMode, Latency latency) {
		if (latency.getCycles() < MemoryElement.minLatency || latency.getCycles() > MemoryElement.maxLatency)
			throw new MaxCompilerAPIError("RAM latency must be between %d and %d inclusive, not %d.", MemoryElement.minLatency, MemoryElement.maxLatency, latency);
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (depth <= 0)
			throw new MaxCompilerAPIError("RAM depth must be greater than 0 (not %d).", depth);
		checkIsInConstructor();

		DualPortRAMMode realPortMode;
		switch (portMode) {
			case READ_FIRST:
				realPortMode = DualPortRAMMode.RW_READ_FIRST;
				break;
			case WRITE_FIRST:
				realPortMode = DualPortRAMMode.RW_WRITE_FIRST;
				break;
			default:
				throw new StateMachineInternalException("Invalid port mode: %s.", portMode);
		}

		int ramID = m_rams.size();
		DFEsmSinglePortRAM r = _StateMachine.Create.DFEsmSinglePortRAM(getStateMachine(), latency, type, realPortMode, ramID, depth);
		m_rams.add(r);

		return r;
	}

	/**
	 * Create a single-port Mapped RAM.
	 * <p>
	 * Note that this creates a RAM with the default latency (1 cycle).
	 * @param name The name of the mapped RAM
	 * @param type The type of data in the RAM.
	 * @param depth The number of elements in the RAM.
	 * @param portMode The type of RAM port.
	 * @return single port RAM
	 * @see #ram(DFEsmValueType, int, SinglePortRAMMode, Latency)
	 * @see #ramDualPort(DFEsmValueType, int, DualPortRAMMode, DualPortRAMMode)
	 * @see #ramDualPort(DFEsmValueType, int, DualPortRAMMode, DualPortRAMMode, Latency)
	 */
	DFEsmSinglePortMappedRAM ramMapped(String name, DFEsmValueType type, int depth, SinglePortRAMMode portMode) {
		return ramMapped(name, type, depth, portMode, s_defaultLatency);
	}

	public DFEsmSinglePortMappedRAM ramMapped(String name, DFEsmValueType type, int depth, SinglePortRAMMode portMode, Latency latency) {
		if (latency.getCycles() < MemoryElement.minLatency || latency.getCycles() > MemoryElement.maxLatency)
			throw new MaxCompilerAPIError("Mapepd RAM latency must be between %d and %d inclusive, not %d.", MemoryElement.minLatency, MemoryElement.maxLatency, latency);
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (depth <= 0)
			throw new MaxCompilerAPIError("Mapped RAM depth must be greater than 0 (not %d).", depth);
		if (m_mappedRAMs.containsKey(name))
			throw new MaxCompilerAPIError("Mapped RAM %s already exists", name);
		checkIsInConstructor();

		DualPortRAMMode realPortMode;
		switch (portMode) {
			case READ_FIRST:
				realPortMode = DualPortRAMMode.RW_READ_FIRST;
				break;
			case WRITE_FIRST:
				realPortMode = DualPortRAMMode.RW_WRITE_FIRST;
				break;
			default:
				throw new StateMachineInternalException("Invalid port mode: %s.", portMode);
		}

		int ramID = m_mappedRAMs.size();
		DFEsmSinglePortMappedRAM r = _StateMachine.Create.DFEsmSinglePortMappedRAM(name, getStateMachine(), latency, type, realPortMode, ramID, depth);
		m_mappedRAMs.put(name, r);
		return r;
	}

	/**
	 * Create a dual-port RAM.
	 * <p>
	 * Note that this creates a RAM with the default latency (1 cycle).
	 * @param type The type of data in the RAM.
	 * @param depth The number of elements in the RAM.
	 * @param portMode0 The type of the first RAM port.
	 * @param portMode1 The type of the second RAM port.
	 * @return dual RAM
	 */
	DFEsmDualPortRAM ramDualPort(DFEsmValueType type, int depth, DualPortRAMMode portMode0, DualPortRAMMode portMode1) {
		return ramDualPort(type, depth, portMode0, portMode1, s_defaultLatency);
	}

	public DFEsmDualPortRAM ramDualPort(DFEsmValueType type, int depth, DualPortRAMMode portModeA, DualPortRAMMode portModeB, Latency latency) {
		if (latency.getCycles() < MemoryElement.minLatency || latency.getCycles() > MemoryElement.maxLatency)
			throw new MaxCompilerAPIError("RAM latency must be between %d and %d inclusive, not %d.", MemoryElement.minLatency, MemoryElement.maxLatency, latency);
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (depth <= 0)
			throw new MaxCompilerAPIError("RAM depth must be greater than 0 (not %d).", depth);
		if (portModeA.equals(portModeB) && (portModeA.equals(DualPortRAMMode.READ_ONLY) || portModeA.equals(DualPortRAMMode.WRITE_ONLY)))
			throw new MaxCompilerAPIError("Cannot create dual-port RAM with both ports set to '%s'.", portModeA);
		checkIsInConstructor();

		int ramID = m_rams.size();
		DFEsmDualPortRAM r = _StateMachine.Create.DFEsmDualPortRAM(getStateMachine(), latency, type, portModeA, portModeB, ramID, depth);
		m_rams.add(r);

		return r;
	}


	/**
	 * Create a dual-port RAM.
	 * <p>
	 * Note that this creates a RAM with the default latency (1 cycle).
	 * @param name The name of the mapped RAM
	 * @param type The type of data in the RAM.
	 * @param depth The number of elements in the RAM.
	 * @param portMode0 The type of the first RAM port.
	 * @param portMode1 The type of the second RAM port.
	 * @return dual RAM
	 */
	DFEsmDualPortMappedRAM ramMappedDualPort(String name, DFEsmValueType type, int depth, DualPortRAMMode portMode0, DualPortRAMMode portMode1) {
		return ramMappedDualPort(name, type, depth, portMode0, portMode1, s_defaultLatency);
	}

	public DFEsmDualPortMappedRAM ramMappedDualPort(String name, DFEsmValueType type, int depth, DualPortRAMMode portModeA, DualPortRAMMode portModeB, Latency latency) {
		if (latency.getCycles() < MemoryElement.minLatency || latency.getCycles() > MemoryElement.maxLatency)
			throw new MaxCompilerAPIError("Mapped RAM latency must be between %d and %d inclusive, not %d.", MemoryElement.minLatency, MemoryElement.maxLatency, latency);
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (depth <= 0)
			throw new MaxCompilerAPIError("Mapped RAM depth must be greater than 0 (not %d).", depth);
		if (portModeA.equals(portModeB) && (portModeA.equals(DualPortRAMMode.READ_ONLY) || portModeA.equals(DualPortRAMMode.WRITE_ONLY)))
			throw new MaxCompilerAPIError("Cannot create dual-port RAM with both ports set to '%s'.", portModeA);
		if (m_mappedRAMs.containsKey(name))
			throw new MaxCompilerAPIError("Mapped RAM %s already exists", name);
		checkIsInConstructor();

		int ramID = m_mappedRAMs.size();
		DFEsmDualPortMappedRAM r = _StateMachine.Create.DFEsmDualPortMappedRAM(name,
			getStateMachine(), latency, type, portModeA, portModeB, ramID, depth);
		m_mappedRAMs.put(name, r);

		return r;
	}



	/**
	 * Return a list of all ROMs that have been created (not including mapped
	 * ROMs), in the order in which they were created.
	 */
	List<DFEsmROM> getROMs() { return Collections.unmodifiableList(m_roms); }

	/**
	 * Return a {@link Map} of all mapped ROMs that have been created (keyed by
	 * name).
	 */
	Map<String, DFEsmMappedROM> getMappedROMs() { return Collections.unmodifiableMap(m_mappedROMs); }

	/**
	 * Return a {@link Map} of all mapped RAMs that have been created (keyed by
	 * name).
	 */
	Map<String, DFEsmMappedRAM> getMappedRAMs() { return Collections.unmodifiableMap(m_mappedRAMs); }

	/**
	 * Return a list of all RAMs that have been created, in the order in which
	 * they were created.
	 */
	List<DFEsmRAM> getRAMs() { return Collections.unmodifiableList(m_rams); }
}
