package com.maxeler.maxcompiler.v2.statemachine.types;

public final class _TypeHelper {

	private _TypeHelper(){}

	public static Class<? extends Enum<?>> getEnumClass(DFEsmEnumType t) {
		if (t == null)
			return null;
		return t.getEnumClass();
	}

}
