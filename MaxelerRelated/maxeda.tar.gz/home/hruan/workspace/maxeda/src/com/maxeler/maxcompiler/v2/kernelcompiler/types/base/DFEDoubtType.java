package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.photon.hw.doubt_bit.DoubtBitUtilsHw;

public class DFEDoubtType extends DoubtType {
	private final boolean m_has_doubt_info;

	DFEDoubtType(boolean has_doubt_info) {
		m_has_doubt_info = has_doubt_info;
	}

	@Override
	public boolean hasDoubtInfo() {
		return m_has_doubt_info;
	}

	@Override
	public int getTotalBits() {
		return m_has_doubt_info ? DoubtBitUtilsHw.DOUBT_WIDTH : 0;
	}

	@Override
	public String toString() {
		return "DFEDoubtType(" + (m_has_doubt_info ? "with doubt info" : "without doubt info") + ")";
	}

	@Override
	public boolean equals(Object other) {
		return
			(other instanceof DFEDoubtType) &&
			((DFEDoubtType)other).m_has_doubt_info == m_has_doubt_info;
	}

	@Override
	public int hashCode() {
		return m_has_doubt_info ? 1 : 2;
	}

	@Override
	public DFEDoubtType union(DoubtType other_type) {
		if(!(other_type instanceof DFEDoubtType))
			throw new MaxCompilerAPIError("Can only union with another DFEDoubtType object.");

		DFEDoubtType other_hw_doubt_info = (DFEDoubtType)other_type;

		return
			DFETypeFactory.dfeDoubtType(m_has_doubt_info | other_hw_doubt_info.m_has_doubt_info);
	}
}
