package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import java.util.LinkedHashMap;
import java.util.Map;

import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;

public class Demux implements ManagerBlock {
	com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeDemux m_imp;

	private final Map<String, Integer> m_inputs =
		new LinkedHashMap<String, Integer>();
	private int m_sel_count = 0;

	Demux(com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeDemux demux) {
		m_imp = demux;
	};

	public DFELink addOutput(String name) {
		int sel = m_sel_count;
		m_sel_count++;
		m_inputs.put(name, sel);
		return _CustomManagers.fromImp(m_imp.addOutput(name, sel));
	}

	public DFELink getInput() {
		return _CustomManagers.fromImp(m_imp.getInput());
	}

	@Override
	public void setClock(ManagerClock clock) {
		m_imp.setClock(_CustomManagers.managerClockToImp(clock));
	}

	public void setWidth(int bitwidth) {
		m_imp.setBitWidth(bitwidth);
	}
}
