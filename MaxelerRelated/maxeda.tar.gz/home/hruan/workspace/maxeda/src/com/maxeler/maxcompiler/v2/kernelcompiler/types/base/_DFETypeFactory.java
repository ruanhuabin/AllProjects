package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import static com.maxeler.utils.EnumTranslator.convert;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.photon.types.HWOffsetFix;
import com.maxeler.utils.numeric.BigFloat;

public class _DFETypeFactory {
	public static DFEFix dfeFixMax(int num_bits, BigFloat max, SignMode sign_mode) {
		return new DFEFix(com.maxeler.photon.types.HWTypeFactory.hwFixMax(num_bits, max, convert(sign_mode, HWOffsetFix.SignMode.class)));
	}
}
