package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.photon.nodes.NodeInput;

public class _KernelCore {
	public static IO newIO(Kernel design) {
		return new IO(design);
	}

	public static Control newMux(Kernel design) {
		return new Control(design);
	}

	public static Constant newConstant(Kernel design) {
		return new Constant(design);
	}

	public static Stream newOffset(Kernel design) {
		return new Stream(design);
	}

	public static Stream newStream(Kernel design) {
		return new Stream(design);
	}

	public static Mem newMem(Kernel design) {
		return new Mem(design);
	}

	public static NodeInput getInputNode(IO io, String name) {
		return io.getInputNode(name);
	}

	public static void applyIOConstraints(IO io) {
		io.applyIOConstraints();
	}
}
