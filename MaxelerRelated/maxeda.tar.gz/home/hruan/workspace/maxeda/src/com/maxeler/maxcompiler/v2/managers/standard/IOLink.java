package com.maxeler.maxcompiler.v2.managers.standard;


public class IOLink  {
	public enum IODestination {
		@Deprecated
		PCIE,
		CPU,
		DRAM_LINEAR_1D,
		DRAM_STRIDE_2D,
		DRAM_BLOCKED_3D,
		IFPGA,
		MAXRING_A,
		MAXRING_B,
		MAXRING_LITE_A,
		MAXRING_LITE_B,
		ETHERNET_CH2_SFP1,
		ETHERNET_CH2_SFP2,
		TCP_CH2_SFP1,
		TCP_CH2_SFP2,
		UDP_ONE_TO_ONE_CH2_SFP1,
		UDP_ONE_TO_ONE_CH2_SFP2,
		UDP_ONE_TO_MANY_CH2_SFP1,
		UDP_ONE_TO_MANY_CH2_SFP2
	};
	IOLink(String name, IODestination iotype) {
		this.name = name;
		this.iotype = iotype;
	}
	final String name;
	final IODestination iotype;
}
