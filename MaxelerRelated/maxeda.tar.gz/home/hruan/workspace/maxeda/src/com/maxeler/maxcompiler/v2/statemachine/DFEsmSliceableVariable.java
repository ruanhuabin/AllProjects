package com.maxeler.maxcompiler.v2.statemachine;

public abstract class DFEsmSliceableVariable extends DFEsmVariable {

	public abstract DFEsmVariable get(int index);
	public abstract DFEsmVariable get(int indexto, int indexfrom);
}
