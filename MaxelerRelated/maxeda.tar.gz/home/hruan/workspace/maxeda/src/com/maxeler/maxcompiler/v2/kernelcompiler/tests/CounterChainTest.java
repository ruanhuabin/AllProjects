package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.CounterChain;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;

public class CounterChainTest extends Kernel {

	private final DFEType scalarType = dfeUInt(32);

	public CounterChainTest(KernelParameters parameters) {
		super(parameters);

		DFEVar input = io.input("input", scalarType);

		flush.whenInputFinished("input");

		CounterChain loops = control.count.makeCounterChain();
		DFEVar N = io.scalarInput("N", dfeUInt(10));
		DFEVar M = io.scalarInput("M", dfeUInt(10));
		DFEVar i = loops.addCounter(N, 1);
		{
			loops.addCounter(M, 1);
			{
				// At the head of the loop, we select whether to take the initial value, or the
				// value that is being carried around the dataflow cycle

				 // sourceless, loop-connected later
				DFEVar carried_sum = scalarType.newInstance(this);

				DFEVar sum = i.eq(0) ? constant.var(0.0) : carried_sum;

				// The loop body itself
				DFEVar new_sum = input + sum;

				// At the foot of the loop, we add the backward edge
				carried_sum.connect( stream.offset(new_sum, - M.cast(dfeInt(11)), -500, -5) );

				// We have a controlled output to deliver the sum at the end of each col
				DFEVar output = io.output("output", scalarType, i.eq(M - 1));
				output.connect(new_sum);
			}
		}
	}

    public static final int M = 7; // image row length
    public static final int N = 7; // image column length

    public static void main(String[] args) {
		SimulationManager tester =
		    new SimulationManager("ColSumNestedLoopsSim");

		KernelParameters parameters =
			tester.makeKernelParameters();
		tester.setKernel( new CounterChainTest(parameters) );

		double inputs[] = new double[M*N];
		double outputs[] = new double[M];

		for (int i=0; i<N; ++i) {
		    outputs[i] = 0.0;
		    for (int j=0; j<M; ++j) {
				inputs[i*M+j] = (i+j);
				outputs[i] += inputs[i*M+j];
		    }
		}

		tester.setInputData("input", inputs);

		tester.setScalarInput("N", N);
		tester.setScalarInput("M", M);

		tester.runTest();
		tester.dumpOutput();
		tester.checkOutputData("output", outputs);

		System.out.println("Test okay!");
    }
}
