package com.maxeler.maxcompiler.v2.kernelcompiler.op_management;

public enum EnableExceptionOps {
	ADD, SUB, MUL, DIV,
	NEG,
	ACCUMULATOR,
	CAST_FROM_FIX,
	CAST_FROM_FLOAT,
	SHIFT_LEFT,
	SQRT,
	ALL
}
