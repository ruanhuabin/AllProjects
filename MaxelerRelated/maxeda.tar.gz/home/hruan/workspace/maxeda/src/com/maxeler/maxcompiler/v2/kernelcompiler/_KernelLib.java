package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.utils.numeric.BigFloat;

public class _KernelLib {

	public static DFEFix dfeOffsetFix(int num_bits, BigFloat max, SignMode sign_mode) {
		return _DFETypeFactory.dfeFixMax(num_bits, max, sign_mode);
	}

	public static DFEFix dfeFixMax(int num_bits, BigFloat max, SignMode sign_mode) {
		return _DFETypeFactory.dfeFixMax(num_bits, max, sign_mode);
	}
}
