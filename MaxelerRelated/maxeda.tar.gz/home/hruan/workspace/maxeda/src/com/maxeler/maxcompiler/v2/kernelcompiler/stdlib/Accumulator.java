package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib;

import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.fromImp;
import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.toImp;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.libs.AccumulatorFactory;

/**
 * Provides methods for implementing accumulators in a Kernel graph.
 */
public class Accumulator {

	/**
	 * Parameters for an accumulator.
	 */
	public static class Params {
		private final AccumulatorFactory.Params m_imp;

		private Params(AccumulatorFactory.Params imp) {
			m_imp = imp;
		}

		/**
		 * Adds an enable stream to the accumulator.
		 * <p>
		 * The current input value will only be added to the accumulated value
		 * when {@code enable} is {@code 1}.
		 * @param enable Enables or disables the input to the accumulator.
		 * @return This {@code Params} object.
		 */
		public Params withEnable(DFEVar enable) {
			return new Params(m_imp.withEnable(toImp(enable)));
		}

		/**
		 * Adds a control stream to clear the accumulator.
		 * <p>
		 * When {@code clear} is {@code 1}, the accumulated value will be reset to {@code 0} on the following cycle.
		 * @param clear Clears the accumulator when the current value is {@code 1}.
		 * @return This {@code Params} object.
		 */
		public Params withClear(DFEVar clear) {
			return new Params(m_imp.withClear(toImp(clear)));
		}
	}

	Accumulator() {
	}

	/**
	 * Creates a parameter object for an accumulator.
	 * @param output_type The Kernel type for the output of the accumulator.
	 * @return A new parameter object.
	 */
	public Params makeAccumulatorConfig(DFEType output_type) {
		return new Params(AccumulatorFactory.makeParams(_KernelBaseTypes.toImp(output_type)));
	}

	/**
	 * Makes a two-input accumulator.
	 * <p>
	 * The sum of the two summands is added to the accumulated value every cycle.
	 * <p>
	 * The current accumulated value is output every cycle.
	 * <p>
	 * The output is set to {@code 0} when the Kernel is reset.
	 * @param summandA The first summand.
	 * @param summandB The second summand (must be of the same Kernel type as {@code summandA})
	 * @param config The parameters for this accumulator.
	 * @return The current accumulated value.
	 */
	public DFEVar makeAccumulator(DFEVar summandA, DFEVar summandB, Params config) {
		Kernel kernel = summandA.getKernel();
		PhotonDesignData pdd = _Kernel.getPhotonDesignData(kernel);
		AccumulatorFactory imp = new AccumulatorFactory(pdd);
		return fromImp(
			kernel,
			imp.makeAccumulator(toImp(summandA), toImp(summandB), config.m_imp));
	}

	/**
	 * Makes an accumulator.
	 * <p>
	 * The summand is added to the accumulated value every cycle.
	 * <p>
	 * The current accumulated value is output every cycle.
	 * <p>
	 * The output is set to {@code 0} when the Kernel is reset.
	 * @param summand The summand.
	 * @param config The parameters for this accumulator.
	 * @return The current accumulated value.
	 */
	public DFEVar makeAccumulator(DFEVar summand, Params config) {
		Kernel kernel = summand.getKernel();
		PhotonDesignData pdd = _Kernel.getPhotonDesignData(kernel);
		AccumulatorFactory imp = new AccumulatorFactory(pdd);

		return fromImp(kernel, imp.makeAccumulator(toImp(summand), config.m_imp));
	}

	/**
	 * Makes a multipipe accumulator.
	 * <p>
	 * An accumulated value is held for each pipe. The current values in
	 * each pipe of {@code summand} are added to a corresponding accumulated value every cycle.
	 * <p>
	 * The current accumulated value for each pipe is output every cycle.
	 * <p>
	 * The output is set to {@code 0} for all pipes when the Kernel is reset.
	 * @param summand The summand.
	 * @param config The parameters for this accumulator.
	 * @return The current accumulated values.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	DFEVar makeAccumulator(M summand, Params config) {
		DFEVar total = null;
		for(int i = 0; i < summand.getNElements(); i++) {
			DFEVar pipe_accumulator = makeAccumulator(summand.getElement(i), config);
			if(i == 0)
				total = pipe_accumulator;
			else
				total = total.add(pipe_accumulator);
		}

		return total;
	}

	/**
	 * Makes a multipipe two-input accumulator.
	 * <p>
	 * An accumulated value is held for each pipe. The current value in each summand pipe
	 * is added to the corresponding accumulated value every cycle.
	 * <p>
	 * The current accumulated value for each pipe is output every cycle.
	 * <p>
	 * The output is set to {@code 0} for all pipes when the Kernel is reset.
	 * @param summandA The first summand.
	 * @param summandB The second summand (must be of the same Kernel type as {@code summandA})
	 * @param config The parameters for this accumulator.
	 * @return The current accumulated values.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	DFEVar makeAccumulator(M summandA, M summandB, Params config) {
		if(summandA.getType().equals(summandB.getType()))
			throw new MaxCompilerAPIError(summandA.getKernel().getManager(),
				"Multi-pipe dyadic accumulator can only be used with summands of identical types." +
				"\n(" + summandA.getType() + " != " + summandB.getType() + ")");

		DFEVar total = null;
		for(int i = 0; i < summandA.getNElements(); i++) {
			DFEVar pipe_accumulator =
				makeAccumulator(summandA.getElement(i), summandB.getElement(i), config);
			if(i == 0)
				total = pipe_accumulator;
			else
				total = total.add(pipe_accumulator);
		}

		return total;
	}
}
