package com.maxeler.maxcompiler.v2.managers.standard;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build.EngineParameters.Target;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._KernelConfiguration;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArrayType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplexType;
import com.maxeler.maxcompiler.v2.managers.BuildConfig;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers.MAXBoardModel;
import com.maxeler.maxcompiler.v2.managers._BuildConfig;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxcompiler.v2.managers.custom.CustomManager;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.KernelBlock;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.DebugLevel;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.Max2RingConnection;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.Max3RingConnection;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MaxRingBidirectionalStream;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControlGroup.MemoryAccessPattern;
import com.maxeler.maxcompiler.v2.managers.engine_interfaces.CPUTypes;
import com.maxeler.maxcompiler.v2.managers.engine_interfaces.EngineInterface;
import com.maxeler.maxcompiler.v2.managers.engine_interfaces.EngineInterface.Direction;
import com.maxeler.maxcompiler.v2.managers.engine_interfaces.InterfaceParam;
import com.maxeler.maxcompiler.v2.managers.standard.IOLink.IODestination;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.EntityStructural;
import com.maxeler.maxdc.EntityTiedIO;
import com.maxeler.maxdc.MaxFileManager;
import com.maxeler.maxdc.xilinx.Virtex6Part;
import com.maxeler.maxdc.xilinx.XilinxPlatform;
import com.maxeler.maxdc.xilinx.constraints.XilinxConstraint;
import com.maxeler.maxdc.xilinx.constraints.XilinxConstraint.XilinxConstraintObject;
import com.maxeler.maxdc.xilinx.constraints.XilinxConstraint.XilinxConstraintType;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.maxeleros.managercompiler.core.WrapperGraphPassGlobal;
import com.maxeler.maxeleros.managercompiler.core.WrapperNode;
import com.maxeler.maxeleros.managercompiler.graph_passes.GenerateMXGInfo;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodePhoton;
import com.maxeler.maxeleros.platforms.BoardCapabilities;
import com.maxeler.maxeleros.platforms.MAX3ComputeFPGA;
import com.maxeler.networking.v1.managers.NetworkManager;
import com.maxeler.networking.v1.managers.netlib.EthernetChecksumMode;
import com.maxeler.networking.v1.managers.netlib.EthernetStream;
import com.maxeler.networking.v1.managers.netlib.Max3NetworkConnection;
import com.maxeler.networking.v1.managers.netlib.TCPStream;
import com.maxeler.networking.v1.managers.netlib.UDPChecksumMode;
import com.maxeler.networking.v1.managers.netlib.UDPHeaderMode;
import com.maxeler.networking.v1.managers.netlib.UDPStream;
import com.maxeler.photon.compile_managers.MaxDCCompileManager;
import com.maxeler.photon.compile_managers.SoftwareSimCompileManager;
import com.maxeler.photon.configuration.PhotonKernelConfiguration.BuildTarget;
import com.maxeler.photon.maxcompilersim.formatterBitAccurate.FormatterBitAccurate;


public class Manager extends DFEManager {
	public static final int DEFAULT_CLOCK_FREQUENCY = 100;

	public enum IOType {
		NOIO,
		ALL_CPU,
		@Deprecated
		ALL_PCIE
	};

	private IOType m_iotype = null;
	private Kernel m_kernel = null;
	private boolean m_ioset = false;
	private int m_clock_frequency = DEFAULT_CLOCK_FREQUENCY;
	private final BuildManager m_build_manager;
	private int m_app_id = 0, m_rev_id = 0;
	private boolean m_use_stream_status = false;
	private boolean m_addr_gen_in_slow_clock = false;
	private boolean m_allow_non_multiple_transitions = false;
	private final Map<String, IODestination> m_iolinks = new LinkedHashMap<String, IODestination>();
	private final BoardCapabilities m_board_caps;
	private boolean m_useMEC = true;
	private boolean m_is_networking_used = false;

	private final Map<String, EngineInterface> m_engineInterfaces = new LinkedHashMap<String, EngineInterface>();
	private boolean m_omit_default_interface = false;

	public enum DRAMAccessPattern { LINEAR, LINEAR_1D, STRIDE_2D, BLOCKING_3D };
	public enum NetworkConnection { CH2_SFP1, CH2_SFP2 };
	public enum UDPConnectionMode { OneToOne, OneToMany };

	@Deprecated
	public static final IOType ALL_PCIE = IOType.ALL_PCIE;
	public static final IOType ALL_CPU = IOType.ALL_CPU;
	public static final IOType NOIO = IOType.NOIO;
	@Deprecated
	public static final IODestination PCIE = IODestination.PCIE;
	public static final IODestination CPU = IODestination.CPU;
	public static final IODestination IFPGA = IODestination.IFPGA;
	public static final IODestination MAXRING_A = IODestination.MAXRING_A;
	public static final IODestination MAXRING_B = IODestination.MAXRING_B;
	public static final IODestination MAXRING_LITE_A = IODestination.MAXRING_LITE_A;
	public static final IODestination MAXRING_LITE_B = IODestination.MAXRING_LITE_B;
	public static final DRAMAccessPattern LINEAR = DRAMAccessPattern.LINEAR;
	public static final DRAMAccessPattern LINEAR_1D = DRAMAccessPattern.LINEAR_1D;
	public static final DRAMAccessPattern STRIDE_2D = DRAMAccessPattern.STRIDE_2D;
	public static final DRAMAccessPattern BLOCKING_3D = DRAMAccessPattern.BLOCKING_3D;

	public static final IODestination DRAM(DRAMAccessPattern pattern) {
		switch (pattern) {
			case LINEAR_1D:
				return IODestination.DRAM_LINEAR_1D;
			case STRIDE_2D:
				return IODestination.DRAM_STRIDE_2D;
			case BLOCKING_3D:
				return IODestination.DRAM_BLOCKED_3D;
			default:
				throw new MaxCompilerInternalError("Invalid DRAM access pattern");
		}
	}

	public static final IODestination ETHERNET(NetworkConnection connection) {
		switch (connection) {
			case CH2_SFP1:
				return IODestination.ETHERNET_CH2_SFP1;
			case CH2_SFP2:
				return IODestination.ETHERNET_CH2_SFP2;
			default:
				throw new MaxCompilerInternalError("Invalid network connection");
		}
	}

	public static final IODestination UDP(NetworkConnection connection, UDPConnectionMode connection_mode) {
		switch (connection) {
			case CH2_SFP1:
				return connection_mode == UDPConnectionMode.OneToOne ? IODestination.UDP_ONE_TO_ONE_CH2_SFP1 : IODestination.UDP_ONE_TO_MANY_CH2_SFP1;
			case CH2_SFP2:
				return connection_mode == UDPConnectionMode.OneToOne ? IODestination.UDP_ONE_TO_ONE_CH2_SFP2 : IODestination.UDP_ONE_TO_MANY_CH2_SFP2;
			default:
				throw new MaxCompilerInternalError("Invalid network connection");
		}
	}

	public static final IODestination TCP(NetworkConnection connection) {
		switch (connection) {
			case CH2_SFP1:
				return IODestination.TCP_CH2_SFP1;
			case CH2_SFP2:
				return IODestination.TCP_CH2_SFP2;
			default:
				throw new MaxCompilerInternalError("Invalid network connection");
		}
	}

	public static IOLink link(String io_name, IODestination iotype) {
		return new IOLink(io_name, iotype);
	}


	/**
	 * Creates a new manager with a given configuration.
	 * The constructor will call {@code logParameters} and
	 * {@code writeParametersToMaxFile} on the configuration object.
	 *
	 * @param configuration configuration for this manager.
	 */
	public Manager(EngineParameters configuration) {
		this(configuration.getTarget() ==  Target.MAXFILE_FOR_SIMULATION,
		     configuration.getMaxFileName(),
		     configuration.getBuildName(),
		     configuration.getBoard());
		configuration.logParameters(this);
		configuration.writeParametersToMaxFile(this);
	}

	/**
	 * The use of this constructor is discouraged. See {@link #Manager(EngineParameters)}
	 *
	 * @param generate_max_file_for_simulation if true MaxCompiler will target CPU Code simulation.
	 * @param name name of the max file
	 * @param build_directory name of the build directory
	 * @param board_model DFE model
	 */
	@Deprecated
	public Manager(
		boolean generate_max_file_for_simulation,
		String name,
		String build_directory,
		MAXBoardModel board_model)
	{
		super(name, build_directory, generate_max_file_for_simulation, board_model);

		BuildManager bm = _Managers.getBuildManager(this);

		bm.logProgress("Instantiating manager");

		if(isTargetSimulation())
			_Managers.setCompileManagerFactory(
				this,
				new SoftwareSimCompileManager.Factory(new FormatterBitAccurate.Factory()));
		else
			_Managers.setCompileManagerFactory(this, new MaxDCCompileManager.Factory());

		m_board_caps = _Managers.getBoardCapabilities(board_model);

		setBuildConfig(new _BuildConfig(BuildConfig.Level.FULL_BUILD));
		m_build_manager = bm;

		if(isTargetSimulation()) {
			_KernelConfiguration.setBuildTarget(m_kernel_configuration, BuildTarget.MAXCOMPILERSIM_HOST_DRIVEN);
		}
		else {
			if (XilinxPlatform.get(bm).getFPGAPart() instanceof Virtex6Part)
				_KernelConfiguration.setBuildTarget(m_kernel_configuration, BuildTarget.HW_BUILD_VIRTEX6);
			else
				_KernelConfiguration.setBuildTarget(m_kernel_configuration, BuildTarget.HW_BUILD_VIRTEX5);
		}
	}

	/**
	 * The use of this constructor is discouraged. See {@link #Manager(EngineParameters)}
	 *
	 * @param generate_max_file_for_simulation if true, target CPU code simulation
	 * @param board_name maxfile name and build directory name
	 * @param board_model DFE model
	 */
	@Deprecated
	public Manager(
		boolean generate_max_file_for_simulation,
		String board_name,
		MAXBoardModel board_model)
	{
		this(generate_max_file_for_simulation, board_name, board_name, board_model);
	}

	/**
	 * The use of this constructor is discouraged. See {@link #Manager(EngineParameters)}
	 *
	 * @param build_directory
	 * @param board_model
	 */
	@Deprecated
	public Manager(String build_directory, MAXBoardModel board_model) {
		this(false, new File(build_directory).getName(), build_directory, board_model);
	}

	/**
	 * The use of this constructor is discouraged. See {@link #Manager(EngineParameters)}
	 *
	 * @param name
	 * @param build_directory
	 * @param board_model
	 */
	@Deprecated
	public Manager(String name, String build_directory, MAXBoardModel board_model) {
		this(false, name, build_directory, board_model);
	}

	public void setClockFrequency(int clock_frequency) {
		m_clock_frequency = clock_frequency;
	}

	public void setIO(IOType io_type) {
		if (m_ioset)
			throw new MaxCompilerAPIError(this, "You can not call setIO more than once");

		m_iotype = io_type;
		m_ioset = true;
	}

	public void setIO(IOLink... links) {
		if (m_iotype != null)
			throw new MaxCompilerAPIError(this, "You can not set a general I/O type (NOIO, PCIE, etc) and also specific links, use one mechanism or the other to setIO()");
		m_ioset = true; // but allow multiple calls to this function
		for (IOLink l : links) {
			if (m_iolinks.containsKey(l.name))
				throw new MaxCompilerAPIError(this, "You can not set more than one I/O link for a signal. " + l.name + " has been connected more than once");

			if(l.iotype == IFPGA && m_board_caps.getMajorVersion() != 2)
				throw new MaxCompilerAPIError(this, "IFPGA can only be used when targeting MAX2");

			if((
				l.iotype == IODestination.MAXRING_A ||
				l.iotype == IODestination.MAXRING_B
				) && m_board_caps.getMajorVersion() != 3
			   )
			{
				throw new MaxCompilerAPIError(this, "MAXRING can only be used when targeting MAX3");
			}

			if((
				l.iotype == IODestination.MAXRING_LITE_A ||
				l.iotype == IODestination.MAXRING_LITE_B
				) && m_board_caps.getMajorVersion() != 3
			   )
			{
				throw new MaxCompilerAPIError(this, "MAXRING_LITE can only be used when targeting MAX3");
			}

			if(
				l.iotype == IODestination.ETHERNET_CH2_SFP1 ||
				l.iotype == IODestination.ETHERNET_CH2_SFP2 ||
				l.iotype == IODestination.UDP_ONE_TO_ONE_CH2_SFP1 ||
				l.iotype == IODestination.UDP_ONE_TO_MANY_CH2_SFP1 ||
				l.iotype == IODestination.UDP_ONE_TO_ONE_CH2_SFP2 ||
				l.iotype == IODestination.UDP_ONE_TO_MANY_CH2_SFP2 ||
				l.iotype == IODestination.TCP_CH2_SFP1 ||
				l.iotype == IODestination.TCP_CH2_SFP2)
			{
				if (m_board_caps.getMajorVersion() != 3)
					throw new MaxCompilerAPIError(this, "Networking can only be used when targeting MAX3");

				m_is_networking_used = true;
			}
			m_iolinks.put(l.name, l.iotype);
		}
	}

	public KernelParameters makeKernelParameters() {
		return makeKernelParameters(getName() + "Kernel");
	}

	public void setKernel(Kernel k) {
		if (m_kernel!=null)
			throw new MaxCompilerAPIError(this, "You can not call setKernel() more than once");
		m_kernel = k;
	}

	private void checkForKernel() {
		if(m_kernel == null)
			throw new MaxCompilerAPIError(this, "Kernel must be specified with setKernel() before build.");
	}

	public void setApplicationRevisionIds(int app_id, int rev_id) {
		if ((app_id & 0xff) != app_id) {
			throw new MaxCompilerAPIError(this, "Application id '" + app_id + "' does not fit within an 8-bit integer.");
		}

		if ((rev_id & 0xffff) != rev_id) {
			throw new MaxCompilerAPIError(this, "Revision id '" + rev_id + "' does not fit within an 16-bit integer.");
		}

		m_app_id = app_id;
		m_rev_id = rev_id;
	}

	public void setEnableStreamStatusBlocks(boolean blocks) {
		//if(!blocks && checksums)
		//	throw new MaxCompilerAPIError("Cannot enable checksums without enabling blocks.");

		m_use_stream_status = blocks;
	}

	public void setAllowNonMultipleTransitions(boolean v) {
		m_allow_non_multiple_transitions = v;
	}

	void setEnableAddressGeneratorsInSlowClock(boolean enable_slow_clock) {
		m_addr_gen_in_slow_clock = enable_slow_clock;
	}

	public void setMECEnabled(boolean enable) {
		m_useMEC = enable;
	}

	@Override
	protected final void realBuild() {
		checkForKernel();

		if (m_iotype == null) {
			if (m_iolinks.size() == 0)
				throw new MaxCompilerAPIError(this, "You must call setIO() before you can build()");

			m_build_manager.logProgress("Compiling manager (Configurable)");
			makeFullManager();

		} else {
			switch (m_iotype) {
				case NOIO:
					m_build_manager.logProgress("Compiling manager (No IO)");
					if(isTargetSimulation())
						throw new MaxCompilerAPIError(this,
							"Building a standard manager with no IO is not supported " +
							"when targetting a simulation .max file.");
					makeNoIOManager();
					break;

				case ALL_PCIE:
				case ALL_CPU:
					m_build_manager.logProgress("Compiling manager (PCIe Only)");

					// A set of IO links to connect everything to PCI Express will
					// be created later, once kernel finalizers have been called.
					// See Ticket #2961.

					// Now build this as a full manager
					makeFullManager();
					break;

				default:
					throw new MaxCompilerInternalError(this, "Invalid I/O type");
			}
		}
	}

	@SuppressWarnings("deprecation")
	private void checkIObitwidth(String ioName, int ioBits, IODestination ioDest, String ioType) {
		int multiple;
		String ioDestStr;
		switch (ioDest) {
			case PCIE:
			case CPU:
				multiple = 64;
				ioDestStr = "PCI Express";
				break;
			case IFPGA:
				multiple = 64;
				ioDestStr = "Inter-FPGA";
				break;
			case MAXRING_A:
				multiple = 64;
				ioDestStr = "Max-Ring A";
				break;
			case MAXRING_B:
				multiple = 64;
				ioDestStr = "Max-Ring B";
				break;
			case MAXRING_LITE_A:
				multiple = 32;
				ioDestStr = "Max-Ring Lite A";
				break;
			case MAXRING_LITE_B:
				multiple = 32;
				ioDestStr = "Max-Ring Lite B";
				break;
			case DRAM_BLOCKED_3D:
			case DRAM_STRIDE_2D:
			case DRAM_LINEAR_1D:
				multiple = 384;
				ioDestStr = "DRAM";
				break;
			case ETHERNET_CH2_SFP1:
			case ETHERNET_CH2_SFP2:
			case UDP_ONE_TO_ONE_CH2_SFP1:
			case UDP_ONE_TO_ONE_CH2_SFP2:
			case UDP_ONE_TO_MANY_CH2_SFP1:
			case UDP_ONE_TO_MANY_CH2_SFP2:
			case TCP_CH2_SFP1:
			case TCP_CH2_SFP2:
				return;
			default:
				throw new MaxCompilerInternalError(this, "Invalid IO type");
		}

		boolean bitsIsMultiple = (ioBits % multiple == 0);
		boolean bitsIsDivisor = (multiple % ioBits == 0);

		if (!(bitsIsMultiple | bitsIsDivisor))
			throw new MaxCompilerAPIError(this, ioType + "s connected to " + ioDestStr + " must be integer multiples or fractions of " + multiple + " bits. " + ioType + " \"" + ioName + "\" is " + ioBits + " bits wide");
	}

	private void checkIOLinkValidity() {
		Map<String, KernelType<?>> kernel_inputs = m_kernel.io.getInputs();
		Map<String, KernelType<?>> kernel_outputs = m_kernel.io.getOutputs();
		Set<String> kernel_input_names = kernel_inputs.keySet();
		Set<String> kernel_output_names = kernel_outputs.keySet();

		// Check that all kernel inputs and outputs have an I/O link, and vice versa
		for (String i : kernel_input_names)
			if (!m_iolinks.containsKey(i))
				throw new MaxCompilerAPIError(this, "Kernel input " + i + " does not have an I/O link in the manager");
		for (String o : kernel_output_names)
			if (!m_iolinks.containsKey(o))
				throw new MaxCompilerAPIError(this, "Kernel output " + o + " does not have an I/O link in the manager");
		for (String l : m_iolinks.keySet())
			if (!(kernel_input_names.contains(l) || kernel_output_names.contains(l)))
				throw new MaxCompilerAPIError(this, "You have specified an I/O link for signal " + l + " that is not present on the specified kernel");

		// Check that all buses are power of 2 sizes
		for (String i : kernel_input_names) {
			KernelType<?> k = kernel_inputs.get(i);
			int bits = k.getTotalBits();
			checkIObitwidth(i, bits, m_iolinks.get(i), "Kernel input");
		}
		for (String o : kernel_output_names) {
			KernelType<?> k = kernel_outputs.get(o);
			int bits = k.getTotalBits();
			checkIObitwidth(o, bits, m_iolinks.get(o), "Kernel output");
		}

		// Check there is only 1 IFPGA link present and at least 1 PCIe input and output
		int ifpga_inputs = 0, ifpga_outputs = 0;
		int maxring_a_inputs = 0, maxring_a_outputs = 0;
		int maxring_b_inputs = 0, maxring_b_outputs = 0;
		int maxring_lite_a_inputs = 0, maxring_lite_a_outputs = 0;
		int maxring_lite_b_inputs = 0, maxring_lite_b_outputs = 0;
		int pcie_inputs = 0, pcie_outputs = 0;

		int eth_sfp1_inputs = 0, eth_sfp1_outputs = 0;
		int eth_sfp2_inputs = 0, eth_sfp2_outputs = 0;
		int udp_sfp1_inputs = 0, udp_sfp1_outputs = 0;
		int udp_sfp2_inputs = 0, udp_sfp2_outputs = 0;
		boolean udp_sfp1_in_one_to_one = false; boolean udp_sfp1_in_one_to_many = false;
		boolean udp_sfp2_in_one_to_one = false; boolean udp_sfp2_in_one_to_many = false;
		boolean udp_sfp1_out_one_to_one = false; boolean udp_sfp1_out_one_to_many = false;
		boolean udp_sfp2_out_one_to_one = false; boolean udp_sfp2_out_one_to_many = false;
		int tcp_sfp1_inputs = 0, tcp_sfp1_outputs = 0;
		int tcp_sfp2_inputs = 0, tcp_sfp2_outputs = 0;

		for (String i : kernel_input_names) {
			if (m_iolinks.get(i) == IFPGA) ifpga_inputs++;
			if (m_iolinks.get(i) == MAXRING_A) maxring_a_inputs++;
			if (m_iolinks.get(i) == MAXRING_B) maxring_b_inputs++;
			if (m_iolinks.get(i) == MAXRING_LITE_A) maxring_lite_a_inputs++;
			if (m_iolinks.get(i) == MAXRING_LITE_B) maxring_lite_b_inputs++;
			if (m_iolinks.get(i) == PCIE) pcie_inputs++;
			if (m_iolinks.get(i) == IODestination.ETHERNET_CH2_SFP1) eth_sfp1_inputs++;
			if (m_iolinks.get(i) == IODestination.ETHERNET_CH2_SFP2) eth_sfp2_inputs++;
			if (m_iolinks.get(i) == IODestination.UDP_ONE_TO_ONE_CH2_SFP1) { udp_sfp1_inputs++; udp_sfp1_in_one_to_one = true; }
			if (m_iolinks.get(i) == IODestination.UDP_ONE_TO_MANY_CH2_SFP1) { udp_sfp1_inputs++; udp_sfp1_in_one_to_many = true; }
			if (m_iolinks.get(i) == IODestination.UDP_ONE_TO_ONE_CH2_SFP2) { udp_sfp2_inputs++; udp_sfp2_in_one_to_one = true; }
			if (m_iolinks.get(i) == IODestination.UDP_ONE_TO_MANY_CH2_SFP2) { udp_sfp2_inputs++; udp_sfp2_in_one_to_many = true; }
			if (m_iolinks.get(i) == IODestination.TCP_CH2_SFP1) tcp_sfp1_inputs++;
			if (m_iolinks.get(i) == IODestination.TCP_CH2_SFP2) tcp_sfp2_inputs++;
		}
		for (String o : kernel_output_names) {
			if (m_iolinks.get(o) == IFPGA) ifpga_outputs++;
			if (m_iolinks.get(o) == MAXRING_A) maxring_a_outputs++;
			if (m_iolinks.get(o) == MAXRING_B) maxring_b_outputs++;
			if (m_iolinks.get(o) == MAXRING_LITE_A) maxring_lite_a_outputs++;
			if (m_iolinks.get(o) == MAXRING_LITE_B) maxring_lite_b_outputs++;
			if (m_iolinks.get(o) == PCIE) pcie_outputs++;
			if (m_iolinks.get(o) == IODestination.ETHERNET_CH2_SFP1) eth_sfp1_outputs++;
			if (m_iolinks.get(o) == IODestination.ETHERNET_CH2_SFP2) eth_sfp2_outputs++;
			if (m_iolinks.get(o) == IODestination.UDP_ONE_TO_ONE_CH2_SFP1) { udp_sfp1_outputs++; udp_sfp1_out_one_to_one = true; }
			if (m_iolinks.get(o) == IODestination.UDP_ONE_TO_MANY_CH2_SFP1) { udp_sfp1_outputs++; udp_sfp1_out_one_to_many = true; }
			if (m_iolinks.get(o) == IODestination.UDP_ONE_TO_ONE_CH2_SFP2) { udp_sfp2_outputs++; udp_sfp2_out_one_to_one = true; }
			if (m_iolinks.get(o) == IODestination.UDP_ONE_TO_MANY_CH2_SFP2) { udp_sfp2_outputs++; udp_sfp2_out_one_to_many = true; }
			if (m_iolinks.get(o) == IODestination.TCP_CH2_SFP1) tcp_sfp1_outputs++;
			if (m_iolinks.get(o) == IODestination.TCP_CH2_SFP2) tcp_sfp2_outputs++;
		}

		if ((ifpga_inputs != 0 | ifpga_outputs != 0) & (ifpga_inputs != 1 | ifpga_outputs != 1))
			throw new MaxCompilerAPIError(this, "To use the IFPGA link, kernels must have 1 IFPGA input and 1 IFPGA output. Specified kernel has " + ifpga_inputs + " IFPGA inputs and " + ifpga_outputs + " IFPGA outputs");

		if ((maxring_a_inputs != 0 | maxring_a_outputs != 0) & (maxring_a_inputs != 1 | maxring_a_outputs != 1))
			throw new MaxCompilerAPIError(this, "To use the MAXRING_A link, kernels must have 1 MAXRING_A input and 1 MAXRING_A output. Specified kernel has " + maxring_a_inputs + " MAXRING_A inputs and " + maxring_a_outputs + " MAXRING_A outputs");

		if ((maxring_b_inputs != 0 | maxring_b_outputs != 0) & (maxring_b_inputs != 1 | maxring_b_outputs != 1))
			throw new MaxCompilerAPIError(this, "To use the MAXRING_B link, kernels must have 1 MAXRING_B input and 1 MAXRING_B output. Specified kernel has " + maxring_b_inputs + " MAXRING_B inputs and " + maxring_b_outputs + " MAXRING_B outputs");

		if ((maxring_lite_a_inputs != 0 | maxring_lite_b_outputs != 0) & (maxring_lite_a_inputs != 1 | maxring_lite_b_outputs != 1))
			throw new MaxCompilerAPIError(this, "To use the MAXRING_LITE B to A link, " +
					"kernels must have 1 MAXRING_LITE_A input and 1 MAXRING_LITE_B output. " +
					"Specified kernel has " + maxring_lite_a_inputs + " MAXRING_LITE_A inputs and " +
					maxring_lite_a_outputs + " MAXRING_LITE_A outputs");

		if ((maxring_lite_b_inputs != 0 | maxring_lite_a_outputs != 0) & (maxring_lite_b_inputs != 1 | maxring_lite_a_outputs != 1))
			throw new MaxCompilerAPIError(this, "To use the MAXRING_LITE A to B link, " +
					"kernels must have 1 MAXRING_LITE_B input and 1 MAXRING_LITE_A output. " +
					"Specified kernel has " + maxring_lite_b_inputs + " MAXRING_LITE_B inputs and " +
					maxring_lite_b_outputs + " MAXRING_LITE_B outputs");

		if (eth_sfp1_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one Ethernet input receiving on CH2_SFP1");
		if (eth_sfp2_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one Ethernet input receiving on CH2_SFP2");
		if (udp_sfp1_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one UDP input receiving on CH2_SFP1");
		if (udp_sfp2_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one UDP input receiving on CH2_SFP2");
		if (tcp_sfp1_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one TCP input receiving on CH2_SFP1");
		if (tcp_sfp2_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one TCP input receiving on CH2_SFP2");

		if (eth_sfp1_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one Ethernet output transmitting on CH2_SFP1");
		if (eth_sfp2_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one Ethernet output transmitting on CH2_SFP2");
		if (udp_sfp1_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one UDP output transmitting on CH2_SFP1");
		if (udp_sfp2_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one UDP output transmitting on CH2_SFP2");
		if (tcp_sfp1_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one TCP output transmitting on CH2_SFP1");
		if (tcp_sfp2_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels cannot have more that one TCP output transmitting on CH2_SFP2");

		if (eth_sfp1_inputs + udp_sfp1_inputs + tcp_sfp1_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels can only receive either Ethernet, UDP or TCP data on CH2_SFP1");

		if (eth_sfp2_inputs + udp_sfp2_inputs + tcp_sfp2_inputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels can only receive either Ethernet, UDP or TCP data on CH2_SFP2");

		if (eth_sfp1_outputs + udp_sfp1_outputs + tcp_sfp1_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels can only transmit either Ethernet, UDP or TCP data on CH2_SFP1");

		if (eth_sfp2_outputs + udp_sfp2_outputs + tcp_sfp2_outputs > 1)
			throw new MaxCompilerAPIError(this, "Kernels can only transmit either Ethernet, UDP or TCP data on CH2_SFP2");

		if (udp_sfp1_in_one_to_one != udp_sfp1_out_one_to_one || udp_sfp1_in_one_to_many != udp_sfp1_out_one_to_many)
			throw new MaxCompilerAPIError(this, "Kernels cannot have UDP inputs and outputs with mixed connection modes on CH2_SFP1");

		if (udp_sfp2_in_one_to_one != udp_sfp2_out_one_to_one || udp_sfp2_in_one_to_many != udp_sfp2_out_one_to_many)
			throw new MaxCompilerAPIError(this, "Kernels cannot have UDP inputs and outputs with mixed connection modes on CH2_SFP2");
	}

	void configureFullManager(CustomManager manager_design) {
		manager_design.setBuildConfig(getBuildConfig());
		manager_design.config.setApplicationRevisionIds(m_app_id, m_rev_id);
		manager_design.config.setEnableAddressGeneratorsInSlowClock(m_addr_gen_in_slow_clock);
		manager_design.debug.setDebugLevel(new DebugLevel() {
			@Override
			public boolean hasStreamStatus() {
				return m_use_stream_status;
			}
		});
		manager_design.config.setAllowNonMultipleTransitions(m_allow_non_multiple_transitions);
	}


	@SuppressWarnings("deprecation")
	private void makeFullManager() {
		CustomManager manager_design;
		NetworkManager net_manager;

		if (m_is_networking_used) {
			net_manager = new NetworkManager(_Managers.getBuildManager(this), m_board_caps, m_useMEC, false);
			manager_design = net_manager;
		}
		else {
			manager_design = new CustomManager(_Managers.getBuildManager(this), m_board_caps, m_useMEC, false);
			net_manager = null;
		}

		configureFullManager(manager_design);

		KernelBlock kernel = manager_design.addKernel(m_kernel);

		for(EngineInterface engine_interface : m_engineInterfaces.values())
			manager_design.createSLiCinterface(engine_interface);

		if (m_omit_default_interface)
			manager_design.suppressDefaultInterface();

		if ((m_iotype == ALL_PCIE) || (m_iotype == ALL_CPU)) {
			// Create a set of IO links to connect everything to PCI Express,
			// this can only be done here, after the kernel has been added to the
			// manager, in case kernel finalizers create IO ports.
			for (String i : m_kernel.io.getInputs().keySet())
				m_iolinks.put(i, IODestination.CPU);
			for (String o : m_kernel.io.getOutputs().keySet())
				m_iolinks.put(o, IODestination.CPU);
		}

		checkIOLinkValidity();

		MaxRingBidirectionalStream ifpga_links = null;
		DFELink ifpga_in = null, ifpga_out = null;

		MaxRingBidirectionalStream maxring_a_links = null;
		DFELink maxring_a_in = null, maxring_a_out = null;

		MaxRingBidirectionalStream maxring_b_links = null;
		DFELink maxring_b_in = null, maxring_b_out = null;

		MaxRingBidirectionalStream maxring_lite_a_links = null;
		DFELink maxring_lite_a_in = null, maxring_lite_a_out = null;

		MaxRingBidirectionalStream maxring_lite_b_links = null;
		DFELink maxring_lite_b_in = null, maxring_lite_b_out = null;

		EthernetChecksumMode eth_checksum_mode = EthernetChecksumMode.DropBadFrames;
		EthernetStream eth_stream_sfp1 = null;
		EthernetStream eth_stream_sfp2 = null;

		UDPChecksumMode udp_checksum_mode = UDPChecksumMode.DropBadFrames;

		UDPHeaderMode udp_header_mode = UDPHeaderMode.StripHeader;
		UDPStream udp_stream_sfp1 = null;
		UDPStream udp_stream_sfp2 = null;

		TCPStream tcp_stream_sfp1 = null;
		TCPStream tcp_stream_sfp2 = null;

		if (m_iolinks.containsValue(IODestination.IFPGA)) {
			ifpga_links = manager_design.addMaxRingBidirectionalStream("ifpga", Max2RingConnection.FPGA_ON_LOCAL_CARD);
			ifpga_in = ifpga_links.getStreamFromRemoteFPGA();
			ifpga_out = ifpga_links.getStreamToRemoteFPGA();
		}

		if (m_iolinks.containsValue(IODestination.MAXRING_A)) {
			maxring_a_links = manager_design.addMaxRingBidirectionalStream("maxring_a", Max3RingConnection.MAXRING_A);
			maxring_a_in = maxring_a_links.getStreamFromRemoteFPGA();
			maxring_a_out = maxring_a_links.getStreamToRemoteFPGA();
		}

		if (m_iolinks.containsValue(IODestination.MAXRING_B)) {
			maxring_b_links = manager_design.addMaxRingBidirectionalStream("maxring_b", Max3RingConnection.MAXRING_B);
			maxring_b_in = maxring_b_links.getStreamFromRemoteFPGA();
			maxring_b_out = maxring_b_links.getStreamToRemoteFPGA();
		}

		if (m_iolinks.containsValue(IODestination.MAXRING_LITE_A)) {
			maxring_lite_a_links = manager_design.addMaxRingBidirectionalStream("maxring_lite_a", Max3RingConnection.MAXRING_LITE_A);
			maxring_lite_a_in = maxring_lite_a_links.getStreamFromRemoteFPGA();
			maxring_lite_a_out = maxring_lite_a_links.getStreamToRemoteFPGA();
		}

		if (m_iolinks.containsValue(IODestination.MAXRING_LITE_B)) {
			maxring_lite_b_links = manager_design.addMaxRingBidirectionalStream("maxring_lite_b", Max3RingConnection.MAXRING_LITE_B);
			maxring_lite_b_in = maxring_lite_b_links.getStreamFromRemoteFPGA();
			maxring_lite_b_out = maxring_lite_b_links.getStreamToRemoteFPGA();
		}

		if (m_iolinks.containsValue(IODestination.DRAM_BLOCKED_3D) ||
			m_iolinks.containsValue(IODestination.DRAM_STRIDE_2D) ||
			m_iolinks.containsValue(IODestination.DRAM_LINEAR_1D))
		{
			DFELink load_dram = manager_design.addStreamFromCPU("cpu_to_dram");
			DFELink save_dram = manager_design.addStreamToCPU("dram_to_cpu");
			manager_design.addStreamToOnCardMemory("write_dram",  MemoryAccessPattern.LINEAR_1D).connect(load_dram);
			save_dram.connect( manager_design.addStreamFromOnCardMemory("read_dram",  MemoryAccessPattern.LINEAR_1D) );

			EngineInterface load_interface = new EngineInterface("writeDRAM");
			InterfaceParam  nbytes    = load_interface.addParam("nbytes", CPUTypes.INT);
			InterfaceParam  address    = load_interface.addParam("address", CPUTypes.INT);
			load_interface.setStream("cpu_to_dram", CPUTypes.VOID, nbytes);
			load_interface.setDramLinear("write_dram", address, nbytes);
			load_interface.ignoreAll(Direction.IN_OUT);
			manager_design.addInterface(load_interface);

			EngineInterface store_interface = new EngineInterface("readDRAM");
			nbytes = store_interface.addParam("nbytes", CPUTypes.INT);
			address = store_interface.addParam("address", CPUTypes.INT);
			store_interface.setStream("dram_to_cpu", CPUTypes.VOID, nbytes);
			store_interface.setDramLinear("read_dram", address, nbytes);
			store_interface.ignoreAll(Direction.IN_OUT);
			manager_design.addInterface(store_interface);
		}

		if (m_is_networking_used) {
			net_manager.network_config.setTCPEnableReceiveDecoder(Max3NetworkConnection.CH2_SFP1, false);
			net_manager.network_config.setTCPEnableReceiveDecoder(Max3NetworkConnection.CH2_SFP2, false);

			if (m_iolinks.containsValue(IODestination.ETHERNET_CH2_SFP1)) {
				eth_stream_sfp1 = net_manager.addEthernetStream("ethernet_ch2_sfp1", Max3NetworkConnection.CH2_SFP1, eth_checksum_mode);
			}

			if (m_iolinks.containsValue(IODestination.ETHERNET_CH2_SFP2)) {
				eth_stream_sfp2 = net_manager.addEthernetStream("ethernet_ch2_sfp2", Max3NetworkConnection.CH2_SFP2, eth_checksum_mode);
			}

			if (m_iolinks.containsValue(IODestination.UDP_ONE_TO_ONE_CH2_SFP1)) {
				udp_stream_sfp1 = net_manager.addUDPStream(
					"udp_ch2_sfp1",
					Max3NetworkConnection.CH2_SFP1,
					com.maxeler.networking.v1.managers.netlib.UDPConnectionMode.OneToOne,
					udp_checksum_mode,
					udp_header_mode);
			}
			else if (m_iolinks.containsValue(IODestination.UDP_ONE_TO_MANY_CH2_SFP1)) {
				udp_stream_sfp1 = net_manager.addUDPStream(
					"udp_ch2_sfp1",
					Max3NetworkConnection.CH2_SFP1,
					com.maxeler.networking.v1.managers.netlib.UDPConnectionMode.OneToMany,
					udp_checksum_mode,
					udp_header_mode);
			}

			if (m_iolinks.containsValue(IODestination.UDP_ONE_TO_ONE_CH2_SFP2)) {
				udp_stream_sfp2 = net_manager.addUDPStream(
					"udp_ch2_sfp2",
					Max3NetworkConnection.CH2_SFP2,
					com.maxeler.networking.v1.managers.netlib.UDPConnectionMode.OneToOne,
					udp_checksum_mode,
					udp_header_mode);
			}
			else if (m_iolinks.containsValue(IODestination.UDP_ONE_TO_MANY_CH2_SFP2)) {
				udp_stream_sfp2 = net_manager.addUDPStream(
					"udp_ch2_sfp2",
					Max3NetworkConnection.CH2_SFP2,
					com.maxeler.networking.v1.managers.netlib.UDPConnectionMode.OneToMany,
					udp_checksum_mode,
					udp_header_mode);
			}

			if (m_iolinks.containsValue(IODestination.TCP_CH2_SFP1)) {
				tcp_stream_sfp1 = net_manager.addTCPStream("tcp_ch2_sfp1", Max3NetworkConnection.CH2_SFP1);
			}

			if (m_iolinks.containsValue(IODestination.TCP_CH2_SFP2)) {
				tcp_stream_sfp2 = net_manager.addTCPStream("tcp_ch2_sfp2", Max3NetworkConnection.CH2_SFP2);
			}
		}

		boolean got_maxring_lite = false;
		boolean got_lite_a_to_b  = false;
		boolean got_lite_b_to_a  = false;

		// Connect kernel inputs
		for (String iname : kernel.getAllInputs()) {
			DFELink dest = kernel.getInput(iname);
			DFELink src = null;
			switch (m_iolinks.get(iname)) {
				case PCIE:
				case CPU:
					src = manager_design.addStreamFromCPU(iname);
					break;
				case DRAM_STRIDE_2D:
					src = manager_design.addStreamFromOnCardMemory(iname, MemoryAccessPattern.STRIDE_2D);
					break;
				case DRAM_BLOCKED_3D:
					src = manager_design.addStreamFromOnCardMemory(iname, MemoryAccessPattern.BLOCKING_3D);
					break;
				case DRAM_LINEAR_1D:
					src = manager_design.addStreamFromOnCardMemory(iname, MemoryAccessPattern.LINEAR_1D);
					break;
				case IFPGA:
					src = ifpga_in;
					break;
				case MAXRING_A:
					src = maxring_a_in;
					break;
				case MAXRING_B:
					src = maxring_b_in;
					break;
				case MAXRING_LITE_A:
					src = maxring_lite_a_in;
					got_maxring_lite = true;
					got_lite_b_to_a  = true;
					break;
				case MAXRING_LITE_B:
					src = maxring_lite_b_in;
					got_maxring_lite = true;
					got_lite_a_to_b  = true;
					break;
				case ETHERNET_CH2_SFP1:
					src = eth_stream_sfp1.getReceiveStream();
					break;
				case ETHERNET_CH2_SFP2:
					src = eth_stream_sfp2.getReceiveStream();
					break;
				case UDP_ONE_TO_ONE_CH2_SFP1:
				case UDP_ONE_TO_MANY_CH2_SFP1:
					src = udp_stream_sfp1.getReceiveStream();
					break;
				case UDP_ONE_TO_ONE_CH2_SFP2:
				case UDP_ONE_TO_MANY_CH2_SFP2:
					src = udp_stream_sfp2.getReceiveStream();
					break;
				case TCP_CH2_SFP1:
					src = tcp_stream_sfp1.getReceiveStream();
					break;
				case TCP_CH2_SFP2:
					src = tcp_stream_sfp2.getReceiveStream();
					break;
				default:
					throw new MaxCompilerInternalError(this, "Unknown link type");
			}
			dest.connect(src);
		}

		// Connect kernel outputs
		for (String oname : kernel.getAllOutputs()) {
			DFELink src = kernel.getOutput(oname);
			DFELink dest = null;
			switch (m_iolinks.get(oname)) {
				case PCIE:
				case CPU:
					dest = manager_design.addStreamToCPU(oname);
					break;
				case DRAM_STRIDE_2D:
					dest = manager_design.addStreamToOnCardMemory(oname, MemoryAccessPattern.STRIDE_2D);
					break;
				case DRAM_BLOCKED_3D:
					dest = manager_design.addStreamToOnCardMemory(oname, MemoryAccessPattern.BLOCKING_3D);
					break;
				case DRAM_LINEAR_1D:
					dest = manager_design.addStreamToOnCardMemory(oname, MemoryAccessPattern.LINEAR_1D);
					break;
				case IFPGA:
					dest = ifpga_out;
					break;
				case MAXRING_A:
					dest = maxring_a_out;
					break;
				case MAXRING_B:
					dest = maxring_b_out;
					break;
				case MAXRING_LITE_A:
					dest = maxring_lite_a_out;
					got_maxring_lite = true;
					got_lite_a_to_b  = true;
					break;
				case MAXRING_LITE_B:
					dest = maxring_lite_b_out;
					got_maxring_lite = true;
					got_lite_b_to_a  = true;
					break;
				case ETHERNET_CH2_SFP1:
					dest = eth_stream_sfp1.getTransmitStream();
					break;
				case ETHERNET_CH2_SFP2:
					dest = eth_stream_sfp2.getTransmitStream();
					break;
				case UDP_ONE_TO_ONE_CH2_SFP1:
				case UDP_ONE_TO_MANY_CH2_SFP1:
					dest = udp_stream_sfp1.getTransmitStream();
					break;
				case UDP_ONE_TO_ONE_CH2_SFP2:
				case UDP_ONE_TO_MANY_CH2_SFP2:
					dest = udp_stream_sfp2.getTransmitStream();
					break;
				case TCP_CH2_SFP1:
					dest = tcp_stream_sfp1.getTransmitStream();
					break;
				case TCP_CH2_SFP2:
					dest = tcp_stream_sfp2.getTransmitStream();
					break;
				default:
					throw new MaxCompilerInternalError(this, "Unknown link type");
			}
			dest.connect(src);
		}

		if (got_maxring_lite) {
			if (!got_lite_a_to_b) maxring_lite_a_out.connect( maxring_lite_b_in );
			if (!got_lite_b_to_a) maxring_lite_b_out.connect( maxring_lite_a_in );
		}

		manager_design.config.setDefaultStreamClockFrequency(m_clock_frequency);

		manager_design.build();
	}

	private LinkedList<WrapperNode> processGraph(WrapperDesignData design,LinkedList<WrapperNode> sorted_nodes, WrapperGraphPassGlobal graph_modifier) {
		m_build_manager.logInfo("Running manager compiler graph-pass: " + graph_modifier.getClass().getSimpleName());
		graph_modifier.processNodes(sorted_nodes, design);
		return sorted_nodes;
	}

	private void makeNoIOManager() {
		// Implementation
		MaxFileManager mf = MaxFileManager.getMaxFileManager(m_build_manager);
		mf.addMaxFileConstant(false, "NUM_IFPGA_LINKS", 0);
		mf.addMaxFileConstant(false, "APP_ID", m_app_id);
		mf.addMaxFileConstant(false, "REV_ID", m_rev_id);
		mf.addMaxFileConstant(false, "CHAIN_LENGTH", 0);
		mf.addMaxFileConstant(false, "CARD_ID", 0);

		EntityStructural e = _Kernel.buildPhotonSBA(m_kernel);
		e = new EntityTiedIO(m_build_manager, e, "clk");
		((EntityTiedIO)e).setCustomSignature("max_compiler_top");


		// Write mxg graph - needs to be done after buildPhotonSBA
		LinkedList<WrapperNode> nodes = new LinkedList<WrapperNode>();
		WrapperDesignData design = new WrapperDesignData(m_build_manager,
			"Manager_" + getName(), 0, 0, true, false);
		nodes.add(new WrapperNodePhoton(design, _Kernel.getPhotonDesignData(m_kernel)));
		processGraph(design, nodes, new GenerateMXGInfo(GenerateMXGInfo.CompilationPhase.Original, design, true));


		XilinxPlatform platform = XilinxPlatform.get(m_build_manager);

		platform.addConstraint(new XilinxConstraint(
				XilinxConstraintObject.NET, "clk",
				XilinxConstraintType.TNM_NET, "streamclk"), e);

		platform.addConstraint(new XilinxConstraint(XilinxConstraintObject.TIMESPEC,
			"TS_STREAMCLK",
			XilinxConstraintType.PERIOD, "streamclk", (1000.0/m_clock_frequency) + " ns HIGH 50 % PRIORITY 0"),
			e);

		platform.addConstraint(new XilinxConstraint(
			XilinxConstraintObject.NET, "reg_clk",
			XilinxConstraintType.TNM_NET, "registerclk"), e);

		platform.addConstraint(new XilinxConstraint(XilinxConstraintObject.TIMESPEC,
			"TS_REGISTERCLK",
			XilinxConstraintType.PERIOD, "registerclk", (1000.0/50) + " ns HIGH 50 % PRIORITY 0"),
			e);

		// Avoid running genmaxfile
		if (getBuildConfig().getBuildLevel() == BuildConfig.Level.FULL_BUILD)
			_BuildConfig.setEnableGenMaxFile(getBuildConfig(), false);

		processGraph(design, nodes, new GenerateMXGInfo(GenerateMXGInfo.CompilationPhase.Final, design, true));
		_Managers.runBuild(this, e);
	}

	/**
	 * Add an engine interface to the manager.
	 * The name must be distinct from any interface already added to the manager.
	 * @param engine_interface the engine interface to add
	 */
	@Deprecated
	public void addInterface(EngineInterface engine_interface)
	{
		createSLiCinterface(engine_interface);
	}

	/**
	 * Create a simple default SLiC interface.
	 * This will assume all input/output streams have the same type and are of the same length.
	 */
	public void createSLiCinterface() {
		if (!m_ioset)
			throw new MaxCompilerAPIError(this, "You must set IOs before creating a simple SLiC interface");
		if (m_iotype!=IOType.ALL_CPU)
			throw new MaxCompilerAPIError(this, "You can only create a simple SLiC interface when all kernel I/Os are connected to CPU.");
		if (m_kernel==null)
			throw new MaxCompilerAPIError(this,"You can only create a simple SLiC interface once you have added a kernel to the manager");
		if (m_engineInterfaces.containsKey("default"))
			throw new MaxCompilerAPIError(this, "You can not create a simple default SLiC interface because you have already created your own default interface.");

		// Create the simple interface
		EngineInterface m = new EngineInterface();
		InterfaceParam n = m.addParam("N", CPUTypes.INT32, "Number of data items to process");
		m.setTicks(m_kernel.getName(), n);

		Map<String, KernelType<?>> inputs = m_kernel.io.getInputs();
		Map<String, KernelType<?>> outputs = m_kernel.io.getOutputs();

		addTypedStreams(m, n, inputs);
		addTypedStreams(m, n, outputs);

		// Now add the created interface to the manager
		createSLiCinterface(m);
	}

	private class StreamInfo {
		final CPUTypes type;
		final int multiple;
		StreamInfo(CPUTypes t) {
			type = t;
			multiple = 1;
		}
		StreamInfo(CPUTypes t, int m) {
			type = t;
			multiple = m;
		}
	}

	/** Recursive function to work out how to describe a Kernel stream as a CPU type and length multiple */
	private StreamInfo getStreamInfo(KernelType<?> type) {
		if (type instanceof DFEFloat) {
			DFEFloat t = (DFEFloat) type;
			int mantissa = t.getMantissaBits();
			int exponent = t.getExponentBits();
			if (mantissa == 24 & exponent == 8) {
				return new StreamInfo(CPUTypes.FLOAT);
			} else if (mantissa == 53 & exponent == 11) {
				return new StreamInfo(CPUTypes.DOUBLE);
			}
		} else if (type instanceof DFERawBits) {
			DFERawBits t = (DFERawBits) type;
			int bits = t.getTotalBits();
			if (bits % 8 == 0) {
				return new StreamInfo(CPUTypes.VOID);
			}
		} else if (type instanceof DFEFix) {
			DFEFix t = (DFEFix) type;

			if (t.isInt()) {
				switch(t.getTotalBits()) {
					case 8:
						return new StreamInfo(CPUTypes.INT8);
					case 16:
						return new StreamInfo(CPUTypes.INT16);
					case 32:
						return new StreamInfo(CPUTypes.INT32);
					case 64:
						return new StreamInfo(CPUTypes.INT64);
				}

			} else if (t.isUInt()) {
				switch(t.getTotalBits()) {
					case 8:
						return new StreamInfo(CPUTypes.UINT8);
					case 16:
						return new StreamInfo(CPUTypes.UINT16);
					case 32:
						return new StreamInfo(CPUTypes.UINT32);
					case 64:
						return new StreamInfo(CPUTypes.UINT64);
				}
			}
		} else if (type instanceof DFEComplexType) { // Special handling for Complex types
			DFEComplexType t = (DFEComplexType) type;
			KernelType<?> rType = t.getRealType();
			KernelType<?> iType = t.getImaginaryType();
			if (!rType.equals(iType))
				return null;
			StreamInfo s = getStreamInfo(rType);
			if (s==null)
				return null;
			return new StreamInfo(s.type, s.multiple*2);
		} else if (type instanceof DFEArrayType) { // Special handling for Array types
			DFEArrayType<?> t = (DFEArrayType<?>) type;
			KernelType<?> cType = t.getContainedType();
			int size = t.getSize();

			StreamInfo s = getStreamInfo(cType);
			if (s==null)
				return null;

			return new StreamInfo(s.type, s.multiple*size);
		}

		return null; // Failed to find a match
	}

	/** Helper function for create simple SLiC interface. Infer CPU types for streams from kernel types */
	private void addTypedStreams(EngineInterface m, InterfaceParam n, Map<String, KernelType<?>> streams) {
		for (Map.Entry<String, KernelType<?>> entry : streams.entrySet()) {
			String name = entry.getKey();
			KernelType<?> type = entry.getValue();

			StreamInfo s = getStreamInfo(type);
			if (s==null)
				throw new MaxCompilerAPIError(this,
					"Kernel input/output stream '%s' of type '%s' cannot be used in a simple " +
					"SLiC interface as it cannot be directly mapped onto a CPU type. " +
					"Please create a custom interface or use a different input type.", name, type);

			// Now set the stream properties
			InterfaceParam nParam = n;
			if (s.multiple==1) nParam = nParam * s.type.sizeInBytes();
			else nParam = nParam * s.multiple * s.type.sizeInBytes();
			m.setStream(name, s.type, nParam);
		}
	}

	/**
	 * Add a SLiC interface for this maxfile.
	 * The interface name must be distinct from any mode already added to the manager.
	 * @param engineInterface the engine interface to add
	 */
	public void createSLiCinterface(EngineInterface engineInterface) {
		String interfaceName = engineInterface.getName();
		if( m_engineInterfaces.containsKey(interfaceName) )
			throw new MaxCompilerAPIError(this, "The engine interface '" + interfaceName +"' is already present");
		if (interfaceName.equals("default") && m_omit_default_interface)
			throw new MaxCompilerAPIError(this, "The default engine interface has already been suppressed.");
		m_engineInterfaces.put(interfaceName, engineInterface);
	}

	/**
	 * Suppress the "default" interface.
	 */
	public void suppressDefaultInterface()
	{
		if (m_engineInterfaces.containsKey("default"))
			throw new MaxCompilerAPIError(this, "The default interface is already present.");
		m_omit_default_interface = true;
	}

	/**
	 * Burst length of the memory controller. This method will return 384 bytes for a MAX3 based
	 * design and 96 bytes for a MAX2 based one.
	 * @return Length of a memory (DRAM) burst in bytes.
	 */
	public int getBurstSize() {
		/* The standard manager will always use the default memory controller configuration
		 * because the user is not able to set a custom one. So the burst length will be
		 *  96 bytes on max2 cards and
		 * 384 bytes on max3 cards (Burst Size == 8, Max2CompatMode == off).
		 * */
		int bsize = 8;
		return _Managers.getBuildManager(this).getPlatform() instanceof MAX3ComputeFPGA ? (bsize==8 ? 384 : 192) :96;
	}
}
