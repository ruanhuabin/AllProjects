package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

public enum ArbitrationMode {
	ROUND_ROBIN (0),
	DYNAMIC (1);

	final int m_vhdl_value;

	private ArbitrationMode(int vhdl_value) {
		m_vhdl_value = vhdl_value;
	}
}