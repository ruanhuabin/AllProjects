package com.maxeler.maxcompiler.v2.kernelcompiler.types;

import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

public abstract class FullType<
	DoubtTypeT extends DoubtType,
	KernelTypeT extends KernelType<InstanceT>,
	InstanceT>
{
	private final DoubtTypeT m_doubt_type;
	private final KernelTypeT m_kernel_type;

	protected FullType(DoubtTypeT doubt_type, KernelTypeT kernel_type) {
		m_doubt_type = doubt_type;
		m_kernel_type = kernel_type;
	}

	public DoubtTypeT getDoubtType() {
		return m_doubt_type;
	}

	public KernelTypeT getKernelType() {
		return m_kernel_type;
	}

	public int getTotalBits() {
		return m_doubt_type.getTotalBits() + m_kernel_type.getTotalBits();
	}

	public InstanceT newInstance(KernelLib design) {
		return m_kernel_type.newInstance(design, m_doubt_type);
	}

	public InstanceT unpack(DFEVar src) {
		return m_kernel_type.unpackWithDoubt(src, m_doubt_type);
	}
}
