package com.maxeler.doclet;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.sun.javadoc.AnnotationDesc;
import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.Doc;
import com.sun.javadoc.Doclet;
import com.sun.javadoc.ProgramElementDoc;
import com.sun.javadoc.Tag;

/**
 * Utilities for Doclet classes.
 */
public class Utils {
	/** Documentation tags that affect visibility. */
	public enum Tags {
		/** Exclude this element from documentation. */
		EXCLUDE("@exclude"),
		/** This element has been deprecated (but is still visible in documentation). */
		DEPRECATED("@deprecated");

		/** Name of the tag, as it appears in documentation. */
		public final String tag;

		private Tags(String tag) { this.tag = tag; }
	}

	/** Map from tag name to enums. */
	private static final Map<String, Tags> tagMap = new HashMap<String, Tags>();
	static {
		for (Tags t : Tags.values())
			tagMap.put(t.tag, t);
	}

	/** Annotations that affect visibility. */
	public enum Annotations {
		/** Hide element from MaxIDE autocompletion. */
		MAXCOMPILER_HIDE(com.maxeler.utils.MaxCompilerHide.class.getName());

		/** Qualified name of the annotation, as it appears in code. */
		public final String annotation;

		private Annotations(String annotation) { this.annotation = annotation; }
	}

	/** Map from annotation name to enums. */
	private static final Map<String, Annotations> annotationsMap = new HashMap<String, Annotations>();
	static {
		for (Annotations a : Annotations.values())
			annotationsMap.put(a.annotation, a);
	}

	public interface CommandLineOption {
		String optionName();
	}

	/** Visibility of a Java API. */
	public enum Visibility {
		/** Is visible externally and published. */
		PUBLISHED,
		/** Is visible externally but deprecated. */
		DEPRECATED,
		/** Is visible externally but explicitly not published. */
		HIDDEN,
		/** Is not visible externally. */
		INTERNAL
	}

	/**
	 * Determine the visibility of a particular class.
	 */
	public static Visibility getVisibility(ClassDoc c) {
		if (c.isPublic()) {
			final Set<Tags> classTags = getTags(c);
			final Set<Annotations> classAnnotations = getAnnotations(c);

			if (classTags.contains(Tags.EXCLUDE))
				return Visibility.HIDDEN;
			if (classAnnotations.contains(Annotations.MAXCOMPILER_HIDE))
				return Visibility.HIDDEN;

			// inner classes have type names of the form 'OuterClass.InnerClass'
			final String[] nameComponents = c.typeName().split("\\.");
			final String outerClass = nameComponents[0];
			final String innerClass = nameComponents[nameComponents.length - 1];

			if (outerClass.startsWith("_") || innerClass.startsWith("_"))
				return Visibility.HIDDEN;

			return classTags.contains(Tags.DEPRECATED) ? Visibility.DEPRECATED : Visibility.PUBLISHED;
		}

		return Visibility.INTERNAL;
	}

	/**
	 * Determine the visibility of a class member.
	 */
	public static Visibility getVisibility(ProgramElementDoc e) {
		if (e.isPublic() || e.isProtected()) {
			final Set<Tags> memberTags = getTags(e);
			final Set<Annotations> memberAnnotations = getAnnotations(e);

			if (memberTags.contains(Tags.EXCLUDE))
				return Visibility.HIDDEN;
			if (memberAnnotations.contains(Annotations.MAXCOMPILER_HIDE))
				return Visibility.HIDDEN;

			return memberTags.contains(Tags.DEPRECATED) ? Visibility.DEPRECATED : Visibility.PUBLISHED;
		}

		return Visibility.INTERNAL;
	}

	/** Get all the tags used by a document element. */
	public static Set<Tags> getTags(Doc doc) {
		final Set<Tags> ts = EnumSet.noneOf(Tags.class);

		for (Tag tag : doc.tags()) {
			final Tags t = tagMap.get(tag.name());

			if (t != null)
				ts.add(t);
		}

		return ts;
	}

	/** Get all the annotations used by a document element. */
	public static Set<Annotations> getAnnotations(ProgramElementDoc doc) {
		final Set<Annotations> as = EnumSet.noneOf(Annotations.class);

		for (AnnotationDesc annotation : doc.annotations()) {
			Annotations a = annotationsMap.get(annotation.annotationType().qualifiedName());

			if (a != null)
				as.add(a);
		}

		return as;
	}

	/**
	 * @param option The command-line option.
	 * @param options Options supplied to the {@link Doclet}.
	 * @return The value of the command-line option.
	 */
	public static String getOption(CommandLineOption option, String[][] options) {
		for (int i = 0; i < options.length; ++i) {
			if (options[i][0].equals(option.optionName()))
				return options[i][1];
		}

		throw new RuntimeException("Command-line option '" + option.optionName() + "' not present.");
	}
}
