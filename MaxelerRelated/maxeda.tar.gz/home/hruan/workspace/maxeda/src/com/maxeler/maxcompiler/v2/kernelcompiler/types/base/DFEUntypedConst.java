package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;

// This is final because extending it really does not work in an obvious way.
// Facaded HWTypes are created at outputs from the compiler losing any
// extra meta-data/type-information you may be trying to add.
/**
 * {@code DFEUntypedConst} objects allow constant values to be passed around
 * without being restricted to a particular type.
 * <p>
 * {@link DFEVar} streams can contain data of Kernel type {@code DFEUntypedConst}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public final class DFEUntypedConst extends DFEType {
	DFEUntypedConst(com.maxeler.photon.types.HWType imp) {
		super(imp);
		if (!(imp instanceof com.maxeler.photon.types.HWUntypedConst))
			throw new MaxCompilerInternalError("Not DFEUntypedConst instance.");
	}

	/**
	 * Returns the name of the type: {@code dfeUntypedConst()}.
	 */
	@Override
	public String toString() {
		return "dfeUntypedConst()";
	}

	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return equals(other_type);
	}

	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		if(!equals(other_type))
			throw new MaxCompilerAPIError("Cannot do " + this + ".unionWithMaxOfMaxes(" + other_type + ")");

		return this;
	}
}
