package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;

public class _Constant extends Constant {

	public _Constant(Kernel design) {
		super(design);
	}

}
