package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import java.util.LinkedList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControlGroup.MemoryAccessPattern;
import com.maxeler.maxeleros.ip.Ethernet.Max2NetworkConnection;
import com.maxeler.maxeleros.ip.Ethernet.NetworkConnection;
import com.maxeler.maxeleros.ip.Ethernet.V5EthernetPlugin;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.maxeleros.managercompiler.libs.InterFPGAFactory;
import com.maxeler.maxeleros.managercompiler.libs.MemoryControllerDefinition.VirtualDIMM;
import com.maxeler.maxeleros.managercompiler.libs.MemoryControllerDefinition.VirtualDIMM.MemoryCommandDefinition;
import com.maxeler.maxeleros.managercompiler.libs.MemoryIOFactory;
import com.maxeler.maxeleros.managercompiler.libs.NetworkIOFactory;
import com.maxeler.maxeleros.managercompiler.libs.NetworkInterfacePlugin;
import com.maxeler.maxeleros.managercompiler.libs.NetworkLinkSpeed;
import com.maxeler.maxeleros.managercompiler.libs.PCIeIOFactory;
import com.maxeler.maxeleros.managercompiler.libs.TimestampingIOFactory.TimestampingIOFormat;
import com.maxeler.maxeleros.platforms.MAX2Board;
import com.maxeler.maxeleros.platforms.MAX2Board.MAX2InterFPGA;
import com.maxeler.maxeleros.platforms.MAX2Board.MAX2Rev;


public class _MAX2BoardIOInterface implements _BoardIOInterface {
	private final WrapperDesignData m_data;
	private final PCIeIOFactory m_pcie_io_factory;
	private final MemoryIOFactory m_memory_io_factory;
	private final InterFPGAFactory m_ifpga_factory;
	private final InterFPGAFactory m_maxring_factory;
	private final NetworkIOFactory m_network_sfps_factory;

	private final VirtualDIMM m_max2_sodimms;

	private final MAX2Board m_platform;

	private int m_maxring_width = 64, m_ifpga_width = 64;
	private static final int m_max2_max_pcie_streams = 8;	/* Not more than 8 streams per direction on MAX2 */
	private int m_num_sfh, m_num_sth;

	private final List<MemoryControlGroup> m_memory_control_groups = new LinkedList<MemoryControlGroup>();

	public _MAX2BoardIOInterface(WrapperDesignData data, MAX2Board platform, WrapperClock clock) {
		m_data = data;
		m_platform = platform;
		m_pcie_io_factory = new PCIeIOFactory(m_data, "pcie", false);
		m_memory_io_factory = new MemoryIOFactory(data, "sodimms", platform.getSODIMMS(), clock);
		m_ifpga_factory = new InterFPGAFactory(data, "ifpga", clock, true);
		m_ifpga_factory.setRemoteRegisterAccess();

		if (platform.getRev() == MAX2Rev.MAX2REVC)
			m_maxring_factory = new InterFPGAFactory(data, "maxring", clock, true);
		else
			m_maxring_factory = null;

		m_memory_io_factory.setOnCardMemoryFrequency(200);
		m_memory_io_factory.setOnCardMemory2TTiming(false);

		m_max2_sodimms = m_memory_io_factory.makeVirtualDIMM(3, "max2_sodimms");

		m_network_sfps_factory = new NetworkIOFactory(data, "sfps");
		m_num_sfh = 0;
		m_num_sth = 0;
	}

	public void setMaxRingNumLanes(MaxRingConnection connection, int num_lanes) {
		if(!(connection instanceof Max2RingConnection))
			throw new MaxCompilerAPIError(m_data, "Must use Max2RingConnection when targetting a MAX2 board");

		switch((Max2RingConnection)connection) {
			case FPGA_ON_LOCAL_CARD:
				m_ifpga_width = num_lanes * 16;
				break;

			case FPGA_ON_REMOTE_CARD:
				if (m_maxring_factory == null)
					throw new MaxCompilerAPIError(m_data, "MAX2 board model does not support MaxRing to remote cards.");
				m_maxring_width = num_lanes * 16;
				break;
		}
	}

	public void setNumberOfPCIExpressLanes(int num_lanes) {
		m_pcie_io_factory.setNumberOfPCIExpressLanes(num_lanes);
	}

	public void setEnablePCIExpressFastClock(boolean fast_clock) {
		m_pcie_io_factory.setPCIeFastClock(fast_clock);
	}

	@Override
	public MaxRingBidirectionalStream addMaxRingBirectionalStream(
		String name,
		MaxRingConnection connection)
	{
		if(!(connection instanceof Max2RingConnection))
			throw new MaxCompilerAPIError(m_data, "Must use Max2RingConnection when targetting a MAX2 board");

		InterFPGAFactory factory = null;
		switch((Max2RingConnection)connection) {
			case FPGA_ON_LOCAL_CARD:
				factory = m_ifpga_factory;
				break;
			case FPGA_ON_REMOTE_CARD:
				if (m_maxring_factory == null)
					throw new MaxCompilerAPIError(m_data,
						"MAX2 board model does not support MaxRing to remote cards.");
				factory = m_maxring_factory;
				break;
		}
		return new MaxRingBidirectionalStream(name, factory.makeInterChipStream(name));
	}

	@Override
	public DFELink addStreamFromHost(String name) {
		++m_num_sfh;
		if(m_num_sfh > m_max2_max_pcie_streams) {
			throw new MaxCompilerAPIError(m_data, "MAX2 doesn't support more than " + m_max2_max_pcie_streams + " streams from host");
		}
		return _CustomManagers.fromImp(m_pcie_io_factory.addPCIeStreamFromHost(name));
	}

	@Override
	public DFELink addStreamToHost(String name) {
		++m_num_sth;
		if(m_num_sth > m_max2_max_pcie_streams) {
			throw new MaxCompilerAPIError(m_data, "MAX2 doesn't support more than " + m_max2_max_pcie_streams + " streams to host");
		}
		return _CustomManagers.fromImp(m_pcie_io_factory.addPCIeStreamToHost(name));
	}

	private MemoryCommandDefinition getCmdDef(MemoryControlGroup controlStream, String name, boolean is_read_stream) {
		return controlStream.addDataStream(name, is_read_stream);
	}

	@Override
	public DFELink addStreamFromOnCardMemory(
		String name,
		MemoryControlGroup controlStream)
	{
		return _CustomManagers.fromImp(getCmdDef(controlStream, name, true).addStreamFromMemory(name));
	}

	@Override
	public DFELink addStreamToOnCardMemory(
		String name,
		MemoryControlGroup controlStream)
	{
		return _CustomManagers.fromImp(getCmdDef(controlStream, name, false).addStreamToMemory(name));
	}

	// debug stream
	@Override
	public DFELink getDebugStreamFromCardMemory(String name) {
		return _CustomManagers.fromImp(m_max2_sodimms.getMemoryDebugStream(name));
	}

	@Override
	public MemoryControlGroup addMemoryControlGroup(
		String name,
		DFELink controlStream)
	{
		MemoryControlGroup grp = new MemoryControlGroup(name, controlStream, m_max2_sodimms);
		m_memory_control_groups.add(grp);
		return grp;
	}

	@Override
	public MemoryControlGroup addMemoryControlGroup(
		String name,
		MemoryAccessPattern pattern)
	{
		MemoryControlGroup grp = new MemoryControlGroup(m_data, name, pattern, m_max2_sodimms);
		m_memory_control_groups.add(grp);
		return grp;
	}

	@Override
	public void finalise() {
		m_ifpga_factory.setBoardResource(m_platform.getIFPGA(MAX2InterFPGA.INTERFPGA_LINK1, m_ifpga_width));
		if (m_maxring_factory != null)
			m_maxring_factory.setBoardResource(m_platform.getIFPGA(MAX2InterFPGA.INTERFPGA_MAXRING, m_maxring_width));
		m_pcie_io_factory.setBoardResource(m_platform.getPCIExpress(m_pcie_io_factory.getNumberOfPCIExpressLanes()));
		if (m_network_sfps_factory.getNetworkInterfacePlugin() != null)
			m_network_sfps_factory.setBoardResource(m_platform.getNetwork(Max2NetworkConnection.CH1_SFPS, m_network_sfps_factory.getNetworkInterfacePlugin()));

		for (MemoryControlGroup grp : m_memory_control_groups) {
			grp.finalise();
		}
	}

	@Override
	public DFELink addStreamFromNetwork(int port, String name) {
		return addStreamFromNetwork(Max2NetworkConnection.CH1_SFPS, port, name);
	}

	@Override
	public DFELink addStreamToNetwork(int port, String name) {
		return addStreamToNetwork(Max2NetworkConnection.CH1_SFPS, port, name);
	}

	@Override
	public void setNetworkInterfacePlugin(NetworkInterfacePlugin plugin) {
		setNetworkInterfacePlugin(Max2NetworkConnection.CH1_SFPS, plugin);
	}

	@Override
	public WrapperClock getNetworkInterfaceClock(int port) {
		return getNetworkInterfaceClock(Max2NetworkConnection.CH1_SFPS, port);
	}

	@Override
	public DFELink addStreamFromNetwork(NetworkConnection connection, int port, String name) {
		if(!(connection instanceof Max2NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max2NetworkConnection when targetting a MAX2 board");

		switch((Max2NetworkConnection)connection) {
			case CH1_SFPS:
				if (m_network_sfps_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_sfps_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_sfps_factory.getStreamFromNetwork(port, name));
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max2NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public DFELink addStreamToNetwork(NetworkConnection connection, int port, String name) {
		if(!(connection instanceof Max2NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max2NetworkConnection when targetting a MAX2 board");

		switch((Max2NetworkConnection)connection) {
			case CH1_SFPS:
				if (m_network_sfps_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_sfps_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_sfps_factory.getStreamToNetwork(port, name));
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max2NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public void setNetworkInterfacePlugin(NetworkConnection connection, NetworkInterfacePlugin plugin) {
		if(!(connection instanceof Max2NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max2NetworkConnection when targetting a MAX2 board");

		switch((Max2NetworkConnection)connection) {
			case CH1_SFPS:
				if(!(plugin instanceof V5EthernetPlugin))
					throw new MaxCompilerAPIError(m_data,
						"Plugin specified for network connection " + connection.toString() + " not supported");
				else
					m_network_sfps_factory.setNetworkInterfacePlugin(connection, plugin); break;
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max2NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public WrapperClock getNetworkInterfaceClock(NetworkConnection connection, int port) {
		if(!(connection instanceof Max2NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max2NetworkConnection when targetting a MAX2 board");

		switch((Max2NetworkConnection)connection) {
			case CH1_SFPS:
				return m_network_sfps_factory.getNetworkInterfaceClock(port);
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max2NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public void setMemoryControllerConfig(MemoryControllerConfig config) {
		m_max2_sodimms.setDDRAddressBitSwapEntity(config.getDDRAddressBitSwap());
	}

	@Override
	public void setOnCardMemoryFrequency(double freq_mhz) {
		if (freq_mhz < 150 || freq_mhz > 300)
			throw new MaxCompilerAPIError(m_data, "MAX2 memory clock frequency must be >= 150 and <= 300 MHz");
		m_memory_io_factory.setOnCardMemoryFrequency(freq_mhz);
		m_memory_io_factory.setOnCardMemory2TTiming(freq_mhz > 200);
	}

	@Override
	public WrapperClock getMemoryCoreClock() {
		return m_memory_io_factory.getMemoryCoreClock();
	}

	@Override
	public double getOnCardMemoryFrequency() {
		return m_memory_io_factory.getOnCardMemoryFrequency();
	}

	@Override
	public void setEnableHideParityBitsForStream(
		DFELink stream,
		boolean hide_parity_bits)
	{
		m_max2_sodimms.setMemoryStreamHideParityBits(_CustomManagers.streamToImp(stream), hide_parity_bits);
	}

	@Override
	public void setIFPGALinkClock(WrapperClock clock) {
		throw new MaxCompilerAPIError(m_data, "This feature is not implemented on MAX2");
	}

	@Override
	public void setMemoryStreamClock(WrapperClock clock) {
		throw new MaxCompilerAPIError(m_data, "This feature is not implemented on MAX2");
	}

	@Override
	public NetworkInterfacePlugin getDefaultEthernetPlugin(NetworkLinkSpeed link_speed, boolean bypass_fifo) {
		if (bypass_fifo)
			throw new MaxCompilerAPIError(m_data, "Cannot bypass FIFO on 1Gig Ethernet.");

		switch(link_speed)
		{
			case OneGig:
				return new V5EthernetPlugin();

			default:
				throw new MaxCompilerAPIError(m_data, "Only 1Gig Ethernet is supported on MAX2.");
		}
	}

	@Override
	public boolean hasNetworkConnectionGotPlugin(NetworkConnection connection) {
		return m_network_sfps_factory.getNetworkInterfacePlugin() != null;
	}

	@Override
	public void setHostStreamClock(WrapperClock clock) {
		throw new MaxCompilerAPIError(m_data,
			"Setting the host stream clock explicitly is not supported on MAX2. " +
			"See CustomManager.config.setPCIeFastClock() to use the faster PCIe clock on MAX2.");
	}

	@Override
	public DFELink addTimestampStream(String name,
		 WrapperClock clock,
		 TimestampingIOFormat format,
		 int decimal_precision) {
		throw new MaxCompilerAPIError(m_data,
			"Timestamp stream is not supported on MAX2.");
	}
}
