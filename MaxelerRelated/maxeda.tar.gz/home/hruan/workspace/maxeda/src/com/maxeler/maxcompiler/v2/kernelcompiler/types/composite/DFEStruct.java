package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._AlreadyConnectedException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizableNull;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types._InternalUtils;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

/**
 * A stream of {@code DFEStructType} data.
 * <p>
 * <b>Note</b>: The operators == and != are not overloaded in MaxCompiler and therefore are interpreted as standard Java == and !=.
 * These test the equality of <em>references</em>.
 * For {@code DFEStruct}
 * streams, the equality of the individual component streams must be tested using the methods {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar#eq(DFEVar) DFEVar.eq(DFEVar)} and {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar#neq(DFEVar) DFEVar.neq(DFEVar)}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFEStruct extends KernelObjectVectorizableNull<DFEStruct> {
	private final LinkedHashMap<String, KernelObjectNotVector<?>> m_field_instances;
	private final DFEStructType m_type;
	private final DFEStructDoubtType m_doubt_type;

	DFEStruct(
		DFEStructType type,
		LinkedHashMap<String, KernelObjectNotVector<?>> field_instances,
		DFEStructDoubtType doubt_type)
	{
		if(field_instances.size() < 1)
			throw new MaxCompilerAPIError(getKernel().getManager(), "Cannot have a Struct with no fields.");

		for(Map.Entry<String, KernelObjectNotVector<?>> entry : field_instances.entrySet()) {
			String field_name = entry.getKey();
			DoubtType expected_doubt_type = doubt_type.getFieldDoubtTypes().get(field_name);
			DoubtType field_doubt_type = entry.getValue().getDoubtType();
			if(!field_doubt_type.equals(expected_doubt_type))
				throw new MaxCompilerAPIError(getKernel().getManager(),
					"Doubt-type of field " + entry.getKey() + " used to construct " +
					"DFEStruct object has doubt-type " + field_doubt_type +
					"does not match expected doubt-type of " + expected_doubt_type);
		}

		m_field_instances = field_instances;
		m_type = type;
		m_doubt_type = doubt_type;
	}

	@Override
	public DFEStructType getType() {
		return m_type;
	}

	@Override
	public DFEVar pack() {
		if(getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use pack() on this stream as it contains doubt " +
				"information. If you want to explicitly discard this information " +
				"use packWithoutDoubt(), otherwise use packWithDoubt().");

		return packWithoutDoubt();
	}

	/**
	 * Gets the field with the given name.
	 * <p>
	 * This can be accessed using the overloaded {@code []} operator for {@code DFEStruct} that takes the name of the field as a {@code String} and returns
	 * the appropriate data from the structure.
	 * @param field_name The name of the field to access.
	 * @return The field stream.
	 */
	@SuppressWarnings("unchecked")
	public <T extends KernelObjectNotVector<?>>
		T get(String field_name)
	{
		KernelObjectNotVector<?> inst = m_field_instances.get(field_name);
		if(inst == null)
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"This DFEStruct does not have a field named '" + field_name + "'");

		return (T)inst;
	}

	// TODO: I cannot figure out how to get this to type in a sensible way...
	/**
	 * Connects the input of a field in the structure to the output of stream {@code src}.
	 * @param field_name The name of the field to connect.
	 * @param src The input stream to which to connect {@code field_name}.
	 * @return The unmodified input stream {@code src}.
	 */
	@SuppressWarnings("unchecked")
	public <T> T set(String field_name, T src) {
		if (field_name == null)
			throw MaxCompilerAPIError.nullParam("field_name");
		if (src == null)
			throw MaxCompilerAPIError.nullParam("src");

		final KernelObject<T> target = (KernelObject<T>) m_field_instances.get(field_name);
		if (target == null) {
			throw new MaxCompilerAPIError(
				getKernel().getManager(),
				"This DFEStruct does not have a field named '%s'.",
				field_name
			);
		}

		_InternalUtils.assertConnectTypesField(field_name, target, (KernelObject<?>) src);

		try {
			return target.connect(src);
		} catch (_AlreadyConnectedException e) {
			throw new _AlreadyConnectedException(this, field_name, e);
		}
	}

	public <T> void put(String field_name, T src) {
		set(field_name, src);
	}

	/**
	 * Returns a new stream cast to the specified {@code DFEStructType} from this stream.
	 * @param type The {@code DFEStructType} to which to cast.
	 * @return A new stream of this stream cast to {@code type}
	 */
	public DFEStruct cast(DFEStructType type) {
		DFEStruct ret = type.newInstance(getKernel());

		for(String key : m_field_instances.keySet()) {
			KernelObjectNotVector<?> field = get(key);
			ret.set(key, field.cast(ret.getType().getTypeForField(key)));
		}

		return ret;
	}

	@Override
	public DFEStruct connect(DFEStruct rhs) {
		_InternalUtils.assertConnectTypes(this, rhs);

		for(String key : m_field_instances.keySet())
			set(key, rhs.get(key));

		return this;
	}

	@Override
	public DFEStruct dfeWatch(String name) {
		for(Map.Entry<String, KernelObjectNotVector<?>> field : m_field_instances.entrySet())
			field.getValue().dfeWatch(name + "_" + field.getKey());

		return this;
	}


	@Override
	public DFEStruct watch(String name) {
		for(Map.Entry<String, KernelObjectNotVector<?>> field : m_field_instances.entrySet())
			field.getValue().watch(name + "_" + field.getKey());

		return this;
	}

	@Override
	public Kernel getKernel() {
		return m_field_instances.values().iterator().next().getKernel();
	}

	@Override
	public KernelObject<?> cast(KernelType<?> type) {
		if(type instanceof DFEStructType)
			return cast((DFEStructType)type);

		throw new MaxCompilerAPIError(getKernel().getManager(), "Cannot cast from " + getType() + " to " + type);
	}

	@Override
	public void setReportOnUnused(boolean v) {
		for(KernelObject<?> field : m_field_instances.values())
			field.setReportOnUnused(v);
	}

	@Override
	public List<DFEVar> packToList() {
		if(!getType().isConcreteType())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot pack DFEStruct as type " + getType() + " is not concrete.");

		List<DFEVar> var_list = new ArrayList<DFEVar>();
		for(KernelObjectNotVector<?> inst : m_field_instances.values())
			var_list.addAll(inst.packToList());

		return var_list;
	}

	@Override
	public DFEStruct castDoubtType(DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEStructDoubtType))
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Can only doubt-type cast DFEStruct using DFEStructDoubtType object.");

		LinkedHashMap<String, KernelObjectNotVector<?>> new_field_instances =
			new LinkedHashMap<String, KernelObjectNotVector<?>>();

		Map<String, DoubtType> kstruct_doubt_type =
			((DFEStructDoubtType)doubt_type).getFieldDoubtTypes();

		for(Map.Entry<String, KernelObjectNotVector<?>> entry : m_field_instances.entrySet()) {
			String field_name = entry.getKey();
			KernelObjectNotVector<?> casted_entry =
				(KernelObjectNotVector<?>)entry.getValue().castDoubtType(kstruct_doubt_type.get(field_name));

			new_field_instances.put(field_name, casted_entry);
		}

		return new DFEStruct(m_type, new_field_instances, (DFEStructDoubtType)doubt_type);
	}

	@Override
	public DFEStructDoubtType getDoubtType() {
		return m_doubt_type;
	}

	@Override
	public DFEVar packWithDoubt() {
		if(!getType().isConcreteType())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot pack DFEStruct as type " + getType() + " is not concrete.");

		DFEVar packed_var = null;
		for(KernelObjectNotVector<?> inst : m_field_instances.values()) {
			DFEVar packed_inst = inst.packWithDoubt();
			if(packed_var == null)
				packed_var = packed_inst;
			else
				packed_var = packed_inst.cat(packed_var);
		}

		return packed_var;
	}

	@Override
	public DFEVar packWithoutDoubt() {
		if(!getType().isConcreteType())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot pack DFEStruct as type " + getType() + " is not concrete.");

		DFEVar packed_var = null;
		for(KernelObjectNotVector<?> inst : m_field_instances.values()) {
			DFEVar packed_inst = inst.packWithoutDoubt();
			if(packed_var == null)
				packed_var = packed_inst;
			else
				packed_var = packed_inst.cat(packed_var);
		}

		return packed_var;
	}

	@Override
	public DFEVar hasDoubt() {
		DFEVar doubt = getKernel().constant.var(false);

		for(KernelObjectNotVector<?> inst : m_field_instances.values())
			doubt = doubt | inst.hasDoubt();

		return doubt;
	}

	@Override
	public DFEStruct setDoubt(DFEVar doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEStruct setDoubt(boolean doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEStruct setDoubt(DFEVar doubt, SetDoubtOperation operation) {
		if (!getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use setDoubt on this stream as it doesn't contain doubt information.");

		LinkedHashMap<String, KernelObjectNotVector<?>> new_field_instances =
			new LinkedHashMap<String, KernelObjectNotVector<?>>();

		for(Map.Entry<String, KernelObjectNotVector<?>> entry : m_field_instances.entrySet()) {
			String field_name = entry.getKey();
			KernelObjectNotVector<?> new_entry =
				(KernelObjectNotVector<?>)entry.getValue().setDoubt(doubt, operation);

			new_field_instances.put(field_name, new_entry);
		}

		return new DFEStruct(m_type, new_field_instances, m_doubt_type);
	}

	@Override
	public DFEStruct setDoubt(boolean doubt, SetDoubtOperation operation) {
		return setDoubt(getKernel().constant.var(doubt), operation);
	}

	Map<String, KernelObjectNotVector<?>> getFields() {return m_field_instances;}
}
