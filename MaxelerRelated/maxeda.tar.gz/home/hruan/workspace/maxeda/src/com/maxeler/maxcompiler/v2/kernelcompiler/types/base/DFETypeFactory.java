package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import static com.maxeler.utils.EnumTranslator.convert;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxdc.xilinx.coregen.CGFloatingPoint_base;
import com.maxeler.photon.types.HWOffsetFix;
import com.maxeler.utils.numeric.BigFloat;

/**
 * The class {@code DFETypeFactory} contains static methods for generating types derived from {@link DFEType}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFETypeFactory {

	/**
	 * Creates an {@link DFEFloat} type.
	 * @param exponent_bits The number of bits for the exponent.
	 * @param mantissa_bits The number of bits for the mantissa.
	 * @return The new type object.
	 */
	public static DFEFloat dfeFloat(int exponent_bits, int mantissa_bits) {

		String invalidType = CGFloatingPoint_base.checkExponentMantissa(exponent_bits, mantissa_bits);
		if (invalidType != null)
			throw new MaxCompilerAPIError("Invalid type for dfeFloat("+exponent_bits + ", "+ mantissa_bits+") - " + invalidType);

		return new DFEFloat(com.maxeler.photon.types.HWTypeFactory.hwFloat(
			exponent_bits, mantissa_bits));
	}

	/**
	 * Creates an {@link DFEFix} type.
	 * <p>
	 * @param integer_bits The number of bits before the binary point.
	 * @param fraction_bits The number of bits after the binary point.
	 * @param sign_mode Sets either two's complement or unsigned mode.
	 * @return The new type object.
	 */
	public static DFEFix dfeFix(
		int integer_bits,
		int fraction_bits,
		DFEFix.SignMode sign_mode)
	{
		HWOffsetFix f = com.maxeler.photon.types.HWTypeFactory.hwOffsetFix(
			integer_bits + fraction_bits,
			-fraction_bits,
			convert(sign_mode, HWOffsetFix.SignMode.class));

		return new DFEFix(f);
	}

	/**
	 * Creates an {@link DFEFix} type capable of representing the supplied maximum value to
	 * the precision of the specified number of bits.
	 * <p>
	 * The number of bits ({@code num_bits}) must be greater than 0.
	 * <p>
	 * In unsigned mode, a {@code num_bits} value of 1 is valid. In two's complement mode, {@code num_bits} must be greater than 1.
	 * <p>
	 * The maximum value ({@code max}) cannot be 0 in either unsigned or two's complement mode.
	 * <p>
	 * In unsigned mode, {@code max} must be greater than 0. In two's complement mode, {@code max} can be less than 0.
	 * @param num_bits The total number of bits in the fixed-point word.
	 * @param max The maximum value that the type will be able to hold.
	 * @param sign_mode Sets either two's complement or unsigned mode.
	 * @return The new type object.
	 */
	public static DFEFix dfeOffsetFix(int num_bits, double max, DFEFix.SignMode sign_mode) {
		if (num_bits <= 0)
			throw new MaxCompilerAPIError("number of bits must be greater than 0, not " + num_bits);
		if (max == 0)
			throw new MaxCompilerAPIError("maximum cannot be 0");
		if (sign_mode == SignMode.TWOSCOMPLEMENT && num_bits == 1)
			throw new MaxCompilerAPIError("must specify more than 1 bit for two's complement sign mode");
		if (sign_mode == SignMode.UNSIGNED && max < 0)
			throw new MaxCompilerAPIError("maximum value must be greater than 0 for an unsigned type (not " + max + ")");

		HWOffsetFix f = com.maxeler.photon.types.HWTypeFactory.hwOffsetFix(
			num_bits,
			max,
			convert(sign_mode, HWOffsetFix.SignMode.class));

		return new DFEFix(f);
	}

	public static DFEFix dfeOffsetFix(int num_bits, long max, DFEFix.SignMode sign_mode) {
		return DFETypeFactory.dfeOffsetFix(num_bits, (double)max, sign_mode);
	}

	public static DFEFix dfeFixMax(int num_bits, double max, SignMode sign_mode) {
		return _DFETypeFactory.dfeFixMax(num_bits, new BigFloat(max), sign_mode);
	}

	public static DFEFix dfeFixMax(int num_bits, long max, SignMode sign_mode) {
		return _DFETypeFactory.dfeFixMax(num_bits, new BigFloat(max), sign_mode);
	}

	/**
	 * Creates an {@link DFEFix} type with an explicit offset.
	 * <p>
	 * The number of bits ({@code num_bits}) must be greater than 0.
	 * <p>
	 * In unsigned mode, a {@code num_bits} value of 1 is valid. In two's complement mode, {@code num_bits} must be greater than 1.
	 * @param num_bits The total number of bits in the fixed-point word.
	 * @param offset The offset of the binary point.
	 * @param sign_mode Sets either two's complement or unsigned mode.
	 * @return The new type object.
	 */
	public static DFEFix dfeOffsetFix(
		int num_bits,
		int offset,
		DFEFix.SignMode sign_mode)
	{
		HWOffsetFix f = com.maxeler.photon.types.HWTypeFactory.hwOffsetFix(
			num_bits,
			offset,
			convert(sign_mode, HWOffsetFix.SignMode.class));

		return new DFEFix(f);
	}

	/**
	 * Creates an {@link DFERawBits} type.
	 * @param num_bits The total number of bits.
	 * @return The new type object.
	 */
	public static DFERawBits dfeRawBits(int num_bits) {
		return new DFERawBits(com.maxeler.photon.types.HWTypeFactory.hwRawBits(num_bits));
	}

	/**
	 * This is an alias for {@code dfeFix(num_bits, 0, SignMode.UNSIGNED)}
	 * @param num_bits The total number of bits.
	 * @return The new type object.
	 */
	public static DFEFix dfeUInt(int num_bits) {
		return new DFEFix(com.maxeler.photon.types.HWTypeFactory.hwUInt(num_bits));
	}

	/**
	 * This is an alias for {@code dfeFix(num_bits, 0, SignMode.TWOSCOMPLEMENT)}
	 * @param num_bits The total number of bits.
	 * @return The new type object.
	 */
	public static DFEFix dfeInt(int num_bits) {
		return new DFEFix(com.maxeler.photon.types.HWTypeFactory.hwInt(num_bits));
	}

	/**
	 * This is an alias for {@code dfeFix(1, 0, SignMode.UNSIGNED)}
	 * @return The new type object.
	 */
	public static DFEFix dfeBool() {
		return new DFEFix(com.maxeler.photon.types.HWTypeFactory.hwBool());
	}

	/**
	 * Creates an {@link DFEUntypedConst} type.
	 * @return The new type object.
	 */
	public static DFEUntypedConst dfeUntypedConst() {
		return new DFEUntypedConst(com.maxeler.photon.types.HWTypeFactory.hwUntypedConst());
	}


	private static final DFEDoubtType s_hw_doubtable_false =
		new DFEDoubtType(false);

	private static final DFEDoubtType s_hw_doubtable_true =
		new DFEDoubtType(true);

	public static DFEDoubtType dfeDoubtType(boolean with_doubt_info) {
		return
			with_doubt_info ?
				s_hw_doubtable_true :
				s_hw_doubtable_false;
	}
}
