package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._DFEsmShifter;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;

public class _Bitops {
	private _Bitops() { }

	public static Bitops create(StateMachineLib owner) { return new Bitops(owner); }

	public static List<_DFEsmShifter> getShifters(Bitops bitops) { return bitops.getShifters(); }

	public static _DFEsmShifter shiftLeft(Bitops bitops, DFEsmValueType dataType, DFEsmValueType shiftType) {
		return bitops.shiftLeft(dataType, shiftType);
	}

	public static _DFEsmShifter shiftRight(Bitops bitops, DFEsmValueType dataType, DFEsmValueType shiftType) {
		return bitops.shiftRight(dataType, shiftType);
	}

	public static _DFEsmShifter rotateLeft(Bitops bitops, DFEsmValueType dataType, DFEsmValueType rotateType) {
		return bitops.rotateLeft(dataType, rotateType);
	}

	public static _DFEsmShifter rotateRight(Bitops bitops, DFEsmValueType dataType, DFEsmValueType rotateType) {
		return bitops.rotateRight(dataType, rotateType);
	}
}
