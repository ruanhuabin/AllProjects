package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.FullType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;

public class DFEArrayFullType<ContainedT extends KernelObjectNotVector<ContainedT>>
	extends
	FullType<DFEArrayDoubtType, DFEArrayType<ContainedT>, DFEArray<ContainedT>>
{
	public DFEArrayFullType(
		DFEArrayDoubtType doubt_type,
		DFEArrayType<ContainedT> kernel_type)
	{
		super(doubt_type, kernel_type);
	}
}
