package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject.SetDoubtOperation;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.maxcompiler.v2.utils._Utils;
import com.maxeler.photon.core.Var;
import com.maxeler.photon.libs.MemoryFactory;
import com.maxeler.photon.libs.MemoryFactory.DualPortRAMOutputs;
import com.maxeler.photon.libs.MemoryFactory.RAMPortMode;
import com.maxeler.photon.libs.MemoryFactory.RAMPortParams;
import com.maxeler.utils.EnumTranslator;

/**
 * Contains all the methods and classes for creating and accessing
 * ROMs and RAMs.
 * <p>
 * There are single- and dual-port ROMs and RAMs available. Mapped ROMs and RAMs can have their contents set dynamically by CPU code.
 * <p>
 * See the
 * <a href="{@docRoot}/../maxcompiler-tutorial.pdf#destination.romsandrams">MaxCompiler Tutorial</a> for more
 * details on using ROMs and RAMs.
 * <p>
 * There are {@link DFEVector multipipe} versions of single-port ROMs
 * available (dual-port multipipe ROMs are unnecessary). Multipipe versions of RAMs
 * are not available.
 */
public class Mem {
	private static final String m_replicated_rom_name = "replicated_dp_mem_";
	private final com.maxeler.photon.libs.MemoryFactory m_imp;
	private final Kernel m_design;

	/**
	 * Specifies the input and output streams of individual RAM ports on.
	 */
	public enum RamPortMode {
		/** Will have a data ouput stream but no write enable or data input streams*/
		READ_ONLY,
		/** Will have write enable and data input streams, but no data output stream*/
		WRITE_ONLY,
		/** Will have data output, data input and write enable streams*/
		READ_WRITE
	}

	/**
	 * Specifies the behavior when data is read from and written to the same location in the RAM in the same cycle.
	 */
	public enum RamWriteMode {
		/** The existing contents of the memory location will be read before being written over*/
		READ_FIRST,
		/** The new value will propagate directly to the output in the same cycle as being written*/
		WRITE_FIRST
	}

	public enum RamDoubtMode {
		STORE_DOUBT,
		GLOBAL_DOUBT_ONLY
	}


	/**
	 * Parameters for an individual port on a RAM.
	 */
	public static class RamPortParams<T extends KernelObjectNotVector<T>> {
		private final com.maxeler.photon.libs.MemoryFactory.RAMPortParams m_imp;
		private final KernelType<T> m_data_type;
		private DoubtType m_doubt_type;
		private T m_data;

		private RamPortParams(com.maxeler.photon.libs.MemoryFactory.RAMPortParams imp, KernelType<T> data_type) {
			if (imp == null)
				throw new MaxCompilerInternalError("Parameter 'imp' must not be null.");
			if (data_type == null)
				throw new MaxCompilerInternalError("Parameter 'data_type' must not be null.");
			m_imp = imp;
			m_data_type = data_type;
			m_doubt_type = data_type.getFullTypeWithoutDoubtInfo().getDoubtType();
		}

		private RamPortParams<T> copy(com.maxeler.photon.libs.MemoryFactory.RAMPortParams imp) {
			if (imp == null)
				throw new MaxCompilerInternalError("Parameter 'imp' must not be null.");

			RamPortParams<T> new_inst = new RamPortParams<T>(imp, m_data_type);
			new_inst.m_data = m_data;
			new_inst.m_doubt_type = m_doubt_type;

			return new_inst;
		}

		/**
		 * Sets the input write enable signal stream for an individual port on a RAM.
		 *
		 * @param write_enable The incoming stream of Boolean values, where true will enable the RAM to write the current input data
		 * value at the current address to the RAM.
		 */
		public RamPortParams<T> withWriteEnable(DFEVar write_enable) {
			if (write_enable == null)
				throw new MaxCompilerAPIError("Parameter 'write_enable' must not be null.");
			if (!write_enable.getType().isBool())
				throw new MaxCompilerAPIError(write_enable.getKernel().getManager(), "Write enable must have boolean type, not %s.", write_enable.getType());

			return copy(m_imp.withWriteEnable(_KernelBaseTypes.toImp(write_enable)));
		}

		/**
		 * Sets the data input stream for an individual port on a RAM.
		 *
		 * @param data The incoming data stream that will be written to the RAM.
		 */
		public RamPortParams<T> withDataIn(T data) {
			if (data == null)
				throw new MaxCompilerAPIError("Parameter 'data' must not be null.");
			if (!data.getType().equals(m_data_type))
				throw new MaxCompilerAPIError(data.getKernel().getManager(), "Data input has type %s, which is different from RAM type %s.", data.getType(), m_data_type);

			// Doubt adjustment and packing is done in the actual
			// ram/ramDualPort methods.

			RamPortParams<T> new_inst = copy(m_imp);

			new_inst.m_data = data;
			new_inst.m_doubt_type = data.getDoubtType();
			return new_inst;
		}

		@Override
		public String toString() {
			return m_data_type.toString();
		}
	}

	/**
	 * Contains the two output data streams for a dual-port ROM or RAM.
	 */
	public class DualPortMemOutputs<T extends KernelObjectNotVector<T>> {
		private final T m_a;
		private final T m_b;

		private DualPortMemOutputs(
			KernelType<T> type,
			DoubtType doubt_type,
			RamDoubtMode doubt_mode,
			com.maxeler.photon.libs.MemoryFactory.DualPortRAMOutputs imp)
		{
			m_a = imp.isOutputAReadable() ?
				getCorrectlyTypedDataOutput(
					imp.getOutputA(),
					type,
					getVarType(type),
					doubt_type,
					doubt_mode) :
				null;

			m_b = imp.isOutputBReadable() ?
				getCorrectlyTypedDataOutput(
					imp.getOutputB(),
					type,
					getVarType(type),
					doubt_type,
					doubt_mode)	:
				null;
		}

		private DualPortMemOutputs(
			KernelType<T> type,
			com.maxeler.photon.libs.MemoryFactory.DualPortROMOutputs imp)
		{
			m_a = getCorrectlyTypedDataOutput(
				imp.getOutputA(),
				type,
				getVarType(type),
				type.getFullTypeWithoutDoubtInfo().getDoubtType(),
				null);
			m_b = getCorrectlyTypedDataOutput(
				imp.getOutputB(),
				type,
				getVarType(type),
				type.getFullTypeWithoutDoubtInfo().getDoubtType(),
				null);
		}

		/**
		 * Gets output Stream A from the ROM or RAM.
		 * <p>
		 * Will throw an exception if the port is in {@link RamPortMode#WRITE_ONLY WRITE_ONLY} mode.
		 *
		 * @return Output stream A.
		 */
		public T getOutputA() {
			if(m_a == null)
				throw new MaxCompilerAPIError(m_design.getManager(), "Output A of dual-port RAM is not readable.");

			return m_a;
		}

		/**
		 * Gets output Stream B from the ROM or RAM.
		 * <p>
		 * Will throw an exception if the port is in {@link RamPortMode#WRITE_ONLY WRITE_ONLY} mode.
		 *
		 * @return Output stream B.
		 */
		public T getOutputB() {
			if(m_b == null)
				throw new MaxCompilerAPIError(m_design.getManager(), "Output B of dual-port RAM is not readable.");

			return m_b;
		}
	}

	Mem(Kernel design) {
		m_imp = new com.maxeler.photon.libs.MemoryFactory(_Kernel.getPhotonDesignData(design));
		m_design = design;
	}

	private <T extends KernelObjectNotVector<T>>
	RAMPortParams packPortData(
		char port,
		DoubtType overall_doubt_type,
		RamDoubtMode doubt_mode,
		RamPortParams<T> port_params)
	{
		RAMPortParams port_params_adjusted =
			port_params.m_imp;

		if(port_params.m_imp.getPortMode() != RAMPortMode.READ_ONLY) {
			if(port_params.m_data == null)
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Port " + port + " is writeable but has no write source set.");

			T data = port_params.m_data;

			if(doubt_mode == RamDoubtMode.STORE_DOUBT) {
				if (!port_params.m_doubt_type.equals(overall_doubt_type))
					data = data.castDoubtType(overall_doubt_type);

				if (data instanceof DFEVar && !overall_doubt_type.hasDoubtInfo()) {
					port_params_adjusted =
						port_params_adjusted.withDataIn(_KernelBaseTypes.toImp((DFEVar)data));
				}
				else {
					port_params_adjusted =
						port_params_adjusted.withDataIn(_KernelBaseTypes.toImp(data.packWithDoubt()));
				}
			}
			else if(doubt_mode == RamDoubtMode.GLOBAL_DOUBT_ONLY) {
				if (!(data instanceof DFEVar) && data.getDoubtType().hasDoubtInfo()) {
					DFEVar global_doubt = data.hasDoubt();
					data = data.removeDoubtInfo();

					port_params_adjusted =
						port_params_adjusted.withDataIn(_KernelBaseTypes.toImp(
							data.packWithoutDoubt().addDoubtInfo().setDoubt(global_doubt)));
				}
				else {
					if ((data instanceof DFEVar)) {
						port_params_adjusted =
							port_params_adjusted.withDataIn(_KernelBaseTypes.toImp((DFEVar)data));
					}
					else {
						port_params_adjusted =
							port_params_adjusted.withDataIn(_KernelBaseTypes.toImp(data.packWithDoubt()));
					}
				}
			}
			else {
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Unimplemented RAM doubt mode '" + doubt_mode + "'.");
			}
		}

		return port_params_adjusted;
	}

	private <T extends KernelObjectNotVector<T>>
	RAMPortParams packMappedRamPortData(
		char port,
		DoubtType overall_doubt_type,
		RamDoubtMode doubt_mode,
		RamPortParams<T> port_params)
	{
		RAMPortParams port_params_adjusted =
			port_params.m_imp;

			T data = port_params.m_data;

			if(doubt_mode == RamDoubtMode.STORE_DOUBT) {
				if (!port_params.m_doubt_type.equals(overall_doubt_type))
					data = data.castDoubtType(overall_doubt_type);

				if (data instanceof DFEVar && !overall_doubt_type.hasDoubtInfo()) {
					port_params_adjusted =
						port_params_adjusted.withDataIn(_KernelBaseTypes.toImp((DFEVar)data));
				}
				else {
					port_params_adjusted =
						port_params_adjusted.withDataIn(_KernelBaseTypes.toImp(data.packWithDoubt()));
				}
			}
			else if(doubt_mode == RamDoubtMode.GLOBAL_DOUBT_ONLY) {
				if (!(data instanceof DFEVar) && data.getDoubtType().hasDoubtInfo()) {
					DFEVar global_doubt = data.hasDoubt();
					data = data.removeDoubtInfo();

					port_params_adjusted =
						port_params_adjusted.withDataIn(_KernelBaseTypes.toImp(
							data.packWithoutDoubt().addDoubtInfo().setDoubt(global_doubt)));
				}
				else {
					if ((data instanceof DFEVar)) {
						port_params_adjusted =
							port_params_adjusted.withDataIn(_KernelBaseTypes.toImp((DFEVar)data));
					}
					else {
						port_params_adjusted =
							port_params_adjusted.withDataIn(_KernelBaseTypes.toImp(data.packWithDoubt()));
					}
				}
			}
			else {
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Unimplemented RAM doubt mode '" + doubt_mode + "'.");
			}

		return port_params_adjusted;
	}



	/**
	 * Creates a dual-port RAM of <code>size</code> elements.
	 * <p>
	 * Each port is configured separately through a {@link RamPortParams} object to determine its
	 * read/write nature and therefore its input and output streams.
	 * <p>
	 * The data types of the two ports set in <code>port_a_params</code> and <code>port_b_params</code> must match.
	 * @param size The size of the RAM in elements.
	 * @param write_mode The {@link RamWriteMode} setting for the whole RAM.
	 * @param port_a_params {@link RamPortParams} object containing settings for port A.
	 * @param port_b_params {@link RamPortParams} object containing settings for port B.
	 * @return {@link DualPortMemOutputs} object containing the two output streams from the RAM.
	 */
	public <T extends KernelObjectNotVector<T>>
	DualPortMemOutputs<T> ramDualPort(
		int size,
		RamWriteMode write_mode,
		RamPortParams<T> port_a_params,
		RamPortParams<T> port_b_params)
	{
		return ramDualPort(size, write_mode, RamDoubtMode.STORE_DOUBT, port_a_params, port_b_params);
	}

	public <T extends KernelObjectNotVector<T>>
	DualPortMemOutputs<T> ramDualPort(
		int size,
		RamWriteMode write_mode,
		RamDoubtMode doubt_mode,
		RamPortParams<T> port_a_params,
		RamPortParams<T> port_b_params)
	{
		if (size <= 0)
			throw new MaxCompilerAPIError(m_design.getManager(), "RAM size must be greater than 0, not %d.", size);
		if (write_mode == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'write_mode' must not be null.");
		if (doubt_mode == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'doubt_mode' must not be null.");
		if (port_a_params == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'port_a_params' must not be null.");
		if (port_b_params == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'port_b_params' must not be null.");
		if (!port_a_params.m_data_type.equals(port_b_params.m_data_type))
			throw new MaxCompilerAPIError(m_design.getManager(), "Type of data input for port A (%s) is different from type for port B (%s).", port_a_params.m_data_type, port_b_params.m_data_type);

		DoubtType overall_doubt_type =
			port_a_params.m_doubt_type.union(port_b_params.m_doubt_type);

		RAMPortParams port_a_params_adjusted =
			packPortData('A', overall_doubt_type, doubt_mode, port_a_params);

		RAMPortParams port_b_params_adjusted =
			packPortData('B', overall_doubt_type, doubt_mode, port_b_params);

		DualPortRAMOutputs x = m_imp.dualPortRAM(
			size,
			EnumTranslator.convert(write_mode, com.maxeler.photon.libs.MemoryFactory.RAMWriteMode.class),
			EnumTranslator.convert(doubt_mode, com.maxeler.photon.hw.doubt_bit.DoubtBitWrapperRam.RamDoubtMode.class),
			port_a_params_adjusted,
			port_b_params_adjusted
		);

		return new DualPortMemOutputs<T>(
			port_a_params.m_data_type,
			overall_doubt_type,
			doubt_mode,
			x);
	}

	/**
	 * Creates a single-port RAM of <code>size</code> elements.
	 *
	 * @param size The size of the RAM in elements.
	 * @param write_mode The {@link RamWriteMode} setting for the whole RAM.
	 * @param port_params {@link RamPortParams} object containing settings for port A.
	 * @return The output stream from the RAM.
	 */
	public <T extends KernelObjectNotVector<T>>
	T ram(int size, RamWriteMode write_mode, RamPortParams<T> port_params) {
		return ram(size, write_mode, RamDoubtMode.STORE_DOUBT, port_params);
	}

	public <T extends KernelObjectNotVector<T>>
	T ram(int size, RamWriteMode write_mode, RamDoubtMode doubt_mode, RamPortParams<T> port_params) {
		if (size <= 0)
			throw new MaxCompilerAPIError(m_design.getManager(), "RAM size must be greater than 0, not %d.", size);
		if (write_mode == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'write_mode' must not be null.");
		if (doubt_mode == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'doubt_mode' must not be null.");
		if (port_params == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'port_params' must not be null.");
		if (port_params.m_data_type == null)
			throw new MaxCompilerInternalError(m_design.getManager(), "RAM port has no defined data type (was dataIn set?).");

		RAMPortParams adjusted_port_params=
			packPortData('A', port_params.m_doubt_type, doubt_mode, port_params);

		Var output =
			m_imp.singlePortRAM(
				size,
				EnumTranslator.convert(write_mode, com.maxeler.photon.libs.MemoryFactory.RAMWriteMode.class),
				EnumTranslator.convert(doubt_mode, com.maxeler.photon.hw.doubt_bit.DoubtBitWrapperRam.RamDoubtMode.class),
				adjusted_port_params);

		return getCorrectlyTypedDataOutput(
			output,
			port_params.m_data_type,
			getVarType(port_params.m_data_type),
			port_params.m_doubt_type,
			doubt_mode);
	}

	public <T extends KernelObjectNotVector<T>>
	T ramMapped(String name, int size, RamWriteMode write_mode, RamPortParams<T> port_params) {
		return ramMapped(name, size, write_mode, RamDoubtMode.STORE_DOUBT, port_params);
	}

	public <T extends KernelObjectNotVector<T>>
	T ramMapped(String name, int size, RamWriteMode write_mode, RamDoubtMode doubt_mode, RamPortParams<T> port_params) {
		checkMappedROMWidth(port_params.m_data_type);
		if (port_params.m_imp.getPortMode() == RAMPortMode.READ_ONLY) {
			port_params =
					port_params.withDataIn(m_design.constant.zero(port_params.m_data_type))
					.withWriteEnable(m_design.constant.var(false));
		}

		RAMPortParams params = packMappedRamPortData('A', port_params.m_doubt_type, RamDoubtMode.GLOBAL_DOUBT_ONLY, port_params);

		Var output = m_imp.mappedRAM(name, size,
			EnumTranslator.convert(write_mode, com.maxeler.photon.libs.MemoryFactory.RAMWriteMode.class),
			params);

		return getCorrectlyTypedDataOutput(
			output,
			port_params.m_data_type,
			getVarType(port_params.m_data_type),
			port_params.m_doubt_type,
			doubt_mode);
	}


	public <T extends KernelObjectNotVector<T>>
	DualPortMemOutputs<T> ramMappedDualPort(
		String name,
		int size,
		RamWriteMode write_mode,
		RamPortParams<T> port_a_params,
		RamPortParams<T> port_b_params)
	{
		return ramMappedDualPort(name, size, write_mode, RamDoubtMode.STORE_DOUBT, port_a_params, port_b_params);
	}

	public <T extends KernelObjectNotVector<T>>
	DualPortMemOutputs<T> ramMappedDualPort(
		String name,
		int size,
		RamWriteMode write_mode,
		RamDoubtMode doubt_mode,
		RamPortParams<T> portA_params,
		RamPortParams<T> portB_params)
	{

		checkMappedROMWidth(portA_params.m_data_type);

		if (portA_params.m_imp.getPortMode() == RAMPortMode.READ_ONLY) {
			portA_params =
				portA_params.withDataIn(m_design.constant.zero(portA_params.m_data_type))
				.withWriteEnable(m_design.constant.var(false));
		}

		if (portB_params.m_imp.getPortMode() == RAMPortMode.READ_ONLY) {
			portB_params =
				portB_params.withDataIn(m_design.constant.zero(portB_params.m_data_type))
				.withWriteEnable(m_design.constant.var(false));
		}

		RAMPortParams paramsA = packMappedRamPortData('A', portA_params.m_doubt_type, doubt_mode, portA_params);
		RAMPortParams paramsB = packMappedRamPortData('B', portB_params.m_doubt_type, doubt_mode, portB_params);

		DualPortRAMOutputs outputs = m_imp.mappedRAMDualPort(name, size,
			EnumTranslator.convert(write_mode, com.maxeler.photon.libs.MemoryFactory.RAMWriteMode.class),
			paramsA, paramsB);

		return new DualPortMemOutputs<T>(
			portA_params.m_data_type,
			portA_params.m_doubt_type,
			doubt_mode,
			outputs);
	}

	/**
	 * Creates a {@link RamPortParams} object for a RAM.
	 * <p>
	 * This version takes an input data stream as an argument, so should be used for a writeable port. See
	 * {@link #makeRamPortParams(RamPortMode, DFEVar, KernelType)} for a version which
	 * does not specify an input stream.
	 *
	 * @param mode {@link RamPortMode} specifying read/write configuration for the port.
	 * @param address The input address stream.
	 * @param data_in The input data stream, from which the type of the contents of the RAM will be inferred.
	 * @return {@link RamPortParams} object containing the settings for the port.
	 */
	public <T extends KernelObjectNotVector<T>>
	RamPortParams<T> makeRamPortParams(RamPortMode mode, DFEVar address, T data_in) {
		if (mode == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'mode' must not be null.");
		if (address == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'address' must not be null.");
		if (data_in == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'data_in' must not be null.");

		return new RamPortParams<T>(
			m_imp.makeRAMPortParams(
				EnumTranslator.convert(mode, com.maxeler.photon.libs.MemoryFactory.RAMPortMode.class),
				_KernelBaseTypes.toImp(address)
			),
			data_in.getType()
		).withDataIn(data_in);
	}

	/**
	 * Creates a {@link RamPortParams} object for a RAM.
	 * <p>
	 * This version takes a data type to specify the type of the contents of the RAM. See
	 * {@link #makeRamPortParams(RamPortMode, DFEVar, KernelObjectNotVector)} for a version which
	 * specifies an input data stream for a writable port.
	 *
	 * @param mode {@link RamPortMode} specifying read/write configuration for the port.
	 * @param address The input address stream.
	 * @param type The type of the contents of the RAM.
	 * @return {@link RamPortParams} object containing the settings for the port.
	 */
	public <T extends KernelObjectNotVector<T>, KernelTypeT extends KernelType<T>>
	RamPortParams<T> makeRamPortParams(RamPortMode mode, DFEVar address, KernelType<T> type) {
		if (mode == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'mode' must not be null.");
		if (address == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'address' must not be null.");
		if (type == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Parameter 'type' must not be null.");

		return new RamPortParams<T>(
			m_imp.makeRAMPortParams(
				EnumTranslator.convert(mode, com.maxeler.photon.libs.MemoryFactory.RAMPortMode.class),
				_KernelBaseTypes.toImp(address)
			),
			type
		);
	}

	/**
	 * Creates a single-port ROM of {@link DFEVar}s.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * <p>
	 * See {@link #rom(DFEVector, DFEType, double...)}
	 * for a {@link DFEVector multipipe} version.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return The output stream from the ROM.
	 */
	public DFEVar rom(DFEVar address, DFEType type, double... contents) {
		Var output = m_imp.rom(
			_KernelBaseTypes.toImp(address),
			_KernelBaseTypes.toImp(type),
			contents);

		return _KernelBaseTypes.fromImp(m_design, output);
	}

	/**
	 * Creates a single-port ROM of {@link KernelObjectNotVector KernelObject}s.
	 * <p>
	 * This version of <code>rom</code> allows the use of objects of classes such as {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray},
	 * {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex} and {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct}.
	 * <p>
	 * See {@link #rom(DFEVector, KernelTypeVectorizable, Bits...)}
	 * for a {@link DFEVector multipipe} version.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return The output stream from the ROM.
	 */
	public <T extends KernelObjectNotVector<T>> T rom(DFEVar address, KernelType<T> type, Bits... contents) {
		DFEType var_type = getVarType(type);

		Var output = m_imp.rom(
			_KernelBaseTypes.toImp(address),
			_KernelBaseTypes.toImp(var_type),
			_Utils.toImp(contents));

		return getCorrectlyTypedDataOutput(
			output,
			type,
			var_type,
			type.getFullTypeWithoutDoubtInfo().getDoubtType(),
			null);
	}

	/**
	 * Creates a multipipe ROM of {@link DFEVar}s.
	 * <p>
	 * MaxCompiler will create the required number of ROMs with identical contents and a unique address and output data
	 * stream for each pipe.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return The output stream from the ROM.
	 */
	public DFEVector<DFEVar> rom(DFEVector<DFEVar> address, DFEType type, double... contents) {
		Bits[] bits_data = new Bits[contents.length];

		for(int i = 0; i < contents.length; i++)
			bits_data[i] = type.encodeConstant(contents[i]);

		return rom(address, type, bits_data);
	}

	/**
	 * Creates a multipipe ROM of {@link KernelObjectVectorizable KernelObject}s.
	 * <p>
	 * MaxCompiler will create the required number of ROMs with identical contents and a unique address and output data
	 * stream for each pipe.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return The output stream from the ROM.
	 */
	public <T extends KernelObjectVectorizable<T>>
	DFEVector<T> rom(DFEVector<DFEVar> address, KernelTypeVectorizable<T> type, Bits... contents) {
		DFEVector<T> res = new DFEVectorType<T>(type, address.getNElements()).newInstance(m_design);

		for(int i = 0; i < address.getNElements() / 2; i++) {
			DualPortMemOutputs<T> dro =
				romDualPort(address.getElement(i*2), address.getElement(i*2 + 1), type, contents);
			res.connect(i*2, dro.getOutputA());
			res.connect(i*2 +  1, dro.getOutputB());
		}

		if(address.getNElements() % 2 != 0) {
			int i = address.getNElements() - 1;

			res.connect(i, rom(address.getElement(i), type, contents));
		}

		return res;
	}

	/**
	 * Creates a multipipe ROM of {@link KernelObjectVectorizable KernelObject}s.
	 * <p>
	 * MaxCompiler will create the required number of ROMs with identical contents and a unique address and output data
	 * stream for each pipe.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * <p>
	 * Example usage:
	 * <p>
	 * <code>
	 * DFEVectorType&lt;DFEVar&gt; romType = new DFEVectorType&lt;DFEVar&gt;(dfeFloat(8, 24), 4);<br>
	 * DFEVector&lt;DFEVar&gt; address = control.count.simpleCounterMP(4, 3, 8);<br>
	 * DFEVector&lt;DFEVar&gt; data = mem.rom(address, romType, 1, 2, 3, 4, 5, 6, 7, 8);<br>
	 * </code>
	 * <p>
	 * Note that this version takes {@code double} values for the contents of the ROM, so is only suitable for pipes
	 * of {@code DFEVar}s.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return The output stream from the ROM.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		A extends DFEVectorBase<DFEVar, A, ?, ?>
	>
	M rom(A address, T type, double... contents) {
		KernelTypeVectorizable<P> pipe_type = type.getContainedType();
		Bits[] bits_data = new Bits[contents.length];
		for (int i = 0; i < bits_data.length; ++i)
			bits_data[i] = pipe_type.encodeConstant(contents[i]);

		return rom(address, type, bits_data);
	}

	/**
	 * Creates a multipipe ROM of {@link KernelObjectVectorizable KernelObject}s.
	 * <p>
	 * MaxCompiler will create the required number of ROMs with identical contents and a unique address and output data
	 * stream for each pipe.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return The output stream from the ROM.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		A extends DFEVectorBase<DFEVar, A, ?, ?>
	>
	M rom(A address, T type, Bits... contents) {
		List<P> new_pipes = new ArrayList<P>(address.getNElements());

		for(int i = 0; i < address.getNElements() / 2; i++) {
			int j = i * 2;
			int k = j + 1;
			DualPortMemOutputs<P> out = romDualPort(
				address.getElement(j),
				address.getElement(k),
				type.getContainedType(),
				contents
			);

			new_pipes.add(out.getOutputA());
			new_pipes.add(out.getOutputB());
		}

		if(address.getNElements() % 2 != 0) {
			int i = address.getNElements() - 1;

			new_pipes.add(rom(address.getElement(i), type.getContainedType(), contents));
		}

		return type.newInstance(m_design, new_pipes);
	}

	@SuppressWarnings("unchecked")
	private <T extends KernelObjectNotVector<T>>
	T getCorrectlyTypedDataOutput(
		Var output,
		KernelType<T> real_type,
		DFEType var_type,
		DoubtType doubt_type,
		RamDoubtMode doubt_mode)
	{
		DFEVar output_dfevar = _KernelBaseTypes.fromImp(m_design, output);

		DFEVar doubt = null;

		if (output_dfevar.getDoubtType().hasDoubtInfo()) {
			doubt = output_dfevar.hasDoubt();
			output_dfevar = output_dfevar.removeDoubtInfo();
		}

		T unpacked;

		if(real_type instanceof DFEType && !doubt_type.hasDoubtInfo())
			unpacked = (T) output_dfevar;
		else if(real_type instanceof DFEType && doubt_type.hasDoubtInfo())
			unpacked = real_type.unpackWithDoubt(output_dfevar, doubt_type);
		else if(doubt_type == null || !doubt_type.hasDoubtInfo() || doubt_mode == RamDoubtMode.GLOBAL_DOUBT_ONLY)
			unpacked = real_type.unpack(output_dfevar);
		else
			unpacked = real_type.unpackWithDoubt(output_dfevar, doubt_type);

		if (doubt != null) {
			if (doubt_type == null || !doubt_type.hasDoubtInfo() || doubt_mode == RamDoubtMode.GLOBAL_DOUBT_ONLY)
				unpacked = unpacked.addDoubtInfo();

			unpacked = unpacked.setDoubt(doubt, SetDoubtOperation.OR);
		}

		return unpacked;
	}

	// Get the type which will be used for the Photon Var from V1 KernelType.
	// This should be used with getCorrectlyTypedDataOutput() above.
	private <T extends KernelObjectNotVector<T>> DFEType getVarType(KernelType<T> real_type) {
		if(real_type instanceof DFEType)
			return (DFEType)real_type;
		else
			return  DFETypeFactory.dfeRawBits(real_type.getTotalBits());
	}

	/**
	 * Creates a dual-port ROM of {@link DFEVar}s.
	 * <p>
	 * Each port has its own input address stream and output data stream looking at the same set of data.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * @param address_a The incoming address stream for port A.
	 * @param address_b The incoming address stream for port B.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return {@link DualPortMemOutputs} object containing the two output streams from the ROM.
	 */
	public DualPortMemOutputs<DFEVar> romDualPort(
		DFEVar address_a,
		DFEVar address_b,
		DFEType type,
		double... contents)
	{
		MemoryFactory.DualPortROMOutputs raw_output = m_imp.dualRom(
			_KernelBaseTypes.toImp(address_a),
			_KernelBaseTypes.toImp(address_b),
			_KernelBaseTypes.toImp(type),
			contents);

		return new DualPortMemOutputs<DFEVar>(type, raw_output);
	}

	/**
	 * Creates a dual-port ROM of {@link KernelObjectNotVector KernelObject}s.
	 * <p>
	 * This version of <code>romDualPort</code> allows the use of objects of classes such as {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray},
	 * {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex} and {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct}.
	 * <p>
	 * Each port has its own input address stream and output data stream looking at the same set of data.
	 * <p>
	 * The size of the ROM is inferred from the size of <code>contents</code>.
	 * @param address_a The incoming address stream for port A.
	 * @param address_b The incoming address stream for port B.
	 * @param type The type of the contents of the ROM.
	 * @param contents The values for the contents of the ROM.
	 * @return {@link DualPortMemOutputs} object containing the two output streams from the ROM.
	 */
	public <T extends KernelObjectNotVector<T>> DualPortMemOutputs<T>
		romDualPort(DFEVar address_a, DFEVar address_b, KernelType<T> type, Bits... contents)
	{
		DFEType var_type = getVarType(type);

		MemoryFactory.DualPortROMOutputs raw_output = m_imp.dualRom(
			_KernelBaseTypes.toImp(address_a),
			_KernelBaseTypes.toImp(address_b),
			_KernelBaseTypes.toImp(var_type),
			_Utils.toImp(contents));

		return new DualPortMemOutputs<T>(type, raw_output);
	}

	/**
	 * Creates a mapped single-port ROM of {@link DFEVar}s of <code>size</code> elements.
	 * <p>
	 * The contents of a mapped ROM can be set by CPU code dynamically. <code>name</code> is used by the
	 * CPU code to identify the ROM, so this must be unique within a Kernel.
	 * <p>
	 * See {@link #romMapped(String, DFEVector, DFEType, double...)}
	 * for a {@link DFEVector multipipe} version.
	 * @param name The name of the ROM as it will appear in the Manager and CPU code.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param size The size of the ROM in elements.
	 * @return The output stream from the ROM.
	 */
	public <T extends KernelObjectNotVector<T>>
		T romMapped(String name, DFEVar address, KernelType<T> type, int size)
	{
		DFEType var_type = getVarType(type);

		checkMappedROMWidth(var_type);

		Var output = m_imp.mappedRom(
			name,
			_KernelBaseTypes.toImp(address),
			_KernelBaseTypes.toImp(var_type),
			size);

		return getCorrectlyTypedDataOutput(
			output,
			type,
			var_type,
			type.getFullTypeWithoutDoubtInfo().getDoubtType(),
			null);
	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMapped(String, DFEVar, KernelType, int)} instead.
	 * <p>
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public DFEVar romMapped(String name, DFEVar address, DFEType type, double... contents) {
		warnInitilisedMappedRom(name);

		checkMappedROMWidth(type);

		Var output = m_imp.mappedRom(
			name,
			_KernelBaseTypes.toImp(address),
			_KernelBaseTypes.toImp(type),
			contents);

		return _KernelBaseTypes.fromImp(m_design, output);
	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMapped(String, DFEVar, KernelType, int)} instead.
	 * <p>
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public <T extends KernelObjectNotVector<T>>
		T romMapped(String name, DFEVar address, KernelType<T> type, Bits... contents)
	{
		warnInitilisedMappedRom(name);

		DFEType var_type = getVarType(type);

		checkMappedROMWidth(var_type);

		Var output = m_imp.mappedRom(
			name,
			_KernelBaseTypes.toImp(address),
			_KernelBaseTypes.toImp(var_type),
			_Utils.toImp(contents));

		return getCorrectlyTypedDataOutput(output, type, var_type, type.getFullTypeWithoutDoubtInfo().getDoubtType(), null);
	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMapped(String, DFEVectorBase, DFEVectorTypeBase, int)} instead.
	 * <p>
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public DFEVector<DFEVar> romMapped(
			String name,
			DFEVector<DFEVar> address,
			DFEType type,
			double... contents)
	{
		Bits[] bits_data = new Bits[contents.length];

		for(int i = 0; i < contents.length; i++)
			bits_data[i] = type.encodeConstant(contents[i]);

		return romMapped(name, address, type, bits_data);
	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMapped(String, DFEVectorBase, DFEVectorTypeBase, int)} instead.
	 *
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public <T extends KernelObjectVectorizable<T>>
	DFEVector<T> romMapped(String name, DFEVector<DFEVar> address, KernelTypeVectorizable<T> type, Bits... contents) {
		warnInitilisedMappedRom(name);

		checkMappedROMWidth(type);

		DFEVector<T> res =
			new DFEVectorType<T>(type, address.getNElements()).newInstance(m_design);

		List<String> duplicates = new ArrayList<String>();

		int rep_n = 0;

		String prefix = _Kernel.getPhotonDesignData(m_design).getName() + ".";
		for(int i = 0; i < address.getNElements() / 2; i++) {
			String real_name = replicatedROMName(name, rep_n++);
			DualPortMemOutputs<T> dro =
				romMappedDualPort(
					real_name,
					address.getElement(i*2),
					address.getElement(i*2 + 1),
					type,
					contents);
			res.connect(i*2, dro.getOutputA());
			res.connect(i*2 +  1, dro.getOutputB());
			duplicates.add(prefix + real_name);
		}

		if(address.getNElements() % 2 != 0) {
			String real_name = replicatedROMName(name, rep_n++);
			int i = address.getNElements() - 1;
			T rom = romMapped(real_name, address.getElement(i), type, contents);
			res.connect(i, rom);
			duplicates.add(prefix + real_name);
		}

		_Kernel.getPhotonDesignData(m_design).addDuplicatedMappedMemory(prefix + name, duplicates);

		return res;
  	}

	private void warnInitilisedMappedRom(String name) {
		if( !name.matches(".*" + m_replicated_rom_name + ".*") )
			m_design.getManager().logWarning(
				"Note although mapped rom '" + name + "' uses pre-initialized data, " +
				"best practise is to always re-initialize at CPU code start-up.");
	}

	private void checkMappedROMWidth(KernelType<?> type) {
		// MaxCompilerRT currently doesn't allow the user to set >64 bit wide mapped ROM elements
		if (type.getTotalBits() > 64)
			throw new MaxCompilerAPIError(m_design.getManager(), "Mapped ROM element width must be <= 64 bits, not " + type.getTotalBits() + "." );
	}

	/**
	 * Creates a multipipe mapped single-port ROM of {@link DFEVar}s of <code>size</code> elements.
	 * <p>
	 * The contents of a mapped ROM can be set by CPU code dynamically. <code>name</code> is used by the CPU
	 * code to identify the ROM, so this must be unique within a Kernel.
	 * <p>
	 * MaxCompiler will create the required number of ROMs with identical contents and a unique address and output data
	 * stream for each pipe.
	 * @param name The name of the ROM as it will appear in the Manager and CPU code.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param size The size of the ROM in elements.
	 * @return The output stream from the ROM.
	 */
	public <T extends KernelObjectVectorizable<T>>
	DFEVector<T> romMapped(String name, DFEVector<DFEVar> address, KernelTypeVectorizable<T> type, int size) {
		checkMappedROMWidth(type);

		DFEVector<T> res =
			new DFEVectorType<T>(type, address.getNElements()).newInstance(m_design);

		List<String> duplicates = new ArrayList<String>();

		int rep_n = 0;

		String prefix = _Kernel.getPhotonDesignData(m_design).getName() + ".";
		for(int i = 0; i < address.getNElements() / 2; i++) {
			String real_name = replicatedROMName(name, rep_n++);
			DualPortMemOutputs<T> dro =
				romMappedDualPort(
					real_name,
					address.getElement(i*2),
					address.getElement(i*2 + 1),
					type,
					size);
			res.connect(i*2, dro.getOutputA());
			res.connect(i*2 +  1, dro.getOutputB());
			duplicates.add(prefix + real_name);
		}

		if(address.getNElements() % 2 != 0) {
			String real_name = replicatedROMName(name, rep_n++);
			int i = address.getNElements() - 1;
			T rom =	romMapped(real_name, address.getElement(i), type, size);
			res.connect(i, rom);
			duplicates.add(prefix + real_name);
		}

		_Kernel.getPhotonDesignData(m_design).addDuplicatedMappedMemory(prefix + name, duplicates);

		return res;
  	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMapped(String, DFEVectorBase, DFEVectorTypeBase, int)} instead.
	 * <p>
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		A extends DFEVectorBase<DFEVar, A, ?, ?>
	>
	M romMapped(String name, A address, T type, double... contents) {
		KernelTypeVectorizable<P> pipe_type = type.getContainedType();
		Bits[] bits_data = new Bits[contents.length];
		for (int i = 0; i < bits_data.length; ++i)
			bits_data[i] = pipe_type.encodeConstant(contents);

		return romMapped(name, address, type, bits_data);
	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMapped(String, DFEVectorBase, DFEVectorTypeBase, int)} instead.
	 *
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		A extends DFEVectorBase<DFEVar, A, ?, ?>
	>
	M romMapped(String name, A address, T type, Bits... contents) {
		List<P> new_pipes = new ArrayList<P>(address.getNElements());
		List<String> duplicates = new ArrayList<String>();

		warnInitilisedMappedRom(name);

		checkMappedROMWidth(type.getContainedType());

		int rep_n = 0;
		String prefix = _Kernel.getPhotonDesignData(m_design).getName() + ".";
		for(int i = 0; i < address.getNElements() / 2; i++) {
			String real_name = replicatedROMName(name, rep_n++);
			int j = i * 2;
			int k = j + 1;
			DualPortMemOutputs<P> out = romMappedDualPort(
				real_name,
				address.getElement(j),
				address.getElement(k),
				type.getContainedType(),
				contents
			);

			new_pipes.add(out.getOutputA());
			new_pipes.add(out.getOutputB());
			duplicates.add(prefix + real_name);
		}

		if(address.getNElements() % 2 != 0) {
			String real_name = replicatedROMName(name, rep_n++);
			int i = address.getNElements() - 1;
			P out =	romMapped(real_name, address.getElement(i), type.getContainedType(), contents);
			new_pipes.add(out);
			duplicates.add(prefix + real_name);
		}

		_Kernel.getPhotonDesignData(m_design).addDuplicatedMappedMemory(prefix + name, duplicates);

		return type.newInstance(m_design, new_pipes);
	}

	/**
	 * Creates a multipipe mapped single-port ROM of {@link KernelObject}s of <code>size</code> elements.
	 * <p>
	 * The contents of a mapped ROM can be set by CPU code dynamically. <code>name</code> is used by the CPU
	 * code to identify the ROM, so this must be unique within a Kernel.
	 * <p>
	 * MaxCompiler will create the required number of ROMs with identical contents and a unique address and output data
	 * stream for each pipe.
	 * <p>
	 * Example usage:
	 * <p>
	 * <code>
	 * DFEVectorType&lt;DFEVar&gt; romType = new DFEVectorType&lt;DFEVar&gt;(dfeFloat(8, 24), 4);<br>
	 * DFEVector&lt;DFEVar&gt; address = control.count.simpleCounterMP(4, 3, 8);<br>
	 * DFEVector&lt;DFEVar&gt; data = mem.rom("myRom", address, romType);<br>
	 * </code>
	 * @param name The name of the ROM as it will appear in the Manager and CPU code.
	 * @param address The incoming address stream.
	 * @param type The type of the contents of the ROM.
	 * @param size The size of the ROM in elements.
	 * @return The output stream from the ROM.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>,
		A extends DFEVectorBase<DFEVar, A, ?, ?>
	>
	M romMapped(String name, A address, T type, int size) {
		checkMappedROMWidth(type.getContainedType());

		List<P> new_pipes = new ArrayList<P>(address.getNElements());
		List<String> duplicates = new ArrayList<String>();

		int rep_n = 0;
		String prefix = _Kernel.getPhotonDesignData(m_design).getName() + ".";
		for(int i = 0; i < address.getNElements() / 2; i++) {
			String real_name = replicatedROMName(name, rep_n++);
			int j = i * 2;
			int k = j + 1;
			DualPortMemOutputs<P> out = romMappedDualPort(
				real_name,
				address.getElement(j),
				address.getElement(k),
				type.getContainedType(),
				size
			);

			new_pipes.add(out.getOutputA());
			new_pipes.add(out.getOutputB());
			duplicates.add(prefix + real_name);
		}

		if(address.getNElements() % 2 != 0) {
			String real_name = replicatedROMName(name, rep_n++);
			int i = address.getNElements() - 1;
			P out = romMapped(real_name, address.getElement(i), type.getContainedType(), size);
			new_pipes.add(out);
			duplicates.add(prefix + real_name);
		}

		_Kernel.getPhotonDesignData(m_design).addDuplicatedMappedMemory(prefix + name, duplicates);

		return type.newInstance(m_design, new_pipes);
	}

	private static String replicatedROMName(String name, int index) {
		return m_replicated_rom_name + index + "_" + name;
	}

	/**
	 * Creates a mapped dual-port ROM of {@link KernelObjectNotVector KernelObject}s of <code>size</code> elements.
	 * <p>
	 * This version of <code>romMappedDualPort</code> allows the use of objects of classes such as {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray},
	 * {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex} and {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct}.
	 * <p>
	 * The contents of a mapped ROM can be set by the CPU code dynamically. <code>name</code> is used by the CPU
	 * code to identify the ROM, so this must be unique within a Kernel.
	 * <p>
	 * Each port has its own input address stream and output data stream looking at the same set of data.
	 * <p>
	 * There is no multipipe version of this method. Use {@link #romMapped(String, DFEVectorBase, DFEVectorTypeBase, int)}.
	 * @param name The name of the ROM as it will appear in the Manager and CPU code.
	 * @param address_a The incoming address stream for port A.
	 * @param address_b The incoming address stream for port B.
	 * @param type The type of the contents of the ROM.
	 * @param size The size of the ROM in elements.
	 * @return {@link DualPortMemOutputs} object containing the two output streams from the ROM.
	 */
	public <T extends KernelObjectNotVector<T>>
	DualPortMemOutputs<T> romMappedDualPort(
			String name,
			DFEVar address_a,
			DFEVar address_b,
			KernelType<T> type,
			int size)
	{
		DFEType var_type = getVarType(type);

		checkMappedROMWidth(var_type);

		MemoryFactory.DualPortROMOutputs raw_output = m_imp.mappedDualRom(
			name,
			_KernelBaseTypes.toImp(address_a),
			_KernelBaseTypes.toImp(address_b),
			_KernelBaseTypes.toImp(var_type),
			size);

		return new DualPortMemOutputs<T>(type, raw_output);
	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMappedDualPort(String, DFEVar, DFEVar, KernelType, int)} instead.
	 * <p>
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public <T extends KernelObjectNotVector<T>>
		DualPortMemOutputs<DFEVar> romMappedDualPort(
			String name,
			DFEVar address_a,
			DFEVar address_b,
			DFEType type,
			double... contents)
	{
		warnInitilisedMappedRom(name);

		checkMappedROMWidth(type);

		MemoryFactory.DualPortROMOutputs raw_output = m_imp.mappedDualRom(
			name,
			_KernelBaseTypes.toImp(address_a),
			_KernelBaseTypes.toImp(address_b),
			_KernelBaseTypes.toImp(type),
			contents);

		return new DualPortMemOutputs<DFEVar>(type, raw_output);
	}

	/**
	 * <b>Deprecated</b> as of MaxCompiler 2010.2, use {@link #romMappedDualPort(String, DFEVar, DFEVar, KernelType, int)} instead.
	 * <p>
	 * This method has been deprecated as setting the contents of a mapped ROM when it is created
	 * can lead to unexpected behavior.
	 */
	public <T extends KernelObjectNotVector<T>>
		DualPortMemOutputs<T> romMappedDualPort(
			String name,
			DFEVar address_a,
			DFEVar address_b,
			KernelType<T> type,
			Bits... contents)
	{
		warnInitilisedMappedRom(name);

		DFEType var_type = getVarType(type);

		checkMappedROMWidth(var_type);

		MemoryFactory.DualPortROMOutputs raw_output = m_imp.mappedDualRom(
			name,
			_KernelBaseTypes.toImp(address_a),
			_KernelBaseTypes.toImp(address_b),
			_KernelBaseTypes.toImp(var_type),
			_Utils.toImp(contents));

		return new DualPortMemOutputs<T>(type, raw_output);
	}
}
