package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import com.maxeler.maxeleros.wrappergenerator.WrapperInterfaceMIGDDR3.PHY_DEBUG;
import com.maxeler.utils.MaxCompilerHide;

public class DebugLevel {
	private boolean m_has_stream_status = false;
	private boolean m_has_stream_status_checksums = false;
	private boolean m_has_mem_ctl_debug_registers = true;
	private boolean m_has_mem_ctl_extra_debug_registers = false;
	private PHY_DEBUG m_has_mem_phy_debug_register = PHY_DEBUG.NONE;
	private boolean m_has_mem_pll_lock_debug_registers = true;
	private boolean m_has_memory_margining_support = false;
	private final boolean m_full_cal_sim = false;


	public DebugLevel setHasStreamStatus(boolean has_stream_status) {
		m_has_stream_status = has_stream_status;
		return this;
	}

	public boolean hasStreamStatus() {
		return m_has_stream_status;
	}


	public DebugLevel setHasStreamStatusChecksums(boolean has_stream_status_checksums) {
		m_has_stream_status_checksums = has_stream_status_checksums;
		// Ticket #2924: if user requests StreamStatusChecksums, then StreamStatus should be set automatically
		if (has_stream_status_checksums) {
			setHasStreamStatus(true);
		}
		return this;
	}

	public boolean hasStreamStatusChecksums() {
		return m_has_stream_status_checksums;
	}



	public DebugLevel setHasMemoryControllerDebugRegisters(boolean has_mem_ctl_debug_registers) {
		m_has_mem_ctl_debug_registers = has_mem_ctl_debug_registers;
		return this;
	}

	public boolean hasMemoryControllerDebugRegisters() {
		return m_has_mem_ctl_debug_registers;
	}



	public DebugLevel setHasMemoryControllerExtraDebugRegisters(boolean has_mem_ctl_extra_debug_registers) {
		m_has_mem_ctl_extra_debug_registers = has_mem_ctl_extra_debug_registers;
		return this;
	}

	public boolean hasMemoryControllerExtraDebugRegisters() {
		return m_has_mem_ctl_extra_debug_registers;
	}



	@MaxCompilerHide
	public DebugLevel setHasMemoryPHYDebugRegisers(PHY_DEBUG has_mem_phy_debug_register) {
		m_has_mem_phy_debug_register = has_mem_phy_debug_register;
		return this;
	}

	@MaxCompilerHide
	public PHY_DEBUG hasMemoryPHYDebugRegisters() {
		return m_has_mem_phy_debug_register;
	}


	public DebugLevel setHasMemoryPLLLockDebugRegisters(boolean has_mem_pll_lock_debug_registers) {
		m_has_mem_pll_lock_debug_registers = has_mem_pll_lock_debug_registers;
		return this;
	}

	public boolean hasMemoryPLLLockDebugRegisters() {
		return m_has_mem_pll_lock_debug_registers;
	}

	public boolean hasFifoUnderflowOverflowRegisters() {
		return false;
	}

	public DebugLevel setHasMemoryMarginingSupport(boolean has_mem_margin_support) {
		m_has_memory_margining_support = has_mem_margin_support;
		return this;
	}

	public boolean hasMemoryMarginingSupport() {
		return m_has_memory_margining_support;
	}

	@MaxCompilerHide
	public boolean hasFullCalSim() {
		return m_full_cal_sim;
	}
}
