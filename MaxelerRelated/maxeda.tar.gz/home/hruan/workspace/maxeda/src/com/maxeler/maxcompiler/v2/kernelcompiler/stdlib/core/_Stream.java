package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.photon.core.StreamOffsetEq;

public class _Stream extends Stream {

	public _Stream(Kernel design) { super(design); }

	public static StreamOffsetEq toImp(OffsetExpr expr) {
		return expr.m_eq_imp;
	}
}
