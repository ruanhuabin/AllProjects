package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.DFEsmValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._DFEsmShifter;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType.SignMode;
import com.maxeler.photon.hw.Shifter;
import com.maxeler.statemachine.FunctionCall;
import com.maxeler.statemachine.FunctionCall.Function;
import com.maxeler.statemachine.StateMachineInternalException;
import com.maxeler.statemachine.expressions.Expression;

/**
 * A library for bit level operations.
 */
public class Bitops extends Lib {
	private final List<_DFEsmShifter> m_shifters = new ArrayList<_DFEsmShifter>();

	Bitops(StateMachineLib sm) { super(sm); }

	public DFEsmValue oneHotEncode(DFEsmValue index) {
		return call(Function.ONE_HOT_ENCODE, index);
	}

	public DFEsmValue oneHotDecode(DFEsmValue oneHotValue) {
		return call(Function.ONE_HOT_DECODE, oneHotValue);
	}

	public DFEsmValue leadingOneDetect(DFEsmValue value) {
		return call(Function.LEADING_ONE_DETECT, value);
	}

	public DFEsmValue trailingOneDetect(DFEsmValue value) {
		return call(Function.TRAILING_ONE_DETECT, value);
	}

	public DFEsmValue reverse(DFEsmValue value) {
		return call(Function.REVERSE, value);
	}

	List<_DFEsmShifter> getShifters() { return Collections.unmodifiableList(m_shifters); }

	int getNextShiftID() { return m_shifters.size() + 1; }

	_DFEsmShifter shiftLeft(DFEsmValueType dataType, DFEsmValueType shiftType) {
		return createShift(dataType, shiftType, Shifter.ShiftDirection.Left, false);
	}

	_DFEsmShifter shiftRight(DFEsmValueType dataType, DFEsmValueType shiftType) {
		return createShift(dataType, shiftType, Shifter.ShiftDirection.Right, false);
	}

	_DFEsmShifter rotateLeft(DFEsmValueType dataType, DFEsmValueType rotateType) {
		return createShift(dataType, rotateType, Shifter.ShiftDirection.Left, true);
	}

	_DFEsmShifter rotateRight(DFEsmValueType dataType, DFEsmValueType rotateType) {
		return createShift(dataType, rotateType, Shifter.ShiftDirection.Right, true);
	}

	private _DFEsmShifter createShift(DFEsmValueType dataType, DFEsmValueType shiftType, Shifter.ShiftDirection direction, boolean circular) {
		if (dataType.getSignMode() == SignMode.Signed)
			throw new StateMachineInternalException("Signed data not supported for shift.");
		if (shiftType.getSignMode() == SignMode.Signed)
			throw new StateMachineInternalException("Signed shift amount not supported for shift.");

		_DFEsmShifter shift = new _DFEsmShifter(getStateMachine(), dataType, shiftType, direction, circular, getNextShiftID());

		m_shifters.add(shift);

		return shift;
	}

	private static DFEsmValue call(FunctionCall.Function function, DFEsmValue... arguments) {
		Expression[] expressions = new Expression[arguments.length];

		for (int i = 0; i < expressions.length; ++i)
			expressions[i] = _StateMachine.getExpression(arguments[i]);
		return _StateMachine.Create.DFEsmValue(new FunctionCall(function, expressions));
	}
}
