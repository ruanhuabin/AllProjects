package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.utils.Box;

/**
 * A Kernel type for multipipe data.
 * @param <ContainedT> Kernel object for an individual pipe.
 */
public class DFEVectorType<ContainedT extends KernelObjectVectorizable<ContainedT>>
	extends DFEVectorTypeBase<
		ContainedT,
		DFEVector<ContainedT>,
		DFEVector<DFEVar>
	>
{
	/**
	 * Constructs a new {@code DFEVectorType} Kernel type.
	 * @param containedType The type of an individual pipe.
	 * @param numPipes The number of pipes. Must be greater than 0.
	 */
	public DFEVectorType(KernelTypeVectorizable<ContainedT> containedType, int numPipes) {
		super(containedType, numPipes);
	}

	@Override
	protected int realGetTotalBits() {
		return m_pipe_type.getTotalBits();
	}

	@Override
	public DFEVector<ContainedT> newInstance(KernelLib design, DFEVectorDoubtType doubt_type) {
		DFEArray<ContainedT> array = m_pipe_type.newInstance(design, doubt_type.getDFEArrayDoubtType());
		return new DFEVector<ContainedT>(array, this);
	}

	@Override
	protected DFEVector<ContainedT> realUnpack(DFEVar src) {
		DFEArray<ContainedT> array = m_pipe_type.realUnpack(src);

		return new DFEVector<ContainedT>(array, this);
	}

	@Override
	protected DFEVector<ContainedT> realUnpackWithDoubt(
		DFEVar src,
		DFEVectorDoubtType doubt_type)
	{
		DFEArray<ContainedT> array = m_pipe_type.realUnpackWithDoubt(
			src,
			doubt_type.getDFEArrayDoubtType());

		return new DFEVector<ContainedT>(array, this);
	}

	@Override
	protected DFEVector<ContainedT> realUnpackFromList(List<DFEVar> primitives) {
		DFEArray<ContainedT> array = m_pipe_type.realUnpackFromList(primitives);

		return new DFEVector<ContainedT>(array, this);
	}

	@Override
	public DFEVector<ContainedT> newInstance(KernelLib design, ContainedT v) {
		DFEVector<ContainedT> n = newInstance(design);
		n.connect(v);

		return n;
	}

	@Override
	public DFEVector<ContainedT> newInstance(KernelLib design, List<ContainedT> pipes) {
		KernelTypeVectorizable<ContainedT> pipeType = pipes.get(0).getType();
		for (int i = 1; i < pipes.size(); ++i)
			if (!pipeType.equals(pipes.get(i).getType()))
				throw new MaxCompilerAPIError(design.getManager(), "All pipes must have the same type (%s != %s).", pipeType, pipes.get(i).getType());

		DFEVectorType<ContainedT> newType = new DFEVectorType<ContainedT>(pipeType, pipes.size());
		DFEVector<ContainedT> n = newType.newInstance(design);

		for (int i = 0; i < pipes.size(); ++i)
			n.connect(i, pipes.get(i));

		return n;
	}

	@Override
	protected DFEVector<DFEVar> newCompareInstance(KernelLib design) {
		KernelTypeVectorizable<DFEVar> pipeType = (KernelTypeVectorizable<DFEVar>) m_compare_type.getContainedType();
		DFEVectorType<DFEVar> newType = new DFEVectorType<DFEVar>(pipeType, m_compare_type.getSize());

		return newType.newInstance(design);
	}

	/**
	 * Creates a new <em>source-less</em> multipipe stream of {@code n_pipes} pipes of Kernel type {@code contained_element}.
	 * @param <ContainedT> Kernel object for an individual pipe.
	 * @param n_pipes
	 * @param contained_element
	 */
	public static <ContainedT extends KernelObjectVectorizable<ContainedT>>
	DFEVector<ContainedT> newInstance(int n_pipes, ContainedT contained_element) {
		List<ContainedT> pipes = new ArrayList<ContainedT>(n_pipes);

		for(int i = 0; i < n_pipes; i++)
			pipes.add(contained_element);

		return newInstance(pipes);
	}

	/**
	 * Creates a new multipipe stream with the inputs connected to the streams in {@code contained_elements}.
	 * @param <ContainedT> Kernel object for an individual pipe.
	 * @param contained_elements A {@code List} of streams to which to connect.
	 * @return A new multipipe stream connected to the streams in {@code contained_elements}.
	 */
	public static <ContainedT extends KernelObjectVectorizable<ContainedT>>
	DFEVector<ContainedT> newInstance(List<ContainedT> contained_elements) {
		if(contained_elements.size() < 1)
			throw new MaxCompilerAPIError(
				"Cannot pre-init instance of MultiPipe with less than 1 data item.");

		int n_pipes = contained_elements.size();

		KernelTypeVectorizable<ContainedT> pipe_type = contained_elements.get(0).getType();
		DFEVectorType<ContainedT> new_type = new DFEVectorType<ContainedT>(pipe_type, n_pipes);
		DFEVector<ContainedT> inst = new_type.newInstance(contained_elements.get(0).getKernel());

		for(int i = 0; i < n_pipes; i++)
			inst.connect(i, contained_elements.get(i));

		return inst;
	}

	@Override
	public int hashCode() {
		return m_pipe_type.hashCode();
	}

	@SuppressWarnings({"rawtypes"})
	@Override
	public List decodeConstant(Bits raw_bits) {
		assertConcrete("decode constant");

		return m_pipe_type.decodeConstant(raw_bits);
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(double... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(float... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(long... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(int... values) {
		return encodeConstant(Box.array(values));
	}

	/**
	 * Encodes a variable number of constants into a single {@link Bits} value.
	 * @param values The constant values to encode.
	 * @return The encoded constant.
	 */
	public Bits encodeConstant(boolean... values) {
		return encodeConstant(Box.array(values));
	}

	@Override
	public Bits encodeConstant(Object value) {
		assertConcrete("encode constant");

		return m_pipe_type.encodeConstant(value);
	}

	@Override
	public <T> Bits encodeConstant(List<T> value_list) {
		assertConcrete("encode constant");

		return m_pipe_type.encodeConstant(value_list);
	}

	@Override
	public <T> Bits encodeConstant(T[] value_array) {
		assertConcrete("encode constant");

		return m_pipe_type.encodeConstant(value_array);
	}

	/**
	 * Returns a string containing the Kernel type information.
	 * <p>
	 * The returned string is of the form:
	 * <p>
	 * <code>
	 * {DFEVectorType: [num_pipes] x [contained_type]}
	 * </code>
	 */
	@Override
	public String toString() {
		return "{DFEVectorType: " + m_pipe_type.getSize() + " x " + m_pipe_type.getContainedType() + "}";
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public DFEVectorFullType getFullTypeWithoutDoubtInfo() {
		// Not sure why this needs to be broken up...
		DFEArrayFullType<?> kadt = m_pipe_type.getFullTypeWithoutDoubtInfo();
		DFEArrayDoubtType x = kadt.getDoubtType();

		return new DFEVectorFullType(new DFEVectorDoubtType(x), this);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public DFEVectorFullType getFullTypeWithDoubtInfo() {
		// Not sure why this needs to be broken up...
		DFEArrayFullType<?> kadt = m_pipe_type.getFullTypeWithDoubtInfo();
		DFEArrayDoubtType x = kadt.getDoubtType();

		return new DFEVectorFullType(new DFEVectorDoubtType(x), this);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		DFEVectorType<ContainedT> foo = (DFEVectorType<ContainedT>)other_type;

		return
			new DFEVectorType<ContainedT>(
				(KernelTypeVectorizable<ContainedT>)getContainedType().unionWithMaxOfMaxes(foo.getContainedType()),
				getNElements());
	}
}
