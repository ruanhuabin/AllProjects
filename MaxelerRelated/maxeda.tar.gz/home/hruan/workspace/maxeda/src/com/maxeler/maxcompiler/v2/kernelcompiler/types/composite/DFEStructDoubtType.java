package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;

public class DFEStructDoubtType extends DoubtType {
	private final Map<String, DoubtType> m_field_doubt_types;

	DFEStructDoubtType(Map<String, DoubtType> field_doubt_types) {
		m_field_doubt_types = new HashMap<String, DoubtType>(field_doubt_types);
	}

	public Map<String, DoubtType> getFieldDoubtTypes() {
		return Collections.unmodifiableMap(m_field_doubt_types);
	}

	@Override
	public boolean hasDoubtInfo() {
		for(DoubtType doubt_type : m_field_doubt_types.values())
			if (doubt_type.hasDoubtInfo())
				return true;

		return false;
	}

	@Override
	public int getTotalBits() {
		int bits = 0;
		for(DoubtType doubt_type : m_field_doubt_types.values())
			bits += doubt_type.getTotalBits();

		return bits;
	}

	@Override
	public String toString() {
		return "DFEStructDoubtType" + m_field_doubt_types.toString();
	}

	@Override
	public boolean equals(Object other) {
		return
			(other instanceof DFEStructDoubtType) &&
			((DFEStructDoubtType)other).m_field_doubt_types.equals(m_field_doubt_types);
	}

	@Override
	public int hashCode() {
		return m_field_doubt_types.hashCode();
	}

	@Override
	public DFEStructDoubtType union(DoubtType other_type) {
		if(!(other_type instanceof DFEStructDoubtType))
			throw new MaxCompilerAPIError("Can only union with another DFEStructDoubtType object.");

		DFEStructDoubtType kstruct_doubt_type = (DFEStructDoubtType)other_type;

		if(!kstruct_doubt_type.m_field_doubt_types.keySet().equals(m_field_doubt_types.keySet()))
			throw new MaxCompilerAPIError(
				"Cannot union doubt-types as fields are incompatible " +
				m_field_doubt_types.keySet() + " vs. " +
				kstruct_doubt_type.m_field_doubt_types.keySet());

		Map<String, DoubtType> new_doubt_doubt_types =
			new HashMap<String, DoubtType>();

		for(Map.Entry<String, DoubtType> field : m_field_doubt_types.entrySet()) {
			String field_name = field.getKey();
			new_doubt_doubt_types.put(
				field_name,
				kstruct_doubt_type.getFieldDoubtTypes().get(field_name).union(field.getValue()));
		}

		return new DFEStructDoubtType(new_doubt_doubt_types);
	}
}
