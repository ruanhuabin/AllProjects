package com.maxeler.maxcompiler.v2.kernelcompiler.types;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;



/**
 * Any {@link KernelObject} type which is not derived from {@link DFEVector}
 * should implement this interface (it is implemented by
 * {@link KernelObjectVectorizable}).
 * <p>
 * This interface exists as many operations
 * are not allowed directly on multipipe types and this enables the Java
 * type-system to enforce this statically in many cases.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public interface KernelObjectNotVector<RealT> extends KernelObject<RealT> {
}
