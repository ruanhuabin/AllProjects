package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.maxcompiler.v2.managers.DFEManager;

public class _KernelParameters extends KernelParameters {

	public _KernelParameters(
		DFEManager manager,
		String name,
		KernelConfiguration config)
	{
		super(manager, name, config);
	}

}
