package com.maxeler.maxcompiler.v2.statemachine.types;


public final class DFEsmEnumType extends DFEsmType {
	private final Class<? extends Enum<?>> m_enumClass;

	<E extends Enum<?>> DFEsmEnumType(Class<E> enumClass) { m_enumClass = enumClass; }

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof DFEsmEnumType))
			return false;

		DFEsmEnumType t = (DFEsmEnumType) o;

		return t.getEnumClass().equals(t.getEnumClass());
	}

	public Class<? extends Enum<?>> getEnumClass() { return m_enumClass; }

	@Override
	public int hashCode() { return m_enumClass.hashCode(); }

	@Override
	public String toString() { return "dfeEnum(" + m_enumClass.getSimpleName() + ")"; }
}
