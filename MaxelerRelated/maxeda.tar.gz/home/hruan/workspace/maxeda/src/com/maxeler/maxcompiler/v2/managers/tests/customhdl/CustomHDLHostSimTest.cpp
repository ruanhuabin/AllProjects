#include "CustomHDLHostSimTest.h"

using namespace maxcompilersim;

namespace project_stalingrad {

CustomHDLHostSimTestSync::CustomHDLHostSimTestSync(const std::string &name, int n) :
	ManagerBlockSync(name),
	m_input_port(registerPullInput("input")),
	m_output_port(registerPushOutput("output")),
	m_full(false),
	m_test_ctor_arg(n)
{
}

void CustomHDLHostSimTestSync::setup(const std::string &s)
{
	m_test_setup_arg = s;
}

bool CustomHDLHostSimTestSync::runCycle()
{
	bool progress = false;

	if(!m_full && !isPullInputEmpty(m_input_port)) {
		m_data = pullInput(m_input_port);
		m_full = true;
		progress = true;
	}

	if(m_full && !isPushOutputStalled(m_output_port)) {
		pushOutput(m_output_port, m_data);
		m_full = false;
		progress = true;
	}

	return progress;
}

void CustomHDLHostSimTestSync::reset()
{
	m_full = false;
}

bool CustomHDLHostSimTestSync::getSimParameter(const std::string &name, std::string &value)
{
	if(name == "test_ctor_arg") {
		value = boost::str(bfmt("%d") % m_test_ctor_arg);
		return true;
	} else if(name == "test_setup_arg") {
		value = m_test_setup_arg;
		return true;
	}

	return false;
}

} // namespace project_stalingrad
