package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamWriteMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.MAX3BoardModel;
import com.maxeler.maxcompiler.v2.managers.BuildConfig.Level;
import com.maxeler.maxcompiler.v2.managers.standard.Manager;
import com.maxeler.maxcompiler.v2.managers.standard.Manager.IOType;

public class ConstraintTest extends Kernel {
	protected ConstraintTest(KernelParameters parameters) {
		super(parameters);

		DFEVar j = io.input("j", dfeUInt(8));
		DFEVar k = io.input("k", dfeUInt(36));
		DFEVar l = io.input("l", dfeUInt(18));
		DFEVar y = io.input("y", dfeUInt(10));


//		pushGroupUnique("g0");
		optimization.setGroupSliceAreaConstraint(1, 1, 20, 20);
		DFEVar ram0 =
			mem.ram(
				1024,
				RamWriteMode.READ_FIRST,
				mem.makeRamPortParams(RamPortMode.READ_WRITE, y, dfeUInt(8)).withDataIn(j));
		io.output("x2", dfeUInt(8)).connect(ram0);
//		popGroup();

		pushGroupUnique("g3");
		DFEVar ram1 =
			mem.ram(
				1024,
				RamWriteMode.READ_FIRST,
				mem.makeRamPortParams(RamPortMode.READ_WRITE, y, dfeUInt(36)).withDataIn(k));
		io.output("x1", dfeUInt(36)).connect(ram1);
		DFEVar ram2 =
			mem.ram(
				1024,
				RamWriteMode.READ_FIRST,
				mem.makeRamPortParams(RamPortMode.READ_WRITE, y, dfeUInt(18)).withDataIn(l));
		io.output("x0", dfeUInt(18)).connect(ram2);
		optimization.setGroupSliceAreaConstraint(1, 1, 4, 4);
		optimization.setGroupRAMB18AreaConstraint(2, 2, 6, 6);
		optimization.setGroupRAMB36AreaConstraint(1, 1, 4, 4);
		popGroup();
	}

	public static void main(String[] args) {
		Manager m = new Manager(new _EngineParameters("ConstraintTest", MAX3BoardModel.MAX3224A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
		m.setKernel( new ConstraintTest(m.makeKernelParameters()) );
		m.getBuildConfig().setBuildLevel(Level.MAP);
		m.setIO(IOType.NOIO);
		m.build();
	}
}