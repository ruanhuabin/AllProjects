package com.maxeler.maxcompiler.v2.statemachine.types;

public final class DFEsmUntypedConst extends DFEsmType {
	@Override
	public boolean equals(Object o) { return o instanceof DFEsmUntypedConst; }

	@Override
	public int hashCode() { return 0; }

	@Override
	public String toString() { return "dfeUntypedConst()"; }
}
