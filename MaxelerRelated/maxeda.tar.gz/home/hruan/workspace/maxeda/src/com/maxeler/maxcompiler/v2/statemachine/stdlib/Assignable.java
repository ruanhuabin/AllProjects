package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._Error;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmAssignableEnum;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmAssignableValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.maxdc.VHDLNameManager;
import com.maxeler.statemachine.ASTContext.ContextMode;

public final class Assignable extends Lib {
	private final List<DFEsmAssignableValue> m_assignableValues = new ArrayList<DFEsmAssignableValue>();
	private final List<DFEsmAssignableEnum<?>> m_assignableEnums = new ArrayList<DFEsmAssignableEnum<?>>();

	private int m_nextAssignableID = 1;
	String generateNextLocalVarID(String someId) {
		String result = "";
		if (someId != null && someId.length() > 0)
		{
			if (!VHDLNameManager.isLegalVHDLName(someId))
				throw _Error.errorAPI(
					_StateMachine.getBuildManager(getStateMachine()), "Not a valid assignable value id: " + someId);
			result = "_" + someId;
		}

		result = "assignableVar" + Integer.toString(m_nextAssignableID++) + result;
		return result;
	}


	Assignable(StateMachineLib sm) {
		super(sm);
	}

	// create an assignable value
	DFEsmAssignableValue value(DFEsmValueType type, String stateId) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (_StateMachine.getInfo(getStateMachine()).getContextMode() != ContextMode.NEXT_STATE &&
			_StateMachine.getInfo(getStateMachine()).getContextMode() != ContextMode.OUTPUT) {
			throw _Error.errorAPI(_StateMachine.getBuildManager(getStateMachine()),
				"Cannot create an assignable value outside the next state or output function.");
		}

		String localVarID = generateNextLocalVarID(stateId);
		DFEsmAssignableValue stateInt = _StateMachine.Create.DFEsmLocalValue(getStateMachine(), type, localVarID);

		m_assignableValues.add(stateInt);
		return stateInt;
	}

	/**
	 * Creates an an integer-typed assignable value.
	 * @param type The value type of the variable.
	 * @return an DFEsmAssignableValue object.
	 */
	public DFEsmAssignableValue value(DFEsmValueType type) {
		return value(type,"");
	}






	<E extends Enum<E>>
	DFEsmAssignableEnum<E> enum_(Class<E> type, String stateId) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (_StateMachine.getInfo(getStateMachine()).getContextMode() != ContextMode.NEXT_STATE &&
			_StateMachine.getInfo(getStateMachine()).getContextMode() != ContextMode.OUTPUT)
		{
			throw _Error.errorAPI(_StateMachine.getBuildManager(getStateMachine()),
				"Cannot create an assignable enum outside the next state or output function.");
		}

		String localVarID = generateNextLocalVarID(stateId);
		DFEsmAssignableEnum<E> lvar = _StateMachine.Create.DFEsmAssignableEnum(getStateMachine(), type, localVarID);

		m_assignableEnums.add(lvar);
		return lvar;
	}


	/**
	 * Creates an enum-typed assignable value.
	 * @param type The enum type of the variable.
	 * @return an DFEsmAssignableEnum object.
	 */
	public <E extends Enum<E>> DFEsmAssignableEnum<E> enum_(Class<E> type) {
		return enum_(type, "");
	}

	List<DFEsmAssignableValue> getAssignableValues() { return Collections.unmodifiableList(m_assignableValues); }
	List<DFEsmAssignableEnum<?>> getAssignableEnums() { return Collections.unmodifiableList(m_assignableEnums); }
}
