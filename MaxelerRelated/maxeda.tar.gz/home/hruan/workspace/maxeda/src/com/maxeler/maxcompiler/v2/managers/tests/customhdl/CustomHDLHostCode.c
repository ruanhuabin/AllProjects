#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include <MaxCompilerRT.h>

#define DATA_SIZE 96*4

#define EXPECTED_CTOR_ARG "10"
#define EXPECTED_SETUP_ARG "dupa"

int main(int argc, char *argv[])
{
	char *device_name = (argc==2 ? argv[1] : "sim0:sim");
	max_maxfile_t* maxfile;
	max_device_handle_t* device;

	int status = 0;

	uint32_t i_data[DATA_SIZE];
	uint32_t o_data[DATA_SIZE];
	uint32_t expected_data[DATA_SIZE];

	for(int i = 0; i < DATA_SIZE; i++)
		i_data[i] = i;

	printf("Opening and configuring FPGA.\n");

	maxfile = max_maxfile_init_CustomHDLHostSimTest();
	device = max_open_device(maxfile, device_name);

	max_set_terminate_on_error(device);

	printf("Checking sim params.\n");
	extern void max_mci_get_sim_parameter(max_device_handle_t *device_handle, const char *name, char *buffer, size_t buffer_size);
	char buf[1024];
	max_mci_get_sim_parameter(device, "test_ctor_arg", buf, sizeof(buf));
	if(strcmp(buf, EXPECTED_CTOR_ARG) != 0) {
		printf("ERROR: test_ctor_arg is `%s', expected `%s'\n", buf, EXPECTED_CTOR_ARG);
		status = 1;
	}
	max_mci_get_sim_parameter(device, "test_setup_arg", buf, sizeof(buf));
	if(strcmp(buf, EXPECTED_SETUP_ARG) != 0) {
		printf("ERROR: test_ctor_arg is `%s', expected `%s'\n", buf, EXPECTED_SETUP_ARG);
		status = 1;
	}

	printf("Setting up inputs and outputs.\n");

	max_stream_handle_t *input_stream = max_get_pcie_stream(device, "input");
	max_stream_handle_t *output_stream = max_get_pcie_stream(device, "output");

	printf("Resetting the kernel.\n");

	max_reset_device(device);

	printf("Starting the PCI Express streams.\n");
	max_queue_pcie_stream(device, input_stream,
							   i_data, DATA_SIZE*sizeof(uint32_t), 1);
	max_queue_pcie_stream(device, output_stream,
							   o_data, DATA_SIZE*sizeof(uint32_t), 1);

	printf("Calculating expected results.\n");

	for(int i = 0; i < DATA_SIZE; i++)
		expected_data[i] = i_data[i];

	printf("Waiting for PCI Express streams to complete.\n");
	max_sync_pcie_stream(device, input_stream);
	max_sync_pcie_stream(device, output_stream);

	printf("Testing results.\n");
	for(int i = 0; i < DATA_SIZE; i++) {
		if(o_data[i] != expected_data[i]) {
			printf("[%d] Verification error, out: %u != expected: %u\n", i, o_data[i], expected_data[i]);
			status = 1;
		}
	}

	if (status)
		printf("Test failed.\n");
	else
		printf("Test passed OK!\n");

	printf("Shutting down\n");
	max_close_device(device);
	max_destroy(maxfile);

	return status;
}
