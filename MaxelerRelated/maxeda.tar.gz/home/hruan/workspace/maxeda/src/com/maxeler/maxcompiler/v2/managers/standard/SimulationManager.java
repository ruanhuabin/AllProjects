package com.maxeler.maxcompiler.v2.managers.standard;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.SimulationOutputCheckException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._KernelConfiguration;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.managers.BuildConfig;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.SimulationParams;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxcompiler.v2.managers._SimulationParams;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.maxcompiler.v2.utils._Utils;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.photon.compile_managers.JavaSimCompileManager;
import com.maxeler.photon.configuration.PhotonKernelConfiguration.BuildTarget;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.StreamOffsetManager.DistanceMeasurement;
import com.maxeler.photon.photontester.OutputDataChecker;
import com.maxeler.photon.photontester.OutputDataChecker.CheckDataException;
import com.maxeler.photon.photontester.PhotonTester;
import com.maxeler.photon.photontester.PhotonTesterDefault;
import com.maxeler.photon.photontester.PhotonTesterInput;
import com.maxeler.photon.photontester.PhotonTesterOutput;
import com.maxeler.photon.software.EqVar.InvalidStreamOffsetParam;
import com.maxeler.utils.AmountOfTime;
import com.maxeler.utils.Conversions;

public class SimulationManager extends DFEManager {
	static final SimulationParams s_default_simparams = SimulationParams.BITACCURATE;

	private Kernel m_kernel;
	private PhotonDesignData m_design_data;
	private boolean m_have_set_cycle_count = false;
	private boolean m_all_stream_offset_params_set = false;

	PhotonTester m_photon_tester = new PhotonTesterDefault(
		new MaxCompilerAPIError(this, "Cannot call this method yet, setKernel needs to be called first!") );
	PhotonTesterInput m_tester_input = new PhotonTesterInput(m_photon_tester);
	PhotonTesterOutput m_tester_output = new PhotonTesterOutput(m_photon_tester);
	OutputDataChecker m_output_data_checker = new OutputDataChecker(m_tester_output);


	public SimulationManager(String name) {
		this(name, s_default_simparams);
	}

	public SimulationManager(String name, SimulationParams parameters) {
		super(name, true, MAX2BoardModel.MAX2116B);
		_Managers.setCompileManagerFactory(
			this,
			_SimulationParams.getCompileManagerFactory(parameters));

		if (parameters == SimulationParams.BITACCURATE)
			_KernelConfiguration.setBuildTarget(m_kernel_configuration,
				BuildTarget.MAXCOMPILERSIM_JAVA_DRIVEN);
		else if (parameters == SimulationParams.HDLSIM)
			_KernelConfiguration.setBuildTarget(m_kernel_configuration,
				BuildTarget.HDL_SIM);
	}

	public void setKernel(Kernel kernel) {
		if(!(m_photon_tester instanceof PhotonTesterDefault))
			throw new MaxCompilerAPIError(this, "Kernel must be set exactly once.");

		m_kernel = kernel;
		m_design_data = _Kernel.getPhotonDesignData(kernel);

		m_photon_tester =
			((JavaSimCompileManager)_Kernel.prepareForBuild(kernel)).buildPhotonTester();
		m_photon_tester.setNotRunException(new MaxCompilerAPIError(this, "Cannot get simulation output because the simulation hasn't been run."));

		m_tester_input = new PhotonTesterInput(m_photon_tester);
		m_tester_output = new PhotonTesterOutput(m_photon_tester);
		m_output_data_checker = new OutputDataChecker(m_tester_output);
	}

	public static Bits packToBits(DFEType type, double... elements) {
		return _Utils.fromImp(
			Conversions.packToBits(
				_KernelBaseTypes.toImp(type),
				elements));
	}

	public static Bits[] packToBits(
		DFEType type,
		int elements_per_bigint,
		float... elements)
	{
		return _Utils.fromImp(
			Conversions.packToBits(
				_KernelBaseTypes.toImp(type),
				elements_per_bigint,
				elements));
	}

	public static Bits[] packToBits(
		DFEType type,
		int elements_per_bigint,
		double... elements)
	{
		return
			_Utils.fromImp(
				Conversions.packToBits(
					_KernelBaseTypes.toImp(type),
					elements_per_bigint,
					elements));
	}

	public static double[] unpackFromBits(DFEType type, Bits... bits) {
		return Conversions.unpackFromBits(
			_KernelBaseTypes.toImp(type), _Utils.toImp(bits));
	}

	public static double[] unpackFromBits(DFEType type, List<Bits> bits)
	{
		return Conversions.unpackFromBits(
			_KernelBaseTypes.toImp(type), _Utils.toImp(bits));
	}

	public void setMappedRom(String name, int address, double value) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRom(name, address, value);
	}

	public void setMappedRom(String name, double... values) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRom(name, values);
	}

	public void setMappedRom(String name, int address, Bits value) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRom(name, address, _Utils.toImp(value));
	}

	public void setMappedRom(String name, Bits... values) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRom(name, _Utils.toImp(values));
	}

	public void setMappedRam(String name, int address, double value) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRam(name, address, value);
	}

	public void setMappedRam(String name, double... values) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRam(name, values);
	}

	public void setMappedRam(String name, int address, Bits value) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRam(name, address, _Utils.toImp(value));
	}

	public void setMappedRam(String name, Bits... values) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		m_tester_input.setMappedRam(name, _Utils.toImp(values));
	}


	public double getMappedRam(String name, int address) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		return m_tester_output.getMappedRam(name, address);
	}

	public Bits getMappedRamRaw(String name, int address) {
		if (!name.contains("."))
			name = m_design_data.getName() + "." + name;
		return _Utils.fromImp(m_tester_output.getMappedRamRaw(name, address));
	}

	public double getStateMachineMappedRam(String stateMachineName, String ramName, int address) {
		return m_tester_output.getStateMachineMappedRam(stateMachineName, ramName, address);
	}

	public Bits getStateMachineMappedRamRaw(String stateMachineName, String ramName, int address) {
		return _Utils.fromImp(m_tester_output.getStateMachineMappedRamRaw(stateMachineName, ramName, address));
	}

	public void setStateMachineMappedRam(String stateMachineName, String ramName, int address, double value) {
		m_tester_input.setStateMachineMappedRam(stateMachineName, ramName, address, value);
	}

	public void setStateMachineMappedRam(String stateMachineName, String ramName, int address, Bits value) {
		m_tester_input.setStateMachineMappedRam(stateMachineName, ramName, address, _Utils.toImp(value));
	}

	public void setStateMachineMappedRam(String stateMachineName, String ramName, double... values) {
		m_tester_input.setStateMachineMappedRam(stateMachineName, ramName, values);
	}

	public void setStateMachineMappedRam(String stateMachineName, String ramName, Bits... values) {
		m_tester_input.setStateMachineMappedRam(stateMachineName, ramName, _Utils.toImp(values));
	}

	public void setStateMachineMappedRom(String stateMachineName, String romName, int address, double value) {
		m_tester_input.setStateMachineMappedRom(stateMachineName, romName, address, value);
	}

	public void setStateMachineMappedRom(String stateMachineName, String romName, int address, Bits value) {
		m_tester_input.setStateMachineMappedRom(stateMachineName, romName, address, _Utils.toImp(value));
	}

	public void setStateMachineMappedRom(String stateMachineName, String romName, double... values) {
		m_tester_input.setStateMachineMappedRom(stateMachineName, romName, values);
	}

	public void setStateMachineMappedRom(String stateMachineName, String romName, Bits... values) {
		m_tester_input.setStateMachineMappedRom(stateMachineName, romName, _Utils.toImp(values));
	}

	public void setScalarInput(String name, double value) {
		m_tester_input.setMappedReg(name, value);
	}

	public void setScalarInput(String name, Bits value) {
		m_tester_input.setMappedReg(name, _Utils.toImp(value));
	}

	public void setStateMachineScalarInput(String stateMachineName, String name, double value) {
		m_tester_input.setStateMachineMappedReg(stateMachineName, name, value);
	}

	public void setStateMachineScalarInput(String stateMachineName, String name, Bits value) {
		m_tester_input.setStateMachineMappedReg(stateMachineName, name, _Utils.toImp(value));
	}

	public double getScalarOutput(String name) {
		return m_tester_output.getMappedReg(name);
	}

	public Bits getScalarOutputRaw(String name) {
		return _Utils.fromImp(m_tester_output.getMappedRegRaw(name));
	}

	public double getStateMachineScalarOutput(String stateMachineName, String name) {
		return m_tester_output.getStateMachineMappedReg(stateMachineName, name);
	}

	public Bits getStateMachineScalarOutputRaw(String stateMachineName, String name) {
		return _Utils.fromImp(m_tester_output.getStateMachineMappedRegRaw(stateMachineName, name));
	}

	public void setStreamOffsetParam(String name, int value) {
		Set<String> names = m_design_data.getStreamOffsetManager().getOffsetParams().keySet();
		if (!names.contains(name))
			throw new MaxCompilerAPIError(this, "Stream offset param '%s' does not exist.", name);

		m_tester_input.setVariableSizeValue(name, value);
	}

	public int getOffsetAutoLoopSize(String name) {
		if (!m_design_data.getStreamOffsetManager().getOffsetAutoLoops().containsKey(name))
			throw new MaxCompilerAPIError(this, "OffsetAutoLoop '%s' does not exist.", name);

		if (!m_all_stream_offset_params_set) {
			Set<String> params = m_design_data.getStreamOffsetManager().getOffsetParams().keySet();
			for (String param : params)
				if (!m_tester_input.isVariableSizeValueSet(param))
					throw new MaxCompilerAPIError(
						this,
						"Stream offset param '%s' not set. " +
						"All stream offset params have to be set before querying an OffsetAutoLoop.", param);

			m_all_stream_offset_params_set = true;
		}

		int var_value = m_tester_input.evalStreamOffsetVar(m_design_data.getSoftwareManager(), name);

		return var_value;
	}

	public int getStreamDistance(String name) {
		Map<String, DistanceMeasurement> measurements = m_design_data.getStreamOffsetManager().getDistanceMeasurements();
		if (!measurements.containsKey(name))
			throw new MaxCompilerAPIError(this, "Stream distance measurement '%s' does not exist.", name);

		if (!m_all_stream_offset_params_set) {
			Set<String> params = m_design_data.getStreamOffsetManager().getOffsetParams().keySet();
			for (String param : params)
				if (!m_tester_input.isVariableSizeValueSet(param))
					throw new MaxCompilerAPIError(
						this,
						"Stream offset param '%s' not set. " +
						"All stream offset params have to be set before querying a stream distance measurement.", param);

			m_all_stream_offset_params_set = true;
		}

		int var_value = m_tester_input.evalStreamOffsetVar(m_design_data.getSoftwareManager(), name);

		return var_value;
	}

	public void setInputDataRaw(String group_name, String stream_name, List<Bits> data) {
		m_tester_input.setInputDataRaw(group_name, stream_name, _Utils.toImp(data));
	}

	public void setInputDataRaw(String group_name, String stream_name, Bits... data) {
		m_tester_input.setInputData(group_name, stream_name, _Utils.toImp(data));
	}

	public void setInputDataRaw(String input_name, Bits... data) {
		m_tester_input.setInputData(input_name, _Utils.toImp(data));
	}

	public void setInputDataRaw(String input_name, List<Bits> data) {
		m_tester_input.setInputDataRaw(input_name, _Utils.toImp(data));
	}

	public void setInputDataLong(String group_name,	String stream_name,	long... data) {
		m_tester_input.setInputDataLong(group_name, stream_name, data);
	}

	public void setInputDataLong(String input_name, long... data) {
		m_tester_input.setInputDataLong(input_name, data);
	}

	public void setInputData(String group_name,	String stream_name,	double... data) {
		m_tester_input.setInputData(group_name, stream_name, data);
	}

	public void setInputData(String group_name,String stream_name, List<Double> data) {
		m_tester_input.setInputData(group_name, stream_name, data);
	}

	public void setInputData(String input_name, double... data) {
		m_tester_input.setInputData(input_name, data);
	}

	public void setInputData(String input_name, List<Double> data) {
		m_tester_input.setInputData(input_name, data);
	}

	public void ioForceDisabled(String io_name, boolean disabled) {
		setScalarInput("io_" + io_name + "_force_disabled", disabled ? 1 : 0);
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getOutputData(KernelType<?> type, String group_name, String stream_name) {
		List<T> res_data = new ArrayList<T>();
		List<Bits> raw_data = getOutputDataRaw(group_name, stream_name);

		for(Bits raw_datum : raw_data)
			res_data.add((T)type.decodeConstant(raw_datum));

		return res_data;
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getOutputData(KernelType<?> type, String output_name) {
		List<T> res_data = new ArrayList<T>();
		List<Bits> raw_data = getOutputDataRaw(output_name);

		for(Bits raw_datum : raw_data)
			res_data.add((T)type.decodeConstant(raw_datum));

		return res_data;
	}

	public List<Double> getOutputData(String group_name, String stream_name) {
		return m_tester_output.getOutputData(group_name, stream_name);
	}

	public List<Double> getOutputData(String output_name) {
		return m_tester_output.getOutputData(output_name);
	}

	public double[] getOutputDataArray(String group_name, String stream_name) {
		return m_tester_output.getOutputDataArray(group_name, stream_name);
	}

	public double[] getOutputDataArray(String output_name) {
		return m_tester_output.getOutputDataArray(output_name);
	}

	public List<Long> getOutputDataLong(String output_name) {
		return m_tester_output.getOutputDataLong(output_name);
	}

	public long[] getOutputDataLongArray(String output_name) {
		return m_tester_output.getOutputDataLongArray(output_name);
	}

	public List<Long> getOutputDataLong(String group_name, String stream_name) {
		return m_tester_output.getOutputDataLong(group_name, stream_name);
	}

	public long[] getOutputDataLongArray(String group_name, String stream_name) {
		return m_tester_output.getOutputDataLongArray(group_name, stream_name);
	}

	public List<Bits> getOutputDataRaw(String group_name, String stream_name) {
		return _Utils.fromImp(m_tester_output.getOutputDataRaw(group_name, stream_name));
	}

	public Bits[] getOutputDataRawArray(String group_name, String stream_name) {
		return _Utils.fromImp(m_tester_output.getOutputDataRawArray(group_name, stream_name));
	}

	public List<Bits> getOutputDataRaw(String output_name) {
		return _Utils.fromImp(m_tester_output.getOutputDataRaw(output_name));
	}

	public Bits[] getOutputDataRawArray(String output_name) {
		return _Utils.fromImp(m_tester_output.getOutputDataRawArray(output_name));
	}

	public void checkOutputDataRange(String group_name,	String stream_name,	int start,
		int end, double... values)
	{
		try {
			m_output_data_checker.checkOutputDataRange(group_name, stream_name, start, end, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataRange(String output_name, int start,	int end,
		double... values)
	{
		try {
			m_output_data_checker.checkOutputDataRange(output_name, start, end, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputData(String group_name, String stream_name, double... values) {
		try {
			m_output_data_checker.checkOutputData(group_name, stream_name, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputData(String output_name, double... values) {
		try {
			m_output_data_checker.checkOutputData(output_name, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataRaw(String output_name, Bits... values) {
		try {
			m_output_data_checker.checkOutputDataRaw(output_name, _Utils.toImp(values));
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataRaw(String group_name, String stream_name, Bits... values) {
		try {
			m_output_data_checker.checkOutputDataRaw(group_name, stream_name, _Utils.toImp(values));
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataRangeRaw(String output_name, int start,	int end, Bits... values) {
		try {
			m_output_data_checker.checkOutputDataRangeRaw(output_name, start, end, _Utils.toImp(values));
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataRangeRaw(String group_name, String stream_name, int start, int end, Bits... values) {
		try {
			m_output_data_checker.checkOutputDataRangeRaw(group_name, stream_name, start, end, _Utils.toImp(values));
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}


	public void checkOutputDataRangeLong(String group_name,	String stream_name,	int start,
		int end, long... values)
	{
		try {
			m_output_data_checker.checkOutputDataRangeLong(group_name, stream_name, start, end, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataRangeLong(String output_name, int start,	int end, long... values) {
		try {
			m_output_data_checker.checkOutputDataRangeLong(output_name, start, end, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataLong(String group_name, String stream_name, long... values) {
		try {
			m_output_data_checker.checkOutputDataLong(group_name, stream_name, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void checkOutputDataLong(String name, long... values) {
		try {
			m_output_data_checker.checkOutputDataLong(name, values);
		} catch (CheckDataException e) {
			throw new SimulationOutputCheckException(this, e.formatMessage(false));
		}
	}

	public void dumpOutput() {
		m_tester_output.dumpOutput(m_kernel.io.getOutputs());
	}


	public void dumpExceptions() {
		m_tester_output.dumpExceptions(_Managers.getBuildManager(this));
	}

	public void runTest() {
		if (_Kernel.isCPUControlled(m_kernel) && !m_have_set_cycle_count)
			throw new MaxCompilerAPIError(this, "Must call setKernelCycles before runTest.");

		build();
		run();
	}

	@Override
	public void setBuildConfig(BuildConfig config) {
		logWarning(
			"SingleKernelSimulationManager does not perform a hardware build. BuildConfig ignored.");
	}

	@Override
	public BuildConfig getBuildConfig() {
		throw new MaxCompilerAPIError(this, "SingleKernelSimulationManager does not perform a hardware build.");
	}

	@Override
	protected void realBuild() { m_photon_tester.build(); }

	public void run(String name) {
		if (_Kernel.isCPUControlled(m_kernel) && !m_have_set_cycle_count)
			throw new MaxCompilerAPIError(this, "Must call setKernelCycles before run.");

		try {
			m_tester_input.setupVariableSizeMappedRegs(m_design_data.getSoftwareManager());
		} catch (InvalidStreamOffsetParam e) {
			throw new MaxCompilerAPIError(this, e.getMessage());
		}

		BuildManager buildManager = _Managers.getBuildManager(this);
		String simName = (name == null || name.length() == 0) ? "" : " '" + name + "'";
		buildManager.logProgress("Running simulation" + simName);

		Date startTime = new Date();
		m_photon_tester.run(name);
		AmountOfTime simulationTime = AmountOfTime.durationBetween(startTime, new Date());
		buildManager.logProgress("Simulation finished (took " + simulationTime + ")");
	}

	public void run() { run(null); }

	public KernelParameters makeKernelParameters() {
		return makeKernelParameters(getName() + "Kernel");
	}

	public void setKernelCycles(long cycles) {
		final long maxCycles = (1l << 48) - 1;
		if (cycles < 0 || maxCycles < cycles)
			throw new MaxCompilerAPIError(this, "Number of cycles must be between 0 and " + maxCycles + " (inclusive).");
		if (!_Kernel.isCPUControlled(m_kernel))
			throw new MaxCompilerAPIError(this, "Kernel '" + m_kernel + "' is not CPU code controlled.");

		Bits b = new Bits(48);
		b.setBits(cycles);
		setScalarInput("run_cycle_count", b);
		m_have_set_cycle_count = true;
	}
}
