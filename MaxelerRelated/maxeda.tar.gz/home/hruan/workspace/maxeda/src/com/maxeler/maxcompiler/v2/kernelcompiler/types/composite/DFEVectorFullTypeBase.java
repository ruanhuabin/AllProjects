package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.FullType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

public class DFEVectorFullTypeBase
	<
		ContainedT extends KernelObjectVectorizable<ContainedT>,
		MPRealT extends DFEVectorBase<ContainedT, MPRealT, ?, ?>,
		CompareT extends DFEVectorBase<DFEVar, CompareT, ?, ?>
	>
	extends FullType
	<
		DFEVectorDoubtType,
		DFEVectorTypeBase<ContainedT, MPRealT, CompareT>,
		MPRealT
	>
{
	protected DFEVectorFullTypeBase(
		DFEVectorDoubtType doubt_type,
		DFEVectorTypeBase<ContainedT, MPRealT, CompareT> kernel_type)
	{
		super(doubt_type, kernel_type);
	}
}
