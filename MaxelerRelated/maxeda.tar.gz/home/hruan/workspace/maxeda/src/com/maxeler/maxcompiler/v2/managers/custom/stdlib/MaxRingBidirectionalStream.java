package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxeleros.managercompiler.libs.InterChipDefinition.InterChipStream;

public class MaxRingBidirectionalStream {
	private final InterChipStream m_imp;
	private final String m_name;

	MaxRingBidirectionalStream(String name, InterChipStream stream) {
		m_name = name;
		m_imp = stream;
	}

	public DFELink getStreamToRemoteFPGA() {
		return _CustomManagers.fromImp(m_imp.getOutputStream(m_name+"_out"));
	}

	public DFELink getStreamFromRemoteFPGA() {
		return _CustomManagers.fromImp(m_imp.getInputStream(m_name+"_in"));
	}
}
