package com.maxeler.maxcompiler.v2.kernelcompiler.types;

public abstract class DoubtType {
	abstract public boolean hasDoubtInfo();

	abstract public int getTotalBits();

	abstract public DoubtType union(DoubtType other_type);

	@Override
	abstract public String toString();

	@Override
	abstract public boolean equals(Object other);
}
