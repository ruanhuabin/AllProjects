package com.maxeler.maxcompiler.v2.kernelcompiler.tests;
import java.util.List;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortParams;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamWriteMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
/**
 * Tests a mapped ram that needs two CGBlockMems..
 */
public class MappedRam2xTest extends Kernel {
	protected MappedRam2xTest(KernelParameters parameters) {
		super(parameters);

		// Mapped RAM
		DFEVar addrIn = io.input("addrIn", dfeUInt(64)).cast(dfeUInt(10));
		DFEVar dataIn = io.input("dataIn", dfeFloat(11, 53)).cast(dfeFloat(7, 41));

		RamPortParams<DFEVar> port_params =
			mem.makeRamPortParams(RamPortMode.READ_WRITE, addrIn, dataIn);
		DFEVar ramOut = mem.ramMapped("mappedRam", 1024, RamWriteMode.WRITE_FIRST, port_params);
		io.output("ramOut", dfeFloat(11, 53)) <== ramOut.cast(dfeFloat(11, 53));
	}

	public static void main(String[] args) {
		double[] addrs = {0,  1,  2,  3};
		double[] data = {30, 31, 32, 33};

		_DualSimulationManager m = new _DualSimulationManager("MappedRam2x");
		Kernel a = new MappedRam2xTest(m.makeKernelParameters_A());
		Kernel b = new MappedRam2xTest(m.makeKernelParameters_B());
		m.setKernels(a, b);
		m.build();

		m.setInputData("addrIn", addrs);
		m.setInputData("dataIn", data);
		m.setKernelCycles(data.length);
		m.run();

		int status = 0;
		List<Double> values_stream = m.getOutputData("ramOut");
		for (int i=0; i<data.length; i++) {
			double value = m.getMappedRam("mappedRam", i);
			double value_a = m.getManager_A().getMappedRam("mappedRam", i);
			double value_b = m.getManager_B().getMappedRam("mappedRam", i);

			if (value != data[i] || value != value_a || value != value_b) {
				System.out.println("Mismatch at addr "+i+": "+ value + " != " + data[i]);
				status = 1;
			}

			if (data[i] != values_stream[i].floatValue()) {
				System.out.println("Output stream mismatch at addr "+i+": "+ values_stream[i] + " != " + data[i]);
				status = 1;
			}
		}
		if (status == 0)
			System.out.println("Test passed.");
		else
			System.out.println("Test FAILED.");
		System.exit(status);
	}
}
