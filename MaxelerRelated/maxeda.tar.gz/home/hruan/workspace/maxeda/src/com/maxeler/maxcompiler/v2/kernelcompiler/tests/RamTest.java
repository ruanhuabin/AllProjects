package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v0.utils.MathUtils;
import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Count.Counter;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Count.WrapMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.DualPortMemOutputs;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortParams;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamWriteMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.standard.Manager;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard.Manager.IOType;
import com.maxeler.maxcompiler.v2.utils.Bits;


public class RamTest {

	// Only change HALF_DATA_SIZE manually!
	private static final int HALF_DATA_SIZE = 12800;
	private static final int DATA_SIZE = HALF_DATA_SIZE * 2;

	private static final int OVERWRITE_CONSTANT = 123;

	private static final KernelType<DFEVar> DATA_TYPE = Kernel.dfeUInt(32);
	private static final KernelType<DFEVar> ADDRESS_TYPE = Kernel.dfeUInt(32);

	// Test data
	private static Bits[] in_data = new Bits[DATA_SIZE];
	private static Bits[] in_write_enable = new Bits[DATA_SIZE];
	private static Bits[] in_input_address = new Bits[DATA_SIZE];
	private static Bits[] in_output_address = new Bits[HALF_DATA_SIZE];

	private static Bits[] expected_reverse = new Bits[HALF_DATA_SIZE];
	private static Bits[] expected_constant = new Bits[HALF_DATA_SIZE];


	public static void main(String[] args) {

		if (args.length > 0 && args[0].equals("buildHW")) {
			buildHardware();
			return;
		}

		// Generate random write_enable and address sequences
		List<Boolean> tmp_rnd_write_enable = new ArrayList<Boolean>(DATA_SIZE);
		List<Integer> tmp_rnd_in_address = new ArrayList<Integer>(DATA_SIZE);

		for (int i = 0; i < DATA_SIZE; ++i)
			tmp_rnd_write_enable.add(i < HALF_DATA_SIZE);

		for (int i = 0; i < HALF_DATA_SIZE; ++i)
			tmp_rnd_in_address.add(i);

		long seed = System.currentTimeMillis();
		Random random = new Random(seed);
		Collections.shuffle(tmp_rnd_write_enable, random);
		Collections.shuffle(tmp_rnd_in_address, random);

		// Generate test data
		int cnt = 0;
		for (int i = 0; i < DATA_SIZE; ++i) {
			boolean enable = tmp_rnd_write_enable.get(i).booleanValue();
			in_write_enable[i] = DATA_TYPE.encodeConstant(enable);

			in_input_address[i] = enable ?
				ADDRESS_TYPE.encodeConstant(tmp_rnd_in_address.get(cnt)) : ADDRESS_TYPE.encodeConstant(0);

			in_data[i] = DATA_TYPE.encodeConstant(i + 1);

			if (enable) {
				in_output_address[HALF_DATA_SIZE - cnt - 1] =
					ADDRESS_TYPE.encodeConstant(tmp_rnd_in_address.get(cnt));
				expected_reverse[HALF_DATA_SIZE - cnt - 1] = DATA_TYPE.encodeConstant(i+1);
				expected_constant[cnt] = DATA_TYPE.encodeConstant(OVERWRITE_CONSTANT);
				++cnt;
			}
		}

		// Run test


		_DualSimulationManager manager = new _DualSimulationManager("RamTest");

		manager.logMsg("Running RamTest");
		manager.logMsg("RamTest seed: " + seed);

		manager.logMsg("RamTest using address counters");
		runTest(manager, true, true);

		manager = new _DualSimulationManager("RamTest");
		runTest(manager, true, false);

		manager = new _DualSimulationManager("RamTest");

		manager.logMsg("RamTest using address stream");
		runTest(manager, false, true);

		manager = new _DualSimulationManager("RamTest");
		runTest(manager, false, false);

		manager.logMsg("RamTest passed");
	}


	private static void runTest(_DualSimulationManager manager, boolean use_counters, boolean dual_port_only) {

		manager.setKernels(new RamTestKernel(manager.makeKernelParameters_A(), dual_port_only),
			               new RamTestKernel(manager.makeKernelParameters_B(), dual_port_only) );

		manager.setKernelCycles(DATA_SIZE + HALF_DATA_SIZE);

		manager.setScalarInput("in_use_counter", DATA_TYPE.encodeConstant(use_counters));
		manager.setInputDataRaw("in_data", in_data);
		manager.setInputDataRaw("in_write_enable", in_write_enable);
		manager.setInputDataRaw("in_address", in_input_address);
		manager.setInputDataRaw("out_address", in_output_address);

		manager.runTest();

		try {
			if (dual_port_only) {
				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData1_readFirst", expected_reverse);
				//compareOutput(manager.getManager_A(), manager.getManager_B(), "outData1_writeFirst", expected_reverse);

				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData2_readFirst", expected_reverse);
				//compareOutput(manager.getManager_A(), manager.getManager_B(), "outData2_writeFirst", expected_reverse);

				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData3_readFirst", expected_reverse);
				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData3_writeFirst", expected_constant);

				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData6_readFirst", expected_reverse);
			}
			else {
				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData4_readFirst", expected_reverse);
				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData4_writeFirst", expected_constant);

				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData5_readFirst", expected_reverse);
				compareOutput(manager.getManager_A(), manager.getManager_B(), "outData5_writeFirst", expected_reverse);
			}
		}
		catch (TestFailedException e)
		{
			manager.logMsg("RamTest failed");
			System.exit(1);
		}
	}

	private static void compareOutput(SimulationManager manager_A, SimulationManager manager_B, String out_name, Bits[] b) throws TestFailedException {
		boolean pass = true;
		List<Bits> a_A = manager_A.getOutputDataRaw(out_name);
		List<Bits> a_B = manager_B.getOutputDataRaw(out_name);

		for (int i = 0; i < HALF_DATA_SIZE; ++i) {
			if (!a_A.get(i).equals(a_B.get(i))) {
				manager_A.logMsg("Managers disagree at " + out_name + "[" + i + "]");
				manager_A.logMsg("  output A:   " + a_A.get(i) + " (" + DATA_TYPE.decodeConstant(a_A.get(i)) + ")");
				manager_A.logMsg("  output B:   " + a_B.get(i) + " (" + DATA_TYPE.decodeConstant(a_B.get(i)) + ")");
				manager_A.logMsg("  expected: " + b[i] + " (" + DATA_TYPE.decodeConstant(b[i]) + ")");
				pass = false;
			}
			else if (!a_A.get(i).equals(b[i])) {
				manager_A.logMsg("Unexpected output at " + out_name + "[" + i + "]");
				manager_A.logMsg("  output:   " + a_A.get(i) + " (" + DATA_TYPE.decodeConstant(a_A.get(i)) + ")");
				manager_A.logMsg("  expected: " + b[i] + " (" + DATA_TYPE.decodeConstant(b[i]) + ")");
				pass = false;
			}
		}

		if (!pass)
			throw new TestFailedException();
	}

	private static void buildHardware() {
		Manager m = new Manager(new _EngineParameters("RamTest1", /*MAX3BoardModel.MAX3424A*/ MAX2BoardModel.MAX24412C, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
		m.setKernel(new RamTestKernel(m.makeKernelParameters(), true));
		m.setIO(IOType.ALL_CPU);
		m.build();

		m = new Manager(new _EngineParameters("RamTest2", /*MAX3BoardModel.MAX3424A*/ MAX2BoardModel.MAX24412C, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
		m.setKernel(new RamTestKernel(m.makeKernelParameters(), false));
		m.setIO(IOType.ALL_CPU);
		m.build();
	}

	private static class TestFailedException extends Exception {
		private static final long serialVersionUID = 1L;
	}

	private static class RamTestKernel extends Kernel {

		public RamTestKernel(KernelParameters parameters, boolean dual_port_only) {

			super(parameters);

			Counter in_counter = control.count.makeCounter(
				control.count.makeParams(MathUtils.bitsToAddress(DATA_SIZE + 1))
				.withMax(DATA_SIZE)
				.withWrapMode(WrapMode.STOP_AT_MAX));

			DFEVar read_input = in_counter.getCount() < DATA_SIZE;

			DFEVar in_data = io.input("in_data", DATA_TYPE, read_input);
			DFEVar in_write_enable = io.input("in_write_enable", DATA_TYPE, read_input).cast(dfeBool());
			DFEVar in_input_address = io.input("in_address", DATA_TYPE, read_input);
			DFEVar in_output_address = io.input("out_address", DATA_TYPE, ~read_input);
			DFEVar in_use_counter = io.scalarInput("in_use_counter", DATA_TYPE).cast(dfeBool());

			Counter in_address_counter = control.count.makeCounter(
				control.count.makeParams(DATA_TYPE.getTotalBits())
				.withMax(HALF_DATA_SIZE - 1)
				.withWrapMode(WrapMode.STOP_AT_MAX)
				.withEnable(in_write_enable));

			Counter out_address_counter = control.count.makeCounter(
				control.count.makeParams(DATA_TYPE.getTotalBits())
				.withMax(HALF_DATA_SIZE)
				.withEnable(~read_input));

			DFEVar overwrite_data = constant.var(
				DATA_TYPE.newInstance(this).getType(),
				DATA_TYPE.encodeConstant(OVERWRITE_CONSTANT));

			DFEVar in_address = in_use_counter ?
				in_address_counter.getCount() : in_input_address;

			DFEVar out_address = in_use_counter ?
				HALF_DATA_SIZE - 1 - out_address_counter.getCount() : in_output_address;

			DFEVar address = read_input ? in_address : out_address;
			address = address.cast(Kernel.dfeUInt(MathUtils.bitsToAddress(HALF_DATA_SIZE)));

			// Test dual port RAM -------------------------------------------------------------------

			RamPortParams<DFEVar> input_port = mem.makeRamPortParams(
				RamPortMode.WRITE_ONLY,
				address,
				DATA_TYPE)
				.withDataIn(in_data)
				.withWriteEnable(in_write_enable & read_input);

			RamPortParams<DFEVar> input_port_always_on = mem.makeRamPortParams(
				RamPortMode.WRITE_ONLY,
				address,
				DATA_TYPE)
				.withDataIn(read_input ? in_data : overwrite_data)
				.withWriteEnable(in_write_enable | ~read_input);

			RamPortParams<DFEVar> output_port = mem.makeRamPortParams(
				RamPortMode.READ_ONLY,
				address,
				DATA_TYPE);

			RamPortParams<DFEVar> input_output_port_always_on = mem.makeRamPortParams(
				RamPortMode.READ_WRITE,
				address,
				DATA_TYPE)
				.withDataIn(read_input ? in_data : overwrite_data)
				.withWriteEnable(in_write_enable | ~read_input);

			RamPortParams<DFEVar> input_output_port_no_overwrite= mem.makeRamPortParams(
				RamPortMode.READ_WRITE,
				address,
				DATA_TYPE)
				.withDataIn(in_data)
				.withWriteEnable(in_write_enable & read_input);

			RamPortParams<DFEVar> input_output_port_out_overwrite = mem.makeRamPortParams(
				RamPortMode.READ_WRITE,
				address,
				DATA_TYPE)
				.withDataIn(overwrite_data)
				.withWriteEnable(~read_input);

			if (dual_port_only) {
				// WRITE_FIRST / READ_FIRST with port *A* as input

				DualPortMemOutputs<DFEVar> ram = mem.ramDualPort(
					HALF_DATA_SIZE,
					RamWriteMode.READ_FIRST,
					input_port,
					output_port);

				io.output("outData1_readFirst", ram.getOutputB(), DATA_TYPE, ~read_input);

				// Unsupported WRITE_FIRST two-port RAM
//				DualPortMemOutputs<DFEVar> ram2 = mem.ramDualPort(
//					HALF_DATA_SIZE,
//					RamWriteMode.WRITE_FIRST,
//					input_port,
//					output_port);
//
//				io.output("outData1_writeFirst", ram2.getOutputB(), DATA_TYPE, ~read_input);


				// WRITE_FIRST / READ_FIRST with port *B* as input

				DualPortMemOutputs<DFEVar> ram3 = mem.ramDualPort(
					HALF_DATA_SIZE,
					RamWriteMode.READ_FIRST,
					output_port,
					input_port);

				io.output("outData2_readFirst", ram3.getOutputA(), DATA_TYPE, ~read_input);

				// Unsupported WRITE_FIRST two-port RAM
//				DualPortMemOutputs<DFEVar> ram4 = mem.ramDualPort(
//					HALF_DATA_SIZE,
//					RamWriteMode.WRITE_FIRST,
//					output_port,
//					input_port);
//
//				io.output("outData2_writeFirst", ram4.getOutputA(), DATA_TYPE, ~read_input);


				// WRITE_FIRST / READ_FIRST with two READ_WRITE ports

				DualPortMemOutputs<DFEVar> ram5 = mem.ramDualPort(
					HALF_DATA_SIZE,
					RamWriteMode.READ_FIRST,
					input_port,
					input_output_port_out_overwrite);

				io.output("outData3_readFirst", ram5.getOutputB(), DATA_TYPE, ~read_input);


				DualPortMemOutputs<DFEVar> ram6 = mem.ramDualPort(
					HALF_DATA_SIZE,
					RamWriteMode.WRITE_FIRST,
					input_port,
					input_output_port_out_overwrite);

				io.output("outData3_writeFirst", ram6.getOutputB(), DATA_TYPE, ~read_input);

				// READ_FRIST on two-port (WRITE_FIRST is undefined)

				DualPortMemOutputs<DFEVar> ram11 = mem.ramDualPort(
					HALF_DATA_SIZE,
					RamWriteMode.READ_FIRST,
					input_port_always_on,
					output_port);

				io.output("outData6_readFirst", ram11.getOutputB(), DATA_TYPE, ~read_input);
			}
			else {

				// Test single port RAM -------------------------------------------------------------------

				// WRITE_FIRST / READ_FIRST

				DFEVar ram7 = mem.ram(
					HALF_DATA_SIZE ,
					RamWriteMode.READ_FIRST,
					input_output_port_always_on);

				io.output("outData4_readFirst", ram7, DATA_TYPE, ~read_input);

				DFEVar ram8 = mem.ram(
					HALF_DATA_SIZE,
					RamWriteMode.WRITE_FIRST,
					input_output_port_always_on);

				io.output("outData4_writeFirst", ram8, DATA_TYPE, ~read_input);

				// WRITE_FIRST / READ_FIRST no overwrite

				DFEVar ram9 = mem.ram(
					HALF_DATA_SIZE,
					RamWriteMode.READ_FIRST,
					input_output_port_no_overwrite);

				io.output("outData5_readFirst", ram9, DATA_TYPE, ~read_input);

				DFEVar ram10 = mem.ram(
					HALF_DATA_SIZE,
					RamWriteMode.WRITE_FIRST,
					input_output_port_no_overwrite);

				io.output("outData5_writeFirst", ram10, DATA_TYPE, ~read_input);
			}
		}
	}
}
