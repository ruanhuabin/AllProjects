package com.maxeler.maxcompiler.v2.kernelcompiler.types;

/**
 * Allows Java to statically check
 * that types used in multipipes are valid (i.e.&nbsp;not other multipipe objects).
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompile/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public abstract class KernelTypeVectorizable<InstanceT> extends KernelType<InstanceT> {
}
