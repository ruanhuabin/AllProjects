package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.utils.CreationLogger;

/**
 * Object needed to construct a {@link Kernel}.
 */
public class KernelParameters {
	private final String m_name;
	private final DFEManager m_manager;
	private CreationLogger m_used_point;
	private final KernelConfiguration m_kernel_config;

	// DO NOT MAKE PUBLIC
	// Only DFEManagers are supposed to construct these objects
	// so they can keep track of duplicate names. This is a cumbersome
	// way of keeping track of duplicate names, but management says
	// we have to have this object so might as well use it for something...
	KernelParameters(DFEManager manager, String name, KernelConfiguration kernel_config) {
		m_name = name;
		m_manager = manager;

		// make a copy of the KernelConfiguration as some values may be changed
		// inside the kernel constructor. Mark the object passed in as
		// immutable.
		m_kernel_config = kernel_config.getImmutableCopy();
		kernel_config.setImmutable();
	}

	void use() {
		if(m_used_point != null)
			throw new MaxCompilerAPIError(m_manager,
				"A new KernelParameters object must be created for each Kernel. " +
				"This kernel parameters was previously used here:\n" +
				m_used_point.getCreationStackTraceString());

		m_used_point = new CreationLogger( _Managers.getBuildManager(m_manager) );
	}

	public String getName() {
		return m_name;
	}

	public DFEManager getManager() {
		return m_manager;
	}

	// only used by Kernel's constructor
	KernelConfiguration getKernelConfiguration() {
		return m_kernel_config;
	}
}
