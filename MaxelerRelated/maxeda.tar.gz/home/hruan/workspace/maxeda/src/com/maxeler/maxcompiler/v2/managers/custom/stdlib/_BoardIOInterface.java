package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControlGroup.MemoryAccessPattern;
import com.maxeler.maxeleros.ip.Ethernet.NetworkConnection;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.libs.NetworkInterfacePlugin;
import com.maxeler.maxeleros.managercompiler.libs.NetworkLinkSpeed;
import com.maxeler.maxeleros.managercompiler.libs.TimestampingIOFactory.TimestampingIOFormat;


public interface _BoardIOInterface {
	MaxRingBidirectionalStream addMaxRingBirectionalStream(String name, MaxRingConnection connection);
	DFELink addStreamFromHost(String name);
	DFELink addStreamToHost(String name);
	DFELink addStreamToOnCardMemory(String name, MemoryControlGroup control_stream);
	DFELink addStreamFromOnCardMemory(String name, MemoryControlGroup control_stream);
	void setEnableHideParityBitsForStream(DFELink stream, boolean hide_parity_bits);
	DFELink getDebugStreamFromCardMemory(String name);

	MemoryControlGroup addMemoryControlGroup(String name, DFELink control_stream);
	MemoryControlGroup addMemoryControlGroup(String name, MemoryAccessPattern pattern);

	void setNetworkInterfacePlugin(NetworkInterfacePlugin plugin);
	DFELink addStreamFromNetwork(int port, String name);
	DFELink addStreamToNetwork(int port, String name);
	WrapperClock getNetworkInterfaceClock(int port);

	/**
	 * Return a NetworkInterfacePlugin which provides raw Ethernet streams that can
	 * be used with {@link #setNetworkInterfacePlugin(NetworkInterfacePlugin)} etc.
	 */
	NetworkInterfacePlugin getDefaultEthernetPlugin(NetworkLinkSpeed link_speed, boolean bypass_fifo);

	void setNetworkInterfacePlugin(NetworkConnection connection, NetworkInterfacePlugin plugin);
	boolean hasNetworkConnectionGotPlugin(NetworkConnection connection);
	DFELink addStreamFromNetwork(NetworkConnection connection, int port, String name);
	DFELink addStreamToNetwork(NetworkConnection connection, int port, String name);
	WrapperClock getNetworkInterfaceClock(NetworkConnection connection, int port);
	void setIFPGALinkClock(WrapperClock clock);
	void setHostStreamClock(WrapperClock clock);
	void setMemoryStreamClock(WrapperClock clock);

	void setNumberOfPCIExpressLanes(int num_lanes);
	void setEnablePCIExpressFastClock(boolean fast_clock);
	void setMaxRingNumLanes(MaxRingConnection connection, int num_lanes);
	void setMemoryControllerConfig(MemoryControllerConfig config);
	void setOnCardMemoryFrequency(double freq_mhz);
	double getOnCardMemoryFrequency();

	WrapperClock getMemoryCoreClock();

	DFELink addTimestampStream(String name, WrapperClock clock, TimestampingIOFormat format, int decimal_precision);

	void finalise();
}
