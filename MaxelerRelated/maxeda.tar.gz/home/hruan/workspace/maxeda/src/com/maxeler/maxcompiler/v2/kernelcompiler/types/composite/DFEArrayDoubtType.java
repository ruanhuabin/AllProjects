package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;

public class DFEArrayDoubtType extends DoubtType {
	private final DoubtType m_contained_doubt_type;
	private final int m_size;

	DFEArrayDoubtType(DoubtType contained_doubt_type, int size) {
		m_contained_doubt_type = contained_doubt_type;
		m_size = size;
	}

	public DoubtType getContainedDoubtType() {
		return m_contained_doubt_type;
	}

	@Override
	public boolean hasDoubtInfo() {
		return m_contained_doubt_type.hasDoubtInfo();
	}

	@Override
	public int getTotalBits() {
		return m_contained_doubt_type.getTotalBits() * m_size;
	}

	@Override
	public String toString() {
		return "DFEArrayDoubtType<" + m_contained_doubt_type + ">";
	}

	@Override
	public boolean equals(Object other) {
		return
			other instanceof DFEArrayDoubtType &&
			((DFEArrayDoubtType)other).m_contained_doubt_type.equals(m_contained_doubt_type) &&
			m_size == ((DFEArrayDoubtType)other).m_size;
	}

	@Override
	public int hashCode() {
		return m_contained_doubt_type.hashCode();
	}

	@Override
	public DFEArrayDoubtType union(DoubtType other_type) {
		if(!(other_type instanceof DFEArrayDoubtType))
			throw new MaxCompilerAPIError("Can only union with another DFEArrayDoubtType object.");

		DFEArrayDoubtType karray_doubt_type = (DFEArrayDoubtType)other_type;

		return
			new DFEArrayDoubtType(m_contained_doubt_type.union(karray_doubt_type.m_contained_doubt_type), m_size);
	}
}
