package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._AlreadyConnectedException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizableNull;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types._InternalUtils;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.Var;
import com.maxeler.photon.hw.Shifter.ShiftDirection;
import com.maxeler.photon.nodes.NodeWordLevelShift;

/**
 * A stream of {@link DFEArrayType} data.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFEArray
	<ContainedT extends KernelObjectNotVector<ContainedT>>
	extends KernelObjectVectorizableNull<DFEArray<ContainedT>>
{
	private final Kernel m_design;

	private final List<ContainedT> m_elements;
	private final DFEArrayType<ContainedT> m_type;
	private final DFEArrayDoubtType m_doubt_type;

	/**
	 * This should only be called by DFEArrayType.newInstance()
	 */
	DFEArray(
		List<ContainedT> elements,
		DFEArrayType<ContainedT> type,
		DFEArrayDoubtType doubt_type)
	{
		if(elements.size() < 1)
			throw new MaxCompilerAPIError(getKernel().getManager(), "DFEArray of size < 1 not supported");

		for(int i = 0; i < elements.size(); i++)
			if(!elements.get(i).getDoubtType().equals(doubt_type.getContainedDoubtType()))
				throw new MaxCompilerAPIError(getKernel().getManager(),
					"Doubt-type of elements used to construct DFEArray do " +
					"not all match requierd doubt-type of "
					+ doubt_type.getContainedDoubtType() + ", element at index " + i +
					" has doubt-type " + elements.get(i).getDoubtType());

		m_design = elements.get(0).getKernel();
		m_elements = elements;
		m_type = type;
		m_doubt_type = doubt_type;
	}

	/**
	 * Returns the number of elements in the {@code DFEArray}.
	 */
	public int getSize() {
		return m_elements.size();
	}

	/**
	 * Connects the input of the stream at element {@code i} of this {@code DFEArray} to the output of the stream {@code src}.
	 * @param i The index of the stream to connect to {@code src}.
	 * @param src The source stream to connect to.
	 */
	public void connect(int i, ContainedT src) {
		try {
			m_elements.get(i).connect(src);
		} catch (_AlreadyConnectedException e) {
			throw new _AlreadyConnectedException(this, i, e);
		}
	}

	/**
	 * Gets the stream at element {@code i} in the {@code DFEArray}.
	 * <p>
	 * This is also accessible through the overloaded {@code []} operator.
	 */
	public ContainedT get(int i) {
		return m_elements.get(i);
	}

	/**
	 * Returns a {@code List} object containing the streams in the {@code DFEArray}.
	 */
	public List<ContainedT> elementsAsList() {
		return Collections.unmodifiableList(m_elements);
	}

	/**
	 * Returns an array containing the streams in the {@code DFEArray}.
	 */
	@SuppressWarnings("unchecked")
	public ContainedT[] elementsAsArray() {
		ContainedT[] rv = (ContainedT[]) Array.newInstance(m_elements.get(0).getClass(), m_elements.size());
		Object[] rv2 = m_elements.toArray();
		for (int i=0; i<rv.length; ++i)
			rv[i] = (ContainedT)rv2[i];

		return rv;
	}

	//JavaDoc inherited from KernelObject
	@Override
	public DFEArray<ContainedT> connect(DFEArray<ContainedT> src) {
		_InternalUtils.assertConnectTypes(this, src);

		for(int i = 0; i < m_elements.size(); i++)
			connect(i, src.get(i));

		return this;
	}

	//JavaDoc inherited from KernelObject
	@Override
	public DFEArrayType<ContainedT> getType() {
		return m_type;
	}

	@Override
	public DFEArray<ContainedT> dfeWatch(String name) {
		int n = 0;
		for (ContainedT element : m_elements) {
			element.dfeWatch(name + "_" + n++);
		}
		return this;
	}

	/**
	 * Adds a watch to this stream.
	 * <p>
	 * Each stream in the {@code DFEArray} will appear with the name of the watch node appended
	 * with "_i", where {@code i} is its index.
	 * @param name The name for the watch node as it will appear in the output.
	 * @return This stream.
	 */
	@Override
	public DFEArray<ContainedT> watch(String name) {
		int n = 0;
		for(ContainedT element : m_elements)
			element.watch(name + "_" + n++);

		return this;
	}

	//JavaDoc inherited from KernelObject
	@Override
	public Kernel getKernel() {
		return m_design;
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public KernelObject<?> cast(KernelType<?> type) {
		if(type instanceof DFEArrayType)
			return cast((DFEArrayType) type);

		throw new MaxCompilerAPIError(getKernel().getManager(), "Cannot cast from " + getType() + " to " + type);
	}

	/**
	 * Casts this DFEArray stream to a DFEArray stream of DFEArrayType {@code type}.
	 * @param type The DFEArrayType to which to cast this stream.
	 * @return The new stream cast to {@code type}.
	 */
	@SuppressWarnings("unchecked")
	public DFEArray<ContainedT> cast(DFEArrayType<ContainedT> type) {
		if(m_type.getSize() != type.getSize())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot cast DFEArray of type " + getType() + " to type " + type);

		DFEArray<ContainedT> ret = type.newInstance(getKernel());

		for (int i = 0; i < m_elements.size(); i++)
			ret.connect(i, (ContainedT) get(i).cast(type.getContainedType()));

		return ret;
	}

	//JavaDoc inherited from KernelObject
	@Override
	public void setReportOnUnused(boolean v) {
		for(ContainedT elements : m_elements)
			elements.setReportOnUnused(v);
	}

	@Override
	public DFEArray<ContainedT> castDoubtType(DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEArrayDoubtType))
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Can only doubt-type cast DFEArray using DFEArrayDoubtType object.");

		DoubtType entry_doubt_type =
			((DFEArrayDoubtType)doubt_type).getContainedDoubtType();

		List<ContainedT> new_elements = new ArrayList<ContainedT>();
		for(int i = 0; i < m_elements.size(); i++)
			new_elements.add(m_elements.get(i).castDoubtType(entry_doubt_type));

		return new DFEArray<ContainedT>(new_elements, m_type, (DFEArrayDoubtType) doubt_type);
	}

	@Override
	public DFEArrayDoubtType getDoubtType() {
		return m_doubt_type;
	}

	//JavaDoc inherited from KernelObject
	@Override
	public DFEVar pack() {
		if(getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use pack() on this stream as it contains doubt " +
				"information. If you want to explicitly discard this information " +
				"use packWithoutDoubt(), otherwise use packWithDoubt().");

		return packWithoutDoubt();
	}

	@Override
	public DFEVar packWithoutDoubt() {
		if(!getType().isConcreteType())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot pack DFEArray as type " + getType() + " is not concrete.");

		DFEVar packed_var = m_elements.get(0).packWithoutDoubt();
		for(int i = 1; i < m_elements.size(); i++)
			packed_var = m_elements.get(i).packWithoutDoubt().cat(packed_var);

		return packed_var;
	}

	@Override
	public DFEVar packWithDoubt() {
		if(!getType().isConcreteType())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot pack DFEArray as type " + getType() + " is not concrete.");

		DFEVar packed_var = m_elements.get(0).packWithDoubt();
		for(int i = 1; i < m_elements.size(); i++)
			packed_var = m_elements.get(i).packWithDoubt().cat(packed_var);

		return packed_var;
	}

	@Override
	public List<DFEVar> packToList() {
		List<DFEVar> var_list = new ArrayList<DFEVar>();
		for(int i = 0; i < m_elements.size(); i++)
			var_list.addAll(m_elements.get(i).packToList());

		return var_list;
	}

	@Override
	public DFEVar hasDoubt() {
		DFEVar doubt = m_elements.get(0).hasDoubt();
		for(int i = 1; i < m_elements.size(); i++)
			doubt = doubt | m_elements.get(i).hasDoubt();

		return doubt;
	}

	@Override
	public DFEArray<ContainedT> setDoubt(DFEVar doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEArray<ContainedT> setDoubt(boolean doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEArray<ContainedT> setDoubt(DFEVar doubt, SetDoubtOperation operation) {
		if (!getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use setDoubt on this stream as it doesn't contain doubt information.");

		List<ContainedT> new_elements = new ArrayList<ContainedT>();
		for(ContainedT element : m_elements)
			new_elements.add(element.setDoubt(doubt, operation));

		return new DFEArray<ContainedT>(new_elements, m_type, m_doubt_type);
	}

	@Override
	public  DFEArray<ContainedT> setDoubt(boolean doubt, SetDoubtOperation operation) {
		return setDoubt(m_design.constant.var(doubt), operation);
	}

	@SuppressWarnings("unchecked")
	private DFEArray<ContainedT> shiftElements(DFEVar shift, ShiftDirection dir, boolean circular) {
		DFEArrayType<ContainedT> type = getType();
		Kernel kernel = getKernel();
		PhotonDesignData container = _Kernel.getPhotonDesignData(kernel);

		NodeWordLevelShift n = new NodeWordLevelShift(container, type.getSize(), dir, circular);

		n.connectInput("datain", _KernelBaseTypes.toImp(pack()));
		n.connectInput("shift", _KernelBaseTypes.toImp(shift));

		Var shifted = n.connectOutput("dataout");

		if (!m_doubt_type.hasDoubtInfo())
			return type.unpack(_KernelBaseTypes.fromImp(kernel, shifted));
		else {
			DFEArrayFullType<ContainedT> full_type = type.getFullTypeWithDoubtInfo();
			return full_type.unpack(_KernelBaseTypes.fromImp(kernel, shifted));
		}
	}

	public DFEArray<ContainedT> shiftElementsLeft(DFEVar shift) {
		return shiftElements(shift, ShiftDirection.Left, false);
	}

	public DFEArray<ContainedT> shiftElementsRight(DFEVar shift) {
		return shiftElements(shift, ShiftDirection.Right, false);
	}

	public DFEArray<ContainedT> rotateElementsLeft(DFEVar shift) {
		return shiftElements(shift, ShiftDirection.Left, true);
	}

	public DFEArray<ContainedT> rotateElementsRight(DFEVar shift) {
		return shiftElements(shift, ShiftDirection.Right, true);
	}
}
