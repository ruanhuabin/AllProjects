package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._Error;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmStateEnum;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmStateValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.maxdc.VHDLNameManager;
import com.maxeler.statemachine.Utils;

/**
 * A library for creating state variables for a {@link StateMachine}.
 */
public final class State extends Lib {
	private final List<DFEsmStateValue> m_stateValues = new ArrayList<DFEsmStateValue>();
	private final List<DFEsmStateEnum<?>> m_stateEnums = new ArrayList<DFEsmStateEnum<?>>();

	/** Unique ID for the next state variable. */
	private int m_nextStateID = 1;

	State(StateMachineLib stateMachine) { super(stateMachine); }

	/**
	 * Create an enumerated state variable.
	 * @param <E>
	 * @param enumClass The Java {@link Class} corresponding to the enumerated type.
	 * @param resetValue The value to set the variable to on reset.
	 * @return An enumerated state variable.
	 * @see #enumerated(Class)
	 */
	public <E extends Enum<E>> DFEsmStateEnum<E> enumerated(Class<E> enumClass, E resetValue)
		{return enumerated(enumClass, resetValue, "");}

	<E extends Enum<E>> DFEsmStateEnum<E> enumerated(Class<E> enumClass, E resetValue, String stateId) {
		if (enumClass == null)
			throw MaxCompilerAPIError.nullParam("enumClass");
		if (resetValue == null)
			throw MaxCompilerAPIError.nullParam("resetValue");
		checkIsInConstructor();
		checkAreEnumIdentifiersValid(enumClass);

		String stateID = generateNextStateID(stateId);
		DFEsmStateEnum<E> stateEnum = _StateMachine.Create.<E>DFEsmStateEnum(getStateMachine(), enumClass, stateID, resetValue);

		m_stateEnums.add(stateEnum);
		return stateEnum;
	}

	private <E> void checkAreEnumIdentifiersValid(Class<E> enumClass) {
		for (E c: enumClass.getEnumConstants()) {
			if (!VHDLNameManager.isLegalVHDLName(c.toString()))
				throw _Error.errorAPI(
					_StateMachine.getBuildManager(getStateMachine()), "Cannot use '" + c.toString() + "' as an identifier.");
		}
	}

	/**
	 * Create an enumerated state variable.
	 * <p>
	 * Note that this will create a state variable without a 'reset' value. The
	 * value of this variable will be undefined until explicitly set.
	 * This is an advanced interface and in most cases state should
	 * be created with a reset value (i.e. via {@link #enumerated(Class, Enum)}).
	 * @param <E>
	 * @param enumClass The Java {@link Class} corresponding to the enumerated type.
	 * @return An enumerated state variable.
	 * @see #enumerated(Class, Enum)
	 */
	public <E extends Enum<E>> DFEsmStateEnum<E> enumerated(Class<E> enumClass)
		{return enumerated(enumClass,"");}

	<E extends Enum<E>> DFEsmStateEnum<E> enumerated(Class<E> enumClass, String stateId) {
		if (enumClass == null)
			throw MaxCompilerAPIError.nullParam("enumClass");
		checkIsInConstructor();
		checkAreEnumIdentifiersValid(enumClass);

		String stateID = generateNextStateID(stateId);
		DFEsmStateEnum<E> stateEnum = _StateMachine.Create.<E>DFEsmStateEnum(getStateMachine(), enumClass, stateID, null);

		m_stateEnums.add(stateEnum);
		return stateEnum;
	}

	/**
	 * Create an integer state variable.
	 * @param type The type of the integer state.
	 * @param resetValue The value of the state upon reset.
	 * @return An integer state variable.
	 * @see #value(DFEsmValueType, long)
	 * @see #value(DFEsmValueType, BigInteger)
	 * @see #value(DFEsmValueType)
	 */
	public DFEsmStateValue value(DFEsmValueType type, boolean resetValue) {
		return value(type, BigInteger.valueOf(resetValue ? 1 : 0));
	}

	/**
	 * Create an integer state variable.
	 * @param type The type of the integer state.
	 * @param resetValue The value of the state upon reset.
	 * @return An integer state variable.
	 * @see #value(DFEsmValueType, boolean)
	 * @see #value(DFEsmValueType, BigInteger)
	 * @see #value(DFEsmValueType)
	 */
	public DFEsmStateValue value(DFEsmValueType type, long resetValue) {
		Utils.checkIsAllowedLiteralValue(resetValue, type);

		return value(type, BigInteger.valueOf(resetValue));
	}

	/**
	 * Create an integer state variable.
	 * @param type The type of the integer state.
	 * @param resetValue The value of the state upon reset.
	 * @return An integer state variable.
	 * @see #value(DFEsmValueType, boolean)
	 * @see #value(DFEsmValueType, long)
	 * @see #value(DFEsmValueType)
	 */
	public DFEsmStateValue value(DFEsmValueType type, BigInteger resetValue)
		{return value(type,resetValue,"");}

	DFEsmStateValue value(DFEsmValueType type, BigInteger resetValue, String stateId) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		if (resetValue == null)
			throw MaxCompilerAPIError.nullParam("resetValue");
		if (!Utils.canRepresent(resetValue, type))
			throw new MaxCompilerAPIError("Cannot represent default value %d with the type %s.", resetValue, type);
		checkIsInConstructor();

		String stateID = generateNextStateID(stateId);
		DFEsmStateValue stateInt = _StateMachine.Create.DFEsmStateValue(getStateMachine(), type, stateID, resetValue);

		m_stateValues.add(stateInt);
		return stateInt;
	}

	/**
	 * Create an integer state variable.
	 * <p>
	 * Note that this will create a state variable without a 'reset' value. The
	 * value of this variable will be undefined until explicitly set.
	 * This is an advanced interface and in most cases state should
	 * be created with a reset value (e.g. via {@link #value(DFEsmValueType, long)}).
	 * @param type The type of the integer state.
	 * @return An integer state variable.
	 * @see #value(DFEsmValueType, boolean)
	 * @see #value(DFEsmValueType, long)
	 * @see #value(DFEsmValueType, BigInteger)
	 */
	public DFEsmStateValue value(DFEsmValueType type) {return value(type,"");}

	DFEsmStateValue value(DFEsmValueType type, String stateId) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");
		checkIsInConstructor();

		String stateID = generateNextStateID(stateId);
		DFEsmStateValue stateInt = _StateMachine.Create.DFEsmStateValue(getStateMachine(), type, stateID, null);

		m_stateValues.add(stateInt);
		return stateInt;
	}

	String generateNextStateID(String someId) {
		String result = "";
		if (someId != null && someId.length() > 0)
		{
			if (!VHDLNameManager.isLegalVHDLName(someId))
				throw _Error.errorAPI(
					_StateMachine.getBuildManager(getStateMachine()), "Not a valid state id: " + someId);
			result = "_" + someId;
		}

		result = Integer.toString(m_nextStateID++) + result;
		return result;
	}

	List<DFEsmStateValue> getValueState() { return Collections.unmodifiableList(m_stateValues); }

	List<DFEsmStateEnum<?>> getEnumState() { return Collections.unmodifiableList(m_stateEnums); }
}
