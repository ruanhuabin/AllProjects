package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.FullType;

public class DFEStructFullType
	extends FullType<DFEStructDoubtType, DFEStructType, DFEStruct>
{
	protected DFEStructFullType(
		DFEStructDoubtType doubt_type,
		DFEStructType kernel_type)
	{
		super(doubt_type, kernel_type);
	}
}
