package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizableNull;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types._InternalUtils;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.photon.nodes.NodeComplexRotate;

/**
 * A stream of {@link DFEComplexType} data.
 * <p>
 * Arithmetic operations are supported on {@code DFEComplex} streams with arguments of real ({@code DFEVar}) or complex streams and Java construction-time constants.
 * <p>
 * Complex number streams offer overloaded arithmetic operators ({@code +, -, *, /}) and negation operator ({@code -}).
 * <p>
 * <b>Note</b>: The operators == and != are not overloaded in MaxCompiler and therefore are interpreted as standard Java == and !=.
 * These test the equality of <em>references</em>.
 * For {@code DFEComplex}
 * streams, the equality of the individual component streams must be tested using the methods {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar#eq(DFEVar) DFEVar.eq(DFEVar)} and {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar#neq(DFEVar) DFEVar.neq(DFEVar)}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFEComplex extends KernelObjectVectorizableNull<DFEComplex> {
	private final DFEStruct m_complex_data;
	private final DFEComplexType m_type;
	private final Kernel m_design;

	DFEComplex(DFEStruct complex_data, DFEComplexType type) {
		m_complex_data = complex_data;
		m_type = type;
		m_design = complex_data.getKernel();
	}

	/**
	 * Returns a new complex number stream cast to the specified {@link DFEComplexType} Kernel type from this stream.
	 * <p>
	 * Casts both the real and imaginary parts.
	 * @param type The complex number Kernel type to which to cast this stream.
	 * @return The resultant cast stream.
	 */
	public DFEComplex cast(DFEComplexType type) {
		return DFEComplexType.newInstance(m_design,
			getReal().cast((DFEType) type.getRealType()),
			getImaginary().cast((DFEType) type.getImaginaryType()));
	}

	/**
	 * Connects the real part of a source-less complex number stream to the output of stream {@code src}.
	 * @param src The input stream for the real part.
	 * @return The unmodified input stream {@code src}.
	 */
	public DFEVar setReal(DFEVar src) {
		return m_complex_data.set("real", src);
	}

	/**
	 * Gets the output stream of the real part of the complex number.
	 */
	public DFEVar getReal() {
		return (DFEVar)m_complex_data.get("real");
	}

	/**
	 * Connects the imaginary part of a source-less complex number stream to the output of stream {@code src}.
	 * @param src The input stream for the imaginary part.
	 * @return The unmodified input stream {@code src}.
	 */
	public DFEVar setImaginary(DFEVar src) {
		return m_complex_data.set("imaginary", src);
	}

	/**
	 * Gets the output stream of the imaginary part of the complex number.
	 */
	public DFEVar getImaginary() {
		return (DFEVar)m_complex_data.get("imaginary");
	}

	/** Compute the complex conjugate of this complex stream. */
	public DFEComplex conjugate() {
		return DFEComplexType.newInstance(
			m_design,
			getReal(),
			getImaginary().neg());
	}

	@Override
	public DFEComplex neg() {
		return DFEComplexType.newInstance(
			m_design,
			getReal().neg(),
			getImaginary().neg());
	}

	@Override
	public DFEComplex add(DFEComplex rhs) {
		return DFEComplexType.newInstance(
			m_design,
			getReal().add(rhs.getReal()),
			getImaginary().add(rhs.getImaginary()));
	}

	public DFEComplex add(DFEVar rhs) {
		return DFEComplexType.newInstance(
			m_design,
			getReal().add(rhs),
			getImaginary());
	}

	@Override
	public DFEComplex sub(DFEComplex rhs) {
		return add(rhs.neg());
	}

	public DFEComplex sub(DFEVar rhs) {
		return DFEComplexType.newInstance(
			m_design,
			getReal().sub(rhs),
			getImaginary());
	}

	@Override
	public DFEComplex mul(DFEComplex rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();
		DFEVar c = rhs.getReal();
		DFEVar d = rhs.getImaginary();

		DFEVar new_real = a.mul(c).sub(b.mul(d));

		DFEVar new_imag;
		if(rhs == this)
			// Slightly more efficient when squaring as the compiler
			// sometimes optimises the multiplication by two.
			new_imag = a.mul(b).mul(2);
		else
			new_imag = b.mul(c).add(a.mul(d));

		return DFEComplexType.newInstance(m_design, new_real, new_imag);
	}

	public DFEComplex mul(DFEVar rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();
		DFEVar c = rhs;

		DFEVar new_real = a.mul(c);
		DFEVar new_imag = b.mul(c);

		return DFEComplexType.newInstance(m_design, new_real, new_imag);
	}

	@Override
	public DFEComplex div(DFEComplex rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();
		DFEVar c = rhs.getReal();
		DFEVar d = rhs.getImaginary();

		DFEVar x = c.mul(c).add(d.mul(d));
		DFEVar new_real = (a.mul(c).add(b.mul(d))).div(x);
		DFEVar new_imag = (b.mul(c).sub(a.mul(d))).div(x);

		return DFEComplexType.newInstance(m_design, new_real, new_imag);
	}

	public DFEComplex div(DFEVar rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();
		DFEVar c = rhs;

		DFEVar x = c.mul(c);
		DFEVar new_real = (a.mul(c)).div(x);
		DFEVar new_imag = (b.mul(c)).div(x);

		return DFEComplexType.newInstance(m_design, new_real, new_imag);
	}

	public DFEComplex addAsRHS(DFEVar x) {
		return this.add(x);
	}

	public DFEComplex subAsRHS(DFEVar x) {
		return this.neg().add(x);
	}

	public DFEComplex mulAsRHS(DFEVar x) {
		return this.mul(x);
	}

	@Override
	public DFEComplex connect(DFEComplex rhs) {
		_InternalUtils.assertConnectTypes(this, rhs);

		m_complex_data.connect(rhs.m_complex_data);

		return this;
	}

	@Override
	public DFEComplexType getType() {
		return m_type;
	}

	@Override
	public DFEVar pack() {
		if(!getType().isConcreteType())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot pack DFEComplex as type " + getType() + " is not concrete.");

		return m_complex_data.pack();
	}

	@Override
	public List<DFEVar> packToList() {
		return m_complex_data.packToList();
	}

	/**
	 * Adds a watch to this stream.
	 * <p>
	 * During simulation, all data passing through this stream will be logged for debugging purposes.
	 * <p>
	 * The real and imaginary parts will be output named {@code name_real} and {@code name_imaginary}.
	 * @param name The name for the watch node as it will appear in the output.
	 * @return This stream.
	 */
	@Override
	public DFEComplex watch(String name) {
		getImaginary().watch(name + "_imag");
		getReal().watch(name + "_real");

		return this;
	}

	@Override
	public DFEComplex dfeWatch(String name) {
		getImaginary().dfeWatch(name + "_imag");
		getReal().dfeWatch(name + "_real");

		return this;
	}

	@Override
	public Kernel getKernel() {
		return m_design;
	}

	@Override
	public DFEComplex add(double rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.add(rhs);

		return DFEComplexType.newInstance(m_design, x, b);
	}

	@Override
	public DFEComplex add(long rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.add(rhs);

		return DFEComplexType.newInstance(m_design, x, b);
	}

	@Override
	public DFEComplex div(double rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.div(rhs);
		DFEVar y = b.div(rhs);

		return DFEComplexType.newInstance(m_design, x, y);
	}

	@Override
	public DFEComplex div(long rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.div(rhs);
		DFEVar y = b.div(rhs);

		return DFEComplexType.newInstance(m_design, x, y);
	}

	@Override
	public DFEComplex divAsRHS(double lhs) {
		DFEVar c = getReal();
		DFEVar d = getImaginary();

		DFEVar x = c.mul(c).add(d.mul(d));
		DFEVar new_real = (c.mul( lhs)).div(x);
		DFEVar new_imag = (d.mul(-lhs)).div(x);

		return DFEComplexType.newInstance(m_design, new_real, new_imag);
	}

	@Override
	public DFEComplex divAsRHS(long lhs) {
		DFEVar c = getReal();
		DFEVar d = getImaginary();

		DFEVar x = c.mul(c).add(d.mul(d));
		DFEVar new_real = (c.mul( lhs)).div(x);
		DFEVar new_imag = (d.mul(-lhs)).div(x);

		return DFEComplexType.newInstance(m_design, new_real, new_imag);
	}

	public DFEComplex divAsRHS(DFEVar lhs) {
		DFEVar a = lhs;
		DFEVar c = getReal();
		DFEVar d = getImaginary();

		DFEVar x = c.mul(c).add(d.mul(d));
		DFEVar new_real = (a.mul(c)).div(x);
		DFEVar new_imag = (a.mul(d).neg()).div(x);

		return DFEComplexType.newInstance(m_design, new_real, new_imag);
	}

	@Override
	public DFEComplex mul(double rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.mul(rhs);
		DFEVar y = b.mul(rhs);

		return DFEComplexType.newInstance(m_design, x, y);
	}

	@Override
	public DFEComplex mul(long rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.mul(rhs);
		DFEVar y = b.mul(rhs);

		return DFEComplexType.newInstance(m_design, x, y);
	}

	@Override
	public DFEComplex sub(double rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.sub(rhs);

		return DFEComplexType.newInstance(m_design, x, b);
	}

	@Override
	public DFEComplex sub(long rhs) {
		DFEVar a = getReal();
		DFEVar b = getImaginary();

		DFEVar x = a.sub(rhs);

		return DFEComplexType.newInstance(m_design, x, b);
	}

	@Override
	public DFEComplex subAsRHS(double lhs) {
		return this.neg().add(lhs);
	}

	@Override
	public DFEComplex subAsRHS(long lhs) {
		return this.neg().add(lhs);
	}

	/**
	 * Rotates the complex number in 90 degree steps.
	 *
	 * @param angle The angle as a 2 bit unsigned fixed-point number.
	 * @return A new rotated complex number.
	 */
    public DFEComplex rotate90(DFEVar angle) {

    	if (!angle.getType().isUInt() ||
    		angle.getType().getTotalBits() != 2)
    	{
    		throw new MaxCompilerAPIError(getKernel().getManager(), "Angle must be 2 bit unsigned fixed-point number");
    	}

    	if (m_type.getRealType() instanceof DFEFix &&
    		m_type.getImaginaryType() instanceof DFEFix)
    	{
	    	NodeComplexRotate rotateNode = new NodeComplexRotate(_Kernel.getPhotonDesignData(m_design));
	    	rotateNode.connectInput("a", _KernelBaseTypes.toImp(getReal()));
	    	rotateNode.connectInput("b", _KernelBaseTypes.toImp(getImaginary()));
	    	rotateNode.connectInput("angle", _KernelBaseTypes.toImp(angle));

	    	DFEVar newReal = _KernelBaseTypes.fromImp(m_design, rotateNode.connectOutput("real_result"));
	    	DFEVar newImaginary = _KernelBaseTypes.fromImp(m_design, rotateNode.connectOutput("imag_result"));

	    	return DFEComplexType.newInstance(m_design, newReal, newImaginary);
    	}
    	else {
    		DFEVar newReal =
    			m_design.control.mux(angle, getReal(), -getImaginary(), -getReal(), getImaginary());
    		DFEVar newImaginary =
    			m_design.control.mux(angle, getImaginary(), getReal(), -getImaginary(), -getReal());

	    	return DFEComplexType.newInstance(m_design, newReal, newImaginary);
    	}
    }

	/**
	 * Returns a new complex number stream cast to the specified {@link DFEComplexType} Kernel type from this stream.
	 * <p>
	 * Casts both the real and imaginary parts.
	 * <p>
	 * It is only valid to use the {@code DFEComplexType} Kernel type for {@code type}.
	 * @param type The complex number Kernel type to which to cast this stream.
	 * @return The resultant cast stream.
	 */
	@Override
	public DFEComplex cast(KernelType<?> type) {
		if(type instanceof DFEComplexType)
			return cast((DFEComplexType)type);

		throw new MaxCompilerAPIError(getKernel().getManager(),
			"Cannot cast a DFEComplex using type: " + type);
	}

	@Override
	public void setReportOnUnused(boolean v) {
		m_complex_data.setReportOnUnused(v);
	}

	@Override
	public DFEComplex castDoubtType(DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEComplexDoubtType))
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Can only doubt-type cast DFEComplex using DFEComplexDoubtType object.");

		DFEStructDoubtType struct_doubt_type =
			((DFEComplexDoubtType)doubt_type).getDFEStructDoubtType();

		return new DFEComplex(
			m_complex_data.castDoubtType(struct_doubt_type),
			m_type);
	}

	@Override
	public DFEComplexDoubtType getDoubtType() {
		return new DFEComplexDoubtType(m_complex_data.getDoubtType());
	}

	@Override
	public DFEVar packWithDoubt() {
		return m_complex_data.packWithDoubt();
	}

	@Override
	public DFEVar packWithoutDoubt() {
		return m_complex_data.packWithoutDoubt();
	}

	@Override
	public DFEVar hasDoubt() {
		return m_complex_data.hasDoubt();
	}

	@Override
	public DFEComplex setDoubt(DFEVar doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEComplex setDoubt(boolean doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEComplex setDoubt(DFEVar doubt, SetDoubtOperation operation) {
		if (!getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use setDoubt on this stream as it doesn't contain doubt information.");

		return new DFEComplex(m_complex_data.setDoubt(doubt, operation), m_type);
	}

	@Override
	public DFEComplex setDoubt(boolean doubt, SetDoubtOperation operation) {
		return setDoubt(m_design.constant.var(doubt), operation);
	}
}
