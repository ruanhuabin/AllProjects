package com.maxeler.maxcompiler.v2.errors;

import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.utils.MaxelerException;

public class SimulationOutputCheckException extends MaxelerException {
	public static final long serialVersionUID = 1L;

	public SimulationOutputCheckException(DFEManager build_manager, String message) {
		super(_Managers.getBuildManager(build_manager), message);
	}
}
