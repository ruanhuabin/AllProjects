package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Reductions;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;

public class Max extends Kernel {

	protected Max(KernelParameters parameters) {
		super(parameters);

		DFEVar x = io.input("x", dfeUInt(32));
		DFEVar y = io.output("y", dfeUInt(32));

		DFEVar max = Reductions.streamMax(x) + 10;

		y.connect(max);
	}

	public static void main(String[] args) {
		SimulationManager manager = new SimulationManager("Max");

		manager.setKernel( new Max(manager.makeKernelParameters()) );

		manager.setKernelCycles(1);
		manager.setInputData("x", 1);
		manager.runTest();
	}
}
