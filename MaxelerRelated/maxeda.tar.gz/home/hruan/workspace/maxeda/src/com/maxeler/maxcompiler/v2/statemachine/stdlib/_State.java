package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.math.BigInteger;
import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.DFEsmStateEnum;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmStateValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.Utils;

public final class _State {
	private _State(){}

	public static State create(StateMachineLib stateMachine) {return new State(stateMachine);};

	public static List<DFEsmStateValue> getValueState(State s) { return s.getValueState(); }
	public static List<DFEsmStateEnum<?>> getEnumState(State s) { return s.getEnumState(); }


	public static <E extends Enum<E>> DFEsmStateEnum<E> enumerated(State s, Class<E> enumClass, E resetValue, String stateId)
		{return s.enumerated(enumClass,resetValue,stateId);}
	public static <E extends Enum<E>> DFEsmStateEnum<E> enumerated(State s, Class<E> enumClass, String stateId)
		{return s.enumerated(enumClass, stateId);}

	public static DFEsmStateValue value(State s, DFEsmValueType type, BigInteger resetValue, String stateId)
		{return s.value(type,resetValue,stateId);}
	public static DFEsmStateValue value(State s, DFEsmValueType type, String stateId)
		{return s.value(type,stateId);}
	public static DFEsmStateValue value(State s, DFEsmValueType type, boolean resetValue, String stateId)
		{return value(s,type, BigInteger.valueOf(resetValue ? 1 : 0), stateId);}
	public static DFEsmStateValue value(State s, DFEsmValueType type, long resetValue, String stateId) {
		Utils.checkIsAllowedLiteralValue(resetValue, type);
		return value(s, type, BigInteger.valueOf(resetValue), stateId);
	}

}
