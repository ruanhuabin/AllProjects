package com.maxeler.maxcompiler.v2.statemachine.stdlib.buffer;

import com.maxeler.maxcompiler.v2.statemachine.DFEsmValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.Buffer.DFEsmFifoConfig;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmTypeFactory;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.buffers.Fifo;
import com.maxeler.statemachine.expressions.FifoSource;
import com.maxeler.utils.MaxDCMath;

public final class DFEsmFifo {
	final Fifo m_fifo;
	public final DFEsmFifoWriteDomain input;
	public final DFEsmFifoReadDomain output;
	public final DFEsmValue data_count;

	DFEsmFifo(String id, DFEsmValueType inputType, int depth, DFEsmFifoConfig fifoConfig, StateMachineLib sm) {
		final int fifodepth = depth + (fifoConfig.isFirstWordFallThrough() ? 2 : 0);
		final int dataCountBits = MaxDCMath.bitsToAddress(fifodepth);
		m_fifo = new Fifo(id, inputType, depth, fifoConfig);
		input = new DFEsmFifoWriteDomain(sm, inputType, m_fifo);
		output = new DFEsmFifoReadDomain(sm, inputType, m_fifo);
		data_count = _StateMachine.Create.DFEsmValue(new FifoSource(m_fifo,"data_count",DFEsmTypeFactory.dfeUInt(dataCountBits)));
	}

	public DFEsmFifoConfig getFifoConfig() {
		return m_fifo.getFifoConfig();
	}
}
