package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * Provides methods for floating point streams.
 */
public class FloatingPoint {

	/**
	 * Returns the exponents of the floating point stream {@code f}.
	 * <p>
	 * The result is undefined for NaNs and positive or negative infinity.
	 * @param f A floating point stream.
	 * @return The unbiased exponent as a stream of signed integers.
	 */
	public static DFEVar getExponent(DFEVar f) {
		if (!(f.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(f.getKernel().getManager(), "Argument must be of type dfeFloat, not " + f.getType());

		DFEFloat type = (DFEFloat) f.getType();

		DFEVar exp = f.slice(type.getMantissaBits() - 1, type.getExponentBits());
		exp = exp.cast(DFETypeFactory.dfeUInt(type.getExponentBits()));

		f.getKernel().optimization.pushEnableBitGrowth(true);
		exp = exp - type.getExponentBias();
		f.getKernel().optimization.popEnableBitGrowth();

		return exp;
	}

	/**
	 * Multi-pipe version of {@link #getExponent(DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M getExponent(M f) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(f.getNElements());
		for (int i = 0; i < f.getNElements(); ++i)
			new_pipes.add(getExponent(f.getElement(i)));
		return f.getType().newInstance(f.getKernel(), new_pipes);
	}

	/**
	 * Returns the mantissas of the floating point stream {@code f}.
	 * <p>
	 * The result is undefined for NaNs and positive or negative infinity.
	 * @param f A floating point stream.
	 * @return The signed mantissa including the implicit leading {@code 1.} as a stream of fixed point numbers.
	 */
	public static DFEVar getMantissa(DFEVar f) {
		if (!(f.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(f.getKernel().getManager(), "Argument must be of type dfeFloat, not " + f.getType());

		DFEFloat type = (DFEFloat) f.getType();

		DFEVar man = f.slice(0, type.getMantissaBits() - 1);

		// We only support normalised floats so re-attach either
		// implicit 1 if f != 0 or 0 if f == 0 || f == infinity
		DFEVar man_and_exp = f.slice(0, type.getTotalBits() - 1);
		DFEVar implicit = man_and_exp.neq(0);

//		DFEVar infinity_pattern = f.getKernel().constant.var(
//			DFETypeFactory.dfeRawBits(type.getTotalBits() - 1),
//			Bits.allZeros(type.getMantissaBits() - 1).concat(Bits.allOnes(type.getExponentBits())));
//		implicit = implicit.and(man_and_exp.neq(infinity_pattern));

		implicit = f.getKernel().constant.zero(DFETypeFactory.dfeRawBits(1)).cat(implicit);

		man = implicit.cat(man);
		man = man.cast(DFETypeFactory.dfeFix(2, type.getMantissaBits() - 1, SignMode.TWOSCOMPLEMENT));
		DFEVar sign = f.slice(type.getTotalBits() - 1, 1);
		sign = sign.cast(DFETypeFactory.dfeBool());
		man = sign ? man.neg() : man;

		return man;
	}

	/**
	 * Multi-pipe version of {@link #getMantissa(DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M getMantissa(M f) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(f.getNElements());
		for (int i = 0; i < f.getNElements(); ++i)
			new_pipes.add(getMantissa(f.getElement(i)));
		return f.getType().newInstance(f.getKernel(), new_pipes);
	}

	/**
	 * Returns a stream of booleans indicating whether {@code f} is Not a Number (NaN).
	 * @param f A floating point stream.
	 * @return {@code 1} if f is Not a Number, {@code 0} otherwise.
	 */
	public static DFEVar isNaN(DFEVar f) {
		if (!(f.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(f.getKernel().getManager(), "Argument must be of type dfeFloat, not " + f.getType());

		DFEFloat type = (DFEFloat) f.getType();

		DFEVar man = f.slice(0, type.getMantissaBits() - 1);
		DFEVar exp = f.slice(type.getMantissaBits() - 1, type.getExponentBits());

		DFEVar all_ones = f.getKernel().constant.var(
			DFETypeFactory.dfeRawBits(type.getExponentBits()),
			Bits.allOnes(type.getExponentBits()));

		return exp.eq(all_ones).and(man.neq(0));
	}

	/**
	 * Multi-pipe version of {@link #isNaN(DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M isNaN(M f) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(f.getNElements());
		for (int i = 0; i < f.getNElements(); ++i)
			new_pipes.add(isNaN(f.getElement(i)));
		return f.getType().newInstance(f.getKernel(), new_pipes);
	}

	/**
	 * Returns a stream of booleans indicating whether {@code f} is negative or positive infinity.
	 * @param f A floating point stream.
	 * @return {@code 1} if f is infinity, {@code 0} otherwise.
	 */
	public static DFEVar isInfinity(DFEVar f) {
		if (!(f.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(f.getKernel().getManager(), "Argument must be of type dfeFloat, not " + f.getType());

		DFEFloat type = (DFEFloat) f.getType();

		DFEVar infinity_pattern = f.getKernel().constant.var(
			DFETypeFactory.dfeRawBits(type.getTotalBits() - 1),
			Bits.allZeros(type.getMantissaBits() - 1).concat(Bits.allOnes(type.getExponentBits())));

		DFEVar man_and_exp = f.slice(0, type.getTotalBits() - 1);

		return man_and_exp.eq(infinity_pattern);
	}

	/**
	 * Multi-pipe version of {@link #isInfinity(DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M isInfinity(M f) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(f.getNElements());
		for (int i = 0; i < f.getNElements(); ++i)
			new_pipes.add(isInfinity(f.getElement(i)));
		return f.getType().newInstance(f.getKernel(), new_pipes);
	}

	/**
	 * Returns raw bits representing the exponents of the floating point stream {@code f}.
	 * @param f A floating point stream.
	 * @return The exponent as a stream of bits.
	 */
	public static DFEVar getExponentBits(DFEVar f) {
		if (!(f.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(f.getKernel().getManager(), "Argument must be of type dfeFloat, not " + f.getType());

		DFEFloat type = (DFEFloat) f.getType();

		DFEVar exp = f.slice(type.getMantissaBits() - 1, type.getExponentBits());

		return exp;
	}

	/**
	 * Multi-pipe version of {@link #getExponentBits(DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M getExponentBits(M f) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(f.getNElements());
		for (int i = 0; i < f.getNElements(); ++i)
			new_pipes.add(getExponentBits(f.getElement(i)));
		return f.getType().newInstance(f.getKernel(), new_pipes);
	}

	/**
	 * Returns raw bits representing the mantissas of the floating point stream {@code f}.
	 * @param f A floating point stream.
	 * @return The mantissa as a stream of bits.
	 */
	public static DFEVar getMantissaBits(DFEVar f) {
		if (!(f.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(f.getKernel().getManager(), "Argument must be of type dfeFloat, not " + f.getType());

		DFEFloat type = (DFEFloat) f.getType();

		DFEVar man = f.slice(0, type.getMantissaBits() - 1);

		return man;
	}

	/**
	 * Multi-pipe version of {@link #getMantissaBits(DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M getMantissaBits(M f) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(f.getNElements());
		for (int i = 0; i < f.getNElements(); ++i)
			new_pipes.add(getMantissaBits(f.getElement(i)));
		return f.getType().newInstance(f.getKernel(), new_pipes);
	}

	/**
	 * Returns the sign bits of the floating point stream {@code f}.
	 * @param f A floating point stream.
	 * @return The stream of sign bits.
	 */
	public static DFEVar getSignBit(DFEVar f) {
		if (!(f.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(f.getKernel().getManager(), "Argument must be of type dfeFloat, not " + f.getType());

		DFEFloat type = (DFEFloat) f.getType();

		DFEVar sign = f.slice(type.getTotalBits() - 1, 1);

		return sign;
	}

	/**
	 * Multi-pipe version of {@link #getSignBit(DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M getSignBit(M f) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(f.getNElements());
		for (int i = 0; i < f.getNElements(); ++i)
			new_pipes.add(getSignBit(f.getElement(i)));
		return f.getType().newInstance(f.getKernel(), new_pipes);
	}

	/**
	 * Returns a stream floating point numbers constructed with {@code mantissa} and {@code exponent}.
	 * <p>
	 * The resulting floating point type will be: <code>dfeFloat(exponent_type.getTotalBits() - 1, man_type.getFractionBits() + 1)</code>
	 *
	 * @param mantissa The mantissa as a signed {@code dfeFix} type in the range 1.0 (inclusive) to 2.0 (exclusive).
	 * @param exponent The exponent as a {@code dfeInt} type in the range {@code -bias} (exclusive) to {@code +bias} (inclusive)
	 *        where {@code bias} is the resulting floating point type's exponent bias. Exponents outside this range will be clipped to 0 or infinity.
	 * @return The result of <code>mantissa * 2^exponent</code> as a stream of floating point numbers.
	 */
	public static DFEVar newInstance(DFEVar mantissa, DFEVar exponent) {
		if (!(mantissa.getType() instanceof DFEFix) ||
			((DFEFix)mantissa.getType()).getSignMode() != SignMode.TWOSCOMPLEMENT ||
			((DFEFix)mantissa.getType()).getIntegerBits() != 2)
			throw new MaxCompilerAPIError(mantissa.getKernel().getManager(), "Mantissa must be a signed dfeFix(2, n) type, not " + mantissa.getType());

		if (!(exponent.getType().isInt()))
			throw new MaxCompilerAPIError(exponent.getKernel().getManager(), "Exponent must be a signed integer, not " + exponent.getType());

		DFEFix man_type = (DFEFix) mantissa.getType();
		DFEFix exp_type = (DFEFix) exponent.getType();

		int man_bits = man_type.getFractionBits() + 1;
		int exp_bits = exp_type.getTotalBits() - 1;

		DFEFloat float_type = DFETypeFactory.dfeFloat(exp_bits, man_bits);

		DFEVar sign = mantissa.slice(man_type.getTotalBits() - 1);
		sign = sign.cast(DFETypeFactory.dfeBool());
		mantissa = sign ? mantissa.neg() : mantissa;
		mantissa = mantissa.slice(0, man_bits - 1);

		int bias = float_type.getExponentBias();

		DFEVar zero_bits = exponent.getKernel().constant.var(DFETypeFactory.dfeRawBits(exp_bits), 0)
			.cat(mantissa.getKernel().constant.var(DFETypeFactory.dfeRawBits(man_bits - 1), 0));

		DFEVar infinity_bits = exponent.getKernel().constant.var(DFETypeFactory.dfeRawBits(exp_bits), Bits.allOnes(exp_bits))
			.cat(mantissa.getKernel().constant.var(DFETypeFactory.dfeRawBits(man_bits - 1), 0));

		DFEVar f =
			exponent <= -bias ?
				sign.cat(zero_bits) :
			(exponent > bias ?
				sign.cat(infinity_bits) :
				sign.cat(exponent.add(bias).slice(0, exp_bits)).cat(mantissa));

		f = f.cast(float_type);

		return f;
	}

	/**
	 * Multi-pipe version of {@link #newInstance(DFEVar, DFEVar)}
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M newInstance(M mantissa, M exponent) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(mantissa.getNElements());
		for (int i = 0; i < mantissa.getNElements(); ++i)
			new_pipes.add(newInstance(mantissa.getElement(i), exponent.getElement(i)));
		return mantissa.getType().newInstance(mantissa.getKernel(), new_pipes);
	}
}
