package com.maxeler.maxcompiler.v2.kernelcompiler.types;

import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._DFEFix;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.utils.numeric.BigFloat;

public class _InternalUtils {
	public static void assertConnectTypes(KernelObject<?> target, KernelObject<?> src) {
		assertTypes(null, target, src);
	}

	public static void assertConnectTypesField(String field_name, KernelObject<?> target, KernelObject<?> src) {
		assertTypes(field_name, target, src);
	}

	private static void assertTypes(String field_name, KernelObject<?> target, KernelObject<?> src) {
		final KernelType<?> main_src_type = src.getType();
		final KernelType<?> main_target_type = target.getType();
		final DFEManager manager = target.getKernel().getManager();

		// first check if the types are fundamentally incompatible
		if (!main_src_type.equalsIgnoreMax(main_target_type)) {
			if (field_name == null) {
				throw new MaxCompilerAPIError(
					manager,
					"Incompatible types in connect: %s.connect(%s)",
					main_target_type, main_src_type
				);
			} else {
				throw new MaxCompilerAPIError(
					manager,
					"Incompatible type when connecting field '%s' of type %s: %s",
					field_name, main_src_type, main_target_type
				);
			}
		}

		// If we have any DFEFix sources, make sure their maximum is not larger than
		// the target maximum (while still having the same offset and bitwidth)
		List<DFEVar> target_vars = target.packToList();
		List<DFEVar> source_vars = src.packToList();

		for (int i = 0; i < target_vars.size(); ++i) {
			DFEType target_type = target_vars.get(i).getType();
			DFEType source_type = source_vars.get(i).getType();

			// At this point target and source types can only differ if they
			// are DFEFix and have different max values
			if (!(target_type instanceof DFEFix))
				continue;

			BigFloat target_max = _DFEFix.getMax((DFEFix)target_type);
			BigFloat source_max = _DFEFix.getMax((DFEFix)source_type);

			if (target_max.compareTo(source_max) < 0) {
				if (field_name == null) {
					manager.logWarning(
						"Incompatible maximum values in connect of type %s: Maximum value of target (%s) must be >= maximum value of source (%s).",
						source_type, target_max, source_max
					);
				} else {
					manager.logWarning(
						"Incompatible maximum values when connecting field '%s' of type %s: Maximum value of target (%s) must be >= maximum value of source (%s).",
						field_name, source_type, target_max, source_max
					);
				}
			}
		}

		final DoubtType src_doubt_type = src.getDoubtType();
		final DoubtType target_doubt_type = target.getDoubtType();
		if (!src_doubt_type.equals(target_doubt_type)) {
			if (field_name == null) {
				throw new MaxCompilerAPIError(
					manager,
					"Incompatible doubt-types in connect: %s.connect(%s)",
					target_doubt_type, src_doubt_type
				);
			} else {
				throw new MaxCompilerAPIError(
					manager,
					"Incompatible doubt-types when connecting field '%s': %s.connect(%s)",
					field_name, target_doubt_type, src_doubt_type
				);
			}
		}
	}
}
