package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;


/**
 * Floating-point type with user-specified size of mantissa and exponent.
 * <p>
 * {@link DFEVar} streams can contain data of Kernel type {@code DFEFloat}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 * <p>
 * <h3> Brief Overview of Floating-Point</h3>
 * Floating-point numbers allow a wider range of numbers to be represented than
 * integers or fixed-point numbers.
 * <p>
 * Floating point uses a fixed number of bits
 * to represent an approximation of the number (the mantissa) which is scaled by
 * an exponent.
 * <p>
 * Floating-point numbers are normalized such that the most significant bit of the
 * mantissa is 1 (i.e. 1 <= mantissa < 2). This allows an optimization where the
 * most significant bit of the mantissa is not stored: it is implicit. This spare
 * bit is then used to represent the sign of the number.
 * <p>
 * Consider a floating point number with a 24-bit mantissa (m) and an 8-bit exponent (e). The storage
 * required for the mantissa is actually 23 bits, leaving one bit for the sign (s). The equation for working
 * out what the real number that this represents is:
 * <p>
 * <img src="{@docRoot}/resources/fp_equation.gif">
 * <p>
 * <b>Note</b>: {@link DFEFloat#getMantissaBits} will return the width of the mantissa as declared, <em> including the implicit bit</em> e.g. 24 for a floating point number declared as {@code dfeFloat(8,24)}.
 * <h3>Range of a Floating-Point Number</h3>
 * The range of a floating point number is between <img src="../../../../../../../resources/general_min_equation.gif"> and approximately <img src="../../../../../../../resources/general_max_equation.gif">.
 * <p>
 * Where {@code N} is the number of bits in the exponent.
 * <p>
 * For single precision ({@code dfeFloat(8,24)}), this is between <img src="../../../../../../../resources/single_min_equation.gif"> and approximately <img src="../../../../../../../resources/single_max_equation.gif">.
 * <p>
 * Note that the maximum exponent is +127 and the minimum -126 as two values are reserved for special values.
 * <p>
 * <h3>Special Values</h3>
 * Certain values of the exponent and mantissa represent special values. These values are the same for all bit-widths of exponent and mantissa.
 * <p>
 * <table border=1>
 *     <tr>
 *         <th>Value</th>
 *         <th>Exponent</th>
 *         <th>Mantissa</th>
 *     </tr>
 *     <tr>
 *         <td> + or - 0 </td>
 *         <td> All zeros </td>
 *         <td> 0 </td>
 *     </tr>
 *     <tr>
 *         <td>NaN (Not a Number)</td>
 *         <td> All ones </td>
 *         <td> Non-zero </td>
 *     </tr>
 *     <tr>
 *         <td>+ or - infinity</td>
 *         <td> All ones </td>
 *         <td> 0 </td>
 *     </tr>
 * </table>
 * <p>
 * <b>Note</b>: MaxCompiler floating point numbers do not support "denormalized" numbers.
 * <h3>Exponent Bias</h3>
 * The exponent is <em>biased</em>, which means it is offset from its actual value when stored.
 * For single precision ({@code dfeFloat(8,24)}) the bias is +127. These needs to be subtracted from the
 * stored value when working out the number represented in floating point.
 * So, for a single-precision number with an exponent of -100, this is stored as 27.
 * For double precision ({@code dfeFloat(11,53}), the bias is 1023.
 * <p>
 * The general equation for calculating the bias is:
 * <p>
 * <img src="{@docRoot}/resources/bias_equation.gif">
 * <p>
 * Where {@code N} is the number of bits in the exponent.
 * <p>
 * <h3> IEEE Floating-Point Compliance</h3>
 * When there are 8 exponent bits and 24 mantissa bits, the floating-point format is equivalent to IEEE 754 single-precision.
 * <p>
 * Similarly, for an exponent of 11 bits and mantissa 53 bits the type is in IEEE double-precision format.
 * <p>
 * <b>Note</b>: MaxCompiler floating point numbers vary from the IEEE standard in the following ways:
 * <ul>
 * <li> No support for denormalized numbers. Results that would have been denormalized are set to an appropriately signed zero.
 * <p> To increase the dynamic range in MaxCompiler, you can increase the width of the exponent.
 * <p> If slight variations in results from a CPU implementation are to be avoided, we recommend that the software model check
 * for denormalized numbers and round to zero.
 * </li>
 * <li> Only the default rounding mode, round to nearest, is supported. </li>
 * <li> All NaNs are treated as Quiet-NaNs - no exceptions will be raised.</li>
 * </ul>
 * <h3> Allowable Mantissa and Exponent Sizes</h3>
 * The valid range for the number of bits of the exponent ({@code exponent_bits}) is between 4 and 16 inclusive.
 * <p>
 * The valid range for the number of bits of the mantissa ({@code mantissa_bits}) depends on the exponent width.
 * The minimum mantissa size is always 4, <em>including the implicit bit due to normalization</em>, and the maximum is determined by the following table:
 * <p>
 * <b>Note</b>: All mantissa widths in this table <em>include the implicit bit due to normalization</em> (see above).
 *
 * <table border=1>
 *     <tr>
 *         <td> <b>Exponent Width</b> </td>
 *         <td> <b>Max. Mantissa Size</b> </td>
 *     </tr>
 *     <tr>
 *         <td> 4 </td>
 *         <td> 5 </td>
 *     </tr>
 *     <tr>
 *         <td> 5 </td>
 *         <td> 13 </td>
 *     </tr>
 *     <tr>
 *         <td> 6 </td>
 *         <td> 29 </td>
 *     </tr>
 *     <tr>
 *         <td> 7 </td>
 *         <td> 61 </td>
 *     </tr>
 *     <tr>
 *         <td> 8 - 16 </td>
 *         <td> 64 </td>
 *     </tr>
 * </table>
 */
public final class DFEFloat extends DFEType {

	DFEFloat(com.maxeler.photon.types.HWType imp) {
		super(imp);
		if (!(imp instanceof com.maxeler.photon.types.HWFloat))
			throw new MaxCompilerInternalError("Not DFEFloat instance.");
	}

	/**
	 * Gets the number of bits in the mantissa, <em>including the implicit bit due to normalization</em>.
	 * <p>
	 * For example, a floating point number declared as {@code dfeFloat(8,24)}, with an 8-bit exponent
	 * and a 24-bit mantissa, stores the mantissa in normalized form in only 23 bits, but {@code getMantissaBits}
	 * will return the width of the mantissa as declared, i.e. 24.
	 * <p>
	 * See the description of floating point in {@link DFEFloat} for more information on normalization and the implicit bit.
	 */
	public int getMantissaBits() {
		com.maxeler.photon.types.HWFloat imp = (com.maxeler.photon.types.HWFloat) m_imp;
		return imp.getMantissaBits();
	}

	/**
	 * Gets the number of bits in the exponent.
	 */
	public int getExponentBits() {
		com.maxeler.photon.types.HWFloat imp = (com.maxeler.photon.types.HWFloat) m_imp;
		return imp.getExponentBits();
	}

	/**
	 * Gets the exponent bias.
	 */
	public int getExponentBias() {
		com.maxeler.photon.types.HWFloat imp = (com.maxeler.photon.types.HWFloat) m_imp;
		return imp.getExponentBias();
	}

	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return equals(other_type);
	}

	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		if(!equals(other_type))
			throw new MaxCompilerAPIError("Cannot do " + this + ".unionWithMaxOfMaxes(" + other_type + ")");

		return this;
	}

	@Override
	public String toString() {
		return "dfeFloat(" + getExponentBits() + ", " + getMantissaBits() + ")";
	}
}
