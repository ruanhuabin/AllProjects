package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import static com.maxeler.maxcompiler.v2.kernelcompiler._Kernel.getPhotonDesignData;
import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.fromImp;
import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.toImp;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelTypeVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.StreamOffsetEq;
import com.maxeler.photon.core.Var;
import com.maxeler.photon.libs.StripedPrev;
import com.maxeler.photon.nodes.NodeEvalStreamOffset;
import com.maxeler.photon.software.EqVar;
import com.maxeler.photon.software.SoftwareDivisibleBy;
import com.maxeler.photon.software.SoftwareEq;
import com.maxeler.photon.software.SoftwareEqConstant;

/**
 * Class {@code DFELink} contains classes and methods for working with
 * stream offsets within a Kernel.
 * <p>
 * A negative offset specifies past values from a stream.
 * <p>
 * A positive offset specifies future values from a stream.
 * <p>
 * The following diagram, taken from the <a href="{@docRoot}/../maxcompiler-overview.pdf">MaxCompiler Overview</a>
 * document, shows the selection of past and future values from a stream:
 * <p>
 * <img src="{@docRoot}/resources/MAVGraph_scaled.png">
 * <p>
 * See the
 * <a href="{@docRoot}/../maxcompiler-tutorial.pdf#destination.offsets">MaxCompiler Tutorial</a> for more
 * details on using stream offsets.
 */
public class Stream {
	private final com.maxeler.photon.libs.StreamShiftFactory m_imp;
	private final com.maxeler.photon.libs.DynamicOffsetFactory m_dynamic_offset_imp;
	private final Kernel m_design;

	/**
	 * Offset expressions can be used to implement variable offsets into a stream.
	 * <p>
	 * Offset expressions can be calculated based on {@link DFELink#makeOffsetParam(String, int, int) offset parameters}
	 * provided by the CPU code.
	 * <p>
	 * Offset expression objects are immutable: operations such as addition result in a new offset expression being created as the result.
	 * <p>
	 * Offset expressions are limited to linear expressions of the form:
	 * <p>
	 * <img src="{@docRoot}/resources/offset_equation.gif">
	 * <p>
	 * Where <img src="{@docRoot}/resources/constant_n_equation.gif"> is a construction-time constant (i.e. calculated in Java)
	 * and x is an offset parameter set by CPU code.
	 * <p>
	 * Offset expressions allow restricted arithmetic with {@code int}s and other offset expressions.
	 * Overloaded {@code +}, {@code -} and {@code *} operators are available. The table below shows
	 * the permitted operations:
	 * <table border=1>
	 * <tr>
	 * <th>Operation</th>
	 * <th><code>int</code></th>
	 * <th><code>OffsetExpr</code></th>
	 * </tr>
	 * <td>Addition</td>
	 * <td align="center">yes</td>
	 * <td align="center">yes</td>
	 * </tr>
	 * <td>Subtraction</td>
	 * <td align="center">yes</td>
	 * <td align="center">yes</td>
	 * </tr>
	 * <td>Multiplication</td>
	 * <td align="center">yes</td>
	 * <td align="center"><b>no</b></td>
	 * </tr>
	 * <td>Other</td>
	 * <td align="center"><b>no</b></td>
	 * <td align="center"><b>no</b></td>
	 * </tr>
	 * </table>
	 */
	public static class OffsetExpr {
		com.maxeler.photon.core.StreamOffsetEq m_eq_imp;

		OffsetExpr(com.maxeler.photon.core.StreamOffsetEq imp) {
			m_eq_imp = imp;
		}

		OffsetExpr(com.maxeler.photon.software.EqVar var) {
			m_eq_imp = new com.maxeler.photon.core.StreamOffsetEq(var);
		}

		OffsetExpr(com.maxeler.photon.software.EqPlaceholder expr) {
			m_eq_imp = new com.maxeler.photon.core.StreamOffsetEq(expr);
		}

		/**
		 * Create a new stream offset expression.
		 */
		public OffsetExpr() {
			m_eq_imp = new com.maxeler.photon.core.StreamOffsetEq();
		}

		/**
		 * Create a new stream offset expression with a value {@code i}.
		 */
		public OffsetExpr(int i) {
			m_eq_imp = new com.maxeler.photon.core.StreamOffsetEq(i);
		}

		public OffsetExpr neg() {
			return new OffsetExpr(m_eq_imp.negate());
		}

		public OffsetExpr add(int c) {
			return new OffsetExpr(m_eq_imp.add(c));
		}

		public OffsetExpr addAsRHS(int c) {
			return add(c);
		}

		public OffsetExpr add(OffsetExpr eq) {
			return new OffsetExpr(m_eq_imp.add(eq.m_eq_imp));
		}

		public OffsetExpr sub(int a) {
			return new OffsetExpr(m_eq_imp.sub(a));
		}

		public OffsetExpr subAsRHS(int a) {
			return new OffsetExpr(a).sub(this);
		}

		public OffsetExpr sub(OffsetExpr eq) {
			return new OffsetExpr(m_eq_imp.sub(eq.m_eq_imp));
		}

		public OffsetExpr mul(int c) {
			return new OffsetExpr(m_eq_imp.mul(c));
		}

		public OffsetExpr mulAsRHS(int c) {
			return mul(c);
		}

		public DFEVar getDFEVar(KernelLib design) {
			NodeEvalStreamOffset node = new NodeEvalStreamOffset(
				getPhotonDesignData(design),
				getPhotonDesignData(design).getGroupPath(),
				m_eq_imp,
				null);

			return _KernelBaseTypes.fromImp(design, node.connectOutput("output"));
		}

		public DFEVar getDFEVar(KernelLib design, DFEType type) {
			if (type == null)
				throw new MaxCompilerAPIError(design.getManager(), "Type cannot be null.");

			NodeEvalStreamOffset node = new NodeEvalStreamOffset(
				getPhotonDesignData(design),
				getPhotonDesignData(design).getGroupPath(),
				m_eq_imp,
				_KernelBaseTypes.toImp(type));

			return _KernelBaseTypes.fromImp(design, node.connectOutput("output"));
		}

		@Override
		public String toString() { return m_eq_imp.toString(); }
	}

	Stream(Kernel design) {
		m_design = design;
		m_imp = new com.maxeler.photon.libs.StreamShiftFactory(getPhotonDesignData(design));
		m_dynamic_offset_imp = new com.maxeler.photon.libs.DynamicOffsetFactory(getPhotonDesignData(design));
	}

	/**
	 * Creates a static stream offset.
 	 * <p>
	 * The returned stream is offset by {@code offset} from the source stream {@code source}.
	 * <p>
	 * A negative {@code offset} specifies past values from the stream {@code source}.
	 * <p>
	 * A positive {@code offset} specifies future values from the stream {@code source}.
	 * @param src The source stream.
	 * @param offset The offset value.
	 * @return The stream {@code source} offset by the specified {@code offset}.
	 */
	public <T extends KernelObjectNotVector<T>> T offset(T src, int offset) {
		List<DFEVar> offset_var_list = new ArrayList<DFEVar>();
		for(DFEVar var : src.packToList()) {
			Var real_offset_var = m_imp.streamOffset(offset, toImp(var));
			offset_var_list.add(fromImp(m_design, real_offset_var));
		}

		return src.getType().unpackFromList(offset_var_list);
	}

	/**
	 * Creates a variable stream offset.
	 * <p>
	 * The returned stream is offset by {@code offset} from the source stream {@code source}.
	 * <p>
	 * A negative {@code offset} specifies past values from the stream {@code source}.
	 * <p>
	 * A positive {@code offset} specifies future values from the stream {@code source}.
	 * @param source The source stream.
	 * @param offset The offset expression.
	 * @return The stream {@code source} offset by the specified {@code offset}.
	 */
	public <T extends KernelObjectNotVector<T>> T offset(T source, OffsetExpr offset) {
		List<DFEVar> offset_var_list = new ArrayList<DFEVar>();
		for(DFEVar var : source.packToList()) {
			Var real_offset_var = m_imp.streamOffset(offset.m_eq_imp, toImp(var));
			offset_var_list.add(fromImp(m_design, real_offset_var));
		}

		return source.getType().unpackFromList(offset_var_list);
	}

	/**
	 * Creates a dynamic stream offset.
	 * <p>
	 * The returned stream is offset by {@code offset} from the source stream {@code source}.
	 * <p>
	 * {@code max_offset} and {@code min_offset} set the upper and lower bounds for {@code offset}.
	 * <p>
	 * A negative {@code offset} specifies past values from the stream {@code source}.
	 * <p>
	 * A positive {@code offset} specifies future values from the stream {@code source}.
	 * <p>
	 * <b>Note</b>: if the {@code offset} stream contains a value greater than {@code max_value} or less
	 * than {@code min_value}, then the behavior of the offset is undefined.
	 * @param source The source stream.
	 * @param offset The offset stream.
	 * @param min_offset The lower bounds for {@code offset}.
	 * @param max_offset The upper bounds for {@code offset}.
	 * @return The stream {@code source} offset by the specified {@code offset}.
	 */
	public <T extends KernelObjectNotVector<T>> T offset(
		T source,
		DFEVar offset,
		int min_offset,
		int max_offset)
	{
		if (source == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "source");
		if (offset == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "offset");
		if (min_offset > max_offset)
			throw new MaxCompilerAPIError(m_design.getManager(), "Minimum offset (%d) must be less than or equal to maximum offset (%d).", min_offset, max_offset);

		List<DFEVar> offset_var_list = new ArrayList<DFEVar>();
		for(DFEVar var : source.packToList()) {
			Var real_offset_var = m_dynamic_offset_imp.dynamicOffset(
				toImp(var),
				toImp(offset),
				min_offset,
				max_offset);
			offset_var_list.add(fromImp(m_design, real_offset_var));
		}

		return source.getType().unpackFromList(offset_var_list);
	}

	/**
	 * Creates a static multipipe stream offset.
 	 * <p>
	 * The returned stream is offset by {@code offset} from the source stream {@code source}.
	 * <p>
	 * A negative {@code offset} specifies past values from the stream {@code source}.
	 * <p>
	 * A positive {@code offset} specifies future values from the stream {@code source}.
	 * @param source The source stream.
	 * @param offset The offset value.
	 * @return The stream {@code source} offset by the specified {@code offset}.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>
	>
	M offset(M source, int offset) {
		KernelType<P> contained_type = source.getType().getContainedType();
		int prims_per_pipe = contained_type.getTotalPrimitives();

		// Created StripedPrevs (one per primitive in the mp contained type)
		StripedPrev[] striped_prev = new StripedPrev[prims_per_pipe];
		for(int i = 0; i < prims_per_pipe; i++)
			striped_prev[i] = new StripedPrev(source.getNElements(), getPhotonDesignData(m_design));

		// Add sources to to Striped prevs
		for(int pipe = 0; pipe < source.getNElements(); pipe++) {
			List<DFEVar> pipe_prims = source.getElement(pipe).packToList();
			for(int prim = 0; prim < prims_per_pipe; prim++)
				striped_prev[prim].addSource(_KernelBaseTypes.toImp(pipe_prims.get(prim)));
		}

		// Get outputs from striped prevs and pack into a new mp object
		M new_mp = source.getType().newInstance(m_design);

		for(int pipe = 0; pipe < source.getNElements(); pipe++) {
			List<DFEVar> pipe_offset_prims = new ArrayList<DFEVar>();
			for(int prim = 0; prim < prims_per_pipe; prim++) {
				striped_prev[prim].usePort(pipe);
				DFEVar pipe_offset_var =
					_KernelBaseTypes.fromImp(m_design, striped_prev[prim].discard(offset));
				pipe_offset_prims.add(pipe_offset_var);
			}

			new_mp.connect(pipe, contained_type.unpackFromList(pipe_offset_prims));
		}

		return new_mp;
	}

	/**
	 * Creates a variable multipipe stream offset.
	 * <p>
	 * The returned stream is offset by {@code offset} from the source stream {@code source}.
	 * <p>
	 * A negative {@code offset} specifies past values from the stream {@code source}.
	 * <p>
	 * A positive {@code offset} specifies future values from the stream {@code source}.
	 * @param source The source stream.
	 * @param offset The offset expression.
	 * @return The stream {@code source} offset by the specified {@code offset}.
	 */
	public <
		P extends KernelObjectVectorizable<P>,
		M extends DFEVectorBase<P, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<P, M, C>
	>
	M offset(M source, OffsetExpr offset) {
		int n_pipes = source.getNElements();

		StreamOffsetEq real_eq = offset.m_eq_imp;

		// First stripe-up the constant part if any
		if(real_eq.getC() != 0)
			source = offset(source, real_eq.getC());

		// Make new expr for the non-constant part.
		StreamOffsetEq new_eq = new StreamOffsetEq();
		for(SoftwareEq eq_var : real_eq.getUsedVariables()) {
			int coeff = real_eq.getCoefficientForVariable(eq_var);

			//if ((coeff % n_pipes) == 0) {
			//	new_eq = new_eq.add(coeff / n_pipes, eq_var);
			//}
			//else {
				//int gcd = MaxDCMath.gcd(Math.abs(coeff), n_pipes);
				new_eq = new_eq.add(coeff, eq_var / n_pipes);
				PhotonDesignData data_imp = getPhotonDesignData(m_design);
				data_imp.getSoftwareManager().addAssertion(
					new SoftwareDivisibleBy(eq_var, new SoftwareEqConstant(n_pipes)),
					"The variable " + eq_var.getName() + " must be divisible by " + n_pipes);
			//}
		}

		KernelTypeVectorizable<P> c = source.getType().getContainedType();
		List<P> new_pipes = new ArrayList<P>(source.getNElements());
		for(int i = 0; i < source.getNElements(); i++) {
			List<DFEVar> new_pipe_vars = new ArrayList<DFEVar>();
			for(DFEVar pipe_var : source.getElement(i).packToList())
				new_pipe_vars.add(offset(pipe_var, new OffsetExpr(new_eq)));
			new_pipes.add(c.unpackFromList(new_pipe_vars));
		}

		return source.getType().newInstance(m_design, new_pipes);
	}

	/**
	 * Creates an offset expression parameter which can be set by CPU code, with a variable minimum and maximum.
	 * <p>
	 * {@code min_offset} and {@code max_offset} are {@link OffsetExpr offset expressions} which can depend on other offset parameters. The
	 * constraints on the offset value are verified dynamically by MaxCompilerRT when the value of the offset is set in the CPU code.
	 * @param name The name of the offset parameter as it will appear in the Manager and CPU code.
	 * @param min_offset The minimum offset value.
	 * @param max_offset The maximum offset value.
	 * @return The resultant offset expression with a minimum of {@code min_offset} and a maximum of {@code max_offset}.
	 */
	public OffsetExpr makeOffsetParam(String name, OffsetExpr min_offset, OffsetExpr max_offset) {
		EqVar eq_var = _Kernel.getPhotonDesignData(m_design).getStreamOffsetManager().makeOffsetParam(name, false, min_offset.m_eq_imp, max_offset.m_eq_imp);

		if (min_offset.m_eq_imp.isComparable(max_offset.m_eq_imp) &&
			min_offset.m_eq_imp.equals(max_offset.m_eq_imp))
		{
			return max_offset;
		}
		else {
			return new OffsetExpr(eq_var);
		}
	}

	/**
	 * Creates an offset expression parameter which can be set by CPU code, with a static minimum and maximum.
	 * <p>
	 * MaxCompilerRT will verify that the offset set in the CPU code is greater than or equal to {@code min_offset} and less than
	 * or equal to {@code max_offset}.
	 * @param name The name of the offset parameter as it will appear in the Manager and CPU code.
	 * @param min_offset The minimum offset value.
	 * @param max_offset The maximum offset value.
	 * @return The resultant offset expression with a minimum of {@code min_offset} and a maximum of {@code max_offset}.
	 */
	public OffsetExpr makeOffsetParam(String name, int min_offset, int max_offset) {
		if (max_offset < min_offset)
			throw new MaxCompilerAPIError(m_design.getManager(), "Minimum offset (%d) must be less than or equal to maximum offset (%d).", min_offset, max_offset);

		return makeOffsetParam(name, new OffsetExpr(min_offset), new OffsetExpr(max_offset));
	}

	/**
	 * Creates an OffsetAutoLoop with a variable minimum and maximum.
	 * <p>
	 * MaxCompiler will attempt to replace the OffsetAutoLoop by an offset expression
	 * that makes all loops containing a stream offset with the OffsetAutoLoop schedulable.
	 *<p>
	 * Note that OffsetAutoLoops will always be replaced by a <em>positive</em> offset expression
	 * (i.e. with all coefficients being positive) but the OffsetAutoLoop term is typically used
	 * with a <em>negative</em> coefficient in stream offsets within loops.
	 * @param name The name of the OffsetAutoLoop as it will appear in the Manager and CPU code.

	 * @return The resultant OffsetAutoLoop.
	 */
	public OffsetExpr makeOffsetAutoLoop(String name) {
		return new OffsetExpr(_Kernel.getPhotonDesignData(m_design).getStreamOffsetManager().makeOffsetAutoLoop(name, false, null, null));
	}

	/**
	 * Creates an OffsetAutoLoop with a static minimum and maximum.
	 * <p>
	 * MaxCompiler will attempt to replace the OffsetAutoLoop by an offset expression
	 * that lies between {@code min_size} and {@code max_size} and makes all loops containing
	 * a stream offset with the OffsetAutoLoop schedulable.
	 *<p>
	 * Note that OffsetAutoLoops will always be replaced by a <em>positive</em> offset expression
	 * (i.e. with all coefficients being positive) but the OffsetAutoLoop term is typically used
	 * with a <em>negative</em> coefficient in stream offsets within loops.
	 * @param name The name of the OffsetAutoLoop as it will appear in the Manager and CPU code.
	 * @param min_size The minimum size.
	 * @param max_size The maximum size.
	 * @return The resultant OffsetAutoLoop with a minimum of size {@code min_size} and a maximum size of {@code max_size}.
	 */
	public OffsetExpr makeOffsetAutoLoop(String name, int min_size, int max_size) {
		if (max_size < min_size)
			throw new MaxCompilerAPIError(m_design.getManager(), "Minimum size (%d) must be less than or equal to maximum size (%d).", min_size, max_size);

		return makeOffsetAutoLoop(name, new OffsetExpr(min_size), new OffsetExpr(max_size));
	}

	/**
	 * Creates an OffsetAutoLoop with a variable minimum and maximum.
	 * <p>
	 * MaxCompiler will attempt to replace the OffsetAutoLoop by an offset expression
	 * that lies between {@code min_size} and {@code max_size} and makes all loops containing
	 * a stream offset with the OffsetAutoLoop schedulable.
	 *<p>
	 * Note that OffsetAutoLoops will always be replaced by a <em>positive</em> offset expression
	 * (i.e. with all coefficients being positive) but the OffsetAutoLoop term is typically used
	 * with a <em>negative</em> coefficient in stream offsets within loops.
	 * @param name The name of the OffsetAutoLoop as it will appear in the Manager and CPU code.
	 * @param min_size The minimum size.
	 * @param max_size The maximum size.
	 * @return The resultant OffsetAutoLoop with a minimum of size {@code min_size} and a maximum size of {@code max_size}.
	 */
	public OffsetExpr makeOffsetAutoLoop(String name, OffsetExpr min_size, OffsetExpr max_size) {
		if (min_size == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Minimum size cannot be null.");
		if (max_size == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Maximum size cannot be null.");

		if (!max_size.m_eq_imp.hasSymbolicTerms() && max_size.m_eq_imp.getC() < 0)
			throw new MaxCompilerAPIError(m_design.getManager(), "Minimum size (%s) must be positive.", min_size.toString());

		if (!min_size.m_eq_imp.hasSymbolicTerms() && min_size.m_eq_imp.getC() < 0)
			throw new MaxCompilerAPIError(m_design.getManager(), "Maxmum size (%s) must be positive.", max_size.toString());

		return new OffsetExpr(_Kernel.getPhotonDesignData(m_design).getStreamOffsetManager().makeOffsetAutoLoop(name, false, min_size.m_eq_imp, max_size.m_eq_imp));
	}

	/**
	 * Measures the stream distance between {@code start} and {@code end}.
	 * <p>
	 * A path from {@code start} to {@code end} must exist and {@code start} must precede {@code end} in the stream.
	 * @param name The name of the distance measurement as it will appear in the Manager and CPU code.
	 * @param start The measurement start.
	 * @param end The measurement end.
	 * @return The resultant distance as an offset expression.
	 */
	public OffsetExpr measureDistance(String name, DFEVar start, DFEVar end) {
		if (start == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "Start cannot be null.");
		if (end == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "End cannot be null.");

		if (!start.getType().isConcreteType())
			throw new MaxCompilerAPIError(m_design.getManager(), "Start must have concrete type.");

		if (!end.getType().isConcreteType())
			throw new MaxCompilerAPIError(m_design.getManager(), "End must have concrete type.");

		return new OffsetExpr(_Kernel.getPhotonDesignData(m_design).getStreamOffsetManager().makeDistanceMeasurement(
			name,
			false,
			_KernelBaseTypes.toImp(start),
			_KernelBaseTypes.toImp(end)));
	}
}
