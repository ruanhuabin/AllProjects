package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import java.util.LinkedList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxeleros.ip.MemoryControllerPro.DDRAddressBitSwapBase;
import com.maxeler.utils.MaxDCMath;

public class MemoryControllerConfig {

	private ArbitrationMode m_arbitration_mode = ArbitrationMode.ROUND_ROBIN;
	private int m_burst_size = 8;  // This is for DDR3 Only
	private int m_data_fifo_depth = 512;
	private int m_data_fifo_primitive_width = 11*72; // max3 data width = ~1536/2
	private boolean m_has_cmd_fifo_reg_in_ram = true;
	private boolean m_has_fabric_data_fifo_reg = true;
	private boolean m_has_fabric_rd_data_fifo_reg = false;
	private boolean m_has_cmdqfifo_inreg = false;
	private boolean m_implement_cmd_fifo_using_lutram = false;
	private boolean m_implement_data_fifo_using_lutram = false;
	private boolean m_has_performance_mode = true;
	private boolean m_enable_high_priority_stream = false;
	//private int m_mem_cmd_start_address_size = 28; // command addr range (bursts) 2^27 = 4G DDR2, 8G DDR3
	private int m_mem_cmd_start_address_size = 32;
	private int m_mem_cmd_inc_size = 8;
	DDRAddressBitSwapBase m_ddr_address_bit_swap = null;
	private boolean m_enable_perdqs_phase_detect = false;
	private int m_CMDFifoSize = 31; // size of CMD q for each stream inside MCP

	// parity support
	private boolean m_enable_parity_mode = false;
	private boolean m_enable_ecc_mode = false;
	private boolean m_parecc_debug_stream = false;
	private int m_parityecc_total_width = 0;

	// MAX2 Compatability Mode
	private boolean m_MAX2CompatibilityMode = false;

	// Flag support
	private boolean m_flag_support = false;

	/**
	 * Set the arbitration mode that controls how the memory controller services
	 * requests from multiple data streams.
	 * <p>
	 * <code>ROUND_ROBIN</code> mode is the default and checks every data stream in turn to check if any
	 * read/write commands are pending and should be used in most cases.
	 * <p>
	 * <code>DYNAMIC</code> mode may give higher performance if there are a large number of data streams
	 * with only a few streams used at time same time.
	 *
	 * @param arbitration_mode {@link ArbitrationMode}, <code>DYNAMIC</code> or <code>ROUND_ROBIN</code>
	 */
	public void setArbitrationMode(ArbitrationMode arbitration_mode) {
		m_arbitration_mode = arbitration_mode;
	}

	/**
	 * Get the arbitration mode.
	 *
	 * @return arbitration mode
	 */
	public ArbitrationMode getArbitrationMode() {
		return m_arbitration_mode;
	}

	/**
	 * Set the size of a single on-card memory/read write in words.  All read/writes to on-card
	 * memory are a multiple of the burst size.
	 * <p>
	 * The word length is determined by the width of the DDR bus in hardware
	 * (192 bits on a MAX2, 384 bits on a MAX3).  The valid burst sizes are determined by
	 * the physical memory installed on the card.
	 * <ul>
	 *   <li>For MAX2 cards using DDR2 memory, 4 is the only valid burst size.
	 *   <li>For MAX3 cards using DDR3 memory, 4 and 8 are the valid burst sizes.
	 * </ul>
	 * <p>
	 * A burst size of 8 is the default for MAX3 since it requires slightly fewer logic
	 * resources on the DFE and is the most efficient from a memory bandwidth perspective.
	 *
	 * For MAX3 a burst size of 4 provides finer grained memory addressing compared to a burst
	 * size of 8 at the expense of memory bus efficiency. Burst 4 accesses at odd addresses and odd
	 * numbers of contiguous bursts 4 accesses have reduced memory bus efficiency compared to
	 * burst 8.

	 * @param burst_size size of an on-card memory read/write burst in words.
	 */
	public void setBurstSize(int burst_size) {
		m_burst_size = burst_size;
	}

	/**
	 * Get the on-card memory burst size in words.
	 */
	public int getBurstSize() {
		return m_burst_size;
	}

	/**
	 * Set the depth of the FIFOs used for data between the on-card memory and the read/write streams
	 * in the manager.
	 * <p>
	 * The default is 512 because this is the maximum depth of a single DFE Block-RAM primitive.
	 * Using a lower number will not by itself reduce Block-RAM resource usage.  Specifying a higher
	 * number increases the buffering per-memory stream which may improve memory performance for
	 * certain access patterns.
	 * <p>
	 * If using LUTRAM FIFOs for memory data (see {@link #setDataFifoImplementUsingLUTRAM(boolean)}) the default
	 * FIFO depth will consume a very large number of LUT resources.  The most area efficient FIFO depth
	 * when using LUTRAM resources is 64.
	 *
	 * @param data_fifo_depth depth of each data FIFO
	 */
	public void setDataFIFODepth(int data_fifo_depth) {
		m_data_fifo_depth = data_fifo_depth;
	}

	/**
	 * Get the depth of the FIFOs used for data between on-card memory and the read/write streams
	 * in the manager.
	 * @return depth in words.
	 */
	public int getDataFIFODepth() {
		return m_data_fifo_depth;
	}

	/**
	 * Set the width of the base FIFO primitives used for data between the on-card memory and the read/write streams
	 * in the manager.
	 * <p>
	 * The default is 792 because this is roughly half the size of the MAX3 memory streams (1536), so 2 primitives
	 * will be generated. Reducing the primitive width may give better timing results by replicating the control logic
	 * <p>
	 * The maximum primitive width is 1024
	 * @param width in bits
	 */
	public void setDataFIFOPrimitiveWidth(int width) {
		if(width > 1024)
			throw new MaxCompilerAPIError("Maximum width of a FIFO primitive is 1024");
		m_data_fifo_primitive_width = width;
	}

	/**
	 * Get the width of the base FIFO primitives used for data between the on-card memory and the read/write streams
	 * in the manager.
	 * @return width in bits
	 */
	public int getDataFIFOPrimitiveWidth() {
		return m_data_fifo_primitive_width;
	}

	/**
	 * Set the location of the pipelining register between the command FIFOs and the
	 * on-card memory control logic.
	 * <p>
	 * If true (the default), the pipeline register is in the DFE Block RAM primitive.
	 * If false, the pipelining stage is in an DFE fabric flip-flop.
	 * <p>
	 * Putting the pipeline register in a Block RAM primitive is most resource efficient.
	 * Using a fabric flip-flop may give better timing results when using high on-card
	 * memory clock frequencies.
	 *
	 * @param has_cmd_fifo_reg_in_ram <code>true</code> to put pipeline register in Block RAM primitive, <code>false</code> to use fabric flip-flop
	 */
	public void setCmdFIFOPipelineRegInBlockRAM(boolean has_cmd_fifo_reg_in_ram) {
		m_has_cmd_fifo_reg_in_ram = has_cmd_fifo_reg_in_ram;
	}

	/**
	 * Get the location of the pipelining register between the command FIFOs and on-card memory control logic.
	 * @return <code>true</code> for register in Block RAM <code>false</code> for register in DFE fabric
	 */
	public boolean getCmdFIFOPipelineRegInBlockRAM() {
		return m_has_cmd_fifo_reg_in_ram;  // false puts CmdFifo register into fabric for speed
	}

	/**
	 * Enable/disable an additional pipeline register between the data FIFOs and the
	 * on-card memory datapath.
	 * <p>
	 * If true, enable pipeline registers in both the DFE Block RAM primitive and in an DFE fabric flip-flop.
	 * If false (default), only enable a pipeline register in the Block RAM primitive.
	 * <p>
	 * The data FIFOs always have a data FIFO in the Block RAM primitive.  Enabling an additional
	 * pipeline stage in fabric flip-flops may give better timing results when using high on-card
	 * memory clock frequencies.
	 *
	 * @param has_fabric_data_fifo_reg true to enable or false to disable an additional fabric pipeline register in the memory data path
	 */
	public void setDataFIFOExtraPipelineRegInFabric(boolean has_fabric_data_fifo_reg) {
		m_has_fabric_data_fifo_reg = has_fabric_data_fifo_reg;
	}

	/**
	 * Get state (enabled/disabled) of the additional fabric pipelining register in the on-card memory data path.
	 *
	 * @return <code>true</code> if there is an additional pipeline register in the DFE fabric
	 */
	public boolean getDataFIFOExtraPipelineRegInFabric() {
		return m_has_fabric_data_fifo_reg;
	}

	/**
	 * Enable/disable an additional pipeline register between the data FIFOs of the read streams
	 * and the on-card memory datapath
	 * @param has_fabric_rd_data_fifo_reg
	 */
	public void setDataReadFIFOExtraPipelineRegInFabric(boolean has_fabric_rd_data_fifo_reg) {
		m_has_fabric_rd_data_fifo_reg = has_fabric_rd_data_fifo_reg;
	}

	/**
	 * Get state (enabled/disabled) of the additional fabric pipelining register in the on-card memory data path
	 * of read streams.
	 *
	 * @return <code>true</code> if there is an additional pipeline register in the DFE fabric
	 */
	public boolean getDataReadFIFOExtraPipelineRegInFabric() {
		return m_has_fabric_rd_data_fifo_reg;
	}

	/**
	 * Enable/disable an additional pipeline register on the input to the CMD Q FIFOs
	 * <p>
	 * @param has_cmdqfifo_inreg {@code true} to enable or {@code false} to disable an additional CMD Q input register
	 */
	public void setExtraCMDQInputReg(boolean has_cmdqfifo_inreg) {
		m_has_cmdqfifo_inreg = has_cmdqfifo_inreg;
	}

	/**
	 * Get state (enabled/disabled) of the additional CMD Q input register
	 *
	 * @return <code>true</code> if there is an additional CMD Q input register
	 */
	public boolean getExtraCMDQInputReg() {
		return m_has_cmdqfifo_inreg;
	}


	/**
	 * Set the implementation of the command FIFOs to use DFE LUTs rather than Block RAM.
	 * The default implementation (Block RAM) is most resource efficient.  Setting this
	 * parameter to true may be useful to trade off LUTs for Block RAM.
	 *
	 * @param implement_cmd_fifo_using_lutram <code>true</code> for command FIFOs in LUT RAM, <code>false</code> for command FIFOs in Block RAM
	 */
	public void setCmdFIFOImplementUsingLUTRAM(boolean implement_cmd_fifo_using_lutram) {
		m_implement_cmd_fifo_using_lutram = implement_cmd_fifo_using_lutram;
	}

	/**
	 * Get command FIFO implementation (LUT RAM or Block RAM)
	 * @return <code>true</code> if command FIFOs are implemented using LUT RAM
	 */
	public boolean getCmdFIFOImplementUsingLUTRAM() {
		return m_implement_cmd_fifo_using_lutram;
	}

	/**
	 * Set the implementation of the data FIFOs to use DFE LUTs rather than Block RAM.
	 * The default implementation (Block RAM) is most resource efficient.  Setting this
	 * parameter to true may be useful to trade off LUTs for Block RAM.
	 *
	 * When using LUTs for data FIFOs, it usually makes sense to reduce the FIFO depth
	 * to reduce the number of LUTs used. See {@link #setDataFIFODepth(int)}.
	 *
	 * @param implement_data_fifo_using_lutram <code>true</code> for data FIFOs in LUT RAM,
	 *        <code>false</code> for data FIFOs in Block RAM
	 */
	public void setDataFifoImplementUsingLUTRAM(boolean implement_data_fifo_using_lutram) {
		m_implement_data_fifo_using_lutram = implement_data_fifo_using_lutram;
	}

	/**
	 * Get data FIFO implementation (LUT RAM or Block RAM).
	 * @return <code>true</code> if data FIFOs are implemented using LUT RAM.
	 */
	public boolean getDataFifoImplementUsingLUTRAM() {
		return m_implement_data_fifo_using_lutram;
	}

	/**
	 * Alternate way to selectively set DFE LUTs rather than Block RAM for data FIFOs.
	 * Override this function to return a list of streams for which LUT RAMs are required.
	 */
	public List<String> getByNameDataFifoImplementUsingLUTRAM() {
		return new LinkedList<String>();
	}

	/**
	 * Set enable/disable for performance mode in the on-card memory controller (enabled by default).
	 * Performance mode reduces the overhead of switching between different addresses in DDR memory.
	 * Disabling performance mode may save a small amount of logic in designs where on-card memory
	 * bandwidth is not critical.
	 * This option has no effect on MAX3.
	 *
	 * @param has_performance_mode <code>true</code> to enable performance mode, <code>false</code> to disable performance mode
	 */
	public void setEnablePerformanceMode(boolean has_performance_mode) {
		m_has_performance_mode = has_performance_mode;
	}

	/**
	 * Get performance mode enabled/disabled.
	 * @return <code>true</code> if performance mode is enabled.
	 */
	public boolean getEnablePerformanceMode() {
		return m_has_performance_mode;
	}

	/**
	 * Set enable/disable additional control over the priority of different data streams at run-time.
	 * When enabled, a set of data streams nominated at run-time as high priority are always serviced
	 * first by the on-card memory.  Other streams are only serviced if there is no work to do
	 * for any high priority stream.
	 * High priority streams are disabled by default.
	 *
	 * @param enable_high_priority_streams
	 */
	public void setEnableHighPriorityStreams(boolean enable_high_priority_streams) {
		m_enable_high_priority_stream = enable_high_priority_streams;
	}

	/**
	 * Get high priority streams enabled/disabled
	 * @return <code>true</code> if performance mode is enabled.
	 */
	public boolean getEnableHighPriorityStreams() {
		return m_enable_high_priority_stream;
	}

	/**
	 * Set the size in bits of the start address in the on-card memory controller read/write commands.
	 * By default, this is set to the width of the memory address for current Maxeler cards so
	 * that all available memory is addressable.
	 *
	 * @param mem_cmd_start_address_size address size in bits.
	 */
	public void setMemCmdStartAddressSize(int mem_cmd_start_address_size) {
		m_mem_cmd_start_address_size = mem_cmd_start_address_size;
	}

	/**
	 * Get the size in bits of the start address in the on-card memory controller read/write commands.
	 * @return address width in bits.
	 */
	public int getMemCmdStartAddressSize() {
		return m_mem_cmd_start_address_size;
	}

	/**
	 * Set the size in bits of the address increment in the on-card memory controller read/write commands.
	 * By default, this is 8 bits and should not be changed.
	 *
	 * @param mem_cmd_inc_size increment size in bits.
	 */
	public void setMemCmdIncSize(int mem_cmd_inc_size) {
		m_mem_cmd_inc_size = mem_cmd_inc_size;
	}

	/**
	 * Get the size in bits of the address increment in the on-card memory controller read/write commands.
	 *
	 * @return increment size in bits
	 */
	public int getMemCmdIncSize() {
		return m_mem_cmd_inc_size;
	}

	/**
	 * Set the address bit swap entity used to map memory addresses to DDR column, row, bank and rank bits.
	 * For advanced use to optimize memory bandwidth for strided access patterns, such as STRIDE_2D.
	 *
	 * @param address_bit_swap MaxDC entity for address bit-swap.
	 */
	void setDDRAddressBitSwap(DDRAddressBitSwapBase address_bit_swap) {
		m_ddr_address_bit_swap = address_bit_swap;
	}

	/**
	 * Get the address bit swap entity.
	 *
	 * @return MaxDC entity for address bit swap.
	 */
	DDRAddressBitSwapBase getDDRAddressBitSwap() {
		return m_ddr_address_bit_swap;
	}

	/**
	 * Get the size of the count in the on-card memory controller read/write commands.
	 * This is calculated from the data FIFO depth up to a maximum of 8 bits.
	 *
	 * @return count size in bits.
	 */
	public int getMemCmdCountSize() {
		// nominally set to <= log2(m_stream_fifo_depth)-1 and <=8
		return (MaxDCMath.bitsToAddress(getDataFIFODepth()) - 1) <=8 ?
            (MaxDCMath.bitsToAddress(getDataFIFODepth()) - 1) : 8;
	}

	public boolean getEnablePerDqsPhaseDetect() {
		return m_enable_perdqs_phase_detect;
	}

	public void setEnablePerDqsPhaseDetect(boolean enabled) {
		m_enable_perdqs_phase_detect = enabled;
	}

	/**
	 * Enable MCP parity mode
	 * To enable ECC, Parity mode must also be enabled
	 */
	public void setEnableParityMode(boolean enable_parity, boolean enable_ecc_mode, int total_size,
		boolean debug_stream) {
		m_enable_parity_mode = enable_parity;
		if (enable_ecc_mode) {
			if (!enable_parity)
				throw new MaxCompilerAPIError("To enable ECC mode in the on-card memory controller, you must also enable parity mode.");
			m_enable_ecc_mode = true;
		}

		if (debug_stream && !enable_parity)
				throw new MaxCompilerAPIError("To enable the debug stream in the on-card memory controller, you must also enable parity mode.");

		m_parityecc_total_width = total_size;
		m_parecc_debug_stream = debug_stream;
	}

	/*
	 * Set the size of the Command Q's inside MCP.
	 * Optimal setting is a power of 2 minus 1.
	 */
	public void setCMDQSize(int size) {
		m_CMDFifoSize = size;
	}

	/**
	 * Get MCP Parity mode status
	 */
	public boolean getEnableParityMode() {
		return m_enable_parity_mode;
	}

	/**
	 * Get MCP ECC mode status
	 */
	public boolean getEnableECCMode() {
		return m_enable_ecc_mode;
	}

	/**
	 * Get MCP parity/ecc total width parity/ecc + data
	 */
	public int getParityTotalWidth() {
		return m_parityecc_total_width;
	}

	/**
	 * Get MCP debug stream status
	 */
	public boolean getParECCDebugStatus() {
		return m_parecc_debug_stream;
	}

	/*
	 * Get the size of the MCP Command Q
	 */
	public int getCMDQSize() {
		return m_CMDFifoSize;
	}


	/**
	 * Set MAX2 Compatibility Mode
	 *
	 * Used to reduce the width of memory streams and reduce burst sizes on MAX3
	 * to emulate MAX2
	 *
	 */
	public void setMAX2CompatibilityMode(boolean mode) {
		m_MAX2CompatibilityMode = mode;
	}

	/**
	 * Get MAX2 Compatibility Mode status
	 */
	public boolean getMAX2CompatibilityMode() {
		return m_MAX2CompatibilityMode;
	}


	/**
	 * Enable 'Flag Commands' Mode.
	 *
	 * Used to enable support for 'Flag' commands in MCP.
	 *
	 * Extra commands are:
	 *   SetFlags, ClearFlags, BlockUntilFlagsSet, BlockUntilFlagsCleared
	 *
	 */
	public void setEnableFlagCommands(boolean mode) {
		m_flag_support = mode;
	}


	/**
	 * Get 'Flag Commands' status.
	 */
	public boolean getEnableFlagCommands() {
		return m_flag_support;
	}


	@Override
	public String toString() {
		StringBuffer ret = new StringBuffer();
		ret.append("_" + getDataFIFODepth());
		if (getArbitrationMode() == ArbitrationMode.DYNAMIC) ret.append("_DynamicArb");
		if (getDataFifoImplementUsingLUTRAM()) ret.append("_LUTRAMFIFOs");
		if (getCmdFIFOImplementUsingLUTRAM()) ret.append("_CMDLUTRAMFIFOs");
		if (getCmdFIFOPipelineRegInBlockRAM()) ret.append("_CMDFIFOREGINRAM");
		if (getDataFIFOExtraPipelineRegInFabric()) ret.append("_DATAFIFOREG");
		if (getDataReadFIFOExtraPipelineRegInFabric()) ret.append("_DATARDFIFOREG");
		if (getExtraCMDQInputReg()) ret.append("_CMDQINREG");
		if (getEnablePerformanceMode()) ret.append("_perfmode");
		if (getMAX2CompatibilityMode()) ret.append("_MAX2mode");
		if (getEnableFlagCommands()) ret.append("_FlagCMDs");
		ret.append("_" + getMemCmdStartAddressSize() + "_" + getMemCmdIncSize() + "_" + getMemCmdCountSize());
		return ret.toString();
	}
}
