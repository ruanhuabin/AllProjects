package com.maxeler.maxcompiler.v2.managers.engine_interfaces;


/**
 * A library of numerical functions for InterfaceParam instances.
 * These functions are evaluated at runtime.
 */
public class InterfaceMath {

	/**
	 * @return the smallest argument
	 */
    public static InterfaceParam min(InterfaceParam a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.min(a.getImpl(), b.getImpl()));
    }

	/**
	 * @return the smallest argument
	 */
    public static InterfaceParam min(long a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.min(a,b.getImpl()));
    }

	/**
	 * @return the smallest argument
	 */
    public static InterfaceParam min(double a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.min(a,b.getImpl()));
    }

	/**
	 * @return the smallest argument
	 */
    public static double min(double a, double b)
    {
    	return Math.min(a, b);
    }

	/**
	 * @return the smallest argument
	 */
    public static long min(long a, long b)
    {
    	return Math.min(a, b);
    }

	/**
	 * @return the smallest argument
	 */
    public static InterfaceParam min(InterfaceParam a, long b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.min(a.getImpl(),b));
    }

	/**
	 * @return the smallest argument
	 */
    public static InterfaceParam min(InterfaceParam a, double b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.min(a.getImpl(),b));
    }

	/**
	 * @return the largest argument
	 */
    public static InterfaceParam max(InterfaceParam a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.max(a.getImpl(),b.getImpl()));
    }

	/**
	 * @return the largest argument
	 */
    public static long max(long a, long b)
    {
    	return Math.max(a, b);
    }

	/**
	 * @return the largest argument
	 */
    public static double max(double a, double b)
    {
    	return Math.max(a, b);
    }

	/**
	 * @return the largest argument
	 */
    public static InterfaceParam max(long a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.max(a,b.getImpl()));
    }

	/**
	 * @return the largest argument
	 */
    public static InterfaceParam max(double a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.max(a,b.getImpl()));
    }

	/**
	 * @return the largest argument
	 */
    public static InterfaceParam max(InterfaceParam a, long b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.max(a.getImpl(),b));
    }

	/**
	 * @return the largest argument
	 */
    public static InterfaceParam max(InterfaceParam a, double b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.max(a.getImpl(),b));
    }

	/**
	 * @return the cosine of the argument
	 */
    public static InterfaceParam cos(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.cos(a.getImpl()));
    }

	/**
	 * @return the cosine of the argument
	 */
    public static double cos(double a)
    {
    	return Math.cos(a);
    }

	/**
	 * @return the sine of the argument
	 */
    public static InterfaceParam sin(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.sin(a.getImpl()));
    }

	/**
	 * @return the sine of the argument
	 */
    public static double sin(double a)
    {
    	return Math.sin(a);
    }

	/**
	 * @return the tangent of the argument
	 */
    public static InterfaceParam tan(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.tan(a.getImpl()));
    }

	/**
	 * @return the tangent of the argument
	 */
    public static double tan(double a)
    {
    	return Math.tan(a);
    }

	/**
	 * @return the largest integral value not greater than the argument
	 */
    public static InterfaceParam floor(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.floor(a.getImpl()));
    }

	/**
	 * @return the largest integral value not greater than the argument
	 */
    public static double floor(double a)
    {
    	return Math.floor(a);
    }

    /**
     * @return the smallest integral value not less than the argument
     */
    public static InterfaceParam ceil(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.ceil(a.getImpl()));
    }

    /**
     * @return the smallest integral value not less than the argument
     */
    public static double ceil(double a)
    {
    	return Math.ceil(a);
    }

    /**
     * @return the natural logarithm of the argument
     */
    public static InterfaceParam log(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.log(a.getImpl()));
    }

    /**
     * @return the natural logarithm of the argument
     */
    public static double log(double a)
    {
    	return Math.log(a);
    }

    /**
     * @return the exponential of the argument
     */
    public static InterfaceParam exp(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.exp(a.getImpl()));
    }

    /**
     * @return the exponential of the argument
     */
    public static double exp(double a)
    {
    	return Math.exp(a);
    }

    /**
     * @return the value of the first argument raised to the power of the second argument
     */
    public static InterfaceParam pow(InterfaceParam a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.pow(
    			a.getImpl(), b.getImpl()));
    }

    /**
     * @return the value of the first argument raised to the power of the second argument
     */
    public static InterfaceParam pow(InterfaceParam a, double b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.pow(
    			a.getImpl(), b));
    }

    /**
     * @return the value of the first argument raised to the power of the second argument
     */
    public static InterfaceParam pow(double a, InterfaceParam b)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.pow(
    			a, b.getImpl()));
    }

    /**
     * @return the value of the first argument raised to the power of the second argument
     */
    public static double pow(double a, double b)
    {
    	return Math.pow(a, b);
    }

    /**
     * @return the square root of the argument
     */
    public static InterfaceParam sqrt(InterfaceParam a)
    {
    	return new InterfaceParam(
    		com.maxeler.maxeleros.managercompiler.software.modeinfo.ModeMath.sqrt(a.getImpl()));
    }

    /**
     * @return the square root of the argument
     */
    public static double sqrt(double a)
    {
    	return Math.sqrt(a);
    }

}
