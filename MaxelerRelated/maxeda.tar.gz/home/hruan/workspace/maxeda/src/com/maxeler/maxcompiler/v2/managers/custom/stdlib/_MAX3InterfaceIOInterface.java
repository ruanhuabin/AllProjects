package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControlGroup.MemoryAccessPattern;
import com.maxeler.maxeleros.ip.Ethernet.NetworkConnection;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.maxeleros.managercompiler.libs.AsymmetricInterFPGAFactory;
import com.maxeler.maxeleros.managercompiler.libs.NetworkInterfacePlugin;
import com.maxeler.maxeleros.managercompiler.libs.NetworkLinkSpeed;
import com.maxeler.maxeleros.managercompiler.libs.PCIeIOFactory;
import com.maxeler.maxeleros.managercompiler.libs.TimestampingIOFactory.TimestampingIOFormat;
import com.maxeler.maxeleros.platforms.MAX3AuroraLinkType;
import com.maxeler.maxeleros.platforms.MAX3InterfaceFPGA;


public class _MAX3InterfaceIOInterface implements _BoardIOInterface {
	private final WrapperDesignData m_data;
	private final PCIeIOFactory m_pcie_io_factory;
	private final AsymmetricInterFPGAFactory m_a_ifpga_factory;

	private final MAX3InterfaceFPGA m_platform;

	public _MAX3InterfaceIOInterface(WrapperDesignData data, MAX3InterfaceFPGA platform, WrapperClock clock) {
		m_data = data;
		m_platform = platform;
		m_pcie_io_factory = new PCIeIOFactory(m_data, "pcie", true);
		m_pcie_io_factory.setPCIeFastClock(true);
		m_a_ifpga_factory = new AsymmetricInterFPGAFactory(m_data, "a_ifpga", m_pcie_io_factory.m_clock_pci_express);
		m_a_ifpga_factory.setRemoteRegisterAccess();
	}

	public DFELink addFWStreamToCompute(String name) {
		return _CustomManagers.fromImp(m_a_ifpga_factory.addStreamToRemoteFPGA(name, true));
	}

	public DFELink addFWStreamFromCompute(String name) {
		return _CustomManagers.fromImp(m_a_ifpga_factory.addStreamFromRemoteFPGA(name, true));
	}

	@Override
	public MaxRingBidirectionalStream addMaxRingBirectionalStream(
		String name,
		MaxRingConnection connection)
	{
		throw new MaxCompilerAPIError(m_data, "IFPGA link is not supported on the MAX3 interface FPGA");
	}

	@Override
	public DFELink addStreamFromHost(String name) {
		return _CustomManagers.fromImp(m_pcie_io_factory.addPCIeStreamFromHost(name));
	}

	@Override
	public DFELink addStreamToHost(String name) {
		return _CustomManagers.fromImp(m_pcie_io_factory.addPCIeStreamToHost(name));
	}

	@Override
	public DFELink addStreamFromOnCardMemory(
		String name,
		MemoryControlGroup controlStream)
	{
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public DFELink addStreamToOnCardMemory(
		String name,
		MemoryControlGroup controlStream)
	{
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public MemoryControlGroup addMemoryControlGroup(
		String name,
		DFELink controlStream)
	{
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public MemoryControlGroup addMemoryControlGroup(
		String name,
		MemoryAccessPattern pattern)
	{
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public void finalise() {
		m_a_ifpga_factory.setBoardResource(m_platform.getIFPGA(MAX3AuroraLinkType.INTERFPGA_LINK, 128));
		m_pcie_io_factory.setBoardResource(m_platform.getPCIExpress(m_pcie_io_factory.getNumberOfPCIExpressLanes()));
	}

	@Override
	public void setMaxRingNumLanes(MaxRingConnection connection, int width) { }

	@Override
	public void setEnablePCIExpressFastClock(boolean fastClock) { }

	@Override
	public void setNumberOfPCIExpressLanes(int numLanes) {	}

	@Override
	public DFELink addStreamFromNetwork(int port, String name) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public DFELink addStreamToNetwork(int port, String name) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public void setNetworkInterfacePlugin(NetworkInterfacePlugin plugin) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public WrapperClock getNetworkInterfaceClock(int port) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public DFELink addStreamFromNetwork(NetworkConnection connection, int port, String name) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public DFELink addStreamToNetwork(NetworkConnection connection, int port, String name) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public void setNetworkInterfacePlugin(NetworkConnection connection, NetworkInterfacePlugin plugin) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public WrapperClock getNetworkInterfaceClock(NetworkConnection connection, int port) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public void setMemoryControllerConfig(MemoryControllerConfig config) {
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public void setOnCardMemoryFrequency(double freqMhz) {
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public WrapperClock getMemoryCoreClock() {
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public double getOnCardMemoryFrequency() {
		return 0.0;
	}

	@Override
	public DFELink getDebugStreamFromCardMemory(String name) {
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	@Override
	public void setEnableHideParityBitsForStream(
		DFELink stream,
		boolean hide_parity_bits) {
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	public void setEnablePCIExpressSlaveStreaming(boolean slave_streaming) {
		m_pcie_io_factory.setEnableSlaveStreaming(slave_streaming);
	}

	@Override
	public void setIFPGALinkClock(WrapperClock clock) {
		m_a_ifpga_factory.setIFPGAClock(clock);
	}

	@Override
	public void setMemoryStreamClock(WrapperClock clock) {
		throw new MaxCompilerAPIError(m_data, "Memory streams not supported on the MAX3 interface FPGA");
	}

	public void forcePCIeGen1Capability(boolean force_gen1) {
		m_pcie_io_factory.setForceGen1Capability(force_gen1);
	}

	@Override
	public NetworkInterfacePlugin getDefaultEthernetPlugin(NetworkLinkSpeed link_speed, boolean bypass_fifo) {
		throw new MaxCompilerAPIError(m_data, "Ethernet not supported on the MAX3 interface FPGA");
	}

	@Override
	public boolean hasNetworkConnectionGotPlugin(NetworkConnection connection) {
		throw new MaxCompilerAPIError(m_data, "Network interfaces not supported on the MAX3 interface FPGA");
	}

	@Override
	public void setHostStreamClock(WrapperClock clock) {
		setIFPGALinkClock(clock);
	}

	@Override
	public DFELink addTimestampStream(String name,
		 WrapperClock clock,
		 TimestampingIOFormat format,
		 int decimal_precision) {
		throw new MaxCompilerAPIError(m_data,
		"Timestamp stream is not supported on MAX3 interface FPGA.");
	}
}
