package com.maxeler.maxcompiler.v2.managers.engine_interfaces;

import com.maxeler.utils.EnumTranslator;

public class InterfaceParam {

	private final com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParam m_impl;

	InterfaceParam(com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParam impl)
	{
		m_impl = impl;
	}

	com.maxeler.maxeleros.managercompiler.software.modeinfo.nodes.ModeParam getImpl()
	{
		return m_impl;
	}

	/**
	 * @return the CPU type of the InterfaceParam
	 */
	public CPUTypes getType()
	{
		return EnumTranslator.convert(m_impl.getType(), CPUTypes.class);
	}

	/**
	 * Cast the value of the InterfaceParam to a new type
	 * @param new_type the target type
	 * @return a InterfaceParam instance of type new_type
	 */
	public InterfaceParam cast(CPUTypes new_type)
	{
		return new InterfaceParam(m_impl.cast( CPUTypes.toMaxelerOS(new_type)));
	}

	/* generated code */

	public InterfaceParam add(InterfaceParam a)
	{
		return new InterfaceParam(m_impl.add(a.m_impl));
	}


	public InterfaceParam add(long a)
	{
		return new InterfaceParam(m_impl.add(a));
	}


	public InterfaceParam add(double a)
	{
		return new InterfaceParam(m_impl.add(a));
	}


	public InterfaceParam addAsRHS(long a)
	{
		return new InterfaceParam(m_impl.addAsRHS(a));
	}


	public InterfaceParam addAsRHS(double a)
	{
		return new InterfaceParam(m_impl.addAsRHS(a));
	}


	public InterfaceParam sub(InterfaceParam a)
	{
		return new InterfaceParam(m_impl.sub(a.m_impl));
	}


	public InterfaceParam sub(long a)
	{
		return new InterfaceParam(m_impl.sub(a));
	}


	public InterfaceParam sub(double a)
	{
		return new InterfaceParam(m_impl.sub(a));
	}

	public InterfaceParam subAsRHS(long a)
	{
		return new InterfaceParam(m_impl.subAsRHS(a));
	}


	public InterfaceParam subAsRHS(double a)
	{
		return new InterfaceParam(m_impl.subAsRHS(a));
	}


	public InterfaceParam div(InterfaceParam a)
	{
		return new InterfaceParam(m_impl.div(a.m_impl));
	}


	public InterfaceParam div(long a)
	{
		return new InterfaceParam(m_impl.div(a));
	}


	public InterfaceParam div(double a)
	{
		return new InterfaceParam(m_impl.div(a));
	}


	public InterfaceParam divAsRHS(long a)
	{
		return new InterfaceParam(m_impl.divAsRHS(a));
	}


	public InterfaceParam divAsRHS(double a)
	{
		return new InterfaceParam(m_impl.divAsRHS(a));
	}


	public InterfaceParam mod(InterfaceParam a)
	{
		return new InterfaceParam(m_impl.mod(a.m_impl));
	}


	public InterfaceParam mod(long a)
	{
		return new InterfaceParam(m_impl.mod(a));
	}


	public InterfaceParam modAsRHS(long a)
	{
		return new InterfaceParam(m_impl.modAsRHS(a));
	}


	public InterfaceParam mul(InterfaceParam a)
	{
		return new InterfaceParam(m_impl.mul(a.m_impl));
	}


	public InterfaceParam mul(long a)
	{
		return new InterfaceParam(m_impl.mul(a));
	}

	public InterfaceParam mulAsRHS(long a)
	{
		return new InterfaceParam(m_impl.mulAsRHS(a));
	}

	public InterfaceParam mul(double a)
	{
		return new InterfaceParam(m_impl.mul(a));
	}

	public InterfaceParam mulAsRHS(double a)
	{
		return new InterfaceParam(m_impl.mulAsRHS(a));
	}


	// ---
	public InterfaceParam gt(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.gt(p.m_impl));
	}

	public InterfaceParam gt(long p)
	{
		return new InterfaceParam(m_impl.gt(p));
	}

	public InterfaceParam gt(double p)
	{
		return new InterfaceParam(m_impl.gt(p));
	}


	public InterfaceParam gtAsRHS(long p)
	{
		return new InterfaceParam(m_impl.gtAsRHS(p));
	}

	public InterfaceParam gtAsRHS(double p)
	{
		return new InterfaceParam(m_impl.gtAsRHS(p));
	}

	public InterfaceParam gte(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.gte(p.m_impl));
	}

	public InterfaceParam gte(long p)
	{
		return new InterfaceParam(m_impl.gte(p));
	}

	public InterfaceParam gte(double p)
	{
		return new InterfaceParam(m_impl.gte(p));
	}


	public InterfaceParam gteAsRHS(long p)
	{
		return new InterfaceParam(m_impl.gteAsRHS(p));
	}

	public InterfaceParam gteAsRHS(double p)
	{
		return new InterfaceParam(m_impl.gteAsRHS(p));
	}

	public InterfaceParam lt(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.lt(p.m_impl));
	}

	public InterfaceParam lt(long p)
	{
		return new InterfaceParam(m_impl.lt(p));
	}

	public InterfaceParam lt(double p)
	{
		return new InterfaceParam(m_impl.lt(p));
	}


	public InterfaceParam ltAsRHS(long p)
	{
		return new InterfaceParam(m_impl.ltAsRHS(p));
	}

	public InterfaceParam ltAsRHS(double p)
	{
		return new InterfaceParam(m_impl.ltAsRHS(p));
	}

	public InterfaceParam lte(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.lte(p.m_impl));
	}

	public InterfaceParam lte(long p)
	{
		return new InterfaceParam(m_impl.lte(p));
	}

	public InterfaceParam lte(double p)
	{
		return new InterfaceParam(m_impl.lte(p));
	}


	public InterfaceParam lteAsRHS(long p)
	{
		return new InterfaceParam(m_impl.lteAsRHS(p));
	}

	public InterfaceParam lteAsRHS(double p)
	{
		return new InterfaceParam(m_impl.lteAsRHS(p));
	}

	public InterfaceParam eq(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.eq(p.m_impl));
	}

	public InterfaceParam eq(long p)
	{
		return new InterfaceParam(m_impl.eq(p));
	}

	public InterfaceParam eq(double p)
	{
		return new InterfaceParam(m_impl.eq(p));
	}


	public InterfaceParam eqAsRHS(long p)
	{
		return new InterfaceParam(m_impl.eqAsRHS(p));
	}

	public InterfaceParam eqAsRHS(double p)
	{
		return new InterfaceParam(m_impl.eqAsRHS(p));
	}

	public InterfaceParam neq(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.neq(p.m_impl));
	}

	public InterfaceParam neq(long p)
	{
		return new InterfaceParam(m_impl.neq(p));
	}

	public InterfaceParam neq(double p)
	{
		return new InterfaceParam(m_impl.neq(p));
	}


	public InterfaceParam neqAsRHS(long p)
	{
		return new InterfaceParam(m_impl.neqAsRHS(p));
	}

	public InterfaceParam neqAsRHS(double p)
	{
		return new InterfaceParam(m_impl.neqAsRHS(p));
	}


	// ---

	public InterfaceParam and(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.and(p.m_impl));
	}

	public InterfaceParam and(long p)
	{
		return new InterfaceParam(m_impl.and(p));
	}

	public InterfaceParam andAsRHS(long p)
	{
		return new InterfaceParam(m_impl.andAsRHS(p));
	}

	public InterfaceParam or(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.or(p.m_impl));
	}

	public InterfaceParam or(long p)
	{
		return new InterfaceParam(m_impl.or(p));
	}

	public InterfaceParam orAsRHS(long p)
	{
		return new InterfaceParam(m_impl.orAsRHS(p));
	}

	public InterfaceParam xor(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.xor(p.m_impl));
	}

	public InterfaceParam xor(long p)
	{
		return new InterfaceParam(m_impl.xor(p));
	}

	public InterfaceParam xorAsRHS(long p)
	{
		return new InterfaceParam(m_impl.xorAsRHS(p));
	}

	// --
	public InterfaceParam shiftLeft(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.shiftLeft(p.m_impl));
	}

	public InterfaceParam shiftLeft(long p)
	{
		return new InterfaceParam(m_impl.shiftLeft(p));
	}

	public InterfaceParam shiftLeftAsRHS(long p)
	{
		return new InterfaceParam(m_impl.shiftLeftAsRHS(p));
	}

	public InterfaceParam shiftRight(InterfaceParam p)
	{
		return new InterfaceParam(m_impl.shiftRight(p.m_impl));
	}

	public InterfaceParam shiftRight(long p)
	{
		return new InterfaceParam(m_impl.shiftRight(p));
	}

	public InterfaceParam shiftRightAsRHS(long p)
	{
		return new InterfaceParam(m_impl.shiftRightAsRHS(p));
	}

	// --
	public InterfaceParam ternaryIf(long a, long b) {
        return new InterfaceParam(m_impl.ternaryIf(a, b));
	}

	public InterfaceParam ternaryIf(InterfaceParam a, long b) {
	        return new InterfaceParam(m_impl.ternaryIf(a.m_impl, b));
	}

	public InterfaceParam ternaryIf(long a, InterfaceParam b) {
	        return new InterfaceParam(m_impl.ternaryIf(a, b.m_impl));
	}

	public InterfaceParam ternaryIf(double a, double b) {
	        return new InterfaceParam(m_impl.ternaryIf(a, b));
	}

	public InterfaceParam ternaryIf(InterfaceParam a, double b) {
	        return new InterfaceParam(m_impl.ternaryIf(a.m_impl, b));
	}

	public InterfaceParam ternaryIf(double a, InterfaceParam b) {
	        return new InterfaceParam(m_impl.ternaryIf(a, b.m_impl));
	}

	public InterfaceParam ternaryIf(InterfaceParam a, InterfaceParam b) {
        return new InterfaceParam(m_impl.ternaryIf(a.m_impl, b.m_impl));
	}


	/* end generated code */

	public InterfaceParam neg()
	{
		return new InterfaceParam(m_impl.neg());
	}

	public InterfaceParam plus()
	{
		return new InterfaceParam(m_impl.plus());
	}

	public InterfaceParam complement()
	{
		return new InterfaceParam(m_impl.complement());
	}

	public InterfaceParam logicalNot()
	{
		return new InterfaceParam(m_impl.logicalNot());
	}


}
