package com.maxeler.maxcompiler.v2.kernelcompiler.op_management;

public enum EnableExceptionTypes {
	DFE_FIX,
	DFE_FLOAT,
	DFE_FIX_DFE_FLOAT
}
