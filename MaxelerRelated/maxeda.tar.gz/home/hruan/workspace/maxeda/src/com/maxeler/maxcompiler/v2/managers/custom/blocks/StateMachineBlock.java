package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeStateMachine;

public class StateMachineBlock implements ManagerBlock {
	private final WrapperNodeStateMachine m_node;

	StateMachineBlock(WrapperNodeStateMachine node) {
		m_node = node;
	}

	public DFELink getInput(String name) {
		return _CustomManagers.fromImp(m_node.getInput(name));
	}

	public DFELink getOutput(String name) {
		return _CustomManagers.fromImp(m_node.getOutput(name));
	}

	@Override
	public void setClock(ManagerClock clock) {
		m_node.setClock(_CustomManagers.managerClockToImp(clock));
	}

}
