package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.StateMachineInternalException;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.expressions.BinaryOp;
import com.maxeler.statemachine.expressions.Cast;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.Slice;
import com.maxeler.statemachine.expressions.UnaryOp;
import com.maxeler.utils.MaxCompilerHide;

public class DFEsmValue extends DFEsmExpr {
	/**
	 * @exclude
	 */
	@MaxCompilerHide
	protected DFEsmValue(Expression expr) {
		super(expr);
		if (!(expr.getType() instanceof DFEsmValueType))
			throw new StateMachineInternalException("Cannot create an DFEsmValue with expression of type %s.", expr.getType());
	}

	private DFEsmValue binOp(BinaryOp.Operation op, long value) {
		final DFEsmValueType type = getType();
		Utils.checkIsAllowedLiteralValue(value, type);

		return binOp(op, BigInteger.valueOf(value));
	}

	private DFEsmValue binOp(BinaryOp.Operation op, BigInteger value) {
		final DFEsmValueType type = getType();
		if (!Utils.canRepresent(value, type))
			throw new MaxCompilerAPIError("Cannot represent %d in type %s.", value, type);

		Constant rhs = new Constant(value, type);
		return new DFEsmValue(new BinaryOp(op, getExpression(), rhs));
	}

	private DFEsmValue binOpNoCast(BinaryOp.Operation op, long value) {
		if (op != BinaryOp.Operation.SHIFT_LEFT && op != BinaryOp.Operation.SHIFT_RIGHT)
			throw new StateMachineInternalException("'binOpNoCast' should only be used for shift operations, not %s.", op.name());

		Constant rhs = new Constant(value);
		return new DFEsmValue(new BinaryOp(op, getExpression(), rhs));
	}

	private DFEsmValue binOpRHS(BinaryOp.Operation op, long value) {
		final DFEsmValueType type = getType();
		Utils.checkIsAllowedLiteralValue(value, type);

		return binOpRHS(op, BigInteger.valueOf(value));
	}

	private DFEsmValue binOpRHS(BinaryOp.Operation op, BigInteger value) {
		final DFEsmValueType type = getType();
		if (!Utils.canRepresent(value, type))
			throw new MaxCompilerAPIError("Cannot represent %d in type %s.", value, type);

		Constant lhs = new Constant(value, type);
		return new DFEsmValue(new BinaryOp(op, lhs, getExpression()));
	}

	private DFEsmValue binOp(BinaryOp.Operation op, DFEsmValue exprRHS) {
		return new DFEsmValue(new BinaryOp(op, getExpression(), exprRHS.getExpression()));
	}

	private DFEsmValue unaryOp(UnaryOp.Operation op) { return new DFEsmValue(new UnaryOp(op, getExpression())); }

	@Override
	public DFEsmValueType getType() { return (DFEsmValueType) super.getType(); }

	public DFEsmValue complement() { return unaryOp(UnaryOp.Operation.COMPLEMENT); }

	public DFEsmValue neg() { return unaryOp(UnaryOp.Operation.NEGATE); }

	public DFEsmValue add(int value) { return binOp(BinaryOp.Operation.ADD, value); }
	public DFEsmValue add(long value) { return binOp(BinaryOp.Operation.ADD, value); }
	public DFEsmValue add(BigInteger value) { return binOp(BinaryOp.Operation.ADD, value); }
	public DFEsmValue add(DFEsmValue expr) { return binOp(BinaryOp.Operation.ADD, expr); }

	public DFEsmValue addAsRHS(int value) { return binOpRHS(BinaryOp.Operation.ADD, value); }
	public DFEsmValue addAsRHS(long value) { return binOpRHS(BinaryOp.Operation.ADD, value); }
	public DFEsmValue addAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.ADD, value); }

	public DFEsmValue sub(int value) { return binOp(BinaryOp.Operation.SUB, value); }
	public DFEsmValue sub(long value) { return binOp(BinaryOp.Operation.SUB, value); }
	public DFEsmValue sub(BigInteger value) { return binOp(BinaryOp.Operation.SUB, value); }
	public DFEsmValue sub(DFEsmValue expr) { return binOp(BinaryOp.Operation.SUB, expr); }

	public DFEsmValue subAsRHS(int value) { return binOpRHS(BinaryOp.Operation.SUB, value); }
	public DFEsmValue subAsRHS(long value) { return binOpRHS(BinaryOp.Operation.SUB, value); }
	public DFEsmValue subAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.SUB, value); }

	public DFEsmValue mul(int value) { return binOp(BinaryOp.Operation.MUL, value); }
	public DFEsmValue mul(long value) { return binOp(BinaryOp.Operation.MUL, value); }
	public DFEsmValue mul(BigInteger value) { return binOp(BinaryOp.Operation.MUL, value); }
	public DFEsmValue mul(DFEsmValue expr) { return binOp(BinaryOp.Operation.MUL, expr); }

	public DFEsmValue mulAsRHS(int value) { return binOpRHS(BinaryOp.Operation.MUL, value); }
	public DFEsmValue mulAsRHS(long value) { return binOpRHS(BinaryOp.Operation.MUL, value); }
	public DFEsmValue mulAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.MUL, value); }

	public DFEsmValue and(int value) { return binOp(BinaryOp.Operation.AND, value); }
	public DFEsmValue and(long value) { return binOp(BinaryOp.Operation.AND, value); }
	public DFEsmValue and(BigInteger value) { return binOp(BinaryOp.Operation.AND, value); }
	public DFEsmValue and(DFEsmValue expr) { return binOp(BinaryOp.Operation.AND, expr); }

	public DFEsmValue andAsRHS(int value) { return binOpRHS(BinaryOp.Operation.AND, value); }
	public DFEsmValue andAsRHS(long value) { return binOpRHS(BinaryOp.Operation.AND, value); }
	public DFEsmValue andAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.AND, value); }

	public DFEsmValue or(int value) { return binOp(BinaryOp.Operation.OR, value); }
	public DFEsmValue or(long value) { return binOp(BinaryOp.Operation.OR, value); }
	public DFEsmValue or(BigInteger value) { return binOp(BinaryOp.Operation.OR, value); }
	public DFEsmValue or(DFEsmValue expr) { return binOp(BinaryOp.Operation.OR, expr); }

	public DFEsmValue orAsRHS(int value) { return binOpRHS(BinaryOp.Operation.OR, value); }
	public DFEsmValue orAsRHS(long value) { return binOpRHS(BinaryOp.Operation.OR, value); }
	public DFEsmValue orAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.OR, value); }

	public DFEsmValue xor(int value) { return binOp(BinaryOp.Operation.XOR, value); }
	public DFEsmValue xor(long value) { return binOp(BinaryOp.Operation.XOR, value); }
	public DFEsmValue xor(BigInteger value) { return binOp(BinaryOp.Operation.XOR, value); }
	public DFEsmValue xor(DFEsmValue expr) { return binOp(BinaryOp.Operation.XOR, expr); }

	public DFEsmValue xorAsRHS(int value) { return binOpRHS(BinaryOp.Operation.XOR, value); }
	public DFEsmValue xorAsRHS(long value) { return binOpRHS(BinaryOp.Operation.XOR, value); }
	public DFEsmValue xorAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.XOR, value); }

	public DFEsmValue eq(boolean value) { return binOp(BinaryOp.Operation.EQUAL, value ? 1 : 0); }
	public DFEsmValue eq(int value) { return binOp(BinaryOp.Operation.EQUAL, value); }
	public DFEsmValue eq(long value) { return binOp(BinaryOp.Operation.EQUAL, value); }
	public DFEsmValue eq(BigInteger value) { return binOp(BinaryOp.Operation.EQUAL, value); }
	public DFEsmValue eq(DFEsmValue expr) { return binOp(BinaryOp.Operation.EQUAL, expr); }

	public DFEsmValue neq(boolean value) { return binOp(BinaryOp.Operation.NOT_EQUAL, value ? 1 : 0); }
	public DFEsmValue neq(int value) { return binOp(BinaryOp.Operation.NOT_EQUAL, value); }
	public DFEsmValue neq(long value) { return binOp(BinaryOp.Operation.NOT_EQUAL, value); }
	public DFEsmValue neq(BigInteger value) { return binOp(BinaryOp.Operation.NOT_EQUAL, value); }
	public DFEsmValue neq(DFEsmValue expr) { return binOp(BinaryOp.Operation.NOT_EQUAL, expr); }

	public DFEsmValue lt(int value) { return binOp(BinaryOp.Operation.LESS_THAN, value); }
	public DFEsmValue lt(long value) { return binOp(BinaryOp.Operation.LESS_THAN, value); }
	public DFEsmValue lt(BigInteger value) { return binOp(BinaryOp.Operation.LESS_THAN, value); }
	public DFEsmValue lt(DFEsmValue expr) { return binOp(BinaryOp.Operation.LESS_THAN, expr); }

	public DFEsmValue ltAsRHS(int value) { return binOpRHS(BinaryOp.Operation.LESS_THAN, value); }
	public DFEsmValue ltAsRHS(long value) { return binOpRHS(BinaryOp.Operation.LESS_THAN, value); }
	public DFEsmValue ltAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.LESS_THAN, value); }

	public DFEsmValue lte(int value) { return binOp(BinaryOp.Operation.LESS_THAN_EQUAL, value); }
	public DFEsmValue lte(long value) { return binOp(BinaryOp.Operation.LESS_THAN_EQUAL, value); }
	public DFEsmValue lte(BigInteger value) { return binOp(BinaryOp.Operation.LESS_THAN_EQUAL, value); }
	public DFEsmValue lte(DFEsmValue expr) { return binOp(BinaryOp.Operation.LESS_THAN_EQUAL, expr); }

	public DFEsmValue lteAsRHS(int value) { return binOpRHS(BinaryOp.Operation.LESS_THAN_EQUAL, value); }
	public DFEsmValue lteAsRHS(long value) { return binOpRHS(BinaryOp.Operation.LESS_THAN_EQUAL, value); }
	public DFEsmValue lteAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.LESS_THAN_EQUAL, value); }

	public DFEsmValue gt(int value) { return binOp(BinaryOp.Operation.GREATER_THAN, value); }
	public DFEsmValue gt(long value) { return binOp(BinaryOp.Operation.GREATER_THAN, value); }
	public DFEsmValue gt(BigInteger value) { return binOp(BinaryOp.Operation.GREATER_THAN, value); }
	public DFEsmValue gt(DFEsmValue expr) { return binOp(BinaryOp.Operation.GREATER_THAN, expr); }

	public DFEsmValue gtAsRHS(int value) { return binOpRHS(BinaryOp.Operation.GREATER_THAN, value); }
	public DFEsmValue gtAsRHS(long value) { return binOpRHS(BinaryOp.Operation.GREATER_THAN, value); }
	public DFEsmValue gtAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.GREATER_THAN, value); }

	public DFEsmValue gte(int value) { return binOp(BinaryOp.Operation.GREATER_THAN_EQUAL, value); }
	public DFEsmValue gte(long value) { return binOp(BinaryOp.Operation.GREATER_THAN_EQUAL, value); }
	public DFEsmValue gte(BigInteger value) { return binOp(BinaryOp.Operation.GREATER_THAN_EQUAL, value); }
	public DFEsmValue gte(DFEsmValue expr) { return binOp(BinaryOp.Operation.GREATER_THAN_EQUAL, expr); }

	public DFEsmValue gteAsRHS(int value) { return binOpRHS(BinaryOp.Operation.GREATER_THAN_EQUAL, value); }
	public DFEsmValue gteAsRHS(long value) { return binOpRHS(BinaryOp.Operation.GREATER_THAN_EQUAL, value); }
	public DFEsmValue gteAsRHS(BigInteger value) { return binOpRHS(BinaryOp.Operation.GREATER_THAN_EQUAL, value); }

	/**
	 * Perform a logical left shift.
	 * <p>
	 * The {@code shiftAmount} least significant bits of the result will be
	 * set to 0.
	 * @param shiftAmount The number of bits to shift left by. If this value is
	 * negative then this will be implemented as a right shift by absolute shift
	 * amount.
	 * @return The input value shifted left by the specified number of bits.
	 */
	public DFEsmValue shiftLeft(int shiftAmount) {
		return shiftAmount < 0 ? shiftRight(-shiftAmount) : binOpNoCast(BinaryOp.Operation.SHIFT_LEFT, shiftAmount);
	}

	/**
	 * Perform an arithmetic right shift.
	 * <p>
	 * The {@code shiftAmount} most significant bits of the result will be the
	 * same as the sign of the input. For unsigned integer types this will always
	 * be 0.
	 * @param shiftAmount The number of bits to shift right by. If this value is
	 * negative then this will be implemented as a left shift by the absolute
	 * shift amount.
	 * @return The input value shifted right by the specified number of bits.
	 */
	public DFEsmValue shiftRight(int shiftAmount) {
		return shiftAmount < 0 ? shiftLeft(-shiftAmount) : binOpNoCast(BinaryOp.Operation.SHIFT_RIGHT, shiftAmount);
	}

	public DFEsmValue cat(DFEsmValue lsb) { return binOp(BinaryOp.Operation.CONCAT, lsb); }

	/**
	 * Cast this expression to an integer type.
	 * @param type The type to convert to.
	 * @return The value of this expression as cast to the specified type.
	 */
	public DFEsmValue cast(DFEsmValueType type) {
		if (type == null)
			throw MaxCompilerAPIError.nullParam("type");

		return new DFEsmValue(new Cast(getExpression(), type));
	}

	public DFEsmValue slice(int base, int width) {
		final DFEsmValueType type = getType();
		final int numBits = type.getTotalBits();

		if (base < 0 || base >= numBits)
			throw new MaxCompilerAPIError("Base for slice operation must be between 0 and %d (inclusive) for type %s, not %d.", numBits - 1, type, base);
		if (width < 0)
			throw new MaxCompilerAPIError("Width for slice operation must be between 1 and %d (inclusive) for type %s, not %d.", numBits, type, width);
		if (base + width > numBits)
			throw new MaxCompilerAPIError("Base + width for slice operation must be <= %d for type %s, not %d.", numBits, type, base + width);

		return new DFEsmValue(new Slice(getExpression(), base, width));
	}

	public DFEsmValue get(int index) {return slice(index,1);}
	public DFEsmValue get(int indexto, int indexfrom) {return slice(indexfrom, indexto - indexfrom + 1);}
}
