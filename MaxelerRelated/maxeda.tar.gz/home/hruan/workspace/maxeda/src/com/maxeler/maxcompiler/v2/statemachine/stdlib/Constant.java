package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmValue;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmTypeFactory;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.Utils;

/**
 * A library for creating constants.
 */
public final class Constant extends Lib {
	// make default constructor invisible
	Constant(StateMachineLib owner) { super(owner); }

	/**
	 * Create a Boolean constant.
	 * @param value The value of the constant.
	 * @return A Boolean constant value with the same type as returned by
	 * {@link DFEsmTypeFactory#dfeBool()}.
	 */
	public DFEsmValue value(boolean value) {
		return _StateMachine.Create.DFEsmValue(new com.maxeler.statemachine.expressions.Constant(value ? 1 : 0, DFEsmTypeFactory.dfeBool()));
	}


	/**
	 * Create an integer constant.
	 * @param type The type of the constant.
	 * @param value The value of the constant. You must be able to represent this
	 * value with the specified {@code type}.
	 * @return A constant expression with the specified value.
	 * @see #value(boolean)
	 * @see #value(DFEsmValueType, BigInteger)
	 */
	public DFEsmValue value(DFEsmValueType type, long value) {
		if (!Utils.canRepresent(value, type))
			throw new MaxCompilerAPIError("Cannot represent the value %d using the type %s.", value, type);
		Utils.checkIsAllowedLiteralValue(value, type);

		return _StateMachine.Create.DFEsmValue(new com.maxeler.statemachine.expressions.Constant(value, type));
	}

	/**
	 * Create an integer constant.
	 * @param type The type of the constant.
	 * @param value The value of the constant. You must be able to represent this
	 * value with the specified {@code type}.
	 * @return A constant expression with the specified value.
	 * @see #value(boolean)
	 * @see #value(DFEsmValueType, long)
	 */
	public DFEsmValue value(DFEsmValueType type, BigInteger value) {
		if (!Utils.canRepresent(value, type))
			throw new MaxCompilerAPIError("Cannot represent the value %d using the type %s.", value, type);

		return _StateMachine.Create.DFEsmValue(new com.maxeler.statemachine.expressions.Constant(value, type));
	}
}
