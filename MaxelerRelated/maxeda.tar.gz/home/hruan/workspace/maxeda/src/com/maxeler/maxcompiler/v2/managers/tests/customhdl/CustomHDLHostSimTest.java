package com.maxeler.maxcompiler.v2.managers.tests.customhdl;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.custom.CustomManager;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.CustomHDLBlock;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.CustomHDLNode;
import com.maxeler.maxcompiler.v2.managers.custom.blocks._CustomHDLNode;

public class CustomHDLHostSimTest {

	private static final int TEST_CTOR_ARG = 10;
	private static final String TEST_SETUP_ARG = "\"dupa\"";

	static class TestHDLNode extends _CustomHDLNode {
		public TestHDLNode(CustomManager manager) {
			super(manager, "CustomHDLNode", "NO_HDL_TOP_LEVEL", "project_stalingrad::CustomHDLHostSimTestSync", TEST_CTOR_ARG);

			addSimulationCppSource("/com/maxeler/maxcompiler/v2/managers/tests/customhdl/CustomHDLHostSimTest.cpp", false);
			addSimulationCppHeader("/com/maxeler/maxcompiler/v2/managers/tests/customhdl/CustomHDLHostSimTest.h", false);

			CustomNodeClock clock = addClockDomain("clock");

			addInputStream("input", 32, clock, CustomNodeFlowControl.PULL, 0);
			addOutputStream("output", 32, clock, CustomNodeFlowControl.PUSH, 0);

			addSimulationSetupCall("setup", TEST_SETUP_ARG);
		}
	}



	static class TestManager extends CustomManager {
		public TestManager(String name) {
			super(new _EngineParameters(name, MAX2BoardModel.MAX2446C, EngineParameters.Target.MAXFILE_FOR_SIMULATION));
			DFELink sfh = addStreamFromCPU("input");
			DFELink sth = addStreamToCPU("output");

			CustomHDLNode node = new TestHDLNode(this);
			CustomHDLBlock block = addCustomHDL(node);
			block.getInput("input").connect(sfh);
			sth.connect(block.getOutput("output"));
		}
	}



	public static void main(String... args) {
		CustomManager manager = new TestManager("CustomHDLHostSimTest");
		manager.build();
	}
}
