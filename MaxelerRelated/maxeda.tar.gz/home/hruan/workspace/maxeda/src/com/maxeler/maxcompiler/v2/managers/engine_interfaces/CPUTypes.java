package com.maxeler.maxcompiler.v2.managers.engine_interfaces;

import com.maxeler.utils.EnumTranslator;


public enum CPUTypes {

	/* This should be kept in sync with
	 *  com.maxeler.maxeleros.managercompiler.software.modeinfo.CPUTypes
	 * _except_ for INT here, which should map to INT64 there.
	 */
	/** Type corresponding to uint8_t */
	UINT8,
	/** Type corresponding to int8_t */
	INT8,
	/** Type corresponding to uint16_t */
	UINT16,
	/** Type corresponding to int16_t */
	INT16,
	/** Type corresponding to int (int64_t) */
	INT,
	/** Type corresponding to int32_t */
	INT32,
	/** Type corresponding to uint32_t */
	UINT32,
	/** Type corresponding to uint64_t */
	UINT64,
	/** Type corresponding to int64_t */
	INT64,
	/** Type corresponding to float */
	FLOAT,
	/** Type corresponding to double */
	DOUBLE,
	/** Type corresponding to void */
	VOID;

	static com.maxeler.maxeleros.managercompiler.software.modeinfo.CPUTypes toMaxelerOS(CPUTypes t)
	{
		if(t == INT)
			return com.maxeler.maxeleros.managercompiler.software.modeinfo.CPUTypes.INT64;
		else
			return EnumTranslator.convert(
				t,
				com.maxeler.maxeleros.managercompiler.software.modeinfo.CPUTypes.class);
	}

	static CPUTypes fromMaxelerOS(com.maxeler.maxeleros.managercompiler.software.modeinfo.CPUTypes t)
	{
		return EnumTranslator.convert(t, CPUTypes.class);
	}

	/**
	 * @return size in byte of a variable of this type
	 */
	public int sizeInBytes()
	{
		return toMaxelerOS(this).sizeInBytes();
	}

	static {
		// Some static tests - Make sure that all types have a sizeInBytes()
		// and that they can all convert.
		for(CPUTypes t : CPUTypes.values() )
		{
			toMaxelerOS(t);
			if(t != VOID)
				t.sizeInBytes();
		}
	}

}
