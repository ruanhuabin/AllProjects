package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmTypeFactory;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.ExprUtils;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.Slice;
import com.maxeler.statemachine.expressions.Stream;
import com.maxeler.statemachine.expressions.StreamOutput;
import com.maxeler.statemachine.statements.StatementAssign;
import com.maxeler.statemachine.statements.StatementSliceAssign;

/**
 * An output stream from a {@link StateMachine}.
 */
public final class DFEsmOutput extends DFEsmSliceableVariable {
	private final StreamOutput m_var;
	private final StateMachineLib m_stateMachine;

	DFEsmOutput(StateMachineLib stateMachine, String name, DFEsmValueType type, Stream.StreamType streamType, int latency) {
		m_var = new StreamOutput(name, type, streamType, latency);
		m_stateMachine = stateMachine;
	}

	StreamOutput getOutput() { return m_var; }

	/**
	 * Get the name of this output.
	 * @return The name of this output.
	 */
	public String getName() { return getOutput().getName(); }

	/**
	 * Get the type of this output.
	 * @return An {@link DFEsmValueType} corresponding to the type of this output.
	 */
	public DFEsmValueType getType() { return getOutput().getType(); }

	/**
	 * Get the latency of this output.
	 * @return The latency of this output stream, in cycles.
	 */
	public int getLatency() { return getOutput().getLatency(); }

	@Override
	public <E extends Enum<E>> void connect(E value) {
		throw new MaxCompilerAPIError("Cannot assign enum %s to output of type %s.", value, getType());
	}

	@Override
	public void connect(boolean value) { connect(value ? 1 : 0); }

	@Override
	public void connect(long value) {
		Utils.checkIsAllowedLiteralValue(value, getType());
		connect(BigInteger.valueOf(value));
	}

	@Override
	public void connect(BigInteger value) { assign(new Constant(value)); }

	@Override
	public void connect(DFEsmExpr expr) { assign(expr.getExpression()); }

	private void assign(Expression expr) {
		if (m_stateMachine.getContextMode() != ContextMode.OUTPUT)
			throw new MaxCompilerAPIError("Output variables can only be modified inside the 'outputFunction' method.");

		expr = ExprUtils.implicitCast(getType(), "output", expr);
		m_stateMachine.addStatement(new StatementAssign(m_var, expr, _StateMachine.getBuildManager(m_stateMachine)));
	}

	@Override
	protected DFEsmExpr getDFEsmExpr() {
		return _StateMachine.Create.DFEsmExpr(m_var);
	}

	@Override
	public String toString() { return "output(" + super.toString() + ")"; }


	private final class OutputSliceAssigner extends DFEsmVariable {
		private final int m_base;
		private final int m_width;

		private OutputSliceAssigner(int base, int width) {
			m_base = base;
			m_width = width;
		}
		private OutputSliceAssigner(int bitPos) {
			m_base = bitPos;
			m_width = 1;
		}

		@Override
		protected DFEsmExpr getDFEsmExpr() {
			return _StateMachine.Create.DFEsmExpr(new Slice(m_var, m_base, m_width));
		}

		@Override
		public <E extends Enum<E>> void connect(E value) {
			DFEsmOutput.this.connect(value); // shows error message
		}

		@Override
		public void connect(boolean value) { connect(value ? 1 : 0); }

		@Override
		public void connect(long value) {
			Utils.checkIsAllowedLiteralValue(value, getType());
			connect(BigInteger.valueOf(value));
		}

		@Override
		public void connect(BigInteger value) { assign(new Constant(value)); }

		@Override
		public void connect(DFEsmExpr expr) { assign(expr.getExpression()); }

		private void assign(Expression expr) {
			if (m_stateMachine.getContextMode() != ContextMode.OUTPUT)
				throw new MaxCompilerAPIError("Output variables can only be modified inside the 'outputFunction' method.");

			expr = ExprUtils.implicitCast(DFEsmTypeFactory.dfeUInt(m_width), "integer output (slice)", expr);
			m_stateMachine.addStatement(
				new StatementSliceAssign(m_var, m_base, m_width, expr, _StateMachine.getBuildManager(m_stateMachine)));
		}
	}

	@Override
	public DFEsmVariable get(int index) {
		return new OutputSliceAssigner(index);
	}

	@Override
	public DFEsmVariable get(int indexto, int indexfrom) {
		if (indexto < indexfrom)
			throw new MaxCompilerAPIError("Slice width cannot be negative.");
		return new OutputSliceAssigner(indexfrom,indexto-indexfrom + 1);
	}
}
