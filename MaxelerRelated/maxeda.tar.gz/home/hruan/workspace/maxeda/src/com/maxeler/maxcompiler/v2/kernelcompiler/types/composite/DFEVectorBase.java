package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._AlreadyConnectedException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types._InternalUtils;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

/**
 * This is the base class for all multipipe streams.
 * <p>
 * See {@link DFEVector} for a concrete multipipe stream for use in Kernels.
 *  * <h3>Operators</h3>
 * {@code DFEVectorBase} streams offer overloaded operators:
 * <ul>
 * <li>Arithmetic operators ({@code +, -, *, /}).</li>
 * <li>Negation operator ({@code -}).</li>
 * <li>Relational operators ({@code <, <=, >, >=}).</li>
 * <li>Shift operators ({@code <<, >>}).</li>
 * <li>Bitwise complement operator ({@code ~}).</li>
 * <li>Bitwise operators ({@code &, ^, |}).</li>
 * <li>Ternary if operator ({@code ?:}).</li>
 * </ul>
 * <p>
 * All binary operators can operate on other multipipe streams, non-multipipe streams or Java construction-time constants.
 * <p>
 * A binary operation between two multipipe streams applies the operation between corresponding pipes of the two streams.
 * <p>
 * A binary operation between a multipipe stream and a non-multipipe stream (or Java construction-time constant) applies the operation between each pipe and the non-multipipe stream (or Java construction-time constant).
 * <p>
 * The result of a relational operation on a {@code DFEVectorBase} stream is a multipipe stream with the same number of pipes of {@code DFEVar} Boolean data ({@code CompareT}).
 * <p>
 * The ternary if operator can only be used on a multipipe stream of {@link DFEVar} Boolean data i.e. boolean_mp_type ? mp_type : mp_type.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 * @param <ContainedT> Kernel object for an individual pipe.
 * @param <VectRealT> The actual multipipe type (should be the type of the subclass).
 * @param <CompareT> Multipipe type returned for comparison operations. This is a multipipe of the same number of streams as {@code MPRealT} of {@link DFEVar} Boolean data.
 * @param <MPRealTType> Class that can create instances of this type.
 */
public abstract class DFEVectorBase<
		ContainedT extends KernelObjectVectorizable<ContainedT>,
		VectRealT extends DFEVectorBase<ContainedT, VectRealT, CompareT, MPRealTType>,
		CompareT extends DFEVectorBase<DFEVar, CompareT, ?, ?>,
		MPRealTType extends DFEVectorTypeBase<ContainedT, VectRealT, CompareT>
	>
	implements KernelObject<VectRealT>
{
	private final DFEArray<ContainedT> m_elements;
	private final MPRealTType m_type;

	/**
	 * @param type An object that can create instances of the real type.
	 */
	protected DFEVectorBase(DFEArray<ContainedT> pipes, MPRealTType type) {
		if (pipes == null)
			throw new MaxCompilerAPIError(getKernel().getManager(), "pipes parameter must not be null");
		if (type == null)
			throw new MaxCompilerAPIError(getKernel().getManager(), "type parameter must not be null");
		m_elements = pipes;
		m_type = type;
	}

	/**
	 * Returns the number of pipes in the stream.
	 */
	public int getNElements() { return m_elements.getSize(); }

	/**
	 * Returns the pipe at index {@code i} in the multipipe stream.
	 * @param i The index of the pipe to retrieve.
	 * @return The pipe at index {@code i} in the stream.
	 */
	public ContainedT getElement(int i) { return m_elements.get(i); }

	/**
	 * Connects the input of each pipe to the output of the corresponding pipe in {@code src}.
	 * @param src The multipipe stream source to which to connect.
	 * @return This stream.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public VectRealT connect(VectRealT src) {
		_InternalUtils.assertConnectTypes(this, src);

		m_elements.connect(src.m_elements);

		return (VectRealT) this;
	}

	/**
	 * Connects the input of pipe {@code pipe_index} to the output of stream {@code src}.
	 * @param element_index The index of the pipe to connect.
	 * @param src The input stream to connect to.
	 */
	public void connect(int element_index, ContainedT src) {
		try {
			getElement(element_index).connect(src);
		} catch (_AlreadyConnectedException e) {
			throw new _AlreadyConnectedException(this, element_index, e);
		}
	}

	/**
	 * Connects the inputs of all pipes to the output of stream {@code src}.
	 * @param src The input stream to connect to.
	 * @return This stream.
	 */
	@SuppressWarnings("unchecked")
	public VectRealT connect(ContainedT src) {
		for(int i = 0; i < getNElements(); i++)
			connect(i, src);

		return (VectRealT) this;
	}

	private CompareT newCompare() {
		return getType().newCompareInstance(getKernel());
	}

	private VectRealT toPiped(ContainedT c) {
		List<ContainedT> new_elements = newPipes();
		for (int i = 0; i < getNElements(); ++i)
			new_elements.add(c);
		return newElements(new_elements);
	}

	private List<ContainedT> newPipes() {
		return new ArrayList<ContainedT>(getNElements());
	}

	private VectRealT newElements(List<ContainedT> pipes) {
		return getType().newInstance(getKernel(), pipes);
	}

	public VectRealT add(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) + rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT add(ContainedT rhs) { return add(toPiped(rhs)); }

	public VectRealT addAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs + getElement(i));
		return newElements(new_elements);
	}

	@Override
	public DFEVar pack() {
		if(getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use pack() on this stream as it contains doubt information. " +
				"If you want to explicitly discard this information use " +
				"packWithoutDoubt(), otherwise use packWithDoubt().");

		return packWithoutDoubt();
	}

	@Override
	public List<DFEVar> packToList() {
		return m_elements.packToList();
	}


	@Override
	public VectRealT castDoubtType(DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEVectorDoubtType))
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Can only doubt-type cast DFEVector-dervied " +
				"types using a KMulitPipeDoubtType object.");

		DFEArray<ContainedT> new_elements =
			m_elements.castDoubtType(((DFEVectorDoubtType)doubt_type).getDFEArrayDoubtType());

		VectRealT new_inst = m_type.newInstance(getKernel(), doubt_type);
		for(int i = 0; i < getNElements(); i++)
			new_inst.connect(i, new_elements[i]);

		return new_inst;
	}

	@Override
	public DFEVectorDoubtType getDoubtType() {
		return new DFEVectorDoubtType(m_elements.getDoubtType());
	}

	@Override
	public DFEVar packWithDoubt() {
		return m_elements.packWithDoubt();
	}

	@Override
	public DFEVar packWithoutDoubt() {
		return m_elements.packWithoutDoubt();
	}

	@Override
	public MPRealTType getType() {
		return m_type;
	}

	/**
	 * Adds a watch to this stream.
	 * <p>
	 * During simulation, all data passing through this stream will be logged for debugging purposes.
	 * <p>
	 * The pipes will be output named {@code name_0}, {@code name_1} etc.
	 * @param name The name for the watch node as it will appear in the output.
	 * @return This stream.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public VectRealT watch(String name) {
		m_elements.watch(name);

		return (VectRealT) this;
	}

	/**
	 * Adds a watch to this stream.
	 * <p>
	 * During a hardware run, all data passing through this stream will be logged for debugging purposes.
	 * <p>
	 * The pipes will be output named {@code name_0}, {@code name_1} etc.
	 * @param name The name for the watch node as it will appear in the output.
	 * @return This stream.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public VectRealT dfeWatch(String name) {
		m_elements.dfeWatch(name);

		return (VectRealT) this;
	}


	public VectRealT and(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) & rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT and(ContainedT rhs) { return and(toPiped(rhs)); }

	public VectRealT andAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs & getElement(i));
		return newElements(new_elements);
	}

	/**
	 * Concatenates the bits from each pipe with the corresponding pipe in {@code rhs}.
	 * @param rhs The data that will form the least significant
	 * bits of the concatenation in each output pipe.
	 * @return A new multipipe where each pipe is the concatenation of a pipe
	 * from this stream (the most significant bits) and the corresponding pipe from {@code rhs} (the least significant bits).
	 */
	public VectRealT cat(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i).cat(rhs.getElement(i)) );
		return newElements(new_elements);
	}

	/**
	 * Concatenates the bits from each pipe with the the single stream {@code rhs}.
	 * @param rhs The data that will form the least significant
	 * bits of the concatenation in each output pipe.
	 * @return A new multipipe where each pipe is the concatenation of a pipe
	 * from this stream (the most significant bits) and {@code rhs} (the least significant bits).
	 */
	public VectRealT cat(ContainedT rhs) { return cat(toPiped(rhs)); }

	public VectRealT catAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs.cat(getElement(i)));
		return newElements(new_elements);
	}

	public VectRealT div(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) / rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT div(ContainedT rhs) { return div(toPiped(rhs)); }

	public VectRealT divAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs / getElement(i));
		return newElements(new_elements);
	}

	public CompareT eq(VectRealT rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eq(rhs.getElement(i)));
		return c;
	}

	public CompareT eq(ContainedT rhs) { return eq(toPiped(rhs)); }

	public CompareT eqAsRHS(ContainedT lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) lhs.eq(getElement(i)));
		return c;
	}

	public CompareT eq(double rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eq(rhs));
		return c;
	}

	public CompareT eq(float rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eq(rhs));
		return c;
	}

	public CompareT eq(int rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eq(rhs));
		return c;
	}

	public CompareT eq(long rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eq(rhs));
		return c;
	}

	public CompareT eqAsRHS(double lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eqAsRHS(lhs));
		return c;
	}

	public CompareT eqAsRHS(float lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eqAsRHS(lhs));
		return c;
	}

	public CompareT eqAsRHS(int lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eqAsRHS(lhs));
		return c;
	}

	public CompareT eqAsRHS(long lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).eqAsRHS(lhs));
		return c;
	}

	public CompareT gt(VectRealT rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) > rhs.getElement(i)));
		return c;
	}

	public CompareT gt(ContainedT rhs) { return gt(toPiped(rhs)); }

	public CompareT gt(double rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) > rhs));
		return c;
	}

	public CompareT gt(float rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) > rhs));
		return c;
	}

	public CompareT gt(int rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) > rhs));
		return c;
	}

	public CompareT gt(long rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) > rhs));
		return c;
	}

	public CompareT gtAsRHS(ContainedT lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs > getElement(i)));
		return c;
	}

	public CompareT gtAsRHS(double lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs > getElement(i)));
		return c;
	}

	public CompareT gtAsRHS(float lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs > getElement(i)));
		return c;
	}

	public CompareT gtAsRHS(int lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs > getElement(i)));
		return c;
	}

	public CompareT gtAsRHS(long lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs > getElement(i)));
		return c;
	}

	public CompareT gte(VectRealT rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) >= rhs.getElement(i)));
		return c;
	}

	public CompareT gte(ContainedT rhs) { return gte(toPiped(rhs)); }

	public CompareT gte(double rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) >= rhs));
		return c;
	}

	public CompareT gte(float rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) >= rhs));
		return c;
	}

	public CompareT gte(int rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) >= rhs));
		return c;
	}

	public CompareT gte(long rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) >= rhs));
		return c;
	}

	public CompareT gteAsRHS(ContainedT lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs >= getElement(i)));
		return c;
	}

	public CompareT gteAsRHS(double lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs >= getElement(i)));
		return c;
	}

	public CompareT gteAsRHS(float lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs >= getElement(i)));
		return c;
	}

	public CompareT gteAsRHS(int lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs >= getElement(i)));
		return c;
	}

	public CompareT gteAsRHS(long lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs >= getElement(i)));
		return c;
	}

	public CompareT lt(VectRealT rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs.getElement(i)));
		return c;
	}

	public CompareT lt(ContainedT rhs) { return lt(toPiped(rhs)); }

	public CompareT lt(double rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT lt(float rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT lt(int rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT lt(long rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT ltAsRHS(double lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs < getElement(i)));
		return c;
	}

	public CompareT ltAsRHS(float lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs < getElement(i)));
		return c;
	}

	public CompareT ltAsRHS(int lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs < getElement(i)));
		return c;
	}

	public CompareT ltAsRHS(long lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs < getElement(i)));
		return c;
	}

	public CompareT ltAsRHS(ContainedT lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs < getElement(i)));
		return c;
	}

	public CompareT lte(VectRealT rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) <= rhs.getElement(i)));
		return c;
	}

	public CompareT lte(ContainedT rhs) { return lte(toPiped(rhs)); }

	public CompareT lte(double rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT lte(float rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT lte(int rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT lte(long rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i) < rhs));
		return c;
	}

	public CompareT lteAsRHS(ContainedT lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs <= getElement(i)));
		return c;
	}

	public CompareT lteAsRHS(double lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs <= getElement(i)));
		return c;
	}

	public CompareT lteAsRHS(float lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs <= getElement(i)));
		return c;
	}

	public CompareT lteAsRHS(int lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs <= getElement(i)));
		return c;
	}

	public CompareT lteAsRHS(long lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (lhs <= getElement(i)));
		return c;
	}

	public VectRealT mul(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) * rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT mul(ContainedT rhs) { return mul(toPiped(rhs)); }

	public VectRealT mulAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs * getElement(i));
		return newElements(new_elements);
	}

	public VectRealT neg() {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(-getElement(i));
		return newElements(new_elements);
	}

	public CompareT neq(VectRealT rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) (getElement(i).neq(rhs.getElement(i))));
		return c;
	}

	public CompareT neq(ContainedT rhs) { return neq(toPiped(rhs)); }

	public CompareT neq(double rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neq(rhs));
		return c;
	}

	public CompareT neq(float rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neq(rhs));
		return c;
	}

	public CompareT neq(int rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neq(rhs));
		return c;
	}

	public CompareT neq(long rhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neq(rhs));
		return c;
	}

	public CompareT neqAsRHS(ContainedT lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) lhs.neq(getElement(i)));
		return c;
	}

	public CompareT neqAsRHS(double lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neqAsRHS(lhs));
		return c;
	}

	public CompareT neqAsRHS(float lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neqAsRHS(lhs));
		return c;
	}

	public CompareT neqAsRHS(int lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neqAsRHS(lhs));
		return c;
	}

	public CompareT neqAsRHS(long lhs) {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, (DFEVar) getElement(i).neqAsRHS(lhs));
		return c;
	}

	public VectRealT complement() {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(~getElement(i));
		return newElements(new_elements);
	}

	public VectRealT or(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) | rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT or(ContainedT rhs) { return or(toPiped(rhs)); }

	public VectRealT orAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs | getElement(i));
		return newElements(new_elements);
	}

	/**
	 * Selects a range of bits from each pipe in this stream.
	 * <p>
	 * Each pipe in the returned stream contains {@code width} bits from position {@code base} in the corresponding pipe of this stream.
	 * @param base The start bit position in the word.
	 * @param width The number of bits to select.
	 * @return A new multipipe stream containing the selected bits.
	 */
	public VectRealT slice(int base, int width) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i).slice(base, width));
		return newElements(new_elements);
	}

	public VectRealT sub(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) - rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT sub(ContainedT rhs) { return sub(toPiped(rhs)); }

	public VectRealT subAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs - getElement(i));
		return newElements(new_elements);
	}

	public VectRealT ternaryIf(VectRealT true_cond, VectRealT false_cond) {
		// TODO: are these conditions correct / needed?
		if(!(getType().getContainedType() instanceof DFEType) ||
		   (((DFEType)getType().getContainedType()).isConcreteType() &&
			!((DFEType)getType().getContainedType()).isBool()))
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Can only perform ternaryIf (?:) on multi-pipe boolean types. This type is " + getType());


		if(true_cond.getNElements() != getNElements() || false_cond.getNElements() != getNElements())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Number of pipes not compatible in expression: " +
				getType() + " ? " + true_cond.getType() + " : " + false_cond.getType());

		// TODO: should assert both types have the same pipe types?

		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) ? true_cond.getElement(i) : false_cond.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT ternaryIf(ContainedT true_cond, VectRealT false_cond) {
		VectRealT t = false_cond.getType().newInstance(false_cond.getKernel(), true_cond);
		return ternaryIf(t, false_cond);
	}

	public VectRealT ternaryIf(VectRealT true_cond, ContainedT false_cond) {
		VectRealT f = true_cond.getType().newInstance(true_cond.getKernel(), false_cond);
		return ternaryIf(true_cond, f);
	}

	public VectRealT ternaryIf(ContainedT true_cond, ContainedT false_cond) {
		return ternaryIf(toPiped(true_cond), toPiped(false_cond));
	}

	public VectRealT xor(VectRealT rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) ^ rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT xor(ContainedT rhs) { return xor(toPiped(rhs)); }

	public VectRealT xorAsRHS(ContainedT lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs ^ getElement(i));
		return newElements(new_elements);
	}

	/**
	 * @deprecated Use {@link #shiftLeft(DFEVectorBase)}.
	 */
	@Deprecated
	public VectRealT leftShift(DFEVectorBase<DFEVar, ?, ?, ?> rhs) { return shiftLeft(rhs); }

	/**
	 * @deprecated Use {@link #shiftLeft(DFEVar)}.
	 */
	@Deprecated
	public VectRealT leftShift(DFEVar rhs) { return shiftLeft(rhs); }

	/**
	 * @deprecated Use {@link #shiftLeft(int)}.
	 */
	@Deprecated
	public VectRealT leftShift(int shift_amt) { return shiftLeft(shift_amt); }

	public VectRealT shiftLeft(DFEVectorBase<DFEVar, ?, ?, ?> rhs) {
		if (getNElements() != rhs.getNElements())
			throw new MaxCompilerAPIError(getKernel().getManager(), "multi-pipe types must have the same number of pipes for left shift (" + getNElements() + " vs. " + rhs.getNElements() + ")");
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) << rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT shiftLeft(DFEVar rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) << rhs);
		return newElements(new_elements);
	}

	public VectRealT shiftLeft(int shift_amt) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) << shift_amt);
		return newElements(new_elements);
	}

	/**
	 * @deprecated Use {@link #shiftRight(DFEVectorBase)}.
	 */
	@Deprecated
	public VectRealT rightShift(DFEVectorBase<DFEVar, ?, ?, ?> rhs) { return shiftRight(rhs); }

	/**
	 * @deprecated Use {@link #shiftRight(DFEVar)}.
	 */
	@Deprecated
	public VectRealT rightShift(DFEVar rhs) { return shiftRight(rhs); }

	/**
	 * @deprecated Use {@link #shiftRight(int)}.
	 */
	@Deprecated
	public VectRealT rightShift(int shift_amt) { return shiftRight(shift_amt); }

	public VectRealT shiftRight(DFEVectorBase<DFEVar, ?, ?, ?> rhs) {
		if (getNElements() != rhs.getNElements())
			throw new MaxCompilerAPIError(getKernel().getManager(), "multi-pipe types must have the same number of pipes for right shift (" + getNElements() + " vs. " + rhs.getNElements() + ")");
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) >> rhs.getElement(i));
		return newElements(new_elements);
	}

	public VectRealT shiftRight(DFEVar rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) >> rhs);
		return newElements(new_elements);
	}

	public VectRealT shiftRight(int shift_amt) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) >> shift_amt);
		return newElements(new_elements);
	}

	@Override
	public Kernel getKernel() { return m_elements.getKernel(); }

	public VectRealT add(double rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) + rhs);
		return newElements(new_elements);
	}

	public VectRealT add(float rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) + rhs);
		return newElements(new_elements);
	}

	public VectRealT add(int rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) + rhs);
		return newElements(new_elements);
	}

	public VectRealT add(long rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) + rhs);
		return newElements(new_elements);
	}

	public VectRealT addAsRHS(double lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs + getElement(i));
		return newElements(new_elements);
	}

	public VectRealT addAsRHS(float lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs + getElement(i));
		return newElements(new_elements);
	}

	public VectRealT addAsRHS(int lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs + getElement(i));
		return newElements(new_elements);
	}

	public VectRealT addAsRHS(long lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs + getElement(i));
		return newElements(new_elements);
	}

	public VectRealT and(double rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) & rhs);
		return newElements(new_elements);
	}

	public VectRealT and(float rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) & rhs);
		return newElements(new_elements);
	}

	public VectRealT and(int rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) & rhs);
		return newElements(new_elements);
	}

	public VectRealT and(boolean rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) & rhs);
		return newElements(new_elements);
	}

	public VectRealT and(long rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) & rhs);
		return newElements(new_elements);
	}

	public VectRealT andAsRHS(double lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs & getElement(i));
		return newElements(new_elements);
	}

	public VectRealT andAsRHS(float lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs & getElement(i));
		return newElements(new_elements);
	}

	public VectRealT andAsRHS(int lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs & getElement(i));
		return newElements(new_elements);
	}

	public VectRealT andAsRHS(boolean lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs & getElement(i));
		return newElements(new_elements);
	}

	public VectRealT andAsRHS(long lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs & getElement(i));
		return newElements(new_elements);
	}

	public VectRealT div(double rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) / rhs);
		return newElements(new_elements);
	}

	public VectRealT div(float rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) / rhs);
		return newElements(new_elements);
	}

	public VectRealT div(int rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) / rhs);
		return newElements(new_elements);
	}

	public VectRealT div(long rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) / rhs);
		return newElements(new_elements);
	}

	public VectRealT divAsRHS(double lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs / getElement(i));
		return newElements(new_elements);
	}

	public VectRealT divAsRHS(float lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs / getElement(i));
		return newElements(new_elements);
	}

	public VectRealT divAsRHS(int lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs / getElement(i));
		return newElements(new_elements);
	}

	public VectRealT divAsRHS(long lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs / getElement(i));
		return newElements(new_elements);
	}

	public VectRealT mul(double rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) * rhs);
		return newElements(new_elements);
	}

	public VectRealT mul(float rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) * rhs);
		return newElements(new_elements);
	}

	public VectRealT mul(int rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) * rhs);
		return newElements(new_elements);
	}

	public VectRealT mul(long rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) * rhs);
		return newElements(new_elements);
	}

	public VectRealT mulAsRHS(double lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs * getElement(i));
		return newElements(new_elements);
	}

	public VectRealT mulAsRHS(float lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs * getElement(i));
		return newElements(new_elements);
	}

	public VectRealT mulAsRHS(int lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs * getElement(i));
		return newElements(new_elements);
	}

	public VectRealT mulAsRHS(long lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs * getElement(i));
		return newElements(new_elements);
	}

	public VectRealT or(double rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) | rhs);
		return newElements(new_elements);
	}

	public VectRealT or(float rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) | rhs);
		return newElements(new_elements);
	}

	public VectRealT or(int rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) | rhs);
		return newElements(new_elements);
	}

	public VectRealT or(boolean rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) | rhs);
		return newElements(new_elements);
	}

	public VectRealT or(long rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) | rhs);
		return newElements(new_elements);
	}

	public VectRealT orAsRHS(double lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs | getElement(i));
		return newElements(new_elements);
	}

	public VectRealT orAsRHS(float lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs | getElement(i));
		return newElements(new_elements);
	}

	public VectRealT orAsRHS(int lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs | getElement(i));
		return newElements(new_elements);
	}

	public VectRealT orAsRHS(boolean lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs | getElement(i));
		return newElements(new_elements);
	}

	public VectRealT orAsRHS(long lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs | getElement(i));
		return newElements(new_elements);
	}

	public VectRealT sub(double rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) - rhs);
		return newElements(new_elements);
	}

	public VectRealT sub(float rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) - rhs);
		return newElements(new_elements);
	}

	public VectRealT sub(int rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) - rhs);
		return newElements(new_elements);
	}

	public VectRealT sub(long rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) - rhs);
		return newElements(new_elements);
	}

	public VectRealT subAsRHS(double lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs - getElement(i));
		return newElements(new_elements);
	}

	public VectRealT subAsRHS(float lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs - getElement(i));
		return newElements(new_elements);
	}

	public VectRealT subAsRHS(int lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs - getElement(i));
		return newElements(new_elements);
	}

	public VectRealT subAsRHS(long lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs - getElement(i));
		return newElements(new_elements);
	}

	public VectRealT xor(double rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) ^ rhs);
		return newElements(new_elements);
	}

	public VectRealT xor(float rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) ^ rhs);
		return newElements(new_elements);
	}

	public VectRealT xor(int rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) ^ rhs);
		return newElements(new_elements);
	}

	public VectRealT xor(boolean rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) ^ rhs);
		return newElements(new_elements);
	}

	public VectRealT xor(long rhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i) ^ rhs);
		return newElements(new_elements);
	}

	public VectRealT xorAsRHS(double lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs ^ getElement(i));
		return newElements(new_elements);
	}

	public VectRealT xorAsRHS(float lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs ^ getElement(i));
		return newElements(new_elements);
	}

	public VectRealT xorAsRHS(int lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs ^ getElement(i));
		return newElements(new_elements);
	}

	public VectRealT xorAsRHS(boolean lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs ^ getElement(i));
		return newElements(new_elements);
	}

	public VectRealT xorAsRHS(long lhs) {
		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(lhs ^ getElement(i));
		return newElements(new_elements);
	}

	@Override
	public void setReportOnUnused(boolean should_report) {
		m_elements.setReportOnUnused(should_report);
	}

	@Override
	public DFEVar hasDoubt() {
		return m_elements.hasDoubt();
	}

	public CompareT hasAnyDoubtVect() {
		CompareT c = newCompare();
		for(int i = 0; i < getNElements(); i++)
			c.connect(i, getElement(i).hasDoubt());

		return c;
	}

	@Override
	public VectRealT addDoubtInfo() {
		return castDoubtType( getType().getFullTypeWithDoubtInfo().getDoubtType() );
	}

	@Override
	public VectRealT removeDoubtInfo() {
		return castDoubtType( getType().getFullTypeWithoutDoubtInfo().getDoubtType() );
	}

	@Override
	public VectRealT setDoubt(DFEVar doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public VectRealT setDoubt(boolean doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public VectRealT setDoubt(DFEVar doubt, SetDoubtOperation operation) {
		if (!getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot use setDoubt on this stream as it doesn't contain doubt information.");

		List<ContainedT> new_elements = newPipes();
		for(int i = 0; i < getNElements(); i++)
			new_elements.add(getElement(i).setDoubt(doubt, operation));
		return newElements(new_elements);
	}

	@Override
	public VectRealT setDoubt(boolean doubt, SetDoubtOperation operation) {
		return setDoubt(getKernel().constant.var(doubt), operation);
	}
}
