package com.maxeler.maxcompiler.v2.kernelcompiler.types;

import java.util.List;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

/**
 * All classes that implement the {@code KernelObject} interface are <em>stream references</em>.
 * <p>
 * Stream references are typically produced by compiler constructs. Fore example, adding two streams references
 * produces a new stream reference with the sum of the input streams. In some cases, streams references can
 * be <em>source-less</em>: the stream they refer to in this case is set later using calls to {@link #connect(Object)}.
 * This is particularly useful for creating loops in a Kernel.
 * <p>
 * Stream references are often referred to as "streams" within this documentation for convenience
 * as stream references are the only way to get hold of streams in MaxCompiler.
 * <p>
 * Every {@code KernelObject} has an object of type {@link KernelType} which represents
 * the Kernel type of the data in the referenced stream.
 * <b>Note</b>:KernelObjects that can be used in a multipipe
 * extend {@link KernelObjectVectorizable} rather than {@code KernelObject} directly.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public interface KernelObject<RealT> {

	/**
	 * Returns a new stream cast from this stream to the specified Kernel type.
	 * <p>
	 * @param type The type to which to cast this object.
	 * @return The resulting cast stream.
	 */
	public KernelObject<?> cast(KernelType<?> type);

	public RealT castDoubtType(DoubtType doubt_type);

	/**
	 * Connects the input of this stream to the output of stream ({@code src}).
	 * <p>
	 * This is used to connect <em>source-less</em> streams created via {@link KernelType#newInstance(com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib)}
	 * to an input stream. A common use is for creating backward edges in a graph.
	 * <p>
	 * MaxCompiler will throw an exception if this stream already has a source
	 * object connected.
	 * @param src The stream to which to connect.
	 * @return The unmodified stream {@code src}.
	 */
	public RealT connect(RealT src);

	/**
	 * Adds a watch to this stream.
	 * <p>
	 * During simulation, all data passing through this stream will be logged for debugging purposes.
	 * @param name The name for the watch data as it will appear in the output.
	 * @return This stream.
	 */
	public RealT watch(String name);

	/**
	 * Adds a hardware and simulation watch to this stream.
	 * <p>
	 * During a hardware or simulation run, all data passing through this stream
	 * will be logged for debugging purposes.
	 * <p>
	 * Note that this uses additional hardware resources.
	 * @param name The name for the watch data as it will appear in the output
	 * @return This stream.
	 */
	public RealT dfeWatch(String name);

	/**
	 * Gets the type of this stream.
	 * @return The type of this stream.
	 */
	public KernelType<RealT> getType();

	/**
	 * Packs this stream into a single primitive stream of type {@link com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits}.
	 * @return The new stream of {@code DFERawBits}.
	 */
	public DFEVar pack();
	public DFEVar packWithoutDoubt();
	public DFEVar packWithDoubt();

	/**
	 * Gets the Kernel in which this stream was created.
	 * @return The Kernel for this stream.
	 */
	public Kernel getKernel();

	/**
	 * Enables or disables MaxCompiler warnings on this stream being unused in the Kernel graph.
	 * <p>
	 * The default state is <em>enabled</em>.
	 * @param v Enables or disables warnings.
	 */
	public void setReportOnUnused(boolean v);

	public List<DFEVar> packToList();

	public DFEVar hasDoubt();

	public enum SetDoubtOperation { OVERRIDE, AND, OR };

	public RealT setDoubt(DFEVar doubt);
	public RealT setDoubt(boolean doubt);
	public RealT setDoubt(DFEVar doubt, SetDoubtOperation operation);
	public RealT setDoubt(boolean doubt, SetDoubtOperation operation);

	public DoubtType getDoubtType();
	public RealT addDoubtInfo();
	public RealT removeDoubtInfo();
}
