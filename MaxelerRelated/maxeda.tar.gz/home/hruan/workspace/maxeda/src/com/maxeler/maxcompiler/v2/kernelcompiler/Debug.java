package com.maxeler.maxcompiler.v2.kernelcompiler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.Warning;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration.WarningOptions.WarningBehaviour;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.EnableExceptionOps;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.EnableExceptionTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Bitops;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFERawBits;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEUntypedConst;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite._Composite;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.PhotonIOInformation;
import com.maxeler.photon.nodes.NodeChecksum;
import com.maxeler.photon.nodes.NodeHWPrintf;
import com.maxeler.photon.nodes.NodePrintf;
import com.maxeler.photon.op_management.SimpleExceptionsStrategy;
import com.maxeler.photon.op_management.TypeAndOpExceptionsStrategy;
import com.maxeler.utils.EnumTranslator;
import com.maxeler.utils.printf.InterleavedString;
import com.maxeler.utils.printf.PrintfUtils;
import com.maxeler.utils.printf.TypedFormat;
import com.maxeler.utils.string.FormatStringParser;
import com.maxeler.utils.string.FormatStringParser.FormatException;
import com.maxeler.utils.string.FormatStringParser.FormatString;
import com.maxeler.utils.string.FormatStringParser.Style;
import com.maxeler.utils.string.DFEFormatStringParser;
import com.maxeler.utils.string.SafeString;

/**
 * Provides methods for adding debugging features to a Kernel.
 */
public class Debug {
	final Kernel m_design;
	public final static String m_maxfileConst = "CONTAINS_PRINTF";

	public Debug(Kernel design) {
		m_design = design;
	}

	private KernelConfiguration getKernelConfiguration() {
		return new _KernelConfiguration(m_design.m_design_data.getKernelConfiguration());
	}

	/**
	 * @deprecated Use {@link #pushEnableNumericExceptions(boolean enable)} instead.
	 */
	@Deprecated
	public void enableHardwareExceptions() {
		pushEnableNumericExceptions(true);
	}

	private static Set<TypeAndOpExceptionsStrategy.Type> getImpTypesFromExTypes(EnableExceptionTypes... types) {
		Set<TypeAndOpExceptionsStrategy.Type> real_types =
			new HashSet<TypeAndOpExceptionsStrategy.Type>();

		for(EnableExceptionTypes type : types) {
			switch(type)
			{
				case DFE_FIX:
					real_types.add(TypeAndOpExceptionsStrategy.Type.HW_FIX);
					break;
				case DFE_FLOAT:
					real_types.add(TypeAndOpExceptionsStrategy.Type.HW_FLOAT);
					break;
				case DFE_FIX_DFE_FLOAT:
					real_types.add(TypeAndOpExceptionsStrategy.Type.HW_FIX);
					real_types.add(TypeAndOpExceptionsStrategy.Type.HW_FLOAT);
					break;
				default:
					throw new MaxCompilerInternalError("Unimplemented MathType " + type);
			}
		}
		return real_types;
	}

	private static Set<TypeAndOpExceptionsStrategy.Op> getImpOpsFromExOps(EnableExceptionOps... ops) {
		Set<TypeAndOpExceptionsStrategy.Op> real_ops =
			new HashSet<TypeAndOpExceptionsStrategy.Op>();

		for(EnableExceptionOps op : ops) {
			switch(op)
			{
				case ALL:
					real_ops.add(TypeAndOpExceptionsStrategy.Op.ADD);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.SUB);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.MUL);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.DIV);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.NEG);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.ACCUMULATOR);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.CAST_FROM_FIX);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.CAST_FROM_FLOAT);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.SHIFT_LEFT);
					real_ops.add(TypeAndOpExceptionsStrategy.Op.SQRT);
					break;

				default:
					real_ops.add( EnumTranslator.convert(op, TypeAndOpExceptionsStrategy.Op.class) );
					break;
			}
		}

		return real_ops;
	}

	public void pushEnableNumericExceptions(boolean enable) {
		m_design.m_design_data.pushExceptionsEnableStrategy(
			new SimpleExceptionsStrategy(enable));
	}

	public void pushEnableNumericExceptions(boolean enable, EnableExceptionTypes type, EnableExceptionOps... ops) {
		if (ops == null || ops.length < 1)
			throw new MaxCompilerAPIError(m_design.getManager(), "No EnableExceptionOps specified.");

		m_design.m_design_data.pushExceptionsEnableStrategy(
			new TypeAndOpExceptionsStrategy(
				enable,
				getImpTypesFromExTypes(type),
				getImpOpsFromExOps(ops)));
	}

	public void popEnableNumericExceptions() {
		m_design.m_design_data.popExceptionsEnableStrategy();
	}

	public void pushNumericExceptionCondition(DFEVar condition) {
		m_design.m_design_data.pushExceptionCondition(_KernelBaseTypes.toImp(condition));
	}

	public void pushNumericExceptionCondition(boolean condition) {
		m_design.m_design_data.pushExceptionCondition(
			_KernelBaseTypes.toImp(DFETypeFactory.dfeBool().newInstance(m_design, condition)));
	}

	public void popNumericExceptionCondition() {
		m_design.m_design_data.popExceptionCondition();
	}


	private boolean canPushPopWarning(Warning warning) {
		switch(warning) {
			case ALL:
			case CONSTANT_ENCODING:
			case DUAL_PORT_RAM_WRITE_MODE:
			case UNSIGNED_NEGATION_IN_NON_BITGROWTH_MODE:
			case INVALID_DESIGN_ELEMENT:
				return true;
			default:
				return false;
		}
	}

	public void pushWarningBehaviour(Warning warning, WarningBehaviour behaviour) {
		if (warning == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "No warning specified");
		if (behaviour == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "No warning behaviour specified");

		if(!canPushPopWarning(warning))
			throw new MaxCompilerAPIError(m_design.getManager(), "Cannot change behaviour of warning '" + warning +  "' inside kernel");

		if (warning == Warning.ALL) {
			for (Warning v : Warning.values()) {
				if (v == Warning.ALL || !canPushPopWarning(v))
					continue;
				m_design.m_design_data.pushWarningBehaviour(
					EnumTranslator.convert(v, com.maxeler.photon.core.Warning.class),
					EnumTranslator.convert(behaviour, com.maxeler.photon.core.WarningBehaviour.class));
			}
		}
		else {
			m_design.m_design_data.pushWarningBehaviour(
				EnumTranslator.convert(warning, com.maxeler.photon.core.Warning.class),
				EnumTranslator.convert(behaviour, com.maxeler.photon.core.WarningBehaviour.class));
		}
	}

	public void popWarningBehaviour(Warning warning) {
		if (warning == null)
			throw new MaxCompilerAPIError(m_design.getManager(), "No warning specified");

		if(!canPushPopWarning(warning))
			throw new MaxCompilerAPIError(m_design.getManager(), "Cannot change behaviour of warning '" + warning +  "' inside kernel");

		if (warning == Warning.ALL) {
			for (Warning v : Warning.values()) {
				if (v == Warning.ALL || !canPushPopWarning(v))
					continue;
				m_design.m_design_data.popWarningBehaviour(
					EnumTranslator.convert(v, com.maxeler.photon.core.Warning.class));
			}
		}
		else {
			m_design.m_design_data.popWarningBehaviour(
				EnumTranslator.convert(warning, com.maxeler.photon.core.Warning.class));
		}
	}


	/**
	 * This configuration stack controls whether {@link KernelMath} calculations are
	 * simulated through native method calls (such as exp(double x) in math.h) during
	 * software simulation, if a native implementation of an invoked method is provided.
	 * <p/>
	 * Requesting {@link #pushEnableNativeSimulationMath(boolean)} to enable native simulation
	 * while compiling for a hardware target is disallowed and will raise an exception.
	 *
	 * @param use_native If set to true, simulation will use native method calls for
	 *   {@link KernelMath} calculations.
	 *
	 * @see #popEnableNativeSimulationMath()
	 * @see #peekEnableNativeSimulationMath()
	 */
	public void pushEnableNativeSimulationMath(boolean use_native) {
		m_design.pushDebugEnableNativeSimulationMath(use_native);
	}

	/**
	 * Pops the latest value for native simulation math off the configuration stack. If
	 * no previous value has been pushed onto the stack, this method raises an exception.
	 * <p/>
	 * See {@link #pushEnableNativeSimulationMath(boolean)}.
	 *
	 * @return The value popped off the stack.
	 *
	 * @see #pushEnableNativeSimulationMath(boolean)
	 * @see #peekEnableNativeSimulationMath()
	 */
	public boolean popEnableNativeSimulationMath() {
		return m_design.popDebugEnableNativeSimulationMath();
	}

	/**
	 * Returns the current value for native simulation math stored on the
	 * configuration stack.
	 *
	 * @return True, if simulation will use native method calls for
	 *   {@link KernelMath} calculations.
	 *
	 * @see #pushEnableNativeSimulationMath(boolean)
	 * @see #popEnableNativeSimulationMath()
	 */
	public boolean peekEnableNativeSimulationMath() {
		return m_design.peekDebugEnableNativeSimulationMath();
	}

	/**
	 * @deprecated Replaced by {@link KernelConfiguration.DebugOptions#setDummyBuildEnabled(boolean)}.
	 */
	@Deprecated
	public void enableDummyBuild() {
		getKernelConfiguration().setDummyBuildEnabled(true);
	}


	/**
	 * This configuration stack controls whether calls to watch(...) and dfeWatch(...) are
	 * enabled (value: true) or disabled, i.e. ignored (value: false). Default value is true.
	 *
	 * @param newValue True, if watches should be enabled, False if watches should be disabled.
	 *
	 * @see #peekEnableWatches()
	 * @see #popEnableWatches()
	 */
	public void pushEnableWatches(boolean newValue) {
		m_design.m_design_data.pushEnableWatches(newValue);
	}

	/**
	 * Returns the current value for enabling watches off the configuration stack. If
	 * no previous value has been pushed onto the stack, this method returns the
	 * default value (true).
	 *
	 * @return True, if watches are enabled, False if watches are disabled.
	 */
	public boolean peekEnableWatches() {
		return m_design.m_design_data.peekEnableWatches();
	}

	/**
	 * Pops the last value off the watches configuration stack and returns it.
	 * @return True, if watches were enabled, False if watches were disabled.
	 */
	public boolean popEnableWatches() {
		return m_design.m_design_data.popEnableWatches();
	}



	DFEVar checksum(DFEVar data, DFEVar en) {
		NodeChecksum chksum = new NodeChecksum(m_design.m_design_data);

		chksum.connectInput("en", _KernelBaseTypes.toImp(en));
		chksum.connectInput("src", _KernelBaseTypes.toImp(data));

		return _KernelBaseTypes.fromImp(m_design, chksum.connectOutput("sum"));
	}

	public void printf(String format, Object... args) {
		printf("", m_design.constant.var(true), format, args);
	}

	public void printf(DFEVar condition, String format, Object... args) {
		printf("", condition, format, args);
	}

	public void printf(String stream_name, String format, Object... args) {
		printf(stream_name, m_design.constant.var(true), format, args);
	}

	// FIXME: fold into existing printf methods
	public void dfePrintf(DFEVar condition, String format, Object... args) {
		if (condition == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "condition");
		if (format == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "format");
		if (args == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "args");

		addDFEPrintf(condition, format, args);
	}

	public void dfePrintf(String format, Object... args) {
		dfePrintf(m_design.constant.var(true), format, args);
	}

	private static enum CustomTags {
		KObj
	};

	private static class PrintfNodeArg {
		public final static String s_replaceMarker = "%REPLACEME%";
		public final String fmtStrToReplace;
		// list of inputs to be connected to nodewatch
		public final List<DFEVar> inputVars = new ArrayList<DFEVar>();
		// list of format strings, formatted as e.g. "<text>%x%<text>"
		// with %REPLACEME% being replaced by the corresponding entry in newCFmtFlags
		// or some integer number if the original formatting string used boost
		// style formatting.
		public final List<String> newFmtStrs = new ArrayList<String>();
		public final List<String> newCFmtFlags = new ArrayList<String>();
		public final boolean isCustomTag;

		public PrintfNodeArg(FormatString tag, DFEVar inputVar) {
			fmtStrToReplace = tag.getRawString();
			inputVars.add(inputVar);
			newFmtStrs.add(s_replaceMarker);
			newCFmtFlags.add(fmtStrToReplace);
			isCustomTag = false;
		}

		public PrintfNodeArg(FormatString tag) {
			fmtStrToReplace = tag.getRawString();
			isCustomTag = true;
		}

		public void checkInvariant() {
			boolean valid = newFmtStrs.size() == newCFmtFlags.size();
			valid &= inputVars.size() == newFmtStrs.size();
			if (!valid)
				throw new MaxCompilerInternalError(
					"Invariant check on printf argument failed.");
		}

		public void addText(String input) {
			if (input.contains(PrintfNodeArg.s_replaceMarker))
				throw new MaxCompilerInternalError(
					"Text cannot have tag.");
			inputVars.add(null);
			newCFmtFlags.add("");
			newFmtStrs.add(input);
		}

		public void addFText(String formatstr, DFEVar input, String cFormat) {
			if (input == null)
				throw new MaxCompilerInternalError(
					"Input cannot be null.");
			if (formatstr == null)
				throw new MaxCompilerInternalError(
					"FormatStr cannot be null.");
			if (cFormat == null)
				throw new MaxCompilerInternalError(
					"cFormat cannot be null.");
			if (!formatstr.contains(PrintfNodeArg.s_replaceMarker))
				throw new MaxCompilerInternalError(
					"FormatStr needs to have one tag.");
			inputVars.add(input);
			newCFmtFlags.add(cFormat);
			newFmtStrs.add(formatstr);
		}
	}

	public void printf(String streamName, DFEVar condition, String format, Object... args) {
		if (streamName == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "streamName");
		if (condition == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "condition");
		if (format == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "format");
		if (args == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "args");

		// (1) Check validity of format string (message)
		final FormatStringParser fmtStrParser = new FormatStringParser(format, CustomTags.class);
		final List<PrintfNodeArg> printfNodeArgs = getPrintfArgs(fmtStrParser, args);

		// (2) Change the format string in case we have to print KArrays, KStructs, etc.
		int inputCount = 0;
		if (fmtStrParser.getStyle() == Style.BOOST) {
			// In boost style we have to re-do the numbering of all the input args
			// in case we had a complex (i.e. %KObj%) printf argument!

			// construct all new boost format strings (i.e., %1% %2% ....)
			List<String> newTagsList = new ArrayList<String>();
			for(int counter = 0; counter < printfNodeArgs.size(); counter++) {
				final PrintfNodeArg arg = printfNodeArgs.get(counter);
				arg.checkInvariant();
				final StringBuilder newTag = new StringBuilder();
				for (int j = 0; j < arg.newFmtStrs.size(); j++) {
					String newFmtStr = arg.newFmtStrs.get(j);
					if (arg.inputVars.get(j) != null) {
						inputCount++;
						newFmtStr = newFmtStr.replaceFirst(
							PrintfNodeArg.s_replaceMarker, "%" + inputCount + "%");
					}
					if (newFmtStr.contains(PrintfNodeArg.s_replaceMarker))
						throw new MaxCompilerInternalError(
							m_design.getManager(), "Invalid Format String - multiple "+PrintfNodeArg.s_replaceMarker+" tags.");
					newTag.append( newFmtStr );
				}
				newTagsList.add(newTag.toString());
			}
			// we need to replace all boost format strings (%<number>%) in the
			// original message with the new numbers. Start with the largest
			// number and work downwards.
			for (int counter = printfNodeArgs.size() - 1; counter >=0; counter--) {
				final PrintfNodeArg arg = printfNodeArgs.get(counter);
				if (!arg.isCustomTag) {
					final String oldBoostFmtString = arg.fmtStrToReplace;
					format = format.replaceFirst(oldBoostFmtString, newTagsList.get(counter));
				}
			}
			// now we need to replace all custom tags (%<text>%). Start in front.
			for (int counter = 0; counter < printfNodeArgs.size(); counter++) {
				final PrintfNodeArg arg = printfNodeArgs.get(counter);
				if (arg.isCustomTag) {
					final String oldBoostFmtString = arg.fmtStrToReplace;
					format = format.replaceFirst(oldBoostFmtString, newTagsList.get(counter));
				}
			}
		} else {
			for (PrintfNodeArg arg: printfNodeArgs) {
				// we only care about custom tags, e.g. %KObj%
				if (!arg.isCustomTag) {
					inputCount++;
					continue;
				}
				arg.checkInvariant();
				final StringBuilder newTag = new StringBuilder();
				for (int j = 0; j < arg.newFmtStrs.size(); j++) {
					String newFmtStr = arg.newFmtStrs.get(j);
					if (arg.inputVars.get(j) != null) {
						inputCount++;
						newFmtStr = newFmtStr.replaceFirst(
							PrintfNodeArg.s_replaceMarker, arg.newCFmtFlags.get(j));
					}
					if (newFmtStr.contains(PrintfNodeArg.s_replaceMarker))
						throw new MaxCompilerInternalError(
							m_design.getManager(), "Invalid Format String - multiple " + PrintfNodeArg.s_replaceMarker + " tags.");
					newTag.append( newFmtStr );
				}
				format = format.replaceFirst(arg.fmtStrToReplace, newTag.toString());
			}
		}
		if (inputCount < args.length)
			throw new MaxCompilerInternalError(
				m_design.getManager(), "More arguments supplied than inputs discovered!");

		// (3) Now create the printf node an connect all the inputs.
		addPrintf(condition, streamName, format, inputCount, printfNodeArgs);
	}

	private List<PrintfNodeArg> getPrintfArgs(FormatStringParser fmtStrParser, Object[] args) {
		final List<PrintfNodeArg> printfNodeArgs = new ArrayList<PrintfNodeArg>();

		for(int i = 0; i < args.length; i++) {
			if(args[i] == null)
				throw new MaxCompilerAPIError(m_design.getManager(),
					"printf data argument %d is null.", i);

			final FormatString fmtStr;
			try {
				fmtStr = fmtStrParser.getNextFormatString();
			} catch (FormatStringParser.FormatException error) {
				throw new MaxCompilerAPIError(m_design.getManager(), error.getMessage());
			}

			final String errorMsg =
				"Type of argument " + (i + 1) + " ('%s') " +
				"not compatible with formatting spec ('" + fmtStr.toString() + "').";

			if (fmtStr.isCustomStyle()) {
				CustomTags tag = fmtStr.getCustomTag(CustomTags.class);
				PrintfNodeArg printfArg = new PrintfNodeArg(fmtStr);
				if (!(args[i] instanceof KernelObject))
					throw new MaxCompilerInternalError(
						m_design.getManager(),"Type of argument " + (i+1) + " not a KernelObject.");
				switch (tag) {
					case KObj:
						printKernelObject((KernelObject<?>)args[i], printfArg, i);
						break;
					default:
						throw new MaxCompilerInternalError(
							m_design.getManager(),"Unknown printf format string.");
				}
				printfNodeArgs.add(printfArg);

			} else if(args[i] instanceof Byte) {
				if (!fmtStr.checkByte())
					throw new MaxCompilerAPIError(m_design.getManager(), errorMsg, "byte");
				Bits bits = new Bits(8);
				bits.setBits((Byte) args[i]);
				final DFEVar input = m_design.constant.var(KernelLib.dfeInt(8), bits);
				printfNodeArgs.add(new PrintfNodeArg(fmtStr, input));

			} else if(args[i] instanceof Short) {
				if (!fmtStr.checkShort())
					throw new MaxCompilerAPIError(m_design.getManager(), errorMsg, "short");
				Bits bits = new Bits(16);
				bits.setBits((Short) args[i]);
				final DFEVar input = m_design.constant.var(KernelLib.dfeInt(16), bits);
				printfNodeArgs.add(new PrintfNodeArg(fmtStr,input));

			} else if(args[i] instanceof Integer) {
				if (!fmtStr.checkInteger())
					throw new MaxCompilerAPIError(m_design.getManager(), errorMsg, "integer");
				Bits bits = new Bits(32);
				bits.setBits((Integer) args[i]);
				final DFEVar input = m_design.constant.var(KernelLib.dfeInt(32), bits);
				printfNodeArgs.add(new PrintfNodeArg(fmtStr,input));

			} else if(args[i] instanceof Long) {
				if (!fmtStr.checkLong())
					throw new MaxCompilerAPIError(m_design.getManager(), errorMsg, "long");
				Bits bits = new Bits(64);
				bits.setBits((Long) args[i]);
				final DFEVar input = m_design.constant.var(KernelLib.dfeInt(64), bits);
				printfNodeArgs.add(new PrintfNodeArg(fmtStr,input));

			} else if(args[i] instanceof Float) {
				if (!fmtStr.checkFloat())
					throw new MaxCompilerAPIError(m_design.getManager(), errorMsg, "float");
				Bits bits = new Bits(32);
				bits.setBits(Float.floatToRawIntBits((Float) args[i]));
				final DFEVar input = m_design.constant.var(KernelLib.dfeFloat(8, 24), bits);
				printfNodeArgs.add(new PrintfNodeArg(fmtStr,input));

			} else if(args[i] instanceof Double) {
				if (!fmtStr.checkDouble())
					throw new MaxCompilerAPIError(m_design.getManager(), errorMsg, "double");
				Bits bits = new Bits(64);
				bits.setBits(Double.doubleToRawLongBits((Double) args[i]));
				final DFEVar input = m_design.constant.var(KernelLib.dfeFloat(11, 53), bits);
				printfNodeArgs.add(new PrintfNodeArg(fmtStr,input));

			} else if(args[i] instanceof DFEVar) {
				if (!fmtStr.checkDFEVar((DFEVar)args[i]))
					throw new MaxCompilerAPIError(m_design.getManager(), errorMsg, ((DFEVar)args[i]).getType().toString());
				printfNodeArgs.add(new PrintfNodeArg(fmtStr, (DFEVar) args[i]));

			} else {
				throw new MaxCompilerAPIError(m_design.getManager(),
					"printf data argument %d is of an unsupported type.\n" +
					"Supported types are: byte, short, int, long, float, double and DFEVar\n",
					i+1, args[i].getClass().getName());
			}
		}

		try {
			fmtStrParser.checkNoMoreFormatStringsLeft();
		} catch (FormatException error) {
			throw new MaxCompilerAPIError(m_design.getManager(), error.getMessage());
		}

		return printfNodeArgs;
	}

	private void addPrintf(DFEVar condition, String stream_name, String message, int inputCount, List<PrintfNodeArg> args) {
		NodePrintf node = new NodePrintf(
			_Kernel.getPhotonDesignData(m_design),
			SafeString.escapeString(stream_name),
			SafeString.escapeString(message),
			inputCount
		);
		node.connectInput("condition", _KernelBaseTypes.toImp(condition));
		int total_count = 0;
		for(int counter = 0; counter < args.size(); counter++) {
			final PrintfNodeArg arg = args.get(counter);
			for (int counter_inner = 0; counter_inner < arg.inputVars.size(); counter_inner++) {
				final DFEVar input = arg.inputVars.get(counter_inner);
				if (input == null)
					continue; // additional text like "{ " doesn't have an input..
				node.connectInput("arg" + String.valueOf(total_count), _KernelBaseTypes.toImp(input));
				total_count++;
			}
		}
		// set a constant, so that SLiC can tell that this design uses debug.printf.
		m_design.getManager().addMaxFileConstantFlag(m_maxfileConst, 1);
	}

	private static class DFEPrintfInfo {
		public final DFEVar condition;
		public final InterleavedString<String> format;
		public final List<DFEVar> variables;

		public DFEPrintfInfo(DFEVar condition, InterleavedString<String> format, List<DFEVar> variables) {
			this.condition = condition;
			this.format = format;
			this.variables = variables;
		}

		@Override
		public String toString() { return format.toString(); }
	}

	private static class DFEPrintfFinalizer implements KernelFinalizer {
		private final List<DFEPrintfInfo> m_printfInfo = new ArrayList<DFEPrintfInfo>();

		public void addPrintf(DFEPrintfInfo info) {
			m_printfInfo.add(info);
		}

		@Override
		public void finalizeKernel(Kernel kernel) {
			final PhotonDesignData designData = _Kernel.getPhotonDesignData(kernel);
			final PhotonIOInformation ioInfo = designData.getIOInformation();
			final NodeHWPrintf printfNode = designData.getOrCreateHWPrintNode();

			for (DFEPrintfInfo info : m_printfInfo) {
				final TypedFormat format = new TypedFormat(info.format, getTypes(info.variables));

				ioInfo.addDebugStream(format);
			}

			for (DFEPrintfInfo info : m_printfInfo)
				printfNode.addInput(!info.variables.isEmpty());

			for (int i = 0; i < m_printfInfo.size(); ++i) {
				final DFEPrintfInfo info = m_printfInfo.get(i);

				printfNode.connectInput("enable_" + i, _KernelBaseTypes.toImp(info.condition));
				if (!info.variables.isEmpty())
					printfNode.connectInput("data_" + i, _KernelBaseTypes.toImp(concatWithoutNulls(info.variables)));
			}

			DFEVar outputData = _KernelBaseTypes.fromImp(kernel, printfNode.connectOutput("debug_info"));
			final DFEVar outputEnable = _KernelBaseTypes.fromImp(kernel, printfNode.connectOutput("output_enable"));
			kernel.io.output("dfeprintf_debug", outputData, outputData.getType(), outputEnable);
		}

		private static DFEVar concatWithoutNulls(List<DFEVar> variables) {
			// apparently Bitops.concat(List<KernelObject<?>>) can't take List<DFEVar>...
			final List<KernelObject<?>> kernelObjects = new ArrayList<KernelObject<?>>();

			for (DFEVar v : variables) {
				if (v != null)
					kernelObjects.add(v);
			}

			// Bitops.concat works from MSB to LSB
			Collections.reverse(kernelObjects);

			return Bitops.concat(kernelObjects);
		}

		private static List<com.maxeler.photon.types.HWType> getTypes(List<DFEVar> vars) {
			final List<com.maxeler.photon.types.HWType> types = new ArrayList<com.maxeler.photon.types.HWType>(vars.size());

			for (DFEVar v : vars)
				types.add(_KernelBaseTypes.toImp(v.getType()));

			return types;
		}
	}

	private DFEPrintfFinalizer m_dfePrintfFinalizer = null;

	private static final DFEFormatStringParser<CustomTags> kernelFormatParser = new DFEFormatStringParser<CustomTags>(CustomTags.class);

	private InterleavedString<String> expandCustomTags(DFEFormatStringParser<CustomTags>.FormatString formatString, Object[] args) {
		final List<DFEFormatStringParser<CustomTags>.FormatSpec> formatSpecs = formatString.formatSpec;

		if (formatSpecs.size() != args.length)
			throw new MaxCompilerAPIError(m_design.getManager(), "Format string requires %d arguments, only received %d.", formatSpecs.size(), args.length);

		final InterleavedString<String> format = new InterleavedString<String>();
		for (int i = 0; i < formatSpecs.size(); ++i) {
			final DFEFormatStringParser<CustomTags>.FormatSpec spec = formatSpecs.get(i);

			format.append(formatString.text.get(i));
			if (spec.customTag == null)
				format.append("", spec.representation);
			else {
				switch (spec.customTag) {
					case KObj:
						if (!(args[i] instanceof KernelObject<?>))
							throw new MaxCompilerAPIError(m_design.getManager(), "Format argument %d of %d is not a KernelObject.", i + 1, args.length);

						final KernelType<?> objectType = ((KernelObject<?>) args[i]).getType();

						format.append(PrintfUtils.formatType(objectType));
						break;
					default:
						throw new MaxCompilerInternalError(m_design.getManager(), "Unknown custom format tag '%s'.", spec.customTag);
				}
			}
		}

		if (formatString.text.size() > formatString.formatSpec.size())
			format.append(formatString.text.get(formatString.text.size() - 1));

		return format;
	}

	private void addDFEPrintf(DFEVar condition, String format, Object[] args) {
		final DFEFormatStringParser<CustomTags>.FormatString formatStr = kernelFormatParser.breakIntocomponents(format);
		final InterleavedString<String> expandedFormat = expandCustomTags(formatStr, args);

		// FIXME: this won't work if a dfePrintf is added in a finalizer
		if (m_dfePrintfFinalizer == null) {
			m_dfePrintfFinalizer = new DFEPrintfFinalizer();
			m_design.addKernelFinalizer(m_dfePrintfFinalizer);
		}

		final List<DFEVar> variables = new ArrayList<DFEVar>();
		for (Object arg : args) {
			if (arg instanceof KernelObject<?>)
				variables.addAll(((KernelObject<?>) arg).packToList());
			else
				throw new MaxCompilerInternalError(m_design.getManager(), "Printf with object of type '%s' not yet supported.", arg.getClass());
		}

		// types greater than 64 bits are not currently supported in the runtime
		// infrastructure:
		// * type conversion only works on 64-bit quantities,
		// * there is no formatting capability for types greater than 64 bits
		for (DFEVar v : variables) {
			if (v.getType().getTotalBits() > 64)
				throw new MaxCompilerAPIError(m_design.getManager(), "Types greater than 64 bits are not currently supported for printf.");
		}

		DFEPrintfInfo info = new DFEPrintfInfo(condition, expandedFormat, variables);
		final List<DFEType> types = new ArrayList<DFEType>(variables.size());
		for (DFEVar v : variables)
			types.add(v.getType());
		m_dfePrintfFinalizer.addPrintf(info);
	}

	private void printDFEVar(
		DFEVar var,
		PrintfNodeArg arg,
		int argNr)
	{
		final DFEType type = var.getType();
		String cFormat;
		if (type instanceof DFEFix) {
			DFEFix fix = (DFEFix)type;
			if (fix.isInt())
				cFormat = "%d";
			else if (fix.isUInt())
				cFormat = "%u";
			else
				cFormat = "%g";
		} else if (type instanceof DFEFloat)
			cFormat = "%f"; // or %g
		else if (type instanceof DFERawBits)
			cFormat = "%u";
		else if (type instanceof DFEUntypedConst) {
			// As we type all untyped consts as double in NodePrintf.assignOutputTypes,
			// the format string has to be float. This might be a bit confusing but is the
			// best option for now. (As no one should be using untyped consts anyway...)
			cFormat = "%g";
		} else
			throw new MaxCompilerInternalError("Unknown type: " + type);
		arg.addFText(PrintfNodeArg.s_replaceMarker, var, cFormat);
	}

	private void printDFEStruct(
		DFEStruct struct,
		PrintfNodeArg arg,
		int argNr)
	{
		Map<String, KernelObjectNotVector<?>> map = _Composite.getFields(struct);
		arg.addText("{ ");
		int i = 0;
		for (String s :map.keySet()) {
			arg.addText(s + ": ");
			printKernelObject(map.get(s), arg, argNr);
			if ( i + 1 < map.keySet().size())
				arg.addText("; ");
			i++;
		}
		arg.addText(" }");
	}

	private void printKArray(
		DFEArray<?> arr,
		PrintfNodeArg arg,
		int argNr)
	{
		arg.addText("[ ");
		for (int i = 0; i < arr.getSize(); i++) {
			KernelObjectNotVector<?> o = arr.get(i);
			printKernelObject(o, arg, argNr);
			if (i + 1 < arr.getSize())
				arg.addText(", ");
		}
		arg.addText(" ]");
	}

	private void printDFEComplex(
		DFEComplex c,
		PrintfNodeArg arg,
		int argNr)
	{
		printKernelObject(c.getReal(), arg, argNr);
		arg.addText(" + ");
		printKernelObject(c.getImaginary(), arg, argNr);
		arg.addText("i ");
	}

	private void printKMultiPipe(
		DFEVector<?> mp,
		PrintfNodeArg arg,
		int argNr)
	{
		arg.addText("< ");
		for (int i = 0; i < mp.getNElements(); i++ ) {
			KernelObjectVectorizable<?> pipe = mp.getElement(i);
			printKernelObject(pipe, arg, argNr);
			if (i + 1 < mp.getNElements())
				arg.addText(" :: ");
		}
		arg.addText(">");
	}

	private void printKernelObject(
		KernelObject<?> kernelObject,
		PrintfNodeArg arg,
		int argNr)
	{
		if (kernelObject instanceof DFEVar)
			printDFEVar((DFEVar) kernelObject, arg, argNr);
		else if (kernelObject instanceof DFEArray<?>)
			printKArray((DFEArray<?>)kernelObject, arg, argNr);
		else if (kernelObject instanceof DFEComplex)
			printDFEComplex((DFEComplex)kernelObject, arg, argNr);
		else if (kernelObject instanceof DFEStruct)
			printDFEStruct((DFEStruct)kernelObject, arg, argNr);
		else if (kernelObject instanceof DFEVector)
			printKMultiPipe((DFEVector<?>)kernelObject, arg, argNr);
		else
			throw new MaxCompilerAPIError(m_design.getManager(),
				"simPrintf data argument %d is of an unsupported type.\n" +
				"Supported types are: byte, short, int, long, float, double, DFEVar, DFEStruct, DFEArray, DFEComplex\n",
				argNr+1, kernelObject.getClass().getName());
	}
}
