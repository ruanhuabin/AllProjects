package com.maxeler.maxcompiler.v2.kernelcompiler;

import static com.maxeler.utils.EnumTranslator.convert;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.FixOpBitSizeMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.FixOpOffsetMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.MathOps;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management._KernelOpManagement;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxdc.xilinx.Virtex5Part;
import com.maxeler.maxdc.xilinx.XilinxPlatform;
import com.maxeler.photon.core.Node;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.PhotonException;
import com.maxeler.photon.graph_passes.maxdc_gen.XilinxAreaGroupConstraint;
import com.maxeler.photon.nodes.NodeRegister;
import com.maxeler.photon.op_management.OpTypeMode;
import com.maxeler.photon.op_management.OperatorSupplier;
import com.maxeler.photon.op_management.OperatorSupplier.Op;
import com.maxeler.photon.op_management.TypeModeBitSizeAll;
import com.maxeler.photon.op_management.TypeModeBitSizeExact;
import com.maxeler.photon.op_management.TypeModeBitSizeLargest;
import com.maxeler.photon.op_management.TypeModeBitSizeLimit;
import com.maxeler.photon.op_management.TypeModeMaxLargest;
import com.maxeler.photon.op_management.TypeModeMaxNoOverflow;
import com.maxeler.photon.op_management.TypeModeMaxNoUnderflow;
import com.maxeler.photon.op_management.TypeModeOffsetExact;
import com.maxeler.photon.op_management.TypeModeOffsetLargest;
import com.maxeler.utils.CoordinateRange;
import com.maxeler.utils.EnumTranslator;
import com.maxeler.utils.MaxCompilerHide;

/**
 * Parameters that can be adjusted to improve Kernel performance.
 *
 */
public class Optimization {
	private static final OperatorSupplier.Op[] s_bit_growth_ops = { Op.ADD, Op.SUB,
		Op.MUL, Op.DIV, Op.EQ, Op.NEQ, Op.GT, Op.GTE, Op.LT, Op.LTE, Op.NEG };

	private static final OpTypeMode s_bit_growth_type_mode =
		new OpTypeMode(false, TypeModeBitSizeAll.get(), TypeModeMaxNoOverflow.get());

	private static final OpTypeMode s_default_type_mode =
		new OpTypeMode(true, TypeModeBitSizeLargest.get(), TypeModeMaxLargest.get());

	private final Kernel m_kernel;

	Optimization(Kernel kernel) {
		m_kernel = kernel;
	}

	Kernel getKernel() {
		return m_kernel;
	}

	private KernelConfiguration getKernelConfiguration() {
		return new _KernelConfiguration(_Kernel.getPhotonDesignData(m_kernel).getKernelConfiguration());
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setClockPhasePartitioningEnabled(boolean)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void enableClockPhasePartitioning() {
		getKernelConfiguration().optimization.setClockPhasePartitioningEnabled(true);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setCEReplicationEnabled(boolean)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void enableCEReplication() {
		getKernelConfiguration().setCEReplicationEnabled(true);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setClockPhaseBalanceThreshold(double)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setClockPhaseBalanceThreshold(float threshold) {
		getKernelConfiguration().optimization.setClockPhaseBalanceThreshold(threshold);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setCEPipelining(int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setControlPipelining(int pipelining) {
		getKernelConfiguration().optimization.setCEPipelining(pipelining);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setFIFOSRLDepthThreshold(int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setFIFOSRLDepthThreshold(int threshold_depth) {
		throw new MaxCompilerAPIError("FIFO SRL depth threshold functionality no longer exists.");
	}

	/**
	 * @deprecated Replaced by {@link KernelConfiguration#setShadowMappedRegistersEnabled(boolean)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void disableShadowScalarInputRegisters() {
		getKernelConfiguration().setShadowMappedRegistersEnabled(false);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#setShadowScalarInputsEnabled(boolean)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void enableShadowScalarInputRegisters() {
		getKernelConfiguration().setShadowMappedRegistersEnabled(true);
	}

	/**
	 * @deprecated Replaced by {@link OptimizationOptions#getShadowScalarInputsEnabled()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public boolean areShadowScalarInputRegistersEnabled() {
		return getKernelConfiguration().areShadowMappedRegistersEnabled();
	}

	/**
	 * @deprecated Replaced by {@link #getRoundingMode()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public RoundingMode peekRoundingMode() {
		return getRoundingMode();
	}

	/**
	 * Get the rounding mode that currently applies to arithmetic operations.
	 * @return The rounding mode that is currently in effect.
	 * @see #pushRoundingMode(RoundingMode)
	 * @see #popRoundingMode()
	 */
	public RoundingMode getRoundingMode() {
		return convert(
			m_kernel.m_design_data.getRoundingMode(),
			RoundingMode.class
		);
	}

	/**
	 * Specify the rounding mode to use for arithmetic operations.
	 * <p>
	 * This method will push the previous settings onto a <em>stack</em> which
	 * can then be retrieved by calling {@link #popRoundingMode()}.
	 * @param mode The new rounding mode to use.
	 * @see #popRoundingMode()
	 */
	public void pushRoundingMode(RoundingMode mode) {
		if (mode == null)
			throw MaxCompilerAPIError.nullParam("mode");

		m_kernel.m_design_data.pushRoundingMode(
			convert(
				mode,
				com.maxeler.photon.op_management.RoundingMode.class
			)
		);
	}

	/**
	 * Remove the previous rounding mode settings from the stack and apply them.
	 * <p>
	 * Note that it is an error to call this method when there has not been a
	 * previous <em>push</em> operation (i.e. a call to {@link #pushRoundingMode(RoundingMode)}).
	 * @see #pushRoundingMode(RoundingMode)
	 */
	public void popRoundingMode() {
		try {
			m_kernel.m_design_data.popRoundingMode();
		} catch (NoSuchElementException e) {
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Cannot pop empty rounding mode stack.");
		}
	}

	/**
	 * @deprecated Replace with {@link #pushPipeliningFactor(double)}
	 * <b>using <code> 1 - factor</code> as the new parameter</b>.
	 */
	@Deprecated
	@MaxCompilerHide
	public void pushSquashFactor(double factor) {
		m_kernel.m_design_data.pushSquashFactor(factor);
	}

	/**
	 * @deprecated Replaced by {@link #getPipeliningFactor()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public double peekSquashFactor() {
		return m_kernel.m_design_data.getSquashFactor();
	}

	/**
	 * @deprecated Replaced by {@link #popPipeliningFactor()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void popSquashFactor() {
		m_kernel.m_design_data.popSquashFactor();
	}

	/**
	 * Specify the amount of pipelining to use for individual kernel operations.
	 * @param pipelining The amount of pipelining to use (between 0 and 1,
	 * inclusive). 0 specifies the minimum amount of pipelining, 1 specifies
	 * the most amount of pipelining.
	 * @see #getPipeliningFactor()
	 * @see #popPipeliningFactor()
	 */
	public void pushPipeliningFactor(double pipelining) {
		// strangely formulated condition to catch NaN
		if (!(0 <= pipelining && pipelining <= 1))
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Pipelining factor must be between 0 and 1 (inclusive), not %g.", pipelining);

		// convert to squash factor and clamp to [0, 1] to catch floating-point
		// rounding
		double squashFactor = 1 - pipelining;
		if (squashFactor < 0)
			squashFactor = 0;
		else if (squashFactor > 1)
			squashFactor = 1;

		m_kernel.m_design_data.pushSquashFactor(squashFactor);
	}

	/**
	 * Retrieve the current pipelining factor.
	 * @return A value between 0 and 1 (inclusive). 0 specifies the minimum
	 * amount of pipelining, 1 specifies the most amount of pipelining.
	 * @see #pushPipeliningFactor(double)
	 * @see #popPipeliningFactor()
	 */
	public double getPipeliningFactor() {
		return 1 - m_kernel.m_design_data.getSquashFactor();
	}

	/**
	 * Remove the previous pipelining factor from the stack and apply it.
	 * <p>
	 * Note that it is an error to call this method when there has not been a
	 * previous <em>push</em> operation (i.e. a call to {@link #pushPipeliningFactor}).
	 * @see #pushPipeliningFactor(double)
	 * @see #getPipeliningFactor()
	 */
	public void popPipeliningFactor() {
		try {
			m_kernel.m_design_data.popSquashFactor();
		} catch (NoSuchElementException e) {
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Cannot pop empty pipelining factor stack.");
		}
	}

	/**
	 * Specify the amount of DSPs that should be used in arithmetic operations.
	 * <p>
	 * This can be used to increase or decrease the number of DSPs used by your
	 * kernel design.
	 * <p>
	 * This method will push the previous settings onto a <em>stack</em> which
	 * can then be retrieved by calling {@link #popDSPFactor()}.
	 * <p>
	 * This is equivalent to {@code pushDSPFactor(dsp_factor, MathOps.ALL)}.
	 * @param dsp_factor The amount of DSPs to use (between 0 and
	 * 1, inclusive). 0 uses the fewest DSPs, 1 uses the most DSPs.
	 * @see #pushDSPFactor(double, MathOps)
	 * @see #popDSPFactor()
	 */
	public void pushDSPFactor(double dsp_factor) {
		pushDSPFactor(dsp_factor, MathOps.ALL);
	}

	/**
	 * Specify the amount of DSPs that should be used in arithmetic operations.
	 * <p>
	 * This can be used to increase or decrease the number of DSPs used by your
	 * kernel design.
	 * <p>
	 * This method will push the previous settings onto a <em>stack</em> which
	 * can then be retrieved by calling {@link #popDSPFactor()}.
	 * @param dsp_factor The amount of DSPs to use (between 0 and
	 * 1, inclusive). 0 uses the fewest DSPs, 1 uses the most DSPs.
	 * @param operations The set of arithmetic operations that this should
	 * apply to.
	 * @see #pushDSPFactor(double)
	 * @see #popDSPFactor()
	 */
	public void pushDSPFactor(double dsp_factor, MathOps operations) {
		// the comparison is done this way to catch NaN
		if (!(0 <= dsp_factor && dsp_factor <= 1))
			throw new MaxCompilerAPIError(m_kernel.getManager(), "DSP factor parameter must be between 0 and 1, inclusive (not %g).", dsp_factor);
		if (operations == null)
			throw MaxCompilerAPIError.nullParam(m_kernel.getManager(), "operations");
		if (operations == MathOps.NEG)
			throw new MaxCompilerAPIError(m_kernel.getManager(), "DSP factor not supported for negation.");

		final Map<Op, Double> new_dsp_factors = new EnumMap<Op, Double>(Op.class);
		switch (operations) {
			case ALL:
				for (Op op : Op.values())
					new_dsp_factors.put(op, dsp_factor);
				break;
			case ADD_SUB:
			case ADD:
			case SUB:
				new_dsp_factors.put(Op.ADD, dsp_factor);
				new_dsp_factors.put(Op.SUB, dsp_factor);
				break;
			case MUL_DIV:
			case MUL:
			case DIV:
				new_dsp_factors.put(Op.MUL, dsp_factor);
				new_dsp_factors.put(Op.DIV, dsp_factor);
				break;
			default:
				throw new PhotonException(_Managers.getBuildManager(m_kernel.getManager()), "Unknown MathOps: %s", operations);
		}

		m_kernel.m_design_data.pushDSPFactor(new_dsp_factors);
	}

	/**
	 * Remove the previous DSP factor settings from the stack and apply them.
	 * <p>
	 * Adding additional stages of pipelining and limiting fanout can be used to
	 * improve timing. This will increase the number of flip flops used by a {@link Kernel}
	 * and may also increase other hardware resources due to changes in scheduling.
	 * Note that it is an error to call this method when there has not been a
	 * previous <em>push</em> operation (i.e. a call to {@link #pushDSPFactor}).
	 * @see #pushDSPFactor(double)
	 * @see #pushDSPFactor(double, MathOps)
	 */
	public void popDSPFactor() {
		try {
			m_kernel.m_design_data.popDSPFactor();
		} catch (NoSuchElementException e) {
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Cannot pop empty DSP factor stack.");
		}
	}

	public void pushEnableBitGrowth(boolean enable) {
		OpTypeMode mode = enable ? s_bit_growth_type_mode : s_default_type_mode;
		for (Op op : s_bit_growth_ops)
			m_kernel.m_design_data.pushOpTypeMode(op, mode);
	}

	/**
	 * @deprecated Replaced by {@link #getEnableBitGrowth()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public boolean peekEnableBitGrowth() { return getEnableBitGrowth(); }

	public boolean getEnableBitGrowth() {
		for (Op op : s_bit_growth_ops)
			if (!m_kernel.m_design_data.getOpTypeMode(op).equals(s_bit_growth_type_mode))
				return false;

		return true;
	}

	public void popEnableBitGrowth() {
		try {
			for (Op op : s_bit_growth_ops)
				m_kernel.m_design_data.popOpTypeMode(op);
		} catch (NoSuchElementException e) {
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Cannot pop empty type mode stack.");
		}
	}

	/**
	 * Insert a single level of pipelining registers into a data stream and
	 * limit the number of fanouts it can have.
	 * @param <T> The type of {@link KernelObject} for the stream.
	 * @param v The stream to add the pipeling to.
	 * @param max_fanout The maximum
	 * @return A data stream which is identical to the stream passed to this
	 * method except that is has an additional level of registers.
	 */
	public <T extends KernelObject<T>> T limitFanout(T v, int max_fanout) {
		if (max_fanout < 0)
			throw new MaxCompilerAPIError("Maximum fanout must be >= 0, not %d.", max_fanout);

		List<DFEVar> limited_vars = new ArrayList<DFEVar>();
		for(DFEVar var : v.packToList() ) {
			Node node_reg = new NodeRegister(_Kernel.getPhotonDesignData(m_kernel), max_fanout);

			node_reg.connectInput("input", _KernelBaseTypes.toImp(var));
			DFEVar limited_var =
				_KernelBaseTypes.fromImp(m_kernel, node_reg.connectOutput("output"));
			limited_vars.add(limited_var);
		}

		return v.getType().unpackFromList(limited_vars);
	}

	/**
	 * Insert a single level of pipelining registers into a data stream.
	 * <p>
	 * Adding additional stages of pipelining can be used to improve timing.
	 * This will increase the number of flip flops used by a {@link Kernel}
	 * and may also increase other hardware resources due to changes in scheduling.
	 * @param <T> The type of {@link KernelObject} for the stream.
	 * @param v The stream to add the pipelining to.
	 * @return A data stream which is identical to the stream passed to this
	 * method except that it has an additional level of registers.
	 */
	public <T extends KernelObject<T>> T pipeline(T v) {
		return limitFanout(v, 0);
	}

	private Set<Op> getImpOpsFromMathOps(MathOps... ops) {
		Set<Op> real_ops = new HashSet<Op>();
		for(MathOps op : ops) {
			switch(op)
			{
				case ADD_SUB:
					real_ops.add(Op.ADD);
					real_ops.add(Op.SUB);
					break;

				case MUL_DIV:
					real_ops.add(Op.MUL);
					real_ops.add(Op.DIV);
					break;

				case ALL:
					real_ops.add(Op.ADD);
					real_ops.add(Op.SUB);
					real_ops.add(Op.MUL);
					real_ops.add(Op.DIV);
					real_ops.add(Op.NEG);
					break;

				default:
					real_ops.add( EnumTranslator.convert(op, Op.class) );
					break;
			}
		}

		return real_ops;
	}

	public void pushFixOpModeDefault(MathOps... ops) {
		if (ops == null || ops.length < 1)
			throw new MaxCompilerAPIError(m_kernel.getManager(), "No MathOps specified.");

		PhotonDesignData design_data = _Kernel.getPhotonDesignData(m_kernel);

		for(Op op : getImpOpsFromMathOps(ops))
			design_data.pushOpTypeMode(op, s_default_type_mode);
	}

	public void pushFixOpMode(
		FixOpBitSizeMode bit_size_mode,
		FixOpOffsetMode offset_size_mode,
		MathOps... ops)
	{
		if (ops == null || ops.length < 1)
			throw new MaxCompilerAPIError(m_kernel.getManager(), "No MathOps specified.");

		PhotonDesignData design_data = _Kernel.getPhotonDesignData(m_kernel);

		for(Op op : getImpOpsFromMathOps(ops)) {
			OpTypeMode op_type_mode =
				new OpTypeMode(
					false,
					_KernelOpManagement.toImp(bit_size_mode),
					_KernelOpManagement.toImp(offset_size_mode));

			design_data.pushOpTypeMode(op, op_type_mode);
		}
	}

	public void popFixOpMode(MathOps... ops) {
		if (ops == null || ops.length < 1)
			throw new MaxCompilerAPIError(m_kernel.getManager(), "No MathOps specified.");

		PhotonDesignData design_data = _Kernel.getPhotonDesignData(m_kernel);

		for(Op op : getImpOpsFromMathOps(ops))
			design_data.popOpTypeMode(op);
	}

	public static FixOpBitSizeMode bitSizeAll() {
		return _KernelOpManagement.fromImp(TypeModeBitSizeAll.get());
	}

	public static FixOpBitSizeMode bitSizeExact(int bits) {
		return _KernelOpManagement.fromImp(TypeModeBitSizeExact.get(bits));
	}

	public static FixOpBitSizeMode bitSizeLimit(int bits) {
		return _KernelOpManagement.fromImp(TypeModeBitSizeLimit.get(bits));
	}

	public static FixOpBitSizeMode bitSizeLargest() {
		return _KernelOpManagement.fromImp(TypeModeBitSizeLargest.get());
	}

	public static FixOpOffsetMode offsetExact(int offset) {
		return _KernelOpManagement.fromImp(TypeModeOffsetExact.get(offset));
	}

	public static FixOpOffsetMode offsetLargest() {
		return _KernelOpManagement.fromImp(TypeModeOffsetLargest.get());
	}

	public static FixOpOffsetMode offsetLargestMsb() {
		return _KernelOpManagement.fromImp(TypeModeMaxLargest.get());
	}

	public static FixOpOffsetMode offsetNoOverflow() {
		return _KernelOpManagement.fromImp(TypeModeMaxNoOverflow.get());
	}

	public static FixOpOffsetMode offsetNoUnderflow() {
		return _KernelOpManagement.fromImp(TypeModeMaxNoUnderflow.get());
	}

	/**
	 * @deprecated Replaced by {@link #setGroupSliceAreaConstraint(int, int, int, int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setGroupSliceAreaConstraint(CoordinateRange c) {
		if (c == null) return;
		setGroupSliceAreaConstraint(c.x0, c.y0, c.x1, c.y1);
	}

	public void setGroupSliceAreaConstraint(int x0, int y0, int x1, int y1) {
		PhotonDesignData design_data = _Kernel.getPhotonDesignData(getKernel());

		XilinxAreaGroupConstraint constraint =
			design_data.getOrCreateCurrentGroupAreaConstraints();

		if(constraint.hasSliceConstraint())
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Current group already has a SLICE constraint.");

		constraint.setSliceConstraint(x0, y0, x1, y1);
	}

	/**
	 * @deprecated Replaced by {@link #setGroupRAMB18AreaConstraint(int, int, int, int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setGroupRAMB18AreaConstraint(CoordinateRange c) {
		if (c == null) return;
		setGroupRAMB18AreaConstraint(c.x0, c.y0, c.x1, c.y1);
	}

	public void setGroupRAMB18AreaConstraint(int x0, int y0, int x1, int y1) {
		PhotonDesignData design_data = _Kernel.getPhotonDesignData(getKernel());

		XilinxAreaGroupConstraint constraint =
			design_data.getOrCreateCurrentGroupAreaConstraints();

		if(constraint.hasRAMB18Constraint())
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Current group already has a RAMB18 constraint.");

		constraint.setRAMB18Constraint(x0, y0, x1, y1);

		// I'm putting this exception at the bottom so it is possible
		// to ignore in the release if I'm mistaken.
		if(XilinxPlatform.get(design_data.getBuildManager()).getFPGAPart() instanceof Virtex5Part)
			throw new MaxCompilerAPIError(m_kernel.getManager(),
				"RAMB18 constraints aren't supported when targetting Virtex5.");
	}

	/**
	 * @deprecated Replaced by {@link #setGroupRAMB36AreaConstraint(int, int, int, int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setGroupRAMB36AreaConstraint(CoordinateRange c) {
		if (c == null) return;
		setGroupRAMB36AreaConstraint(c.x0, c.y0, c.x1, c.y1);
	}

	public void setGroupRAMB36AreaConstraint(int x0, int y0, int x1, int y1) {
		PhotonDesignData design_data = _Kernel.getPhotonDesignData(getKernel());

		XilinxAreaGroupConstraint constraint =
			design_data.getOrCreateCurrentGroupAreaConstraints();

		if(constraint.hasRAMB36Constraint())
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Current group already has a RAMB36 constraint.");

		constraint.setRAMB36Constraint(x0, y0, x1, y1);
	}

	/**
	 * @deprecated Replaced by {@link #setGroupDSPAreaConstraint(int, int, int, int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setGroupDSPAreaConstraint(CoordinateRange c) {
		if (c == null) return;
		setGroupDSPAreaConstraint(c.x0, c.y0, c.x1, c.y1);
	}

	public void setGroupDSPAreaConstraint(int x0, int y0, int x1, int y1) {
		PhotonDesignData design_data = _Kernel.getPhotonDesignData(getKernel());

		XilinxAreaGroupConstraint constraint =
			design_data.getOrCreateCurrentGroupAreaConstraints();

		if(constraint.hasDSPConstraint())
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Current group already has a DSP48 constraint.");

		constraint.setDSPConstraint(x0, y0, x1, y1);
	}

	/**
	 * @deprecated Replaced by {@link #setGroupClockRegionAreaConstraint(int, int, int, int)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setGroupClockRegionAreaConstraint(CoordinateRange c) {
		if (c == null) return;
		setGroupClockRegionAreaConstraint(c.x0, c.y0, c.x1, c.y1);
	}

	public void setGroupClockRegionAreaConstraint(int x0, int y0, int x1, int y1) {
		PhotonDesignData design_data = _Kernel.getPhotonDesignData(getKernel());

		XilinxAreaGroupConstraint constraint =
			design_data.getOrCreateCurrentGroupAreaConstraints();

		if(constraint.hasClockRegionConstraint())
			throw new MaxCompilerAPIError(m_kernel.getManager(), "Current group already has a ClockRegion constraint.");

		constraint.setClockRegionConstraint(x0, y0, x1, y1);
	}
}
