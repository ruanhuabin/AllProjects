package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.managers.custom.ManagerClock;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperNode;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodePhoton;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeStateMachine;
import com.maxeler.photon.input_arbitration.ArbitratedInput;

public class KernelBlock implements ManagerBlock {
	private final WrapperNodePhoton m_photon;
	private final Map<String, WrapperNodeStateMachine> m_arbitrators;
	private final Map<String, WrapperNodeStateMachine> m_non_blockers;

	// This is used by KernelBlockV0
	KernelBlock() {
		m_photon = null;
		m_arbitrators = Collections.emptyMap();
		m_non_blockers = Collections.emptyMap();
	}

	KernelBlock(
		WrapperNodePhoton photon,
		Collection<WrapperNodeStateMachine> input_arbitrators,
		Map<String, WrapperNodeStateMachine> non_blockers
	) {
		m_photon = photon;
		m_arbitrators = new HashMap<String, WrapperNodeStateMachine>();
		for (WrapperNodeStateMachine arbitrator : input_arbitrators) {
			for (WrapperNode.IODesc input : arbitrator.iterateInputDescs()) {
				if (m_arbitrators.put(input.getName(), arbitrator) != null)
					throw new MaxCompilerInternalError("Arbitrator already exists for input '%s'.", input.getName());
			}
		}

		m_non_blockers = new HashMap<String, WrapperNodeStateMachine>(non_blockers);
	}

	@Override
	public void setClock(ManagerClock clock) {
		final WrapperClock clockImp = _CustomManagers.managerClockToImp(clock);
		m_photon.setClock(clockImp);

		for (WrapperNodeStateMachine sm : m_arbitrators.values())
			sm.setClock(clockImp);
		for (WrapperNodeStateMachine sm : m_non_blockers.values())
			sm.setClock(clockImp);
	}

	public DFELink getInput(String name) {
		// is the specified input non-blocking? if so, get the input to the
		// relevant state machine
		WrapperNode node = m_non_blockers.get(name);
		if (node != null)
			return _CustomManagers.fromImp(node.getInput("input"));

		// is the specified input arbitrated? if so, get the input to the
		// relevant state machine
		node = m_arbitrators.get(name);
		if (node == null)
			node = m_photon;

		return _CustomManagers.fromImp(node.getInput(name));
	}

	public DFELink getOutput(String name) {
		return _CustomManagers.fromImp(m_photon.getOutput(name));
	}

	/**
	 * This is no longer needed, and is now just an alias for {@link #getOutput(String)}.
	 */
	@Deprecated
	public DFELink getOutputKStructAsGroup(String name) {
		return getOutput(name);
	}

	public Collection<String> getAllInputs() {
		final SortedSet<String> inputs = new TreeSet<String>();
		final Map<String, ArbitratedInput> arbitratedInputs = m_photon.getIOInformation().getArbitratedInputs();

		for (String name : m_photon.getAllInputs()) {
			ArbitratedInput arb = arbitratedInputs.get(name);

			if (arb == null)
				inputs.add(name);
			else
				inputs.addAll(arb.names);
		}

		return inputs;
	}

	public Collection<String> getAllOutputs() {
		return m_photon.getAllOutputs();
	}
}
