package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import java.util.Collection;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;

public class _KernelBlockV0 extends KernelBlock {
	com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeStreamingBlock m_imp;

	_KernelBlockV0(com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeV0Photon photon) {
		m_imp = photon;
	}

	@Override
	public DFELink getInput(String name) {
		return _CustomManagers.fromImp(m_imp.getInput(name));
	}

	@Override
	public DFELink getOutput(String name) {
		return _CustomManagers.fromImp(m_imp.getOutput(name));
	}

	@Override
	public DFELink getOutputKStructAsGroup(String name) {
		throw new MaxCompilerAPIError("V0 KernelDesigns cannot use KStructs");
	}

	@Override
	public Collection<String> getAllInputs() {
		return m_imp.getAllInputs();
	}

	@Override
	public Collection<String> getAllOutputs() {
		return m_imp.getAllOutputs();
	}
}
