package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

public class LogCornerCasesTest extends Kernel {

	public LogCornerCasesTest(KernelParameters parameters, KernelMath.Range inputRange, DFEType inputType, DFEType outputType) {
		super(parameters);
		DFEVar input = io.input("input", inputType);
		DFEVar log = KernelMath.log2(inputRange, input, outputType);
		io.output("output", log, log.getType());
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SimulationManager mgr = new SimulationManager("LogCornerCasesTest");
		DFEType inputType = dfeFloat(11, 53);
		Kernel kernel = new LogCornerCasesTest(mgr.makeKernelParameters(), new KernelMath.Range(1E-10, 1E10), inputType, dfeFloat(7,41));
		mgr.setKernel(kernel);

		String cases[] = new String[]{
			"0011111111101111111111111111111111111111111111111111111111111111"
		};
		List<Double> expected = new ArrayList<Double>(cases.length);

		Bits data[] = new Bits[cases.length];
		for(int i = 0; i < cases.length; i++) {
			data[i] = new Bits(cases[i].length());
			data[i].setBinaryBits(cases[i]);
			expected.add(Math.log(inputType.decodeConstant(data[i]))/Math.log(2));
		}

		mgr.setInputDataRaw("input", data);

		mgr.setKernelCycles(data.length);

		mgr.runTest();

		List<Double> output = mgr.getOutputData("output");
		for(int i = 0; i < cases.length; i++) {
			if(Math.abs(expected[i]-output[i]) > 1E-10) {
				throw new RuntimeException("Test failed on input " + cases[i] + ". Got " + output[i] +
					" when expected " + expected[i]);
			}
		}

		System.out.println("TEST PASSED");
	}
}
