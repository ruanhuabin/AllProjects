package com.maxeler.maxcompiler.v2.managers;

import com.maxeler.maxeleros.platforms.MAX3Board.MAX3BoardCapabilities;
import com.maxeler.maxeleros.platforms.MAX3Board.MAX3FPGA;
import com.maxeler.maxeleros.platforms.MAX3Board.MAX3FPGAType;


public enum MAX3BoardModel implements MAXBoardModel {
	/** MAX3 Rev A, Virtex-6 SX475T, 12GB RAM (6x 2GB SODIMMs) */
	MAX3412A(MAX3BoardCapabilities.MAX3412A),
	/** MAX3 Rev A, Virtex-6 SX475T, 24GB RAM (6x 4GB SODIMMs) */
	MAX3424A(MAX3BoardCapabilities.MAX3424A),
	/** MAX3 Rev A, Virtex-6 SX475T, 48GB RAM (6x 8GB SODIMMs) */
	MAX3448A(MAX3BoardCapabilities.MAX3448A),

	/** MAX3 Rev A, Virtex-6 SX315T, 12GB RAM (6x 2GB SODIMMs) */
	MAX3312A(MAX3BoardCapabilities.MAX3312A),
	/** MAX3 Rev A, Virtex-6 SX315T, 24GB RAM (6x 4GB SODIMMs) */
	MAX3324A(MAX3BoardCapabilities.MAX3324A),
	/** MAX3 Rev A, Virtex-6 SX315T, 48GB RAM (6x 8GB SODIMMs) */
	MAX3348A(MAX3BoardCapabilities.MAX3348A),

	/** MAX3 Rev A, Virtex-6 LX240T, 12GB RAM (6x 2GB SODIMMs) */
	MAX3212A(MAX3BoardCapabilities.MAX3212A),
	/** MAX3 Rev A, Virtex-6 LX240T, 24GB RAM (6x 4GB SODIMMs) */
	MAX3224A(MAX3BoardCapabilities.MAX3224A),
	/** MAX3 Rev A, Virtex-6 LX240T, 48GB RAM (6x 8GB SODIMMs) */
	MAX3248A(MAX3BoardCapabilities.MAX3248A),

	MAX3LX75_INTERFACE(new MAX3BoardCapabilities(MAX3FPGA.MAX3INTERFACE_FPGA, MAX3FPGAType.LXT75_2)),
	MAX3LX130_INTERFACE(new MAX3BoardCapabilities(MAX3FPGA.MAX3INTERFACE_FPGA, MAX3FPGAType.LXT130_2ES));


	final MAX3BoardCapabilities m_board_caps;

	private MAX3BoardModel(MAX3BoardCapabilities board_caps) {
		m_board_caps = board_caps;
	}
}
