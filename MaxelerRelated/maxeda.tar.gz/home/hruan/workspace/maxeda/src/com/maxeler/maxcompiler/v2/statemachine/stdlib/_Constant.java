package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;

public final class _Constant {
	private _Constant(){}

	public static Constant create (StateMachineLib owner) {return new Constant(owner);}
}
