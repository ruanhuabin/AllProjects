package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.SimulationOutputCheckException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath.Range;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager.DualSimMode;

public class LogTest extends Kernel {

	static private int test_count = 0;

	double m_test_a;
	double m_test_b;

	protected LogTest(KernelParameters params, DFEType format, double a, double b) {
		this(params, format, format, a, b);
	}

	protected LogTest(KernelParameters params, DFEType inputType, DFEType outputType, double a, double b) {
		super(params);

		DFEVar inputx = io.input("inputx", inputType);
		DFEVar outputy = io.output("outputy", outputType);

		m_test_a = a;
		if(inputType instanceof DFEFix) {
			m_test_b = Math.min(b, ((DFEFix)inputType).getMax());
		} else {
			m_test_b = b;
		}

		outputy <== KernelMath.log(new Range(a, b), inputx, outputType);
	}

	public static void test(DFEType testType, double a, double b){
		test(testType, testType, a, b);
	}

	public static void test(DFEType inputType, DFEType outputType, double a, double b){
		test_count++;

		_DualSimulationManager manager = new _DualSimulationManager("LogTest", DualSimMode.A_ONLY);
		LogTest toTestA = new LogTest(manager.getManager_A().makeKernelParameters(), inputType, outputType, a, b);
		LogTest toTestB = new LogTest(manager.getManager_B().makeKernelParameters(), inputType, outputType, a, b);
		manager.setKernels(toTestA, toTestB);

		int dataSize = 500;
		double [] inputVal = new double[dataSize];
		Random r = new Random(System.currentTimeMillis());
		for ( int i = 0;  i < dataSize; i++ ){
			inputVal[i] = inputType.decodeConstant(inputType.encodeConstant(toTestA.m_test_a + (toTestA.m_test_b-toTestA.m_test_a)*r.nextDouble()));
		}

		manager.setInputData("inputx", inputVal);
		manager.setKernelCycles(inputVal.length);
		manager.runTest();

		List<Double> outputList;
		Double[] outputArray = new Double[dataSize];

		outputList = manager.getOutputData("outputy");
		outputList.toArray(outputArray);

		int numPassed = 0;
		int numFailed = 0;

		for ( int i = 0; i < dataSize; i++ ){

			double orgInput = inputVal[i];
			double trueVal = Math.log(inputVal[i]);

			double absError = Math.abs(trueVal - outputArray[i]);
			double relError = Math.abs(absError/trueVal);
			double error = Math.min(absError, relError);

			double acceptableError = 0;
			if(outputType instanceof DFEFix)
				acceptableError = Math.pow(2.0, -((DFEFix)outputType).getFractionBits());
			else
				acceptableError = Math.pow(2.0, - (((DFEFloat)outputType).getMantissaBits()-1) );

			if ( error > acceptableError ){
				System.out.println("input val     : " + inputVal[i] + " : " + orgInput);
				System.out.println("Error crosses the required bound!");
				System.out.println("true val      : " + trueVal);
				System.out.println("hardware val  : " + outputArray[i]);
				System.out.println("error:        : " + error);
				System.out.println("req error     : " + acceptableError);
				System.out.println("\n\n");
				numFailed ++ ;
			}
			else
				numPassed ++;
		}

		System.out.println("total  samples: " + dataSize);
		System.out.println("passed samples: " + numPassed);
		System.out.println("failed samples: " + numFailed);

		String str = "Test LOG " + inputType + " " + outputType + ", [" + a + ", " + b + "]";
		if ( numFailed > 0 )
			throw new SimulationOutputCheckException(manager.getManager_A(), str + "  FAILED");
		System.out.println(str + "  PASSED");
	}

	public static void main(String[] args) {
		test(Kernel.dfeFix(6, 16, SignMode.TWOSCOMPLEMENT), 0.5, 4);
		test(Kernel.dfeFix(10, 16, SignMode.TWOSCOMPLEMENT), 0.0001, 512);
		test(Kernel.dfeFloat(8, 24), 1E-10, 1E10);
		test(Kernel.dfeOffsetFix(32, 0.25, SignMode.TWOSCOMPLEMENT), Kernel.dfeOffsetFix(32, 128., SignMode.TWOSCOMPLEMENT), 0.0625, 0.2);
		test(Kernel.dfeOffsetFix(32, 0.4, SignMode.TWOSCOMPLEMENT), Kernel.dfeOffsetFix(32, 128., SignMode.TWOSCOMPLEMENT), 0.0625, 1);
		test(Kernel.dfeOffsetFix(32, 0.5, SignMode.TWOSCOMPLEMENT), Kernel.dfeOffsetFix(32, 128., SignMode.TWOSCOMPLEMENT), 0.0625, 1);

		System.out.println("\n\nAll " + test_count + " tests passed for LOG units.\n\n");
	}
}
