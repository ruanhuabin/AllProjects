package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;

public abstract class Lib {
	private final StateMachineLib m_stateMachineLib;

	/**
	 * @exclude
	 */
	protected Lib (StateMachineLib sm) {
		m_stateMachineLib = sm;
	}

	/**
	 * @exclude
	 */
	protected StateMachineLib getStateMachine() {
		return m_stateMachineLib;
	}

	/**
	 * @exclude
	 */
	protected void checkIsInConstructor() {
		if (_StateMachine.getInfo(m_stateMachineLib).haveContext())
			throw new MaxCompilerAPIError("State variables must not be created in the next-state or output-function methods. (Use the constructor.)");
	}

}
