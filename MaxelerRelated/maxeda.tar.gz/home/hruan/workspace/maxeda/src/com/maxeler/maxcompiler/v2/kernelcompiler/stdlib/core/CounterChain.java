package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Stack;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelFinalizer;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Count.Params;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.maxcompiler.v2.utils.MathUtils;

/**
* {@code CounterChain} objects connect together a series of dependent counters,
* similarly to nested loops in software.
* <p>
* See the
* <a href="{@docRoot}/../maxcompiler-tutorial.pdf#destination.counters">MaxCompiler Tutorial</a> for more
* details on using counter chains.
*/
public class CounterChain {
	private abstract class NestedLoopNode {
		private final DFEVar m_control;

		private NestedLoopNode() {
			m_control = DFETypeFactory.dfeBool().newInstance(m_design);
		}

		protected abstract DFEVar getWrap();

		protected DFEVar getControl() {
			return m_control;
		}

		NestedLoopNode setParent(NestedLoopNode parent) {
			// If we have a parent node, connect our chain, etc.
			if (parent != null) {
				DFEVar wrap = getWrap();

				// currently the wrap signal from a counter comes directly from
				// comparison logic and not a register
				final int wrapPipelining = _Kernel.getPhotonDesignData(m_design).getKernelConfiguration().optimizations().getCounterChainWrapPipelining();
				for (int i = 0; i < wrapPipelining; ++i)
					wrap = m_design.optimization.pipeline(wrap);

				parent.getControl().connect(wrap);
			}

			return this;
		}
	}

	private int getNumBitsForMax(long max) {
		if(!m_less_bits)
			return MathUtils.bitsToRepresentUnsigned(max);
		else
			return MathUtils.bitsToAddress(max);
	}

	private static int getNumBitsForMax(DFEVar max) {
		return max.getType().getTotalBits();
	}

	private class NestedLoopNodeSP extends NestedLoopNode {
		private final Count.Counter m_counter;

		private NestedLoopNodeSP(long max, int increment) {
			// TODO Fix this, whenever v2 comes along: numbits should use
			// bitsToAddress, otherwise we have an extra unused bit for
			// max = Power-of-2. Can't fix this without breaking the interface.
			int numbits = getNumBitsForMax(max);

			// Setup this counter
			m_counter = m_design.control.count.makeCounter(
				m_design.control.count.makeParams(numbits)
					.withMax(max)
					.withInc(increment)
					.withEnable(getControl()));
		}

		private NestedLoopNodeSP(DFEVar max, int increment) {
			int numbits = getNumBitsForMax(max);

			// Setup this counter
			m_counter = m_design.control.count.makeCounter(
				m_design.control.count.makeParams(numbits)
					.withMax(max)
					.withInc(increment)
					.withEnable(getControl()));
		}

		@Override
		protected DFEVar getWrap() {
			return m_counter.getWrap();
		}

		protected DFEVar getCounter() {
			return m_counter.getCount();
		}
	}

	private class NestedLoopNodeMP<
			M extends DFEVectorBase<DFEVar, M, ?, ?>
		>
		extends NestedLoopNode
	{
		private final Count.CounterVectBase<M> m_counter;

		private NestedLoopNodeMP(long max, M mp_obj, int increment) {
			// TODO Fix this, whenever v2 comes along: numbits should use
			// bitsToAddress, otherwise we have an extra unused bit for
			// max = Power-of-2. Can't fix this without breaking the interface.
			int numbits = getNumBitsForMax(max);

			// Setup this counter
			m_counter = m_design.control.count.makeCounterVect(
				mp_obj,
				m_design.control.count.makeParams(numbits)
					.withMax(max)
					.withInc(increment)
					.withEnable(getControl()));
		}

		private NestedLoopNodeMP(DFEVar max, M mp_obj, int increment, boolean warn) {
			int numbits = getNumBitsForMax(max);
			Params params = m_design.control.count.makeParams(numbits)
				.withMax(max)
				.withInc(increment)
				.withEnable(getControl());

			// Setup this counter
			if (warn)
				m_counter = m_design.control.count.makeCounterVect(mp_obj, params);
			else
				m_counter = m_design.control.count.makeCounterMPNoWarn(mp_obj.getType(), params);
		}

		@Override
		protected DFEVar getWrap() {
			return m_counter.getWrap();
		}

		private M getCounter() {
			return m_counter.getCount();
		}

	}

	private final Kernel m_design;
	private final DFEVar m_enable;
	private final boolean m_less_bits;

	private final Stack<NestedLoopNode> m_nestedloop_stack =
		new Stack<NestedLoopNode>();

	private final Map<KernelObject<?>, DFEVar> m_counter_wrap_map =
		new IdentityHashMap<KernelObject<?>, DFEVar>();

	private boolean m_mp_added = false;

	CounterChain(Kernel design, DFEVar enable, boolean lessBits) {
		m_design = design;
		m_enable = enable;
		m_less_bits = lessBits;

		m_design.addKernelFinalizer( new KernelFinalizer() {
			@Override
			public void finalizeKernel(Kernel kernelDesign) {
				if(m_nestedloop_stack.isEmpty())
					m_design.getManager().logWarning("Design has unused NestedCounter.");
				else
					m_nestedloop_stack.peek().getControl().connect(m_enable);
			}
		});
	}

	private void checkNoVectAdded() {
		if(m_mp_added)
			throw new MaxCompilerAPIError(m_design.getManager(),
				"When using a nested-counters, the multi-pipe counter must be the last (inner-most) counter.");
	}

	private <M extends DFEVectorBase<DFEVar, M, ?, ?>>
		M addCounterVect(NestedLoopNodeMP<M> new_node)
	{
		checkNoVectAdded();
		m_mp_added = true;

		// Set the enable on the outer loop to be the chain on this counter
		NestedLoopNode parent;
		if(m_nestedloop_stack.empty())
			parent = null;
		else
			parent = m_nestedloop_stack.peek();

		// Push the loop onto the stack
		new_node.setParent(parent);
		m_nestedloop_stack.push(new_node);

		M counter = new_node.getCounter();
		m_counter_wrap_map.put(counter, new_node.getWrap());

		return counter;
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * Each pipe in the stream
	 * has a value {@code increment} larger than the previous pipe.
	 * <p>
	 * Each pipe increments from {@code pipe_id*increment} by {@code num_pipes*increment}
	 * to {@code max-pipe_id*increment-1} inclusive before repeating from {@code pipe_id*increment} again.
	 * <p>
	 * <b>Note</b>: {@code max} must be a multiple of {@code num_pipes}.
	 *
	 * @param num_pipes The number of pipes in the counter.
	 * @param max The counter will count up to this value <i>minus 1</i>.
	 * @param increment The value added for each pipe.
	 * @return The {@code DFEVector<DFEVar>} counter.
	 */
	public DFEVector<DFEVar> addCounterVect(int num_pipes, long max, int increment) {
		DFEType counter_type =
			m_design.control.count.makeParams(getNumBitsForMax(max)).getExpectedType();
		NestedLoopNodeMP<DFEVector<DFEVar>> new_node =
			new NestedLoopNodeMP<DFEVector<DFEVar>>(
				max,
				new DFEVectorType<DFEVar>(counter_type, num_pipes).newInstance(m_design),
				increment);
		return addCounterVect(new_node);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with the {@code max}
	 * variable set at run-time by a stream.
	 * <p>
	 * Each pipe in the stream
	 * has a value {@code increment} larger than the previous pipe.
	 * <p>
	 * <b>Note</b>: the values in stream {@code max} must be multiples of the number of pipes, but this
	 *            cannot be checked at compile time.
	 *
	 * @see #addCounterMPNoWarn(int, DFEVar, int)
	 * @param num_pipes The number of pipes in the counter.
	 * @param max An {@code DFEVar} providing a stream of wrap points.
	 * @param increment The value added for each pipe.
	 * @return The {@code DFEVector<DFEVar>} counter.
	 */
	public DFEVector<DFEVar> addCounterVect(int num_pipes, DFEVar max, int increment) {
		return addCounterVect(num_pipes, max, increment, true);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with the {@code max}
	 * variable set at run-time by a stream.
	 * <p>
	 * Each pipe in the stream
	 * has a value {@code increment} larger than the previous pipe.
	 * <p>
	 * <b>Note</b>: the values in stream {@code max} must be multiples of the number of pipes, but this
	 *            cannot be checked at compile time.
	 * <p>
	 * This method is identical to {@link #addCounterMP(int, DFEVar, int)} except
	 * that it does not generate a compiler warning.
	 *
	 * @see #addCounterMP(int, DFEVar, int)
	 * @param num_pipes The number of pipes in the counter.
	 * @param max An {@code DFEVar} providing a stream of wrap points.
	 * @param increment The value added for each pipe.
	 * @return The {@code DFEVector<DFEVar>} counter.
	 */
	public DFEVector<DFEVar> addCounterVectNoWarn(int num_pipes, DFEVar max, int increment) {
		return addCounterVect(num_pipes, max, increment, false);
	}

	private DFEVector<DFEVar> addCounterVect(int num_pipes, DFEVar max, int increment, boolean warn) {
		if(!max.getType().isConcreteType() || !max.getType().isUInt())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Type of DFEVar used for max must be a concrete " +
				"and unsigned integer, not: "  + max.getType());

		DFEType counter_type =
			m_design.control.count.makeParams(getNumBitsForMax(max)).getExpectedType();
		NestedLoopNodeMP<DFEVector<DFEVar>> new_node =
			new NestedLoopNodeMP<DFEVector<DFEVar>>(
				max,
				new DFEVectorType<DFEVar>(counter_type, num_pipes).newInstance(m_design),
				increment,
				warn);

		return addCounterVect(new_node);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with the number of
	 * pipes defined according to the multipipe type template.
	 *
	 * @param template_mp_type The multipipe type that defines the number of pipes
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M addCounterVect(T template_mp_type, long max, int increment) {
		DFEType counter_type =
			m_design.control.count.makeParams(getNumBitsForMax(max)).getExpectedType();

		NestedLoopNodeMP<M> new_node =
			new NestedLoopNodeMP<M>(
				max,
				template_mp_type.newInstance(m_design, counter_type.newInstance(m_design)).getType().newInstance(m_design),
				increment);

		return addCounterVect(new_node);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with the number of
	 * pipes defined according to the multipipe object template.
	 *
	 * @param template_mp_obj A multipipe object that defines the number of pipes
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M addCounterVect(M template_mp_obj, long max, int increment) {
		return addCounterVect(template_mp_obj.getType(), max, increment);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with
	 * the number of pipes defined according to the multipipe object template
	 * and the {@code max} variable set at run-time by a stream.
	 * <p>
	 * <b>Note</b>: the values in stream {@code max} must be multiples of the number of pipes, but this
	 *            cannot be checked at compile time.
	 * @param template_mp_type The multipipe type that defines the number of pipes
	 * @param max An {@code DFEVar} providing a stream of wrap points.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M addCounterVect(T template_mp_type, DFEVar max, int increment) {
		return addCounterVect(template_mp_type, max, increment, true);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with
	 * the number of pipes defined according to the multipipe object template
	 * and the {@code max} variable set at run-time by a stream.
	 * <p>
	 * <b>Note</b>: the values in stream {@code max} must be multiples of the number of pipes, but this
	 *            cannot be checked at compile time.
	 * <p>
	 * This method is identical to {@link #addCounterMP(DFEVectorTypeBase, DFEVar, int)}
	 * except that it does not generate a warning.
	 * @see #addCounterMP(DFEVectorTypeBase, DFEVar, int)
	 * @param template_mp_type The multipipe type that defines the number of pipes
	 * @param max An {@code DFEVar} providing a stream of wrap points.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M addCounterVectNoWarn(T template_mp_type, DFEVar max, int increment) {
		return addCounterVect(template_mp_type, max, increment, false);
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M addCounterVect(T template_mp_type, DFEVar max, int increment, boolean warn) {
		if(!max.getType().isConcreteType() || !max.getType().isUInt())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Type of DFEVar used for max must be a concrete " +
				"and unsigned integer, not: "  + max.getType());

		DFEType counter_type =
			m_design.control.count.makeParams(getNumBitsForMax(max)).getExpectedType();

		NestedLoopNodeMP<M> new_node =
			new NestedLoopNodeMP<M>(
				max,
				template_mp_type.newInstance(m_design, counter_type.newInstance(m_design)).getType().newInstance(m_design),
				increment,
				warn);

		return addCounterVect(new_node);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with
	 * the number of pipes defined according to the multipipe object template
	 * and the {@code max} variable set at run-time by a stream.
	 * <p>
	 * <b>Note</b>: the values in stream {@code max} must be multiples of the number of pipes, but this
	 *            cannot be checked at compile time.
	 * @param template_mp_obj A multipipe object of the type that
	 *            defines the number of pipes.
	 * @param max An {@code DFEVar} providing a stream of wrap points.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M addCounterVect(M template_mp_obj, DFEVar max, int increment) {
		return addCounterVect(template_mp_obj.getType(), max, increment);
	}

	/**
	 * Adds a multipipe counter to the counter chain.
	 * <p>
	 * As {@link CounterChain#addCounterMP(int, long, int)} but with
	 * the number of pipes defined according to the multipipe object template
	 * and the {@code max} variable set at run-time by a stream.
	 * <p>
	 * <b>Note</b>: the values in stream {@code max} must be multiples of the number of pipes, but this
	 *            cannot be checked at compile time.
	 * <p>
	 * This method is identical to {@link #addCounterMP(DFEVectorBase, DFEVar, int)}
	 * except that it does not generate a compiler warning.
	 * @see #addCounterMP(DFEVectorBase, DFEVar, int)
	 * @param template_mp_obj A multipipe object of the type that
	 *            defines the number of pipes.
	 * @param max An {@code DFEVar} providing a stream of wrap points.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M addCounterVectNoWarn(M template_mp_obj, DFEVar max, int increment) {
		return addCounterVectNoWarn(template_mp_obj.getType(), max, increment);
	}

	private DFEVar addCounter(NestedLoopNodeSP new_node) {
		checkNoVectAdded();

		// Set the enable on the outer loop to be the chain on this counter
		NestedLoopNode parent;
		if(m_nestedloop_stack.empty())
			parent = null;
		else
			parent = m_nestedloop_stack.peek();

		// Push the loop onto the stack
		new_node.setParent(parent);
		m_nestedloop_stack.push(new_node);

		DFEVar counter = new_node.getCounter();
		m_counter_wrap_map.put(counter, new_node.getWrap());

		return counter;
	}

	/**
	 * Adds a counter into the chain with values sequentially increasing from {code 0},
	 * in steps of {@code increment}, up to {@code (max - 1)} inclusive,
	 * before repeating from {@code 0} again.
	 * <p>
	 * This method may be invoked more than once on a single CounterChain object:
	 * each call creates a new counter loop nested within the previous one,
	 * i.e. the first call creates the outermost, or "slowest", loop.
	 * @param max The counter will count up to this value <i>minus 1</i>.
	 * @param increment The value by which the counter increases on each cycle.
	 * @return An {@code DFEVar} with the count value for current counter in the chain.
	 */
	public DFEVar addCounter(long max, int increment) {
		NestedLoopNodeSP new_node = new NestedLoopNodeSP(max, increment);
		return addCounter(new_node);
	}

	/**
	 * Adds a counter into the chain with values sequentially increasing from {code 0},
	 * in steps of {@code increment}, up to {@code (max - 1)} inclusive,
	 * before repeating from {@code 0} again.
	 * <p>
	 * As {@link CounterChain#addCounter(long, int)} but with the {@code max}
	 * variable at run-time by a stream.
	 *
	 * @param max An {@code DFEVar} providing a stream of maximum values.
	 * @param increment The value by which the counter increases on each cycle.
	 * @return An {@code DFEVar} with the count value for current counter in the chain.
	 */
	public DFEVar addCounter(DFEVar max, int increment) {
		if(!max.getType().isConcreteType() || !max.getType().isUInt())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Type of DFEVar used for max must be a concrete " +
				"and unsigned integer, not: "  + max.getType());

		NestedLoopNodeSP new_node = new NestedLoopNodeSP(max, increment);
		return addCounter(new_node);
	}

	/**
	 * Returns a Boolean {@code DFEVar} stream which is equal to {@code 1} at the point
	 * when the last counter added to the chain will wrap <i>on the next cycle</i>,
	 * and {@code 0} otherwise.
	 */
	public DFEVar getCurrentCounterWrap() {
		if(m_nestedloop_stack.empty())
			throw new MaxCompilerAPIError(m_design.getManager(), "No counters have yet been added to this chain.");

		return m_nestedloop_stack.peek().getWrap();
	}

	/**
	 * Returns a Boolean {@code DFEVar} stream which is equal to {@code 1} at the point
	 * when the specified counter will wrap <i>on the next cycle</i>,
	 * and {@code 0} otherwise.
	 * @param counter The counter for which the wrap signal is required,
	 *                as returned by {@link CounterChain#addCounter(long, int)}
	 *                or {@link CounterChain#addCounter(DFEVar, int)}
	 */
	public DFEVar getCounterWrap(KernelObject<?> counter) {
		DFEVar wrap = m_counter_wrap_map.get(counter);
		if(wrap == null)
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Supplied counter object is not associated with this counter-chain.");

		return wrap;
	}
}
