package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

public class DFEVectorFullType<ContainedT extends KernelObjectVectorizable<ContainedT>>
	extends
	DFEVectorFullTypeBase<
		ContainedT,
		DFEVector<ContainedT>,
		DFEVector<DFEVar>>
{
	public DFEVectorFullType(
		DFEVectorDoubtType doubt_type,
		DFEVectorType<ContainedT> kernel_type)
	{
		super(doubt_type, kernel_type);
	}
}
