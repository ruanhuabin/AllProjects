package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import java.util.LinkedList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom.DFELink;
import com.maxeler.maxcompiler.v2.managers.custom._CustomManagers;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControlGroup.MemoryAccessPattern;
import com.maxeler.maxeleros.BoardResourceDIMM;
import com.maxeler.maxeleros.ip.Ethernet.Max3NetworkConnection;
import com.maxeler.maxeleros.ip.Ethernet.NetworkConnection;
import com.maxeler.maxeleros.ip.Ethernet.V6OneGigEthernetPlugin;
import com.maxeler.maxeleros.ip.Ethernet.V6TenGigEthernetPlugin;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.maxeleros.managercompiler.libs.AsymmetricInterFPGAFactory;
import com.maxeler.maxeleros.managercompiler.libs.InterFPGAFactory;
import com.maxeler.maxeleros.managercompiler.libs.MemoryControllerDefinition.VirtualDIMM;
import com.maxeler.maxeleros.managercompiler.libs.MemoryControllerDefinition.VirtualDIMM.MemoryCommandDefinition;
import com.maxeler.maxeleros.managercompiler.libs.MemoryIOFactory;
import com.maxeler.maxeleros.managercompiler.libs.NetworkIOFactory;
import com.maxeler.maxeleros.managercompiler.libs.NetworkInterfacePlugin;
import com.maxeler.maxeleros.managercompiler.libs.NetworkLinkSpeed;
import com.maxeler.maxeleros.managercompiler.libs.TimestampingIOFactory;
import com.maxeler.maxeleros.managercompiler.libs.TimestampingIOFactory.TimestampingIOFormat;
import com.maxeler.maxeleros.platforms.MAX3AuroraLinkType;
import com.maxeler.maxeleros.platforms.MAX3ComputeFPGA;


public class _MAX3ComputeIOInterface implements _BoardIOInterface {
	private final WrapperDesignData m_data;

	private static final int m_ifpga_width = 128;

	private final AsymmetricInterFPGAFactory m_ifpga_factory;

	private final InterFPGAFactory m_maxring_a_factory;
	private final InterFPGAFactory m_maxring_b_factory;
	private final InterFPGAFactory m_maxring_lite_a_factory;
	private final InterFPGAFactory m_maxring_lite_b_factory;

	private final NetworkIOFactory m_network_sfp1_factory;
	private final NetworkIOFactory m_network_sfp2_factory;
	private final NetworkIOFactory m_network_cx4_factory;

	private final TimestampingIOFactory m_timestamping_factory;

	private final MAX3ComputeFPGA m_platform;

	private final MemoryIOFactory m_memory_io_factory;
	private final VirtualDIMM m_max3_sodimms;

	private final List<MemoryControlGroup> m_memory_control_groups = new LinkedList<MemoryControlGroup>();

	private int m_maxring_a_width = 64, m_maxring_b_width = 64;
	private int m_maxring_lite_a_width = 32, m_maxring_lite_b_width = 32;

	private static final int m_default_max_sth_num = 8;
	private int m_max_sth_num = m_default_max_sth_num;
	private int m_sth_num = 0;
	private static final int m_default_max_sfh_num = 8;
	private int m_max_sfh_num = m_default_max_sfh_num;
	private int m_sfh_num = 0;



	public _MAX3ComputeIOInterface(WrapperDesignData data, MAX3ComputeFPGA platform, WrapperClock clock) {
		m_data = data;
		m_platform = platform;

		m_maxring_a_factory = new InterFPGAFactory(data, "maxring_a", clock, true);
		m_maxring_b_factory = new InterFPGAFactory(data, "maxring_b", clock, true);
		m_maxring_lite_a_factory = new InterFPGAFactory(data, "maxring_lite_a", clock, false);
		m_maxring_lite_b_factory = new InterFPGAFactory(data, "maxring_lite_b", clock, false);

		m_network_sfp1_factory = new NetworkIOFactory(data, "sfp1");
		m_network_sfp2_factory = new NetworkIOFactory(data, "sfp2");
		m_network_cx4_factory = new NetworkIOFactory(data, "cx4");

		m_timestamping_factory = new TimestampingIOFactory(data, "timestamp");

		BoardResourceDIMM resource[] = new BoardResourceDIMM[1];
		resource[0] = m_platform.getDIMMS(6);
		m_memory_io_factory = new MemoryIOFactory(data, "sodimms", resource, clock);

		m_memory_io_factory.setOnCardMemoryFrequency(303.0);


		m_ifpga_factory = new AsymmetricInterFPGAFactory(data, "ifpga", clock);
		m_ifpga_factory.setRemoteRegisterAccess();

		m_max3_sodimms = m_memory_io_factory.makeVirtualDIMM(1, "max3_sodimms");
	}

	public void setMaxRingNumLanes(MaxRingConnection connection, int num_lanes) {
		if(!(connection instanceof Max3RingConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max3RingConnection when targetting a MAX3 board");


		switch((Max3RingConnection)connection) {
			case MAXRING_A:
				m_maxring_a_width = num_lanes * 32;
				break;

			case MAXRING_B:
				m_maxring_b_width = num_lanes * 32;
				break;

			case MAXRING_LITE_A:
				m_maxring_lite_a_width = num_lanes * 32;
				break;

			case MAXRING_LITE_B:
				m_maxring_lite_b_width = num_lanes * 32;
				break;

		}
	}

	public void setNumberOfPCIExpressLanes(int num_lanes) { }

	public void setEnablePCIExpressFastClock(boolean fast_clock) { }

	public void setStreamToCPUMaxNum(int num) {
		int max_num = m_platform.getIFPGA(MAX3AuroraLinkType.INTERFPGA_LINK, m_ifpga_width).getMaxStreamsToRemoteNum();
		if(num > max_num) {
			throw new MaxCompilerAPIError(m_data,
				"Platform doesn't support more than " + max_num + " streams to host.");
		}
		m_max_sth_num = num;
	}

	public void setStreamFromCPUMaxNum(int num) {
		int max_num = m_platform.getIFPGA(MAX3AuroraLinkType.INTERFPGA_LINK, m_ifpga_width).getMaxStreamsToRemoteNum();
		if(num > max_num) {
			throw new MaxCompilerAPIError(m_data,
				"Platform doesn't support more than " + max_num + " streams from host.");
		}
		m_max_sfh_num = num;
	}

	@Override
	public MaxRingBidirectionalStream addMaxRingBirectionalStream(
		String name,
		MaxRingConnection connection)
	{
		if(!(connection instanceof Max3RingConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max3RingConnection when targetting a MAX3 board");

		InterFPGAFactory factory = null;
		switch((Max3RingConnection)connection) {
			case MAXRING_A:
				factory = m_maxring_a_factory; break;
			case MAXRING_B:
				factory = m_maxring_b_factory; break;
			case MAXRING_LITE_A:
				factory = m_maxring_lite_a_factory; break;
			case MAXRING_LITE_B:
				factory = m_maxring_lite_b_factory; break;
		}
		return new MaxRingBidirectionalStream(name, factory.makeInterChipStream(name));
	}

	@Override
	public DFELink addStreamFromHost(String name) {
		if(++m_sfh_num > m_max_sfh_num) {
			throw new MaxCompilerAPIError(m_data, "Adding stream '" + name + "': " +
			"too many streams from host.\nUse config.setStreamFromHostMaxNumber() to increase " +
			"the maximum number of streams if your Interface FPGA supports it.");
		}
		if(m_sfh_num > m_default_max_sfh_num) {
			m_data.getBuildManager().logWarning("Adding stream '" + name + "': " +
					"design has more than " + m_default_max_sfh_num + " streams from host. "+
					"Ensure the Interface FPGA supports it.");
		}
		return _CustomManagers.fromImp(m_ifpga_factory.addStreamFromRemoteFPGA(name, true));
	}

	@Override
	public DFELink addStreamToHost(String name) {
		if(++m_sth_num > m_max_sth_num) {
			throw new MaxCompilerAPIError(m_data, "Adding stream '" + name + "': " +
			"too many streams to host.\nUse config.setStreamToHostMaxNumber() to increase " +
			"the maximum number of streams if your Interface FPGA supports it.");
		}
		if(m_sth_num > m_default_max_sth_num) {
			m_data.getBuildManager().logWarning("Adding stream '" + name + "': " +
					"design has more than " + m_default_max_sth_num + " streams to host. "+
					"Ensure the Interface FPGA supports it.");
		}
		return _CustomManagers.fromImp(m_ifpga_factory.addStreamToRemoteFPGA(name, true));
	}

	private MemoryCommandDefinition getCmdDef(MemoryControlGroup controlStream, String name, boolean is_read_stream) {
		return controlStream.addDataStream(name, is_read_stream);
	}

	@Override
	public DFELink addStreamFromOnCardMemory(
		String name,
		MemoryControlGroup controlStream)
	{
		return _CustomManagers.fromImp(getCmdDef(controlStream, name, true).addStreamFromMemory(name));
	}

	@Override
	public DFELink addStreamToOnCardMemory(
		String name,
		MemoryControlGroup controlStream)
	{
		return _CustomManagers.fromImp(getCmdDef(controlStream, name, false).addStreamToMemory(name));
	}

	// debug stream
	@Override
	public DFELink getDebugStreamFromCardMemory(String name) {
		return _CustomManagers.fromImp(m_max3_sodimms.getMemoryDebugStream(name));
	}

	@Override
	public MemoryControlGroup addMemoryControlGroup(
		String name,
		DFELink controlStream)
	{
		MemoryControlGroup grp = new MemoryControlGroup(name, controlStream, m_max3_sodimms);
		m_memory_control_groups.add(grp);
		return grp;
	}

	@Override
	public MemoryControlGroup addMemoryControlGroup(
		String name,
		MemoryAccessPattern pattern)
	{
		MemoryControlGroup grp = new MemoryControlGroup(m_data, name, pattern, m_max3_sodimms);
		m_memory_control_groups.add(grp);
		return grp;
	}

	@Override
	public void finalise() {
		m_maxring_a_factory.setBoardResource(m_platform.getIFPGA(MAX3AuroraLinkType.MAXRING_A, m_maxring_a_width));
		m_maxring_b_factory.setBoardResource(m_platform.getIFPGA(MAX3AuroraLinkType.MAXRING_B, m_maxring_b_width));
		m_maxring_lite_a_factory.setBoardResource(m_platform.getIFPGA(MAX3AuroraLinkType.MAXRING_LITE_A, m_maxring_lite_a_width));
		m_maxring_lite_b_factory.setBoardResource(m_platform.getIFPGA(MAX3AuroraLinkType.MAXRING_LITE_B, m_maxring_lite_b_width));
		m_ifpga_factory.setBoardResource(m_platform.getIFPGA(MAX3AuroraLinkType.INTERFPGA_LINK, m_ifpga_width));
		if (m_network_sfp1_factory.getNetworkInterfacePlugin() != null)
			m_network_sfp1_factory.setBoardResource(m_platform.getNetwork(Max3NetworkConnection.CH2_SFP1, m_network_sfp1_factory.getNetworkInterfacePlugin()));
		if (m_network_sfp2_factory.getNetworkInterfacePlugin() != null)
			m_network_sfp2_factory.setBoardResource(m_platform.getNetwork(Max3NetworkConnection.CH2_SFP2, m_network_sfp2_factory.getNetworkInterfacePlugin()));
		if (m_network_cx4_factory.getNetworkInterfacePlugin() != null)
			m_network_cx4_factory.setBoardResource(m_platform.getNetwork(Max3NetworkConnection.CH2_CX4, m_network_cx4_factory.getNetworkInterfacePlugin()));
		m_timestamping_factory.setBoardResource(m_platform.getTimestamp());

		for (MemoryControlGroup grp : m_memory_control_groups) {
			grp.finalise();
		}
	}

	@Override
	public DFELink addStreamFromNetwork(int port, String name) {
		throw new MaxCompilerAPIError(m_data,
			"Not supported when targetting a MAX3 board");
	}

	@Override
	public DFELink addStreamToNetwork(int port, String name) {
		throw new MaxCompilerAPIError(m_data,
			"Not supported when targetting a MAX3 board");
	}

	@Override
	public void setNetworkInterfacePlugin(NetworkInterfacePlugin plugin) {
		throw new MaxCompilerAPIError(m_data,
			"Not supported when targetting a MAX3 board");
	}

	@Override
	public WrapperClock getNetworkInterfaceClock(int port) {
		throw new MaxCompilerAPIError(m_data,
			"Not supported when targetting a MAX3 board");
	}

	@Override
	public DFELink addStreamFromNetwork(NetworkConnection connection, int port, String name) {
		if(!(connection instanceof Max3NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max3NetworkConnection when targetting a MAX3 board");

		switch((Max3NetworkConnection)connection) {
			case CH2_SFP1:
				if (m_network_sfp1_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_sfp1_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_sfp1_factory.getStreamFromNetwork(port, name));
			case CH2_SFP2:
				if (m_network_sfp2_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_sfp2_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_sfp2_factory.getStreamFromNetwork(port, name));
			case CH2_CX4:
				if (m_network_cx4_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_cx4_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_cx4_factory.getStreamFromNetwork(port, name));
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max3NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public DFELink addStreamToNetwork(NetworkConnection connection, int port, String name) {
		if(!(connection instanceof Max3NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max3NetworkConnection when targetting a MAX3 board");

		switch((Max3NetworkConnection)connection) {
			case CH2_SFP1:
				if (m_network_sfp1_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_sfp1_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_sfp1_factory.getStreamToNetwork(port, name));
			case CH2_SFP2:
				if (m_network_sfp2_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_sfp2_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_sfp2_factory.getStreamToNetwork(port, name));
			case CH2_CX4:
				if (m_network_cx4_factory.getNetworkInterfacePlugin() == null)
					throw new MaxCompilerAPIError(m_data,
						"Set network plugin before assigning streams");
				else if (port < 0 || port > m_network_cx4_factory.getNetworkInterfacePlugin().getNumberOfPorts()-1)
					throw new MaxCompilerAPIError(m_data,
						"Port " + port + " not available for this plugin");
				return _CustomManagers.fromImp(m_network_cx4_factory.getStreamToNetwork(port, name));
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max3NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public void setNetworkInterfacePlugin(NetworkConnection connection, NetworkInterfacePlugin plugin) {
		if(!(connection instanceof Max3NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max3NetworkConnection when targetting a MAX3 board");

		switch((Max3NetworkConnection)connection) {
			case CH2_SFP1:
				if(!(plugin instanceof V6OneGigEthernetPlugin || plugin instanceof V6TenGigEthernetPlugin))
					throw new MaxCompilerAPIError(m_data,
						"Plugin specified for network connection " + connection.toString() + " not supported");
				else
					m_network_sfp1_factory.setNetworkInterfacePlugin(connection, plugin); break;
			case CH2_SFP2:
				if(!(plugin instanceof V6OneGigEthernetPlugin || plugin instanceof V6TenGigEthernetPlugin))
					throw new MaxCompilerAPIError(m_data,
						"Plugin specified for network connection " + connection.toString() + " not supported");
				else
					m_network_sfp2_factory.setNetworkInterfacePlugin(connection, plugin); break;
			case CH2_CX4:
				throw new MaxCompilerAPIError(m_data,
					"Network connection " + connection.toString() + " not supported yet");
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max3NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public WrapperClock getNetworkInterfaceClock(NetworkConnection connection, int port) {
		if(!(connection instanceof Max3NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max3NetworkConnection when targetting a MAX3 board");

		switch((Max3NetworkConnection)connection) {
			case CH2_SFP1:
				return m_network_sfp1_factory.getNetworkInterfaceClock(port);
			case CH2_SFP2:
				return m_network_sfp2_factory.getNetworkInterfaceClock(port);
			case CH2_CX4:
				throw new MaxCompilerAPIError(m_data,
					"Network connection " + connection.toString() + " not supported yet");
			default:
				throw new MaxCompilerAPIError(m_data,
					"Invalid Max3NetworkConnection " + connection.toString() + " specified");
		}
	}

	@Override
	public void setMemoryControllerConfig(MemoryControllerConfig config) {
		m_max3_sodimms.setDDRAddressBitSwapEntity(config.getDDRAddressBitSwap());
	}

	@Override
	public void setOnCardMemoryFrequency(double freq_mhz) {
		if (freq_mhz < 300 || freq_mhz > 400)
			throw new MaxCompilerAPIError(m_data, "MAX3 memory clock frequency must be >= 300 and <= 400 MHz");
		m_memory_io_factory.setOnCardMemoryFrequency(freq_mhz == 300.0 ? 303.0 : freq_mhz);
	}

	@Override
	public WrapperClock getMemoryCoreClock() {
		return m_memory_io_factory.getMemoryCoreClock();
	}

	@Override
	public double getOnCardMemoryFrequency() {
		return m_memory_io_factory.getOnCardMemoryFrequency();
	}

	@Override
	public void setEnableHideParityBitsForStream(
		DFELink stream,
		boolean hide_parity_bits)
	{
		m_max3_sodimms.setMemoryStreamHideParityBits(_CustomManagers.streamToImp(stream), hide_parity_bits);
	}

	@Override
	public void setIFPGALinkClock(WrapperClock clock) {
		m_ifpga_factory.setIFPGAClock(clock);
	}

	@Override
	public void setMemoryStreamClock(WrapperClock clock) {
		m_memory_io_factory.setMemoryStreamClock(clock);
	}

	public void setSystemJitter(int picoseconds) {
		m_platform.setSystemJitter(picoseconds);
	}

	@Override
	public NetworkInterfacePlugin getDefaultEthernetPlugin(NetworkLinkSpeed link_speed, boolean bypass_fifo) {
		switch(link_speed)
		{
			case OneGig:
				if (bypass_fifo)
					throw new MaxCompilerAPIError(m_data, "Cannot bypass FIFO on 1Gig Ethernet.");

				return new V6OneGigEthernetPlugin();

			case TenGig:
				return new V6TenGigEthernetPlugin(bypass_fifo);

			default:
				throw new MaxCompilerAPIError(m_data, "Only 1Gig Ethernet is supported on MAX2.");
		}
	}

	@Override
	public boolean hasNetworkConnectionGotPlugin(NetworkConnection connection) {
		if(!(connection instanceof Max3NetworkConnection))
			throw new MaxCompilerAPIError(m_data,
				"Must use Max3NetworkConnection when targetting a MAX3 board");

		switch((Max3NetworkConnection)connection) {
			case CH2_SFP1:
					return m_network_sfp1_factory.getNetworkInterfacePlugin() != null;

			case CH2_SFP2:
				return m_network_sfp2_factory.getNetworkInterfacePlugin() != null;

			default:
				throw new MaxCompilerAPIError(m_data,
					"Network connection " + connection + " not supported yet on MAX3.");
		}
	}

	@Override
	public void setHostStreamClock(WrapperClock clock) {
		setIFPGALinkClock(clock);
	}

	@Override
	public DFELink addTimestampStream(String name,
									 WrapperClock clock,
									 TimestampingIOFormat format,
									 int decimal_precision) {
		return _CustomManagers.fromImp(
			m_timestamping_factory.addTimeStampStream(name, clock, format, decimal_precision));
	}

}
