#ifndef CUSTOMHDLHOSTSIMTEST_H
#define CUSTOMHDLHOSTSIMTEST_H

#include "ManagerSync.h"
#include "PullSync.h"
#include "PushSync.h"

// a random namespace
// user nodes need not be in maxcompilersim namespace
namespace project_stalingrad {

class CustomHDLHostSimTestSync :
	public maxcompilersim::ManagerBlockSync,
	public maxcompilersim::PullSinkSync,
	public maxcompilersim::PushSourceSync
{
	maxcompilersim::t_port_number m_input_port;
	maxcompilersim::t_port_number m_output_port;

	maxcompilersim::Data m_data;
	bool m_full;

	int m_test_ctor_arg;
	std::string m_test_setup_arg;

public:
	CustomHDLHostSimTestSync(const std::string &name, int n);

	void setup(const std::string &s);

	virtual bool runCycle();
	virtual void reset();

	virtual bool getSimParameter(const std::string &name, std::string &value);
};

} // namespace project_stalingrad

#endif
