package com.maxeler.maxcompiler.v2.managers.custom.blocks;

import com.maxeler.maxcompiler.v2.managers.custom.CustomManager;

public class _CustomHDLNode extends CustomHDLNode {

	/**
	 * \brief Create a CustomHDLNode with a C++ simulation model.
	 *
	 * @param manager Manager.
	 * @param name Node name.
	 * @param top_level Name of HDL top-level entity.
	 * @param sim_c_type Name of C++ class implementing the simulation model.
	 * @param ctor_args Arguments to C++ constructor, rendered using .toString().
	 */
	public _CustomHDLNode(CustomManager manager, String name, String top_level, String sim_c_type, Object... ctor_args) {
		super(manager, name, top_level, sim_c_type, ctor_args);
	}



	@Override
	public void addSimulationCppSource(String name, boolean is_on_filesystem) {
		super.addSimulationCppSource(name, is_on_filesystem);
	}

	@Override
	public void addSimulationCppHeader(String name, boolean is_on_filesystem) {
		super.addSimulationCppHeader(name, is_on_filesystem);
	}

	@Override
	public void addSimulationSetupCall(String method, Object... args) {
		super.addSimulationSetupCall(method, args);
	}
}
