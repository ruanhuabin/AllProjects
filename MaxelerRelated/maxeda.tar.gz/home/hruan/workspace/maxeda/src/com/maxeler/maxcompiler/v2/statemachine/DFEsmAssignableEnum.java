package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.types._DFEsmTypeFactory;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.expressions.AssignableEnum;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.statements.StatementAssign;
import com.maxeler.utils.MaxCompilerHide;

public class DFEsmAssignableEnum<E extends Enum<E>> extends DFEsmEnum<E> {
	private final StateMachineLib m_stateMachine;
	private final ContextMode m_context;
	private boolean m_initialized; // this is not foolproof but better than nothing (misses out on IF/ELSE partial initialisations)

	@MaxCompilerHide
	DFEsmAssignableEnum(StateMachineLib stateMachine, Class<E> enumClass, String stateID) {
		super(new AssignableEnum<E>(_DFEsmTypeFactory.dfeEnum(enumClass), stateID));
		m_stateMachine = stateMachine;
		m_context = m_stateMachine.getContextMode();
		m_initialized = false;
		if (m_context != ContextMode.NEXT_STATE && m_context != ContextMode.OUTPUT)
			throw new MaxCompilerAPIError("DFEsmAssignableEnums can only be declared inside the next_state or output-function method.");
	}

	@SuppressWarnings("unchecked")
	private AssignableEnum<E> getLocalVar() {
		return (AssignableEnum<E>) getExpression();
	}

	private void assign(Expression expr) {
		if (m_stateMachine.getContextMode() != m_context)
			throw new MaxCompilerAPIError("DFEsmAssignableEnums can only be assigned to inside the context (next-state/output function) " +
					"they are declared in.");
		if (expr.getType() != super.getExpression().getType())
			throw new MaxCompilerAPIError("Cannot assign type '%s' to assignable enum of type '%s'.", expr.getType(), getType());
		m_initialized = true;
		m_stateMachine.addStatement(new StatementAssign(getLocalVar(), expr, _StateMachine.getBuildManager(m_stateMachine)));
	}

	@Override
	Expression getExpression() {
		if (!m_initialized)
			throw new MaxCompilerAPIError("Trying to read an uninitialised DFEsmAssignableEnum.");
		if (m_stateMachine.getContextMode() != ContextMode.CODEGEN && m_stateMachine.getContextMode() != m_context)
			throw new MaxCompilerAPIError("DFEsmAssignableEnums can only be read inside the context (next-state/output function) " +
					"they are declared in. " + m_stateMachine.getContextMode());
		return super.getExpression();
	}


	public void connect(E value) {
		assign(new Constant(value));
	}

	public void connect(DFEsmExpr expr) {
		assign(expr.getExpression());
	}
}
