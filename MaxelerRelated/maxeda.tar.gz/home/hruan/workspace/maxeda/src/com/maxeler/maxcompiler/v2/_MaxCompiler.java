package com.maxeler.maxcompiler.v2;

import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.BuildManager.PrevBuildData;

public class _MaxCompiler {
	public static void rerunCompileNow(BuildManager bm, PrevBuildData data) {
		MaxCompiler.rerunCompileNow(bm, data);
	}

	public static PrevBuildData getAndClearPreviousRunData() {
		return MaxCompiler.getAndClearPreviousRunData();
	}

	public static void setAssociatedBuildManager(BuildManager bm) {
		MaxCompiler.setAssociatedBuildManager(bm);
	}

	public static boolean isUsingMaxCompilerRunner() {
		return MaxCompiler.isUsingMaxCompilerRunner();
	}
}
