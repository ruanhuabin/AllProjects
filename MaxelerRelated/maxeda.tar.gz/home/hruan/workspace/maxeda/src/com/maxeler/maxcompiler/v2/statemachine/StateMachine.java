package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.statemachine.StateMachineInfo;
import com.maxeler.utils.MaxCompilerHide;


public abstract class StateMachine extends StateMachineLib {
	/**
	 * @exclude
	 * Use the ExcludeDoclet to exclude this constructor from the Java Doc.
	 */
	@MaxCompilerHide
	protected StateMachine(BuildManager manager) {
		super(new StateMachineInfo(), manager);
	}

	/**
	 * @exclude
	 * Use the ExcludeDoclet to exclude this constructor from the Java Doc.
	 */
	@MaxCompilerHide
	protected StateMachine(DFEManager manager) {
		super(new StateMachineInfo(), manager);
	}

	protected abstract void nextState();

	protected abstract void outputFunction();
}
