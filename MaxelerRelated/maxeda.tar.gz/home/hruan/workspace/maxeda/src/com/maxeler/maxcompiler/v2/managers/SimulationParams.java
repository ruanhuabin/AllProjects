package com.maxeler.maxcompiler.v2.managers;

import com.maxeler.photon.compile_managers.HDLSimCompileManager;
import com.maxeler.photon.compile_managers.JavaSimCompileManager;
import com.maxeler.photon.compile_managers.SoftwareSimCompileManager;
import com.maxeler.photon.maxcompilersim.formatterBitAccurate.FormatterBitAccurate;

public class SimulationParams {
	public static final SimulationParams HDLSIM =
		new SimulationParams(new HDLSimCompileManager.Factory());

	public static final SimulationParams BITACCURATE =
		new SimulationParams(new SoftwareSimCompileManager.Factory(new FormatterBitAccurate.Factory()));

	final JavaSimCompileManager.Factory m_compile_manager_factory;

	<T extends JavaSimCompileManager>
		SimulationParams(JavaSimCompileManager.Factory compile_manager_factory)
	{
		m_compile_manager_factory = compile_manager_factory;
	}

	@Override
	public String toString() {
		return m_compile_manager_factory.toString();
	}
}
