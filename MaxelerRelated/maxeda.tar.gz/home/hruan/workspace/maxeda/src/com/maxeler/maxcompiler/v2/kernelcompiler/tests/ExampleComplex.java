package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplexType;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.standard.Manager;

public class ExampleComplex extends Kernel {
	private static final DFEComplexType cplx_type =
		new DFEComplexType(dfeFloat(8,24), dfeInt(32));

	public ExampleComplex(KernelParameters parameters) {
		super(parameters);

		flush.whenInputFinished("cplx_in1");

		DFEComplex cplx_in1 = io.input("cplx_in1", cplx_type);
		DFEComplex cplx_in2 = io.input("cplx_in2", cplx_type);
		DFEComplex cplx_out = io.output("cplx_out", cplx_type);

		cplx_out.connect( (cplx_in1 + cplx_in2).watch("sum") * 3 + constant.cplx(1, 1));
	}

	public static void main(String[] args) {
		Manager manager =
			new Manager(new _EngineParameters("ExampleHostCodeComplex", MAX2BoardModel.MAX24412C, EngineParameters.Target.MAXFILE_FOR_SIMULATION));

		KernelParameters parameters =
			manager.makeKernelParameters();

		manager.setKernel( new ExampleComplex(parameters) );

		manager.setIO(Manager.IOType.ALL_CPU);

		manager.build();
	}
}
