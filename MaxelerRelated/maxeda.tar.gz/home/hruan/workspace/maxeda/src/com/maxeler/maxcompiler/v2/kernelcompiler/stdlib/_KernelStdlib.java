package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;

public class _KernelStdlib {
	public static Reductions newReductions(Kernel design) {
		return new Reductions(design);
	}

	public static Bitops newBitops(Kernel design) {
		return new Bitops(design);
	}
}
