package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

import java.util.Set;

import com.maxeler.maxeleros.managercompiler.core.WrapperClock;

public class _ManagerStdlib {
	public static String getMemoryControlGroupType(MemoryControlGroup group) {
		return group.getType();
	}

	public static String getMemoryControlGroupRegName(MemoryControlGroup group) {
		return group.getRegName();
	}

	public static String getMemoryControlGroupName(MemoryControlGroup group) {
		return group.getName();
	}

	public static String getMemoryControlGroupControllerName(MemoryControlGroup group) {
		return group.getControllerName();
	}

	public static Set<String> getMemoryControlGroupStreams(MemoryControlGroup group) {
		return group.getStreams();
	}

	public static void setMemoryControlGroupCommandStreamClock(MemoryControlGroup mcg, WrapperClock clock) {
		mcg.setCommandStreamClock(clock);
	}

	public static boolean isStreamSource(MemoryControlGroup mcg) {
		return mcg.isStreamSource();
	}
}
