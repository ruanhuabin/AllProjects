package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;
import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.memory.MemoryElement;
import com.maxeler.statemachine.memory.ROM;

/**
 * @see DFEsmDualPortROM
 */
public final class DFEsmSinglePortROM extends DFEsmROM {
	public final DFEsmMemAddress address;
	public final DFEsmValue dataOut;

	DFEsmSinglePortROM(StateMachineLib stateMachine, Latency latency, DFEsmValueType type, int romID, List<BigInteger> values) {
		super(1, latency, type, romID, values);

		ROM rom = getROM();

		MemoryElement.Port port0 = rom.getPort(0);
		address = new DFEsmMemAddress(stateMachine, port0.address);
		dataOut = new DFEsmValue(port0.dataOut);
	}
}
