package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.memory.MemoryElement;

public abstract class DFEsmMem {
	final MemoryElement m_mem;

	DFEsmMem(MemoryElement mem) {
		m_mem = mem;
	}

	public final int getNumPorts() { return m_mem.getNumPorts(); }
	public final int getDepth() { return m_mem.getDepth(); }
	public final int getAddressWidth() { return m_mem.getAddressWidth(); }
	public final int getLatency() { return m_mem.getLatency(); }
	public final DFEsmValueType getType() { return m_mem.getType(); }
}
