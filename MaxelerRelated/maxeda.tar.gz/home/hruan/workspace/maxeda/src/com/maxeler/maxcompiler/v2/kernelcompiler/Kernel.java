package com.maxeler.maxcompiler.v2.kernelcompiler;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Bitops;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Reductions;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib._KernelStdlib;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Count;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core._KernelCore;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Count.Counter;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.photon.compile_managers.SoftwareSimCompileManager;
import com.maxeler.photon.core.PhotonCompileManager;
import com.maxeler.photon.core.PhotonDesignData;

/**
 * A Kernel implementation inherits from the {@code Kernel} class.
 * <p>
 * All Kernel designs have exactly one associated Kernel object.
 * <p>
 * See the
 * <a href="{@docRoot}/../maxcompiler-tutorial.pdf#destination.gettingstarted">MaxCompiler Tutorial getting started section</a> for more
 * details on the basics of Kernels.
 */
public class Kernel extends KernelLib {
	private final List<KernelFinalizer> m_kernel_finalizers =
		new ArrayList<KernelFinalizer>();

	private final Stack<Boolean> m_debug_native_simulation_math = new Stack<Boolean>();

	public final Flush flush;

	private final Reductions m_reductions;
	private final Bitops m_bitops;

	protected Kernel(KernelParameters parameters) {
		super(parameters.getManager(), parameters.getName(), parameters.getKernelConfiguration());

		parameters.use();

		flush = new Flush(this);
		m_reductions = _KernelStdlib.newReductions(this);
		m_bitops = _KernelStdlib.newBitops(this);

		m_debug_native_simulation_math.push(false);
	}

	/**
	 * Returns the name given to this Kernel in its constructor.
	 */
	public String getName() {
		return m_design_data.getName();
	}

	/**
	 * Add a {@link KernelFinalizer} object to this Kernel.
	 * <p>
	 * The {@link KernelFinalizer#finalizeKernel(Kernel)} method on {@code kernel_finalizer}
	 * will be called when the construction of the graph in the Kernel is complete.
	 * @param kernel_finalizer The {@link KernelFinalizer} object to add.
	 */
	public void addKernelFinalizer(KernelFinalizer kernel_finalizer) {
		m_kernel_finalizers.add(kernel_finalizer);
	}

	/** Makes a global 48bit counter that continually increases. */
	private DFEVar makeCycleCounter() {
		Count.Params params = control.count.makeParams(48);
		Counter c = control.count.makeCounter(params);

		DFEVar current_cycle_count = c.getCount();

		io.scalarOutput(
			"current_run_cycle_count",
			current_cycle_count.getType()).connect(current_cycle_count);

		return current_cycle_count;
	}

	PhotonCompileManager prepareForBuild() {
		PhotonDesignData     design_data     = _Kernel.getPhotonDesignData(getKernel());
		PhotonCompileManager compile_manager = design_data.getCompileManager();

		if(compile_manager.isPreparedForBuild())
			throw new MaxCompilerInternalError(getManager(), "Prepared Kernel for build twice.");

		design_data.pushNodeVisible(false);

		// !!! do not use iterators as finalizers may create additional
		// finalizers when they run !!!
		for (int i = 0; i < m_kernel_finalizers.size(); ++i)
			m_kernel_finalizers.get(i).finalizeKernel(this);

		flush.setupPhotonFlush(makeCycleCounter());
		_KernelCore.applyIOConstraints(io);

		compile_manager.setPreparedForbuild();

		design_data.popNodeVisible();

		return compile_manager;
	}

	Reductions getGlobalReductionInst() {
		return m_reductions;
	}

	Bitops getGlobalBitopsInst() {
		return m_bitops;
	}

	void pushDebugEnableNativeSimulationMath(boolean use_native) {
		boolean isSoftwareSim = m_design_data.getCompileManager() instanceof SoftwareSimCompileManager;

		if (use_native && !isSoftwareSim)
			throw new MaxCompilerAPIError(getManager(),
				"Native simulation math can only be enabled while compiling for software simulation.");

		m_debug_native_simulation_math.push(use_native);
	}

	boolean popDebugEnableNativeSimulationMath() {
		if (m_debug_native_simulation_math.size() <= 1)
			throw new MaxCompilerAPIError(getManager(),
				"Tried to pop the last value for native simulation math of the configuration stack.");

		return m_debug_native_simulation_math.pop();
	}

	boolean peekDebugEnableNativeSimulationMath() {
		return m_debug_native_simulation_math.peek();
	}

	/**
	 * Returns the name of this Kernel.
	 */
	@Override
	public String toString() { return getName(); }
}
