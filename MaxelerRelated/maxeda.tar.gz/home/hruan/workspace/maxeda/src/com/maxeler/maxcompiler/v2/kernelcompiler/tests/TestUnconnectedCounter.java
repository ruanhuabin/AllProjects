package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;

public class TestUnconnectedCounter extends Kernel {

	protected TestUnconnectedCounter(KernelParameters parameters) {
		super(parameters);

		DFEVar i = io.input("i", dfeBool());
		DFEVar o = io.output("o", dfeBool());

		o.connect(i);

		control.count.simpleCounter(10);

	}

	public static void main(String[] args) {
		SimulationManager m = new SimulationManager("TUCC");

		m.setKernel( new TestUnconnectedCounter(m.makeKernelParameters()) );

		m.setInputData("i", 0);
		m.runTest();
	}

}
