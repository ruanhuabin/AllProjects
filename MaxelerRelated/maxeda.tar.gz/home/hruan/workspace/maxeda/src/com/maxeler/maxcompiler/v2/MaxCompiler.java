package com.maxeler.maxcompiler.v2;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.BuildManager.PrevBuildData;

import edu.umd.cs.findbugs.annotations.SuppressWarnings;

public class MaxCompiler {
	private static class RestartCompile extends RuntimeException {
		private static final long serialVersionUID = 1L;
	}

	// If any of the following need to be statically initialised, do
	// this in reset(). This way when run() exits it can restore the
	// static methods to their initial states.
	private static boolean s_is_maxcompiler_runner_active;
	private static BuildManager s_associated_build_manager;
	private static PrevBuildData s_previous_run_data;
	static {
		reset();
	}

	private static void reset() {
		s_is_maxcompiler_runner_active = false;
		s_associated_build_manager = null;
		s_previous_run_data = null;
	}

	static void rerunCompileNow(BuildManager bm, PrevBuildData data) {
		if(bm != s_associated_build_manager)
			throw new MaxCompilerInternalError(
				"Tried to restart compilation from another BuildManager context.");

		s_previous_run_data = data;

		throw new RestartCompile();
	}

	static PrevBuildData getAndClearPreviousRunData() {
		PrevBuildData o = s_previous_run_data;
		s_previous_run_data = null;

		return o;
	}

	public static void clearAssociatedBuildManager() {
		setAssociatedBuildManager(null);
	}

	static void setAssociatedBuildManager(BuildManager bm) {
		if(s_associated_build_manager == null || bm == null)
			s_associated_build_manager = bm;
		else
			if(s_associated_build_manager != bm)
				throw new MaxCompilerAPIError(
					"Tried to create more than one Manager while using MaxCompiler.run(). " +
					"If you're absoultely sure all work associated with the first Manager is " +
					"fully completed and this is really what you intended, call " +
					"MaxCompiler.clearAssociatedBuildManager() immedaiately before creating your " +
					"second Manager.");
	}

	static boolean isUsingMaxCompilerRunner() {
		return s_is_maxcompiler_runner_active;
	}

	private static void standardReflectionError(Class<?> main_class, Exception e) {
		throw new MaxCompilerAPIError(
			"Error calling main method on " + main_class.getSimpleName() +
			": " + e.getMessage());
	}

	@SuppressWarnings("DM_GC")
	public static void run(Class<?> main_class, String[] args) {
		synchronized(MaxCompiler.class) {
			if(s_is_maxcompiler_runner_active)
				throw new MaxCompilerAPIError(
					"Cannot call MaxCompiler.run() multiple times in parallel.");

			s_is_maxcompiler_runner_active = true;
		}

		try {
			boolean re_run_compile;
			do {
				re_run_compile = false;
				try {
					String[] args_copy = new String[args.length];
					System.arraycopy(args, 0, args_copy, 0, args.length);
					Method main_method;
					main_method = main_class.getMethod("maxMain", String[].class);
					main_method.invoke(null, (Object)args_copy);
				} catch(InvocationTargetException e) {
					if(e.getTargetException() instanceof RestartCompile) {
						// We null the associated build manager here and below
						// rather than in a finally to try and make sure the GC
						// covers as much as possible.
						s_associated_build_manager = null;
						System.gc();
						re_run_compile = true;

					} else if(e.getTargetException() instanceof RuntimeException) {
						throw (RuntimeException)(e.getTargetException());

					} else {
							throw new RuntimeException(e.getTargetException());
					}
				}
				s_associated_build_manager = null;
			} while(re_run_compile);
		} catch (SecurityException e) {
			standardReflectionError(main_class, e);
		} catch (NoSuchMethodException e) {
			standardReflectionError(main_class, e);
		} catch (IllegalArgumentException e) {
			standardReflectionError(main_class, e);
		} catch (IllegalAccessException e) {
			standardReflectionError(main_class, e);
		} finally {
			reset();
		}
	}
}
