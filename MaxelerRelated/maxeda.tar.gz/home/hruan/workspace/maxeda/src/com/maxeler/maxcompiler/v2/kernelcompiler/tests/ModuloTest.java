package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxConstantEncodingException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager.DualSimMode;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.maxcompiler.v2.utils.MathUtils;

public class ModuloTest extends Kernel {

	private static long s_seed;
	private static Random s_random;

	private static void resetRandom() {
		s_seed = System.currentTimeMillis();
		s_random = new Random(s_seed);
	}

	protected ModuloTest(KernelParameters parameters, DFEType inputType, int base) {
		super(parameters);
		DFEVar input = io.input("input", inputType);
		DFEVar modulo = KernelMath.modulo(input, base);
		io.output("output", base == 1 ? dfeUInt(1) : dfeUInt(MathUtils.bitsToAddress(base))).connect(modulo);
	}

	protected ModuloTest(KernelParameters parameters, DFEVectorType<DFEVar> inputType, int base) {
		super(parameters);
		DFEVector<DFEVar> input = io.input("input", inputType);
		DFEVector<DFEVar> modulo = KernelMath.modulo(input, base);
		DFEVectorType<DFEVar> retType = new DFEVectorType<DFEVar>(base == 1 ? dfeUInt(1) : dfeUInt(MathUtils.bitsToAddress(base)), inputType.getNElements());
		io.output("output", retType).connect(modulo);
	}

	private static void runTest(DFEType inType, int base, int size) {
		String name = inType.toString().replaceAll("[^\\w]+", "_").replaceAll("_+{2,}", "_").replaceAll("^_+", "").replaceAll("_+$", "") +
						"_base" + base + "_size" + size;
		name = name.replaceAll("-", "minus");

		_DualSimulationManager mgr = new _DualSimulationManager("ModuloTest_" + name, DualSimMode.SEQUENTIAL);
		ModuloTest kernelA = new ModuloTest(mgr.makeKernelParameters_A(), inType, base);
		ModuloTest kernelB = new ModuloTest(mgr.makeKernelParameters_B(), inType, base);
		mgr.setKernels(kernelA, kernelB);

		resetRandom();
		mgr.logMsg("Using seed " + s_seed);

		double input[] = new double[size];
		double expected[] = new double[size];
		for(int i = 0; i < size; i++) {
			int rnd = s_random.nextInt();
			rnd = (rnd == Integer.MIN_VALUE ? 42 : rnd);
			int tocode = Math.abs(rnd);
			Bits coded;
			try {
				coded = inType.encodeConstant(tocode);
			}
			catch (MaxConstantEncodingException e) {
				coded = e.getPackedValue();
			}
			input[i] = inType.decodeConstant(coded);
			expected[i] = input[i] % base;
			if(expected[i] < 0)
				expected[i] += base;
		}
		System.out.println("input: " + Arrays.toString(input));
		System.out.println("expected: " + Arrays.toString(expected));
		mgr.setInputData("input", input);
		mgr.setKernelCycles(input.length);
		mgr.runTest();
		mgr.dumpOutput();
		mgr.checkOutputData("output", expected);

		System.out.println("Test " + name + " PASSED. You are a really useful engine.");
	}

	@SuppressWarnings("unchecked")
	private static void runTest(DFEVectorType<DFEVar> inType, int base, int size) {
		String name = inType.toString().replaceAll("[^\\w]+", "_").replaceAll(
			"_+{2,}", "_").replaceAll("^_+", "").replaceAll("_+$", "")
			+ "_base" + base + "_size" + size;
		name = name.replaceAll("-", "minus");

		DFEType containedType = (DFEType)inType.getContainedType();
		int numPipes = inType.getNElements();

		_DualSimulationManager mgr = new _DualSimulationManager("ModuloTest_" + name, DualSimMode.SEQUENTIAL);
		ModuloTest kernelA = new ModuloTest(mgr.makeKernelParameters_A(), inType, base);
		ModuloTest kernelB = new ModuloTest(mgr.makeKernelParameters_B(), inType, base);
		mgr.setKernels(kernelA, kernelB);

		resetRandom();
		mgr.logMsg("Using seed " + s_seed);

		double input[][] = new double[size][numPipes];
		List<Bits> inputBits = new ArrayList<Bits>(size);
		double expected[][] = new double[size][numPipes];
		for (int i = 0; i < size; i++) {
			for(int j = 0; j < numPipes; j++) {
				int rnd = s_random.nextInt();
				rnd = (rnd == Integer.MIN_VALUE ? 42 : rnd);
				int tocode = Math.abs(rnd);
				Bits coded;
				try {
					coded = containedType.encodeConstant(tocode);
				}
				catch (MaxConstantEncodingException e) {
					coded = e.getPackedValue();
				}
				input[i][j] = containedType.decodeConstant(coded);
				expected[i][j] = input[i][j] % base;
				if(expected[i][j] < 0)
					expected[i][j] += base;
			}
			Bits bits;
			try {
				bits = inType.encodeConstant(input[i]);
			}
			catch (MaxConstantEncodingException e) {
				bits = e.getPackedValue();
			}
			inputBits.add(bits);
		}
		System.out.println("input: " + Arrays.toString(input));
		System.out.println("expected: " + Arrays.toString(expected));
		mgr.setInputDataRaw("input", inputBits);
		mgr.setKernelCycles(input.length);
		mgr.runTest();
		mgr.dumpOutput();

		List<Bits> outputRaw = mgr.getOutputDataRaw("output");
		DFEVectorType<DFEVar> outputType = new DFEVectorType<DFEVar>(base == 1 ? dfeUInt(1) : dfeUInt(MathUtils.bitsToAddress(base)), numPipes);
		for (int i = 0; i < size; i++) {
			List<Double> output = outputType.decodeConstant(outputRaw.get(i));
			for(int j = 0; j < numPipes; j++) {
				if(output.get(j) != expected[i][j]) {
					throw new RuntimeException(
						"Error at index " + i + " pipe " + j + ": Expected " + expected[i][j] +
						" but got " + output.get(j));
				}
			}
		}

		System.out.println("Test " + name + " PASSED. You are a really useful engine.");
	}

	private static void runExceptionTest(DFEType inType, int base, int size) {
		try {
			runTest(inType, base, size);
		} catch(MaxCompilerAPIError e) {
			System.out.println("Caught: " + e.toString());
			System.out.println("TEST PASSED. Have a cookie!");
			return;
		}
		throw new RuntimeException("Expected MaxCompilerAPIError but got None!");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// test good kernels
		runTest(Kernel.dfeUInt(11), 1, 16);
		runTest(Kernel.dfeUInt(16), 3, 16);
		runTest(Kernel.dfeInt(16), 3, 16);

		runTest(Kernel.dfeUInt(19), 7, 16);
		runTest(Kernel.dfeInt(19), 7, 16);

		runTest(Kernel.dfeUInt(16), 17, 16);
		runTest(Kernel.dfeInt(16), 17, 16);

		runTest(Kernel.dfeUInt(32), 2357, 16);
		runTest(Kernel.dfeInt(32), 2357, 16);

		runTest(Kernel.dfeUInt(48), 32, 16);
		runTest(Kernel.dfeInt(48), 32, 16);

		// test exceptions
		runExceptionTest(dfeUInt(32), -17, 1);
		runExceptionTest(dfeInt(32), 0, 1);
		runExceptionTest(dfeUInt(5), 1234566, 1);
		runExceptionTest(dfeFloat(11, 53), 5, 1);

		// test multi-pipes
		runTest(new DFEVectorType<DFEVar>(Kernel.dfeUInt(9), 4), 1, 4);
		runTest(new DFEVectorType<DFEVar>(Kernel.dfeUInt(9), 4), 3, 4);
		runTest(new DFEVectorType<DFEVar>(Kernel.dfeUInt(16), 4), 64, 4);
		runTest(new DFEVectorType<DFEVar>(Kernel.dfeUInt(32), 4), 67499, 4);

		System.out.println("All tests PASSED. Well done compiler team!");
	}
}
