package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.Mem.DualPortRAMMode;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmTypeFactory;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.ASTContext.ContextMode;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.MemoryDataOut;
import com.maxeler.statemachine.expressions.MemoryWriteEnable;
import com.maxeler.statemachine.memory.RAM;

public abstract class DFEsmRAM extends DFEsmMem{
	// Helper: RAM input is a DFEsmVariable
	static abstract class RamInput extends DFEsmVariable {
		protected final StateMachineLib m_stateMachine;

		public RamInput(StateMachineLib stateMachine) {
			m_stateMachine = stateMachine;
		}

		@Override
		public <E extends Enum<E>> void connect(E value) {
			throw new MaxCompilerAPIError("Cannot use an enum as memory data.");
		}

		@Override
		public void connect(boolean value) { connect(value ? 1 : 0); }

		@Override
		public void connect(long value) {
			Utils.checkIsAllowedLiteralValue(value, getType());
			connect(BigInteger.valueOf(value));
		}

		@Override
		public void connect(BigInteger value) { assign(new Constant(value)); }

		@Override
		public void connect(DFEsmExpr expr) { assign(expr.getExpression()); }

		protected abstract void assign(Expression expr);
		protected abstract DFEsmValueType getType();

		protected void checkContextValid() {
			if (m_stateMachine.getContextMode() != ContextMode.NEXT_STATE)
				throw new MaxCompilerAPIError("Memory dataIn can only be accessed inside the 'nextState' method.");
		}
	}
	// Helper: RAM write-enable signal needs to extend DFEsmVariable
	static abstract class WriteEnableAssigner extends DFEsmVariable {
		protected final StateMachineLib m_stateMachine;
		protected final MemoryWriteEnable m_writeEnable;

		public WriteEnableAssigner(StateMachineLib stateMachine, MemoryWriteEnable writeEnable) {
			m_stateMachine = stateMachine;
			m_writeEnable = writeEnable;
		}

		@Override
		public <E extends Enum<E>> void connect(E value) {
			throw new MaxCompilerAPIError("Cannot use an enum as write enable signal.");
		}

		@Override
		public void connect(boolean value) { connect(value ? 1 : 0); }

		@Override
		public void connect(long value) {
			Utils.checkIsAllowedLiteralValue(value, getType());
			connect(BigInteger.valueOf(value));
		}

		@Override
		public void connect(BigInteger value) { assign(new Constant(value)); }

		private static DFEsmValueType getType() { return DFEsmTypeFactory.dfeBool(); }

		@Override
		public void connect(DFEsmExpr expr) { assign(expr.getExpression()); }

		protected abstract void assign(Expression expr);

		protected void checkContextValid() {
			if (m_stateMachine.getContextMode() != ContextMode.NEXT_STATE)
				throw new MaxCompilerAPIError("Memory writeEnable can only be accessed inside the 'nextState' method.");
		}
	}

	static class WriteEnableValue extends DFEsmValue {
		public WriteEnableValue(MemoryWriteEnable expr) {
			super (expr);
		}
	}

	// RAM output is a DFEsmValue
	static class RamValue extends DFEsmValue {
		public RamValue(MemoryDataOut expr)
		{
			super(expr);
		}
	}


	DFEsmRAM(int numPorts, Latency latency, DFEsmValueType type, DualPortRAMMode portMode0, DualPortRAMMode portMode1, int ramID, int depth) {
		super(new RAM(numPorts, latency.getCycles(), type, portMode0, portMode1, ramID, depth));
	}

	RAM getRAM() { return (RAM)m_mem; }

	@Override
	public String toString() { return "ram(" + getNumPorts() + ", " + getType() + ", " + getDepth() + ")"; }
}
