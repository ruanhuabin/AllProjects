package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM.RamInput;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM.RamValue;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmRAM.WriteEnableAssigner;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.Mem.DualPortRAMMode;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmEnumType;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmTypeFactory;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmUntypedConst;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.ExprUtils;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.MemoryDataIn;
import com.maxeler.statemachine.expressions.MemoryDataOut;
import com.maxeler.statemachine.expressions.MemoryWriteEnable;
import com.maxeler.statemachine.memory.MappedRAM;
import com.maxeler.statemachine.memory.MemoryElement;
import com.maxeler.statemachine.statements.StatementAssign;

public class DFEsmSinglePortMappedRAM extends DFEsmMappedRAM {

	private final class SinglePortRamDataAssigner extends RamInput {
		private SinglePortRamDataAssigner(StateMachineLib s) { super(s); }

		@Override
		protected void assign(Expression expr) {
			checkContextValid();

			if (m_port_mode == DualPortRAMMode.READ_ONLY)
				throw new MaxCompilerAPIError("Cannot assign data to a read-only port.");

			expr = ExprUtils.implicitCast(dataOut.getType(), "RAM data", expr);
			m_stateMachine.addStatement(new StatementAssign(getDataOut(), expr, _StateMachine.getBuildManager(m_stateMachine)));
		}

		@Override
		protected DFEsmExpr getDFEsmExpr() {
			checkContextValid();

			return _StateMachine.Create.DFEsmExpr(getDataIn());
		}

		@Override
		protected DFEsmValueType getType() {
			return dataOut.getType();
		}
	}

	private final class SinglePortRamWriteEnableAssigner extends WriteEnableAssigner {
		private SinglePortRamWriteEnableAssigner(
			StateMachineLib s,
			MemoryWriteEnable writeEnable
		) {
			super (s, writeEnable);
		}

		@Override
		protected void assign(Expression expr) {
			checkContextValid();

			if (m_port_mode == DualPortRAMMode.READ_ONLY)
				throw new MaxCompilerAPIError("Cannot assign data to a read-only port.");

			if (expr.getType() instanceof DFEsmEnumType)
				throw new MaxCompilerAPIError("Cannot assign enums to the write enable port.");
			if ((expr.getType() instanceof DFEsmValueType) && ( !((DFEsmValueType)expr.getType()).isBool() ))
				throw new MaxCompilerAPIError("Cannot assign non-boolean integer value to write enable port.");
			if (expr.getType() instanceof DFEsmUntypedConst)
				expr = ExprUtils.implicitCast(DFEsmTypeFactory.dfeBool(), "Write Enable", expr);
			m_stateMachine.addStatement(new StatementAssign(m_writeEnable,  expr, _StateMachine.getBuildManager(m_stateMachine)));
		}

		@Override
		protected DFEsmExpr getDFEsmExpr() {
			checkContextValid();

			return _StateMachine.Create.DFEsmExpr(m_writeEnable);
		}
	}

	private final DualPortRAMMode m_port_mode;

	private final MemoryDataIn dataInExpr;

	public final DFEsmMemAddress address;
	public final DFEsmVariable writeEnable;
	public final DFEsmValue dataOut;
	public final DFEsmVariable dataIn;

	DFEsmSinglePortMappedRAM(String name, StateMachineLib stateMachine, Latency latency, DFEsmValueType type,
		DualPortRAMMode portMode, int ram_id, int depth) {
		super(1, name, latency, type, portMode, null, depth);

		MappedRAM ram = getMappedRAM();

		m_port_mode = portMode;
		dataIn = new SinglePortRamDataAssigner(stateMachine);
		MemoryElement.Port port0 = ram.getPort(0);
		address = new DFEsmMemAddress(stateMachine, port0.address);
		dataInExpr = port0.dataIn;
		dataOut = new RamValue(port0.dataOut);
		writeEnable = new SinglePortRamWriteEnableAssigner(stateMachine, port0.write_enable);
	}

	private MemoryDataIn getDataIn() { return dataInExpr; }
	private MemoryDataOut getDataOut() { return (MemoryDataOut) dataOut.getExpression(); }
}
