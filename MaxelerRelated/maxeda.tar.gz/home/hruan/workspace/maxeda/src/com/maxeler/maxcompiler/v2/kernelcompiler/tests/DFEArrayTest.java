package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArrayType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStructType;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;

/**
 * Test class to exercise as much as possible of the DFEArray class; refer to nightly tests' EMMA output for coverage statistics.
 *
 * @author kate
 */
public class DFEArrayTest extends Kernel {

	private static Random m_random = null;
	private static long   m_seed;

	private static final int m_arr_size = 2;
	private static final DFEFloat floatType = dfeFloat( 11, 53 );
	private static final DFEFix fixType = dfeFix(32, 32, SignMode.TWOSCOMPLEMENT);
	private static final DFEStructType complexType = new DFEStructType( DFEStructType.sft("real",floatType), DFEStructType.sft("imag",floatType) );
	private static final DFEArrayType<DFEVar> floatArrayType = new DFEArrayType<DFEVar>(floatType, m_arr_size);
	private static final DFEArrayType<DFEVar> fixArrayType = new DFEArrayType<DFEVar>(fixType, m_arr_size);

	public DFEArrayTest( KernelParameters parameters ) {
		super( parameters );
		DFEArray<DFEVar> arrA = io.input( "a", floatArrayType );
		DFEArray<DFEVar> arrB = io.input( "b", floatArrayType );
		flush.whenInputFinished("b");
		DFEVar ar = arrA.get(0);
		DFEVar ai = arrA.get(1);

		if ( arrA.getSize() != m_arr_size )
			throw new RuntimeException( "DFEArray.getSize() result differs from m_arr_size." );
		arrA.getKernel().logMsg( "watching arrA, size = " + arrA.getSize() );
		arrA.watch( "arrA" );

		//----- casting to non-DFEArray types not supported for DFEArray type
		try {
			DFEStruct cplx = (DFEStruct) arrA.cast( complexType );
			cplx.setReportOnUnused( false );
		} catch (MaxCompilerAPIError e) {
			logMsg( "***** successfully caught DFEArray.cast exception for arrA<" + arrA.getType() + ">.cast( <" + complexType + "> ) : " + e );
		}

		//----- casting between DFEArray types
		DFEArray<DFEVar> arrCast = arrA.cast( fixArrayType );
		io.output("arrCast", fixArrayType ).connect(arrCast);

		//----- create an array of non-concrete type
		DFEArrayType<DFEVar> newArrayType = new DFEArrayType<DFEVar>( DFETypeFactory.dfeUntypedConst(), m_arr_size );
		DFEArray<DFEVar> arr_non_concrete = newArrayType.newInstance(this);
		try {
			DFEVar packD = arr_non_concrete.pack();
			packD.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "***** successfully caught DFEArray.pack() exception for " + newArrayType + " : " + e );
		}

		//----- create an empty array
		try {
			DFEArrayType<DFEVar> zeroArrayType = new DFEArrayType<DFEVar>( DFETypeFactory.dfeUntypedConst(), 0 );
			DFEArray<DFEVar>     arr_empty     = zeroArrayType.newInstance(this);
			arr_empty.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "***** successfully caught empty DFEArray exception for " + newArrayType + " : " + e );
		}

		//----- exercise various DFEArray members...
		List<DFEVar> aList = arrA.elementsAsList();
		DFEVar[]     aElem = arrA.elementsAsArray();
		DFEArray<DFEVar>  a2 = io.output( "a2", floatArrayType );
		a2.setReportOnUnused( false );
		for ( int i = 0 ; i < aList.size() ; i++ ) {
			a2.connect( i, (aElem[i] + aList.get(i)) );
		}

		DFEArray<DFEVar> aListArr = DFEArrayType.newInstance( aList );
		DFEArray<DFEVar> aElemArr = DFEArrayType.newInstance( aElem );
		aListArr.setReportOnUnused(false);
		aElemArr.setReportOnUnused(false);

		try {
			DFEArray<DFEVar> aListEmpty = DFEArrayType.newInstance( new ArrayList<DFEVar>() );
			aListEmpty.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "***** successfully caught exception for empty DFEArrayType.newInstance( List<T> ) : " + e );
		}

		try {
			DFEArray<DFEVar> aElemEmpty = DFEArrayType.newInstance( new DFEVar[0] );
			aElemEmpty.setReportOnUnused(false);
		} catch (MaxCompilerAPIError e) {
			logMsg( "***** successfully caught exception for empty DFEArrayType.newInstance( <T>[] ) : " + e );
		}

		//----- spring an AlreadyConnected exception
		try {
			a2.connect( arrB );
		} catch (MaxCompilerAPIError e) {
			logMsg( "***** successfully caught DFEArray.connect() exception : " + e );
		}

		DFEArray<DFEVar> x = floatArrayType.newInstance(this);
		x[0].connect( ar );
		x[1].connect( ai );
		io.output("x", floatArrayType ).connect( x );
		io.output("y", floatArrayType ).connect( arrB );

		//----- exercise various DFEArrayType members...
		arrA.getKernel().logMsg( "arrA type size = " + arrA.getType().getSize() +
			                     ", total bits = " + arrA.getType().getTotalBits() +
		                         ", contained type = " + arrA.getType().getContainedType() +
		                         ", hashCode = " + arrA.getType().hashCode() );
		logMsg( "(floatArrayType == newArrayType  ) = " + floatArrayType.equals(newArrayType  ) );
		logMsg( "(floatArrayType == floatArrayType) = " + floatArrayType.equals(floatArrayType) );

		//----- DFEArray-related methods in Constant...
		DFEArray<DFEVar> const_d = constant.array( 1, 2, 3, 4 );
		DFEArray<DFEVar> const_b = constant.array( true, false, false, true );
		DFEArray<DFEVar> const_f = constant.array( floatType, 1, 2, 3, 4 );
		const_d.watch( "const_d" );
		const_b.watch( "const_b" );
		const_f.watch( "const_f" );
	}


	/**
	 * This is run by the nightly tests.
	 * @param args - not used.
	 */
	public static void main(String[] args) {
		String name = "DFEArrayTest";
		runTest1( name );
		System.out.println( "     ***** Reached here, so everything passed! *****" );
		System.exit(0);
	}

	private static int runTest1( String main_name ) {
		String                 name        = main_name + "_1";
		_DualSimulationManager manager     = new _DualSimulationManager(name);
		KernelParameters       parametersA = manager.makeKernelParameters_A();
		KernelParameters       parametersB = manager.makeKernelParameters_B();
		manager.setKernels( new DFEArrayTest(parametersA), new DFEArrayTest(parametersB) );
		checkRandomSet();
		manager.logMsg( "=====  Using Random seed = " + m_seed  + "  =====" );

		int len = 7;
		double[] inA = initToRandom( len*m_arr_size );
		double[] inB = initToRandom( len*m_arr_size );
		for ( int i = 0 ; i < len*m_arr_size ; i++ )
			System.out.println( "input data    inA[" + i + "] = " + inA[i] + " \t   inB[" + i + "] = " + inB[i] );
		manager.setInputDataRaw( "a", SimulationManager.packToBits(floatType, m_arr_size, inA) );
		manager.setInputDataRaw( "b", SimulationManager.packToBits(floatType, m_arr_size, inB) );
		manager.runTest();

		Bits[] x  = manager.getOutputDataRawArray( "x" );
		Bits[] y  = manager.getOutputDataRawArray( "y" );
		manager.logMsg( "output x size = " + x.length + ",   y size = " + y.length );
		Bits[] a2 = manager.getOutputDataRawArray( "a2" );
		double[] aa = SimulationManager.unpackFromBits( floatType, a2 );
		for ( int i = 0 ; i < aa.length ; i++ ) {
			double  req    = 2 * inA[i];
			boolean isOK   = isWithinThreshold( aa[i], req );
			String  status = isOK ? "pass" : "fail";
			System.out.println( i + ":  " + status + " :  Simulation = " + aa[i] + ",  \t required = " + req );
			if ( !isOK )
				throw new RuntimeException( "Test failed" );
		}

		Bits[] arrCast  = manager.getOutputDataRawArray( "arrCast" );
		manager.logMsg( "output arrCast size = " + arrCast.length);
		double[] arrCastDbl = SimulationManager.unpackFromBits( fixType, arrCast );
		for (int i = 0; i < arrCastDbl.length; i++) {
			double  req    = inA[i];
			boolean isOK   = isWithinThreshold( arrCastDbl[i], req, 1.e-6 );
			String  status = isOK ? "pass" : "fail";
			System.out.println( i + ":  " + status + " :  Simulation = " + arrCastDbl[i] + ",  \t required = " + req );
			if ( !isOK )
				throw new RuntimeException( "Test failed" );
		}

		//----- exercise all the DFEArrayType encode/decode methods...
		@SuppressWarnings("rawtypes")
		List list = floatArrayType.decodeConstant( a2[0] );
		manager.logMsg( "alist = " + list.toString() );

		try {
			Bits bits_bad = floatArrayType.encodeConstant( inA );
			manager.logMsg( "bits_bad = " + bits_bad );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "***** successfully caught DFEArrayType exception: " + e );
		}

		Bits bits_d = floatArrayType.encodeConstant( new double[]{1,2} );
		Bits bits_f = floatArrayType.encodeConstant( new  float[]{3,4} );
		Bits bits_i = floatArrayType.encodeConstant( new    int[]{5,6} );
		Bits bits_l = floatArrayType.encodeConstant( new   long[]{7,8} );
		Bits bits_b = floatArrayType.encodeConstant( new boolean[]{true,false} );
		manager.logMsg( "bits_d \t= " + bits_d + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits_d) ) );
		manager.logMsg( "bits_f \t= " + bits_f + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits_f) ) );
		manager.logMsg( "bits_i \t= " + bits_i + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits_i) ) );
		manager.logMsg( "bits_l \t= " + bits_l + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits_l) ) );
		manager.logMsg( "bits_b \t= " + bits_b + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits_b) ) );

		ArrayList<Double> array_list = new ArrayList<Double>();
		array_list.add( new Double( 1 ) );
		array_list.add( new Double( 2 ) );
		Bits bits_al = floatArrayType.encodeConstant( array_list );
		manager.logMsg( "bits_al \t= " + bits_al );

		Bits bits = floatArrayType.encodeConstant( (Object)array_list.toArray() );
		manager.logMsg( "Object[] bits \t= " + bits + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits) ) );

		try {
			bits = floatArrayType.encodeConstant( new Double(1.234) );
			manager.logMsg( "Double bits \t= " + bits + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits) ) );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "***** successfully caught encodeConstant(Double) exception: " + e );
		}

		bits = floatArrayType.encodeConstant( (Object)array_list );
		manager.logMsg( "(Object)ArrayList bits \t= " + bits + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits) ) );

		bits = floatArrayType.encodeConstant( new Float[]{ new Float(1), new Float(2) }  );
		manager.logMsg( "Float[] bits \t= " + bits + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits) ) );

		try {
			bits = floatArrayType.encodeConstant( "This should fail"  );
			manager.logMsg( "String bits \t= " + bits + " = " + Arrays.toString( SimulationManager.unpackFromBits(floatType, bits) ) );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "***** successfully caught encodeConstant(String) exception: " + e );
		}

		array_list.add( new Double( 3 ) );
		try {
			bits_al = floatArrayType.encodeConstant( array_list );
			manager.logMsg( "bits_al extra \t= " + bits_al );
		} catch (MaxCompilerAPIError e) {
			manager.logMsg( "***** successfully caught DFEArrayType exception: " + e );
		}

		return 0;
	}

	//----------------------------------------------------------------------------------------------------

	private static void checkRandomSet() {
		if ( m_random == null ) {
			m_seed   = System.currentTimeMillis();
			m_random = new Random( m_seed );
		}
	}

	private static final double  err_threshold = 1.e-14;

	/**
	 * checks whether two values are within a given threshold of each other
	 * @param v1 is the first value, e.g. as returned by the simulator
	 * @param v2 is the second value, e.g. as calculated as the required value
	 * @return true = values match to within threshold; false = values differ
	 */
	private static boolean isWithinThreshold( double v1, double v2 ) {
		return isWithinThreshold(v1, v2, err_threshold);
	}

	/**
	 * checks whether two values are within a given threshold of each other
	 * @param v1 is the first value, e.g. as returned by the simulator
	 * @param v2 is the second value, e.g. as calculated as the required value
	 * @return true = values match to within threshold; false = values differ
	 */
	private static boolean isWithinThreshold( double v1, double v2, double t) {
		boolean isOK = true;
		if ( Math.abs(v1) > t )
			isOK = Math.abs((v2 - v1) / v1) < t;
		else if ( Math.abs(v2) > t )
			isOK = Math.abs((v2 - v1) / v2) < t;

		if (!isOK)
			System.out.println( "    threshold test failed comparing  " + v1 + "  vs  " + v2 );
		return isOK;
	}

	/**
	 * initialize an array with random values with the range 0 to 100.
	 * @param len is the length of the array
	 * @return the array of random values
	 */
	private static double[] initToRandom( int len ) {
		double[] arr = new double[len];
		for ( int i = 0 ; i < len ; i++ )
			arr[i] = m_random.nextDouble() * 100.0;
		return arr;
	}

}
