package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import java.util.Collections;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors._AlreadyConnectedException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types._InternalUtils;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.photon.core.Node;
import com.maxeler.photon.core.Var;
import com.maxeler.photon.core.VarSourceless;
import com.maxeler.photon.core.Warning;
import com.maxeler.photon.hw.Shifter;
import com.maxeler.photon.libs.CoreNodeFactory;
import com.maxeler.photon.libs.DoubtBitOpFactory;
import com.maxeler.photon.libs.WatchFactory;
import com.maxeler.photon.nodes.NodeAdd;
import com.maxeler.photon.nodes.NodeAnd;
import com.maxeler.photon.nodes.NodeCast;
import com.maxeler.photon.nodes.NodeCat;
import com.maxeler.photon.nodes.NodeDiv;
import com.maxeler.photon.nodes.NodeEq;
import com.maxeler.photon.nodes.NodeGt;
import com.maxeler.photon.nodes.NodeGte;
import com.maxeler.photon.nodes.NodeLt;
import com.maxeler.photon.nodes.NodeLte;
import com.maxeler.photon.nodes.NodeMul;
import com.maxeler.photon.nodes.NodeNeg;
import com.maxeler.photon.nodes.NodeNeq;
import com.maxeler.photon.nodes.NodeNot;
import com.maxeler.photon.nodes.NodeOr;
import com.maxeler.photon.nodes.NodeReinterpret;
import com.maxeler.photon.nodes.NodeShift;
import com.maxeler.photon.nodes.NodeSlice;
import com.maxeler.photon.nodes.NodeSub;
import com.maxeler.photon.nodes.NodeXor;
import com.maxeler.photon.op_management.OperatorSupplier.Op;
import com.maxeler.utils.EnumTranslator;

/**
 * {@code DFEVar} streams are of primitive types inherited from {@link DFEType}.
 * <h3>Operators</h3>
 * {@code DFEVar} streams offer overloaded operators:
 * <ul>
 * <li>Arithmetic operators ({@code +, -, *, /}).</li>
 * <li>Negation operator ({@code -}).</li>
 * <li>Relational operators ({@code <, <=, >, >=}).</li>
 * <li>Shift operators ({@code <<, >>}).</li>
 * <li>Bitwise complement operator ({@code ~}).</li>
 * <li>Bitwise operators ({@code &, ^, |}).</li>
 * <li>Ternary if operator ({@code ?:}).</li>
 * </ul>
 * <p>
 * <b>Note</b>: The operators == and != are not overloaded in MaxCompiler and therefore are interpreted as standard Java == and !=.
 * These test the equality of <em>references</em>.
 * Use the methods {@link #eq(DFEVar)} and {@link #neq(DFEVar)} to test the equality of values in {@code DFEVar} streams.
 * <p>
 * <b>Note</b>: Some operations can only be used on a subset of types. For example, floating-point numbers cannot be shifted and raw bits cannot
 * be used in arithmetic expressions. MaxCompiler will throw an exception in these cases.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public class DFEVar implements KernelObjectVectorizable<DFEVar> {
	/**
	 * Radix for formatting {@link DFEVar#watch(String) watch} outputs.
	 */
	public enum Radix {
		BINARY,
		HEXADECIMAL,
		DECIMAL
	}

	final com.maxeler.photon.core.Var m_imp;
	private final Kernel m_design;

	DFEVar(Kernel data, DFEType type, DFEDoubtType doubt_type) {
		m_imp = new VarSourceless(
			_KernelBaseTypes.toImp(type),
			doubt_type.hasDoubtInfo(),
			_Managers.getBuildManager(data.getManager()));

		m_design = data;
	}

	DFEVar(Kernel data, com.maxeler.photon.core.Var imp) {
		m_imp = imp;
		m_design = data;
	}

	@Override
	public Kernel getKernel() {
		return m_design;
	}

	// JavaDoc in KernelObject interface
	@Override
	public void setReportOnUnused(boolean v) {
		m_imp.setReportUnused(v);
	}

	public DFEType getType() {
		return _KernelBaseTypes.fromImp(m_imp.getType());
	}

	@Override
	public DFEDoubtType getDoubtType() {
		return new DFEDoubtType(m_imp.hasDoubt());
	}

	//Javadoc in KernelObject interface declaration
	public DFEVar connect(DFEVar src) {
		_InternalUtils.assertConnectTypes(this, src);

		try {
			m_imp.connect(src.m_imp);
		} catch (Var.AlreadyConnectedException e) {
			throw new _AlreadyConnectedException(this);
		}

		return src;
	}

	/**
	 * Returns a new stream cast to the specified Kernel type from this stream.
	 * <p>
	 * Casting from {@link DFERawBits} to any other Kernel type is free. However, generally
	 * casting to a different Kernel type, for example between {@link DFEFix} and
	 * {@link DFEFloat}, can be expensive in resource usage, so should be
	 * used judiciously.
	 * <p>
	 * Casting to a different Kernel type can lead to a loss of precision, so care
	 * must be taken to ensure that this does not unexpectedly impact the behavior
	 * of the design.
	 * <p>
	 * {@code DFEVar} can only be cast using {@link DFEType} Kernel types. To convert an {@code DFEVar}
	 * to a composite Kernel type, for example {@code DFEComplex}, use {@link KernelType#unpack(DFEVar)}.
	 * @see KernelObject#cast(KernelType)
	 */
	public DFEVar cast(DFEType type) {
		if(type instanceof DFERawBits || getType() instanceof DFERawBits) {
			Node cast_node = new NodeReinterpret(
				_Kernel.getPhotonDesignData(m_design),
				_Kernel.getPhotonDesignData(m_design).getGroupPath(),
				_KernelBaseTypes.toImp(type));

			cast_node.connectInput("input", m_imp);

			return _KernelBaseTypes.fromImp(m_design, cast_node.connectOutput("output"));
		} else {
			Node cast_node = new NodeCast(
				_Kernel.getPhotonDesignData(m_design),
				_Kernel.getPhotonDesignData(m_design).getGroupPath(),
				_KernelBaseTypes.toImp(type));

			cast_node.connectInput("i", m_imp);

			return _KernelBaseTypes.fromImp(m_design, cast_node.connectOutput("o"));
		}
	}

	/**
	 * Concatenates the bits of this {@link DFEVar} object with those of another {@code DFEVar}, e.g.&nbsp;{@code (0b010).cat(0b101)=>0b010101}.
	 * @param lsb The data that will form the least significant
	 * bits of the concatenation. This must not be {@code null}.
	 * @return A new {@code DFEVar} object of Kernel type {@link DFERawBits} which is the concatenation of this
	 * object (the most significant bits) and the argument
	 * {@code lsb} (the least significant bits).
	 */
	@Override
	public DFEVar cat(DFEVar lsb) {
		if (lsb == null)
			throw MaxCompilerAPIError.nullParam(m_design.getManager(), "lsb");
		NodeCat cat_node = new NodeCat(
			_Kernel.getPhotonDesignData(m_design),
			_Kernel.getPhotonDesignData(m_design).getGroupPath());

		cat_node.addCatInput(m_imp);
		cat_node.addCatInput(lsb.m_imp);

		Var result = cat_node.connectOutput("result");

		return _KernelBaseTypes.fromImp(m_design, result);
	}

	@Override
	public DFEVar shiftLeft(DFEVar rhs) {
		NodeShift shifter = new NodeShift(
			_Kernel.getPhotonDesignData(m_design),
			_Kernel.getPhotonDesignData(m_design).getGroupPath(),
			Shifter.ShiftDirection.Left, false);

		shifter.connectInput("datain", m_imp);
		shifter.connectInput("shift", rhs.m_imp);

		DFEVar shifted = _KernelBaseTypes.fromImp(m_design, shifter.connectOutput("dataout"));

		// Backwards compatibility: DFEFix derived types keep their type after shifting
		if(getType() instanceof DFEFix)
			shifted = shifted.cast(getType());

		return shifted;
	}

	@Override
	public DFEVar shiftLeft(int amt) {
		return shiftLeft(DFETypeFactory.dfeUntypedConst().newInstance(m_design, amt));
	}

	@Override
	public DFEVar shiftRight(DFEVar rhs) {
		NodeShift shifter = new NodeShift(
			_Kernel.getPhotonDesignData(m_design),
			_Kernel.getPhotonDesignData(m_design).getGroupPath(),
			Shifter.ShiftDirection.Right, false);

		shifter.connectInput("datain", m_imp);
		shifter.connectInput("shift", rhs.m_imp);

		DFEVar shifted = _KernelBaseTypes.fromImp(m_design, shifter.connectOutput("dataout"));

		// Backwards compatibility: DFEFix derived types keep their type after shifting
		if(getType() instanceof DFEFix)
			shifted = shifted.cast(getType());

		return shifted;
	}

	@Override
	public DFEVar shiftRight(int amt) {
		return shiftRight(DFETypeFactory.dfeUntypedConst().newInstance(m_design, amt));
	}

	public DFEVar rotateLeft(DFEVar rhs) {
		NodeShift shifter = new NodeShift(
			_Kernel.getPhotonDesignData(m_design),
			_Kernel.getPhotonDesignData(m_design).getGroupPath(),
			Shifter.ShiftDirection.Left, true);

		shifter.connectInput("datain", m_imp);
		shifter.connectInput("shift", rhs.m_imp);

		DFEVar shifted = _KernelBaseTypes.fromImp(m_design, shifter.connectOutput("dataout"));

		// Backwards compatibility: DFEFix derived types keep their type after shifting
		if(getType() instanceof DFEFix)
			shifted = shifted.cast(getType());

		return shifted;
	}

	public DFEVar rotateLeft(int amt) {
		return rotateLeft(DFETypeFactory.dfeUntypedConst().newInstance(m_design, amt));
	}

	public DFEVar rotateRight(DFEVar rhs) {
		NodeShift shifter = new NodeShift(
			_Kernel.getPhotonDesignData(m_design),
			_Kernel.getPhotonDesignData(m_design).getGroupPath(),
			Shifter.ShiftDirection.Right, true);

		shifter.connectInput("datain", m_imp);
		shifter.connectInput("shift", rhs.m_imp);

		DFEVar shifted = _KernelBaseTypes.fromImp(m_design, shifter.connectOutput("dataout"));

		// Backwards compatibility: DFEFix derived types keep their type after shifting
		if(getType() instanceof DFEFix)
			shifted = shifted.cast(getType());

		return shifted;
	}

	public DFEVar rotateRight(int amt) {
		return rotateRight(DFETypeFactory.dfeUntypedConst().newInstance(m_design, amt));
	}

	// Note that the get functions are called from evals
	// which take an explicit range. This slice function
	// takes a range and a base.
	/**
	 * Returns a stream of a selection of bits from this {@code DFEVar} object.
	 * <p>
	 * Returns an {@link DFERawBits} stream of {@code width} bits from position {@code base} in the input stream word.
	 * <p>
	 * e.g.
	 * <code>
	 * DFEVar x = constant.var(dfeUInt(6), 13);	// 0b001101 (13)
	 * DFEVar y = x.slice(2,2);					// 0b11     (3)
	 * </code>
	 * @param base The index of the start bit, with 0 being the least significant bit.
	 * @param width The number of bits to select.
	 * @return A {@code width}-bit wide {@link DFEVar} of type {@link DFERawBits} containing the values of the selected bits.
	 */
	public DFEVar slice(int base, int width) {
		final DFEType type = getType();
		if (type instanceof DFEUntypedConst)
			throw new MaxCompilerAPIError(m_design.getManager(), "Cannot slice an DFEVar with type DFEUntypedConst.");

		final int totalBits = type.getTotalBits();
		if (base < 0 || base > totalBits - 1)
			throw new MaxCompilerAPIError(m_design.getManager(), "Slice base must be between 0 and %d inclusive, not %d.", totalBits - 1, base);
		if (width < 1)
			throw new MaxCompilerAPIError(m_design.getManager(), "Slice width must be at least 1, not %d.", width);
		if (base + width > totalBits)
			throw new MaxCompilerAPIError(m_design.getManager(), "End of slice (%d) exceeds size of type (%s bit%s).", base + width, totalBits, totalBits == 1 ? "" : "s");

		NodeSlice slice_node = new NodeSlice(
			_Kernel.getPhotonDesignData(m_design),
			_Kernel.getPhotonDesignData(m_design).getGroupPath(),
			base, width);

		slice_node.connectInput("a", m_imp);

		return _KernelBaseTypes.fromImp(m_design, slice_node.connectOutput("result"));
	}

	/**
	 * Alias for {@link #slice(int, int) slice(i,1)}.
	 * <p>
	 * This is also accessible through the overloaded {@code []} operator.
	 * @param i The index of the bit, with 0 being the least significant bit.
	 * @return A 1-bit wide {@link DFEVar} of type {@link DFERawBits} containing the value of the bit at
	 * index {@code i}.
	 */
	public DFEVar get(int i) {
		return slice(i, 1);
	}

	/**
	 * Alias for {@link #slice(int, int) slice(i,1)}.
	 * @param i The index of the bit, with 0 being the least significant bit.
	 * @return A 1-bit wide {@link DFEVar} of type {@link DFERawBits} containing the value of the bit at
	 * index {@code i}.
	 */
	public DFEVar slice(int i) {
		return slice(i, 1);
	}

	private DFEVar abNode(DFEVar rhs, Node node) {
		node.connectInput("a", m_imp);
		node.connectInput("b", rhs.m_imp);

		return _KernelBaseTypes.fromImp(m_design, node.connectOutput("result"));
	}

	private DFEVar abBitwiseNode(DFEVar rhs, Node node) {
		// NodeBitwise expects matching input types. For backwards compatibility, we have to do some
		// extra casting to simulate old-style typing in cases that don't involve DFERawBits.
		if (getType() instanceof DFERawBits && rhs.getType() instanceof DFERawBits)
			return abNode(rhs, node);		// Strict typing!

		// Backwards-compatible typing:
		DFEType a_type = getType();
		DFEType b_type = rhs.getType();
		DFEType overall_type;

		if(!a_type.isConcreteType()) {
			if(!b_type.isConcreteType())
				// input_a = const, input_b = const => This node is also a constant
				overall_type = DFETypeFactory.dfeUntypedConst();
			else {
				overall_type = b_type;
			}
		} else {
			if(!b_type.isConcreteType()) {
				overall_type = a_type;
			} else {
				// input_a = non-const, input_b = non-const
				if(a_type.getTotalBits() != b_type.getTotalBits())
					throw new MaxCompilerAPIError(m_design.getManager(), "Input types " + a_type + " and " + b_type + " do not match.");

				overall_type = a_type;
			}
		}

		if(!(overall_type instanceof DFEFix) && !(overall_type instanceof DFERawBits))
			throw new MaxCompilerAPIError(m_design.getManager(), "Inputs to bitwise operator must be DFEFix or DFERawBits, not " + overall_type + ".");

		DFEVar a_cast = this.cast(DFETypeFactory.dfeRawBits(overall_type.getTotalBits()));
		DFEVar b_cast = rhs.cast(DFETypeFactory.dfeRawBits(overall_type.getTotalBits()));
		return a_cast.abNode(b_cast, node).cast(overall_type);
	}

	@Override
	public DFEVar or(DFEVar rhs) {
		return abBitwiseNode(rhs, new NodeOr(_Kernel.getPhotonDesignData(m_design), _Kernel.getPhotonDesignData(m_design).getGroupPath()));
	}

	public DFEVar or(double rhs) {
		return or(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar or(float rhs) {
		return or(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar or(int rhs) {
		return or(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar or(boolean rhs) {
		return or(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar or(long rhs) {
		return or(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar orAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).or(this);
	}

	public DFEVar orAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).or(this);
	}

	public DFEVar orAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).or(this);
	}

	public DFEVar orAsRHS(boolean lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).or(this);
	}

	public DFEVar orAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).or(this);
	}

	@Override
	public DFEVar xor(DFEVar rhs) {
		return abBitwiseNode(rhs, new NodeXor(_Kernel.getPhotonDesignData(m_design), _Kernel.getPhotonDesignData(m_design).getGroupPath()));
	}

	public DFEVar xor(double rhs) {
		return xor(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar xor(float rhs) {
		return xor(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar xor(int rhs) {
		return xor(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar xor(boolean rhs) {
		return xor(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar xor(long rhs) {
		return xor(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar xorAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).xor(this);
	}

	public DFEVar xorAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).xor(this);
	}

	public DFEVar xorAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).xor(this);
	}

	public DFEVar xorAsRHS(boolean lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).xor(this);
	}

	public DFEVar xorAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).xor(this);
	}

	@Override
	public DFEVar and(DFEVar rhs) {
		return abBitwiseNode(rhs, new NodeAnd(_Kernel.getPhotonDesignData(m_design), _Kernel.getPhotonDesignData(m_design).getGroupPath()));
	}

	public DFEVar and(double rhs) {
		return and(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar and(float rhs) {
		return and(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar and(int rhs) {
		return and(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar and(boolean rhs) {
		return and(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar and(long rhs) {
		return and(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar andAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).and(this);
	}

	public DFEVar andAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).and(this);
	}

	public DFEVar andAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).and(this);
	}

	public DFEVar andAsRHS(boolean lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).and(this);
	}

	public DFEVar andAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).and(this);
	}

	@Override
	public DFEVar eq(DFEVar rhs) {
		return abNode(rhs, new NodeEq(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar eq(double rhs) {
		return eq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar eq(float rhs) {
		return eq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar eq(int rhs) {
		return eq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar eq(long rhs) {
		return eq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar eq(boolean rhs) {
		return eq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar eqAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).eq(this);
	}

	public DFEVar eqAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).eq(this);
	}

	public DFEVar eqAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).eq(this);
	}

	public DFEVar eqAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).eq(this);
	}

	public DFEVar eqAsRHS(boolean lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).eq(this);
	}

	@Override
	public DFEVar neq(DFEVar rhs) {
		return abNode(rhs, new NodeNeq(_Kernel.getPhotonDesignData(m_design)));
	}


	public DFEVar neq(double rhs) {
		return neq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar neq(float rhs) {
		return neq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar neq(int rhs) {
		return neq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar neq(long rhs) {
		return neq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar neq(boolean rhs) {
		return neq(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}	/**
	 * Returns a new stream cast to the specified type from this stream.
	 * <p>
	 * <b>Note</b>: {@code DFEVar} can only be cast using {@link DFEType} types.
	 * @see DFEVar#cast(DFEType)
	 */

	public DFEVar neqAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).neq(this);
	}

	public DFEVar neqAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).neq(this);
	}

	public DFEVar neqAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).neq(this);
	}

	public DFEVar neqAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).neq(this);
	}

	public DFEVar neqAsRHS(boolean lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).neq(this);
	}

	@Override
	public DFEVar lte(DFEVar rhs) {
		return abNode(rhs, new NodeLte(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar lte(double rhs) {
		return lte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar lte(float rhs) {
		return lte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar lte(int rhs) {
		return lte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar lte(long rhs) {
		return lte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar lteAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lte(this);
	}

	public DFEVar lteAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lte(this);
	}

	public DFEVar lteAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lte(this);
	}

	public DFEVar lteAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lte(this);
	}

	@Override
	public DFEVar gte(DFEVar rhs) {
		return abNode(rhs, new NodeGte(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar gte(double rhs) {
		return gte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gte(float rhs) {
		return gte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gte(int rhs) {
		return gte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gte(long rhs) {
		return gte(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gteAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gte(this);
	}

	public DFEVar gteAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gte(this);
	}

	public DFEVar gteAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gte(this);
	}

	public DFEVar gteAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gte(this);
	}

	@Override
	public DFEVar gt(DFEVar rhs) {
		return abNode(rhs, new NodeGt(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar gt(double rhs) {
		return gt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gt(float rhs) {
		return gt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gt(int rhs) {
		return gt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gt(long rhs) {
		return gt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar gtAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gt(this);
	}

	public DFEVar gtAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gt(this);
	}

	public DFEVar gtAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gt(this);
	}

	public DFEVar gtAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).gt(this);
	}

	@Override
	public DFEVar lt(DFEVar rhs) {
		return abNode(rhs, new NodeLt(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar lt(double rhs) {
		return lt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar lt(float rhs) {
		return lt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar lt(int rhs) {
		return lt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar lt(long rhs) {
		return lt(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar ltAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lt(this);
	}

	public DFEVar ltAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lt(this);
	}

	public DFEVar ltAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lt(this);
	}

	public DFEVar ltAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).lt(this);
	}

	@Override
	public DFEVar add(DFEVar rhs) {
		return abNode(rhs, new NodeAdd(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar add(double rhs) {
		return add(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar add(float rhs) {
		return add(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar add(int rhs) {
		return add(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar add(long rhs) {
		return add(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar addAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).add(this);
	}

	public DFEVar addAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).add(this);
	}

	public DFEVar addAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).add(this);
	}

	public DFEVar addAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).add(this);
	}

	@Override
	public DFEVar sub(DFEVar rhs) {
		return abNode(rhs, new NodeSub(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar sub(double rhs) {
		return sub(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar sub(float rhs) {
		return sub(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar sub(int rhs) {
		return sub(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar sub(long rhs) {
		return sub(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar subAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).sub(this);
	}

	public DFEVar subAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).sub(this);
	}

	public DFEVar subAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).sub(this);
	}

	public DFEVar subAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).sub(this);
	}

	@Override
	public DFEVar mul(DFEVar rhs) {
		return abNode(rhs, new NodeMul(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar mul(double rhs) {
		return mul(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar mul(float rhs) {
		return mul(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar mul(int rhs) {
		return mul(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar mul(long rhs) {
		return mul(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar mulAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).mul(this);
	}

	public DFEVar mulAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).mul(this);
	}

	public DFEVar mulAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).mul(this);
	}

	public DFEVar mulAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).mul(this);
	}

	@Override
	public DFEVar div(DFEVar rhs) {
		return abNode(rhs, new NodeDiv(_Kernel.getPhotonDesignData(m_design)));
	}

	public DFEVar div(double rhs) {
		return div(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar div(float rhs) {
		return div(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar div(int rhs) {
		return div(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar div(long rhs) {
		return div(DFETypeFactory.dfeUntypedConst().newInstance(m_design, rhs));
	}

	public DFEVar divAsRHS(double lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).div(this);
	}

	public DFEVar divAsRHS(float lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).div(this);
	}

	public DFEVar divAsRHS(int lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).div(this);
	}

	public DFEVar divAsRHS(long lhs) {
		return DFETypeFactory.dfeUntypedConst().newInstance(m_design, lhs).div(this);
	}

	@Override
	public DFEVar complement() {
		NodeNot not_node = new NodeNot(_Kernel.getPhotonDesignData(m_design), _Kernel.getPhotonDesignData(m_design).getGroupPath());

		not_node.connectInput("a", m_imp);

		return _KernelBaseTypes.fromImp(m_design, not_node.connectOutput("result"));
	}

	@Override
	public DFEVar neg() {
		NodeNeg neg_node = new NodeNeg(_Kernel.getPhotonDesignData(m_design));

		neg_node.connectInput("a", m_imp);

		Var result = neg_node.connectOutput("result");

		if (getType() instanceof DFEFix &&
			((DFEFix)getType()).getSignMode() == SignMode.UNSIGNED &&
			neg_node.getOperatorSupplier().getTypeModeForOp(Op.NEG).m_bin_op_types_must_match)
		{
			_Kernel.getPhotonDesignData(m_design).raiseWarning(
				Warning.UNSIGNED_NEGATION_IN_NON_BITGROWTH_MODE, neg_node,
				"Negating unsigned fixed-point number with bit growth disabled");
		}

		return _KernelBaseTypes.fromImp(m_design, result);
	}

	private CoreNodeFactory getCoreNodeFactory() {
		return new CoreNodeFactory(_Kernel.getPhotonDesignData(m_design));
	}

	private WatchFactory getWatchFactory() {
		return new WatchFactory(_Kernel.getPhotonDesignData(m_design));
	}

	private DoubtBitOpFactory getDoubtBitOpFactory() {
		return new DoubtBitOpFactory(_Kernel.getPhotonDesignData(m_design));
	}

	@Override
	public DFEVar dfeWatch(String name) { return dfeWatch(name, Radix.DECIMAL); }

	public DFEVar dfeWatch(String name, Radix radix) {
		getWatchFactory().hwWatch(
			name,
			_KernelBaseTypes.toImp(this),
			EnumTranslator.convert(
				radix,
				WatchFactory.Radix.class
			)
		);
		return this;
	}

	//Javadoc in KernelObject interface declaration
	@Override
	public DFEVar watch(String name) {
		if(m_design.getManager().isTargetSimulation())
			getWatchFactory().watch(name, m_imp);

		return this;
	}

	/**
	 * Adds a watch to the stream, formatted with a specific radix.
	 * @param name The name for the watch node as it will appear in the output.
	 * @param radix The radix with which to format the output.
	 */
	public DFEVar watch(String name, Radix radix) {
		if(m_design.getManager().isTargetSimulation())
			getWatchFactory().watch(
				name,
				m_imp,
				EnumTranslator.convert(radix, WatchFactory.Radix.class));

		return this;
	}

	/**
	 * Adds a watch to the stream, formatted with a specific radix.
	 * @param name The name for the watch node as it will appear in the output.
	 * @param radix The radix with which to format the output.
	 * @param fmt_str Extra formatting for the output.
	 */
	public DFEVar watch(String name, Radix radix, String fmt_str) {
		if(m_design.getManager().isTargetSimulation())
			getWatchFactory().watch(
				name,
				m_imp,
				EnumTranslator.convert(radix, WatchFactory.Radix.class),
				fmt_str);

		return this;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends KernelObject<T>> T ternaryIf(T true_cond, T false_cond) {
		return getKernel().control.mux(this, false_cond, true_cond);
	}

	public DFEVar ternaryIf(DFEVar true_cond, double false_cond) {
		return ternaryIf(true_cond, getKernel().constant.var(true_cond.getType(), false_cond));
	}
	public DFEVar ternaryIf(DFEVar true_cond, float false_cond) {
		return ternaryIf(true_cond, (double)false_cond);
	}
	public DFEVar ternaryIf(DFEVar true_cond, int false_cond) {
		return ternaryIf(true_cond, (double)false_cond);
	}
	public DFEVar ternaryIf(DFEVar true_cond, long false_cond) {
		return ternaryIf(true_cond, (double)false_cond);
	}

	public DFEVar ternaryIf(double true_cond, DFEVar false_cond) {
		return ternaryIf(getKernel().constant.var(false_cond.getType(), true_cond), false_cond);
	}
	public DFEVar ternaryIf(float true_cond, DFEVar false_cond) {
		return ternaryIf((double)true_cond, false_cond);
	}
	public DFEVar ternaryIf(int true_cond, DFEVar false_cond) {
		return ternaryIf((double)true_cond, false_cond);
	}
	public DFEVar ternaryIf(long true_cond, DFEVar false_cond) {
		return ternaryIf((double)true_cond, false_cond);
	}

	public DFEComplex ternaryIf(DFEComplex true_cond, double false_cond) {
		return ternaryIf(true_cond, getKernel().constant.cplx(true_cond.getType(), false_cond, 0));
	}
	public DFEComplex ternaryIf(DFEComplex true_cond, float false_cond) {
		return ternaryIf(true_cond, (double)false_cond);
	}
	public DFEComplex ternaryIf(DFEComplex true_cond, int false_cond) {
		return ternaryIf(true_cond, (double)false_cond);
	}
	public DFEComplex ternaryIf(DFEComplex true_cond, long false_cond) {
		return ternaryIf(true_cond, (double)false_cond);
	}

	public DFEComplex ternaryIf(double true_cond, DFEComplex false_cond) {
		return ternaryIf(getKernel().constant.cplx(false_cond.getType(), true_cond, 0), false_cond);
	}
	public DFEComplex ternaryIf(float true_cond, DFEComplex false_cond) {
		return ternaryIf((double)true_cond, false_cond);
	}
	public DFEComplex ternaryIf(int true_cond, DFEComplex false_cond) {
		return ternaryIf((double)true_cond, false_cond);
	}
	public DFEComplex ternaryIf(long true_cond, DFEComplex false_cond) {
		return ternaryIf((double)true_cond, false_cond);
	}

	/**
	 * Only accepts {@link DFEType}.&nbsp;See {@link #cast(DFEType)} for details.
	 * <p>
	 * <b>Note</b>: {@code DFEVar} can only be cast using {@link DFEType} types.
	 * @see KernelObject#cast(KernelType)
	 */
	@Override
	public KernelObject<?> cast(KernelType<?> type) {
		if(type instanceof DFEType)
			return cast((DFEType)type);

		throw new MaxCompilerAPIError(m_design.getManager(), "DFEVar can only be cast using DFEType types.");
	}

	/**
	 * Returns the type of this object.
	 */
	@Override
	public String toString() {
		DFEType type = getType();

		String str = type == null ? "(no type)" : type.toString();
		if (getDoubtType().hasDoubtInfo())
			str += " with doubt info";

		return str;
	}

	public DFEVar hasDoubt() {
		if(getDoubtType().hasDoubtInfo())
			return _KernelBaseTypes.fromImp(m_design, getDoubtBitOpFactory().getDoubt(m_imp));
		else
			return m_design.constant.var(false);
	}

	public DFEVar castDoubtType(DFEDoubtType doubt_type) {
		if(doubt_type.hasDoubtInfo() == getDoubtType().hasDoubtInfo())
			return this;

		if (doubt_type.hasDoubtInfo())
			return _KernelBaseTypes.fromImp(m_design, getDoubtBitOpFactory().setDoubt(
				m_imp,
				m_design.constant.var(false).m_imp));
		else
			return _KernelBaseTypes.fromImp(m_design, getDoubtBitOpFactory().removeDoubt(
				m_imp));
	}

	@Override
	public DFEVar castDoubtType(DoubtType doubt_type) {
		if(!(doubt_type instanceof DFEDoubtType))
			throw new MaxCompilerAPIError(m_design.getManager(),
				"DFEVar can only be doubt-type casted using a DFEDoubtType object.");

		return castDoubtType((DFEDoubtType)doubt_type);
	}

	@Override
	public List<DFEVar> packToList() {
		return Collections.singletonList(this);
	}

	@Override
	public DFEVar packWithDoubt() {
		return
			getDoubtType().hasDoubtInfo() ?
				_KernelBaseTypes.fromImp(m_design, getDoubtBitOpFactory().makeDoubtExplicit(m_imp)) :
				packWithoutDoubt();
	}

	@Override
	public DFEVar packWithoutDoubt() {
		if(!getType().isConcreteType())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Cannot pack DFEVar as type " + getType() + " is not concrete.");

		DFEVar data_packed =
			 _KernelBaseTypes.fromImp(m_design,
					getCoreNodeFactory().reinterpretCast(
						m_imp,
						_KernelBaseTypes.toImp(DFETypeFactory.dfeRawBits(getType().getTotalBits()))));

		return
			getDoubtType().hasDoubtInfo() ?
				data_packed.castDoubtType(new DFEDoubtType(false)) :
				data_packed;
	}

	/**
	 * Returns this {@code DFEVar} object cast to {@link DFERawBits}.
	 */
	@Override
	public DFEVar pack() {
		if(getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Cannot use pack() on this stream as it contains doubt " +
				"information. If you want to explicitly discard this information " +
				"use packWithoutDoubt(), otherwise use packWithDoubt().");

		return packWithoutDoubt();
	}

	@Override
	public DFEVar addDoubtInfo() {
		return castDoubtType(getType().getFullTypeWithDoubtInfo().getDoubtType());
	}

	@Override
	public DFEVar removeDoubtInfo() {
		return castDoubtType(getType().getFullTypeWithoutDoubtInfo().getDoubtType());
	}

	@Override
	public DFEVar setDoubt(DFEVar doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEVar setDoubt(boolean doubt) {
		return setDoubt(doubt, SetDoubtOperation.OVERRIDE);
	}

	@Override
	public DFEVar setDoubt(DFEVar doubt, SetDoubtOperation operation) {
		if (!getDoubtType().hasDoubtInfo())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Cannot use setDoubt on this stream as it doesn't contain doubt information.");

		DFEVar combined_doubt = null;

		switch(operation) {
			case AND:
				combined_doubt = doubt & hasDoubt();
				break;
			case OR:
				combined_doubt = doubt | hasDoubt();
				break;
			case OVERRIDE:
				combined_doubt = doubt;
				break;
		}

		return _KernelBaseTypes.fromImp(m_design, getDoubtBitOpFactory().setDoubt(m_imp, _KernelBaseTypes.toImp(combined_doubt)));
	}

	@Override
	public DFEVar setDoubt(boolean doubt, SetDoubtOperation operation) {
		return setDoubt(m_design.constant.var(doubt), operation);
	}
}
