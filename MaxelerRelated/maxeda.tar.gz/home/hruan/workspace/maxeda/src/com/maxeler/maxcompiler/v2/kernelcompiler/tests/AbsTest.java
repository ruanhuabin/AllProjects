package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxConstantEncodingException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.utils.Pair;

public class AbsTest {

	private static long s_seed;
	private static Random s_random;

	private static void resetRandom() {
		s_seed = System.currentTimeMillis();
		s_random = new Random(s_seed);
	}

	private static class Lib extends KernelLib {

		public final String inputName;
		public final String outputName;

		protected Lib(KernelLib owner, DFEType type, String name) {
			super(owner);

			inputName  = "input_"  + name;
			outputName = "output_" + name;

			DFEVar input = io.input(inputName, type);
			io.output(outputName, type).connect(KernelMath.abs(input));
		}

		protected <
			M extends DFEVectorBase<DFEVar, M, C, T>,
			C extends DFEVectorBase<DFEVar, C, ?, ?>,
			T extends DFEVectorTypeBase<DFEVar, M, C>
		> Lib(KernelLib owner, T type, String name) {
			super(owner);

			inputName  = "input_"  + name;
			outputName = "output_" + name;

			M input = io.input(inputName, type);
			io.output(outputName, type).connect(KernelMath.abs(input));
		}
	}

	private static class KernelHWVar extends Kernel {

		public final HashMap<String, Pair<String, DFEType>> inOutMap = new HashMap<String, Pair<String, DFEType>>();

		protected KernelHWVar(KernelParameters parameters) {
			super(parameters);
			DFEType floatType = dfeFloat(11, 53);
			DFEType fixedType = dfeFix(7, 13, SignMode.TWOSCOMPLEMENT);
			DFEType unsignedType = dfeFix(9, 7, SignMode.UNSIGNED);
			Lib lib = new Lib(this, dfeFloat(11, 53), "float");
			inOutMap.put(lib.inputName, new Pair<String, DFEType>(lib.outputName, floatType));
			lib = new Lib(this, fixedType, "fixed");
			inOutMap.put(lib.inputName, new Pair<String, DFEType>(lib.outputName, fixedType));
			lib = new Lib(this, unsignedType, "unsigned");
			inOutMap.put(lib.inputName, new Pair<String, DFEType>(lib.outputName, unsignedType));
		}

	}

	private static Bits[] encode(DFEVectorType<DFEVar> type, double[] data) {
		int n = type.getNElements();
		if(data.length % n != 0) {
			throw new RuntimeException("length of data " + data.length + " must be a multiple "
				+ "of " + n);
		}
		Bits ret[] = new Bits[data.length/n];
		for(int i = 0; i < ret.length; i++) {
			double val[] = new double[n];
			for(int j = 0; j < n; j++) {
				val[j] = data[n*i + j];
			}
			ret[i] = type.encodeConstant(val);
		}
		return ret;
	}

	@SuppressWarnings("unchecked")
	private static double[] decode(DFEVectorType<DFEVar> type, Bits[] bits) {
		int n = type.getNElements();
		double[] ret = new double[n*bits.length];
		for(int i = 0; i < bits.length; i++) {
    	   List<Double> vals = type.decodeConstant(bits[i]);
	       for(int j = 0; j < vals.size(); j++) {
	    	   ret[i*n + j] = vals.get(j);
	       }
		}
		return ret;
	}

	private static class KernelMP extends Kernel {

		private final static int nPipes = 3;
		public final HashMap<String, Pair<String, DFEVectorType<DFEVar>>> inOutMap = new HashMap<String, Pair<String, DFEVectorType<DFEVar>>>();
		public final DFEVectorType<DFEVar> fixType;
		public final DFEVectorType<DFEVar> floatType;

		protected KernelMP(KernelParameters parameters) {
			super(parameters);
			fixType = new DFEVectorType<DFEVar>(dfeFix(7, 57, SignMode.TWOSCOMPLEMENT), nPipes);
			floatType = new DFEVectorType<DFEVar>(dfeFloat(8, 24), nPipes);
			Lib lib = new Lib(this, floatType, "multipipe_float");
			inOutMap.put(lib.inputName, new Pair<String, DFEVectorType<DFEVar>>(lib.outputName, floatType));
			lib = new Lib(this, fixType, "multipipe_fixed");
			inOutMap.put(lib.inputName, new Pair<String, DFEVectorType<DFEVar>>(lib.outputName, fixType));
		}

	}

	private static class KernelUntyped extends Kernel {

		protected KernelUntyped(KernelParameters parameters, DFEType type, double cst) {
			super(parameters);
			DFEVar input = io.input("input", type);
			io.output("output", type).connect(input + KernelMath.abs(this.constant.var(cst)));
		}

	}

	private static double[] generateInputData(int length) {
		double[] res = new double[length];
		for (int i = 0; i < res.length; ++i) {
			res[i] = s_random.nextDouble();
		}
		return res;
	}

	private static double[] generateExpectedData(double[] input) {
		double[] res = new double[input.length];
		for (int i = 0; i < res.length; ++i) {
			res[i] = Math.abs(input[i]);
		}
		return res;
	}

	private static boolean validateInput(KernelHWVar k, double[] input) {
		for (Pair<String, DFEType> pair : k.inOutMap.values()) {
			DFEType type = pair.value;
			for (double d : input) {
				try {
					type.encodeConstant(d);
				} catch (MaxConstantEncodingException ex) {
					return false;
				}
			}
		}
		return true;
	}

	private static void runTestHWVar() {
		resetRandom();
		int length = 32;
		double[] input_data = generateInputData(length);
		double[] expected_data = generateExpectedData(input_data);

		_DualSimulationManager mgr = new _DualSimulationManager("AbsTestKernelHWVar");
		mgr.logMsg("Starting test Kernel DFEVar.\nUsing seed " + s_seed);
		KernelHWVar kernelA = new KernelHWVar(mgr.makeKernelParameters_A());
		KernelHWVar kernelB = new KernelHWVar(mgr.makeKernelParameters_B());
		mgr.setKernels(kernelA, kernelB);
		while (!validateInput(kernelA, input_data)) {
			input_data = generateInputData(length);
			expected_data = generateExpectedData(input_data);
		}
		for(String input_name : kernelA.inOutMap.keySet()) {
			DFEType type = kernelA.inOutMap.get(input_name).value;
			if(type instanceof DFEFix && ((DFEFix)type).getSignMode().equals(SignMode.UNSIGNED)) {
				mgr.setInputData(input_name, expected_data);
			} else {
				mgr.setInputData(input_name, input_data);
			}
		}

		mgr.setKernelCycles(length);
		mgr.runTest();

		for(Pair<String, DFEType> pair : kernelA.inOutMap.values()) {
			String output_name = pair.key;
			DFEType type = pair.value;
			double data[] = new double[length];
			for(int i = 0; i < length; i++) {
				data[i] = type.decodeConstant(type.encodeConstant(expected_data[i]));
			}
			mgr.checkOutputData(output_name, data);
		}
		System.out.println("DFEVar TEST PASSED");
	}

	private static void runTestMultiPipe() {
		resetRandom();
		int length = 16*KernelMP.nPipes;
		double input_data[] = generateInputData(length);
		double expected_data[] = generateExpectedData(input_data);

		_DualSimulationManager mgr = new _DualSimulationManager("AbsTestKernelMP");
		mgr.logMsg("Starting test Kernel Multi-Pipe.\nUsing seed " + s_seed);
		KernelMP kernelA = new KernelMP(mgr.makeKernelParameters_A());
		KernelMP kernelB = new KernelMP(mgr.makeKernelParameters_B());
		mgr.setKernels(kernelA, kernelB);
		set_data:
		for(String input_name : kernelA.inOutMap.keySet()) {
			try {
				mgr.setInputDataRaw(input_name, encode(kernelA.inOutMap.get(input_name).value, input_data));
			} catch (Exception e) {
				input_data = generateInputData(length);
				expected_data = generateExpectedData(input_data);
				break set_data;
			}
		}

		mgr.setKernelCycles(length/KernelMP.nPipes);
		mgr.runTest();

		for(Pair<String, DFEVectorType<DFEVar>> pair : kernelA.inOutMap.values()) {
			List<Bits> _output = mgr.getOutputDataRaw(pair.key);
			DFEVectorType<DFEVar> mptype = pair.value;
			DFEType type = (DFEType)mptype.getContainedType();
			Bits[] output_raw = new Bits[_output.size()];
			for(int i = 0; i < output_raw.length; i++)
				output_raw[i] = _output.get(i);
			double output[] = decode(mptype, output_raw);
			if(output.length != expected_data.length) {
				throw new RuntimeException("Error with type " + mptype.toString() + ". " +
					"Expected output of length " + expected_data.length + " but got output of length " + output.length);
			}
			for(int i = 0; i < output.length; i++) {
				if(output[i] != type.decodeConstant(type.encodeConstant(expected_data[i]))) {
					throw new RuntimeException("Error with type " + mptype.toString() + ". " +
						"Got " + output[i] + ", when expected " + expected_data[i]);
				}
			}
		}
		System.out.println("Multi-Pipe TEST PASSED");
	}


	private static void runTestUntyped() {
		resetRandom();
		s_seed = 1295449133709L;
		int length = 16;
		double input_data[] = new double[length];
		double expected_data[] = new double[length];
		DFEType type = Kernel.dfeFloat(11, 53);
		double cst = s_random.nextDouble();

		for(int i = 0; i < length; i++) {
			input_data[i] = s_random.nextDouble();
			expected_data[i] = input_data[i] + Math.abs(cst);
		}

		_DualSimulationManager mgr = new _DualSimulationManager("AbsTestKernelUntyped");
		mgr.logMsg("Starting test Kernel Untyped.\nUsing seed " + s_seed);
		KernelUntyped kernelA = new KernelUntyped(mgr.makeKernelParameters_A(), type, cst);
		KernelUntyped kernelB = new KernelUntyped(mgr.makeKernelParameters_B(), type, cst);
		mgr.setKernels(kernelA, kernelB);

		mgr.setInputData("input", input_data);
		mgr.setKernelCycles(length);
		mgr.runTest();

		System.out.println("input: " + Arrays.toString(input_data));
		System.out.println("cst: " + cst);
		System.out.println("expected: " + Arrays.toString(expected_data));

		double data[] = new double[length];
		for(int i = 0; i < length; i++) {
			data[i] = type.decodeConstant(type.encodeConstant(expected_data[i]));
		}
		mgr.dumpOutput();
		mgr.checkOutputData("output", data);
		System.out.println("Untyped TEST PASSED");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		runTestHWVar();
		runTestMultiPipe();
		runTestUntyped();
	}
}
