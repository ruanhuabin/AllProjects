package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

public interface MaxRingConnection {
}
