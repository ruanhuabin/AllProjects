package com.maxeler.maxcompiler.v2.kernelcompiler.types.base;

import static com.maxeler.utils.EnumTranslator.convert;

import java.math.BigDecimal;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.photon.types.HWOffsetFix;
import com.maxeler.photon.types.HWTypeFactory;
import com.maxeler.utils.numeric.BigFloat;

// This is final because extending it really does not work in an obvious way.
// Facaded HWTypes are created at outputs from the compiler losing any
// extra meta-data/type-information you may be trying to add.
/**
 * Fixed-point type with an offset binary point.
 * <p>
 * Booleans (see {@link com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib#dfeBool}), signed integers (see {@link com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib#dfeInt})
 * and unsigned integers (see {@link com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib#dfeUInt}) are all special cases of fixed-point numbers
 * and are implemented using the {@code DFEFix} type in MaxCompiler.
 * <p>
 * {@link DFEVar} streams can contain data of Kernel type {@code DFEFix}.
 * <p>
 * See <a href="{@docRoot}/com/maxeler/maxcompiler/v2/kernelcompiler/types/package-summary.html">com.maxeler.maxcompiler.v2.kernelcompiler.types</a> for more information on
 * the Kernel type and stream reference hierarchy.
 */
public final class DFEFix extends DFEType {

	/**
	 * Used to specify the sign representation mode of fixed-point numbers.
	 * <p>
	 * See <a href="http://www.dsprelated.com/dspbooks/mdft/Two_s_Complement_Fixed_Point_Format.html">this link</a> for an
	 * introduction to two's complement.
	 */
	public enum SignMode {
		UNSIGNED, TWOSCOMPLEMENT;
	}

	DFEFix(com.maxeler.photon.types.HWType imp) {
		super(imp);
		if (!(imp instanceof com.maxeler.photon.types.HWOffsetFix))
			throw new MaxCompilerInternalError("Not DFEFix instance.");
	}

	/**
	 * Gets the sign mode of the fixed-point type.
	 */
	public SignMode getSignMode() {
		com.maxeler.photon.types.HWOffsetFix imp = (com.maxeler.photon.types.HWOffsetFix) m_imp;

		return convert(imp.getSignMode(), SignMode.class);
	}

	/**
	 * Gets the number of integer bits in the fixed-point type.
	 * <p>
	 * <b>Note</b>: this can be negative in the case of a negative offset of
	 * a magnitude greater than the total number of bits in the word.
	 */
	public int getIntegerBits() {
		com.maxeler.photon.types.HWOffsetFix imp = (com.maxeler.photon.types.HWOffsetFix) m_imp;

		return imp.getOffsetMSB();
	}

	/**
	 * Gets the number of fractional bits in the fixed-point type.
	 * <p>
	 * <b>Note</b>: this can be negative in the case of a positive offset
	 * greater than the total number of bits in the word.
	 */
	public int getFractionBits() {
		com.maxeler.photon.types.HWOffsetFix imp = (com.maxeler.photon.types.HWOffsetFix) m_imp;

		return -imp.getOffset();
	}

	/**
	 * Gets the offset of the binary point in the fixed-point type.
	 */
	public int getOffset() {
		com.maxeler.photon.types.HWOffsetFix imp = (com.maxeler.photon.types.HWOffsetFix) m_imp;

		return imp.getOffset();
	}

	public double getMax() {
		com.maxeler.photon.types.HWOffsetFix imp = (com.maxeler.photon.types.HWOffsetFix) m_imp;
		return imp.getMax().toDouble();
	}

	public BigDecimal getMaxBigDecimal() {
		com.maxeler.photon.types.HWOffsetFix imp = (com.maxeler.photon.types.HWOffsetFix) m_imp;
		return imp.getMax().toBigDecimal();
	}

	@Override
	public boolean equalsIgnoreMax(KernelType<?> other_type) {
		return
			(other_type instanceof DFEFix) &&
			((HWOffsetFix)m_imp).equalsIgnoreMax((HWOffsetFix)(((DFEFix)other_type).m_imp));
	}

	/**
	 * Returns a string summary of the fixed-point type.
	 * <p>
	 * e.g:<br>
	 * <code>System.out.print(dfeOffsetFix(8,8,DFEFix.SignMode.UNSIGNED));</code><br>
	 * prints: <code>dfeFix(16, -8, UNSIGNED)</code><br>
	 */
	@Override
	public String toString() {
		return "dfeFix(" + getIntegerBits() + ", " + getFractionBits() /* + ", " + getMax()*/ + ", " + getSignMode() + ")";
	}

	@Override
	protected KernelType<?> realUnionWithMaxOfMaxes(KernelType<?> other_type) {
		// The validity of this cast should have been asserted in KernelType.unionWithMaxOfMaxes()
		DFEFix other_type_fix = (DFEFix)other_type;

		BigFloat max1 = ((HWOffsetFix)m_imp).getMax();
		BigFloat max2 = ((HWOffsetFix)(other_type_fix.m_imp)).getMax();

		BigFloat new_max = max1.max(max2);

		HWOffsetFix new_type = HWTypeFactory.hwFixMax(
			getTotalBits(),
			new_max,
			((HWOffsetFix)m_imp).getSignMode());

		return new DFEFix(new_type);
	}
}
