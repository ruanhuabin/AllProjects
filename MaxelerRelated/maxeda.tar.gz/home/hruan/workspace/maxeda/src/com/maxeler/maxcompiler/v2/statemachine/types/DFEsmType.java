package com.maxeler.maxcompiler.v2.statemachine.types;

public abstract class DFEsmType {
}
