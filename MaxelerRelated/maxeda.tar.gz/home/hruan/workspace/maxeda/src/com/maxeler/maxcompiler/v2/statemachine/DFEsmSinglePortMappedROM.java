package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.memory.MappedROM;
import com.maxeler.statemachine.memory.MemoryElement;

/**
 * @see DFEsmDualPortMappedROM
 */
public final class DFEsmSinglePortMappedROM extends DFEsmMappedROM {
	public final DFEsmMemAddress address;
	public final DFEsmValue dataOut;

	DFEsmSinglePortMappedROM(StateMachineLib stateMachine, String name, Latency latency, DFEsmValueType type, int depth) {
		super(1, name, latency, type, depth);

		MappedROM rom = getMappedROM();

		MemoryElement.Port port0 = rom.getPort(0);
		address = new DFEsmMemAddress(stateMachine, port0.address);
		dataOut = new DFEsmValue(port0.dataOut);
	}

}
