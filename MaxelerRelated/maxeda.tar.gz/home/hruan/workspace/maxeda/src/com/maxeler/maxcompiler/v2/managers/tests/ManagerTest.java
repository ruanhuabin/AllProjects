package com.maxeler.maxcompiler.v2.managers.tests;

import static com.maxeler.maxcompiler.v2.managers.standard.Manager.ALL_CPU;
import static com.maxeler.maxcompiler.v2.managers.standard.Manager.CPU;
import static com.maxeler.maxcompiler.v2.managers.standard.Manager.DRAM;
import static com.maxeler.maxcompiler.v2.managers.standard.Manager.IFPGA;
import static com.maxeler.maxcompiler.v2.managers.standard.Manager.LINEAR_1D;
import static com.maxeler.maxcompiler.v2.managers.standard.Manager.NOIO;
import static com.maxeler.maxcompiler.v2.managers.standard.Manager.STRIDE_2D;
import static com.maxeler.maxcompiler.v2.managers.standard.Manager.link;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.BuildConfig;
import com.maxeler.maxcompiler.v2.managers.BuildConfig.Level;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.MAX3BoardModel;
import com.maxeler.maxcompiler.v2.managers.standard.Manager;
import com.maxeler.maxcompiler.v2.managers.standard.Manager.NetworkConnection;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.networking.types.EthernetRXType;
import com.maxeler.networking.types.EthernetTXType;
import com.maxeler.networking.types.TCPType;
import com.maxeler.networking.types.UDPOneToManyRXType;
import com.maxeler.networking.types.UDPOneToOneRXType;
import com.maxeler.networking.types.UDPOneToOneTXType;

class TestKernel extends Kernel {
	protected TestKernel(KernelParameters p, int num_inputs, int num_outputs, int width) {
		super(p);
		DFEVar inputs[] = new DFEVar[num_inputs];
		DFEVar outputs[] = new DFEVar[num_outputs];
		flush.whenInputFinished("input1");
		for (int i = 0; i < num_inputs; i++)
			inputs[i] = io.input("input"+(i+1), dfeUInt(width));

		for (int i = 0; i < num_outputs; i++)
			outputs[i] = io.output("output"+(i+1), dfeUInt(width));

		if (num_inputs == num_outputs) {
			for (int i = 0; i < num_inputs; i++)
				outputs[i].connect(inputs[i]);
		} else {
			DFEVar reducedInput = inputs[0];
			for (int i = 1; i < num_inputs; i++)
				reducedInput = reducedInput.add(inputs[i]); // accumulate

			for (int i = 0; i < num_outputs; i++)
				outputs[i].connect(reducedInput);
		}

		logMsg("TestKernel built with %d inputs, %d outputs and width of %d", num_inputs, num_outputs, width);

	}
}

class NetworkTestKernel extends Kernel {
	protected NetworkTestKernel(KernelParameters p, int num_inputs, int num_outputs, int input_width, int output_width) {
		super(p);
		DFEVar inputs[] = new DFEVar[num_inputs];
		DFEVar outputs[] = new DFEVar[num_outputs];
		flush.whenInputFinished("input1");

		DFEVar reducedInput = null;

		for (int i = 0; i < num_inputs; i++) {
			inputs[i] = io.input("input"+(i+1), dfeUInt(input_width));
			if (reducedInput == null)
				reducedInput = inputs[i];
			else
				reducedInput = reducedInput + inputs[i];
		}

		for (int i = 0; i < num_outputs; i++) {
			outputs[i] = io.output("output"+(i+1), dfeUInt(output_width));
			outputs[i].connect(reducedInput.cast(outputs[i].getType()));
		}
	}
}

public class ManagerTest {

	public static void simulationTests() {
		SimulationManager m;
		Kernel k;

		// 1 input, 1 output
		System.out.println("SimulationManager test: 1 input, 1 output");
		m = new SimulationManager("SimulationManagerTest");
		k = new TestKernel(m.makeKernelParameters(), 1, 1, 32);
		m.setKernel(k);
		m.setInputData("input1", 1, 2, 3, 4, 5);
		m.runTest();
		m.checkOutputData("output1", 1, 2, 3, 4, 5);

		// 2 input, 2 output
		System.out.println("SimulationManager test: 2 input, 2 output");
		m = new SimulationManager("SimulationManagerTest");
		k = new TestKernel(m.makeKernelParameters(), 2, 2, 16);
		m.setKernel(k);
		m.setInputData("input1", 1, 2, 3, 4, 5);
		m.setInputData("input2", 10, 12, 14, 16, 18);

		m.runTest();
		m.checkOutputData("output1", 1, 2, 3, 4, 5);
		m.checkOutputData("output2", 10, 12, 14, 16, 18);

		// 2 input, 1 output
		System.out.println("SimulationManager test: 2 input, 1 output");

		m = new SimulationManager("SimulationManagerTest");
		k = new TestKernel(m.makeKernelParameters(), 2, 1, 64);
		m.setKernel(k);
		m.setInputData("input1", 1, 2, 3, 4, 5);
		m.setInputData("input2", 10, 12, 14, 16, 18);

		m.runTest();
		m.checkOutputData("output1", 11, 14, 17, 20, 23);

		// 1 input, 2 output
		System.out.println("SimulationManager test: 1 input, 2 output");

		m = new SimulationManager("SimulationManagerTest");
		k = new TestKernel(m.makeKernelParameters(), 1, 2, 32);
		m.setKernel(k);
		m.setInputData("input1", 1, 2, 3, 4, 5);

		m.runTest();
		m.checkOutputData("output1", 1, 2, 3, 4, 5);
		m.checkOutputData("output2", 1, 2, 3, 4, 5);
	}

	public static void buildTests(boolean testNoIO, boolean testPCIe, boolean testFull, boolean testNetwork) {
		Manager m;
		Kernel k;
		BuildConfig b = new BuildConfig(BuildConfig.Level.COMPILE_ONLY);

		boolean detectedFail = false;

		if (testNoIO) {
			// No I/O manager tests

			// Test MPPR
			System.out.println("Manager test: No I/O, 1 input, 1 output, MPPR");

			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 1, 1, 32);
			BuildConfig b2 = new BuildConfig(Level.FULL_BUILD);
			b2.setMPPRCostTableSearchRange(1, 2);
			b2.setMPPRParallelism(2);
			m.setBuildConfig(b2);
			m.setKernel(k);
			m.setIO(NOIO);
			m.build();

			System.out.println("Manager test: No I/O, 1 input, 1 output");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 1, 1, 32);
			m.setKernel(k);
			m.setIO(NOIO);
			m.build();

			System.out.println("Manager test: No I/O, 3 input, 10 output");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 3, 10, 64);
			m.setKernel(k);
			m.setIO(NOIO);
			m.build();
		}

		if (testPCIe) {
			// PCIe only manager tests: compile only
			System.out.println("Manager test: PCIe only, 3 input, 5 output");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 3, 5, 32);
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(ALL_CPU);
			m.build();

			System.out.println("Manager test: PCIe only, 4 input, 1 output");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 4, 1, 16);
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(ALL_CPU);
			m.build();

			System.out.println("Manager test: PCIe only, 1 input, 1 output with 20-bits (should fail with API exception)");
			detectedFail = false;
			try {
				m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
				k = new TestKernel(m.makeKernelParameters(), 1, 1, 20);
				m.setKernel(k);
				m.setBuildConfig(b);
				m.setIO(ALL_CPU);
				m.build();
			} catch (MaxCompilerAPIError e) {
				detectedFail = true;
				System.out.println("API error returned from compiler (GOOD): " + e);
			}
			if (!detectedFail) throw new RuntimeException("Test failure: should have triggered an API error");
		}

		if (testFull) {
			// Full manager tests: compile only
			System.out.println("Manager test: Full, 2 input, 2 output, with DRAM linear+stride");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 2, 2, 16);
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(link("input1", CPU), link("input2", DRAM(LINEAR_1D)), link("output1", CPU), link("output2", DRAM(STRIDE_2D)));
			m.build();

			System.out.println("Manager test: Full, 2 input, 3 output, with DRAM linear+blocking");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 2, 3, 16);
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(link("input1", CPU), link("input2", DRAM(LINEAR_1D)), link("output1", CPU), link("output2", DRAM(STRIDE_2D)), link("output3", DRAM(Manager.BLOCKING_3D)));
			m.build();

			System.out.println("Manager test: Full, 3 input, 3 output, with DRAM linear + IFPGA");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 3, 3, 16);
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(link("input1", CPU), link("input2", DRAM(LINEAR_1D)), link("input3", IFPGA),
					link("output1", CPU), link("output2", DRAM(LINEAR_1D)), link("output3", IFPGA));
			m.build();

			System.out.println("Manager test: Full, 3 input, 3 output, with DRAM linear + IFPGA with 320-bit inputs (should fail with API exception from DRAM)");
			detectedFail = false;
			try {
				m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
				k = new TestKernel(m.makeKernelParameters(), 3, 3, 320);
				m.setKernel(k);
				m.setBuildConfig(b);
				m.setIO(link("input1", CPU), link("input2", DRAM(LINEAR_1D)), link("input3", IFPGA),
					link("output1", CPU), link("output2", DRAM(LINEAR_1D)), link("output3", IFPGA));
				m.build();
			} catch (MaxCompilerAPIError e) {
				if (e.toString().contains("DRAM")) {
					detectedFail = true;
					System.out.println("API error returned from compiler (GOOD): " + e);
				} else
					System.out.println("Incorrect API error returned from compiler: " + e);
			}
			if (!detectedFail) throw new RuntimeException("Test failure: should have triggered an API error");

			System.out.println("Manager test: Full, 1 input, 1 output, just to IFPGA (should fail with API exception due to missing PCIe streams)");
			detectedFail = false;
			try {
				m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
				k = new TestKernel(m.makeKernelParameters(), 1, 1, 32);
				m.setKernel(k);
				m.setBuildConfig(b);
				m.setIO(link("input1", IFPGA),
					link("output1", IFPGA));
				m.build();
			} catch (MaxCompilerAPIError e) {
				if (e.toString().contains("least one input")) {
					detectedFail = true;
					System.out.println("API error returned from compiler (GOOD): " + e);
				} else
					System.out.println("Incorrect API error returned from compiler: " + e);
			}
			if (!detectedFail) throw new RuntimeException("Test failure: should have triggered an API error");
			System.out.println("");

			System.out.println("Manager test: Full, 1 input, 1 output, just to DRAM");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX2BoardModel.MAX2116B, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			k = new TestKernel(m.makeKernelParameters(), 1, 1, 32);
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(link("input1", DRAM(LINEAR_1D)), link("output1", DRAM(LINEAR_1D)));
			m.build();
		}

		if (testNetwork) {
			// Simple single protocol configurations
			System.out.println("Manager test: ETHERNET");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 1, 1, new EthernetRXType().getTotalBits(),  new EthernetTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
				link("output1", Manager.ETHERNET(NetworkConnection.CH2_SFP2)));
			m.build();

			System.out.println("Manager test: UDP");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 1, 1, new UDPOneToOneRXType().getTotalBits(), new UDPOneToOneTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToOne)),
				link("output1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToOne)));
			m.build();

			System.out.println("Manager test: TCP");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 1, 1,  new TCPType().getTotalBits(), new TCPType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.TCP(NetworkConnection.CH2_SFP2)),
				link("output1", Manager.TCP(NetworkConnection.CH2_SFP2)));
			m.build();

			// Different protocols on both SFPs
			System.out.println("Manager test: ETHERNET / UDP single");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new EthernetRXType().getTotalBits(), new EthernetTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("output1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("input2", Manager.ETHERNET(NetworkConnection.CH2_SFP2)),
				link("output2", Manager.ETHERNET(NetworkConnection.CH2_SFP2)));
			m.build();

			System.out.println("Manager test: ETHERNET / TCP single");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new EthernetRXType().getTotalBits(), new EthernetTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("output1", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("input2", Manager.ETHERNET(NetworkConnection.CH2_SFP2)),
				link("output2", Manager.ETHERNET(NetworkConnection.CH2_SFP2)));
			m.build();

			System.out.println("Manager test: UDP / TCP single");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new EthernetRXType().getTotalBits(), new EthernetTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("output1", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("input2", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
				link("output2", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)));
			m.build();

/* Not supported yet
			// Multiple protocols on SFPs
			System.out.println("Manager test: ETHERNET / UDP / TCP multi");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A);
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 3, 3, EthernetTypes.rxType.getTotalBits(), EthernetTypes.txType.getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("output1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("input2", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
				link("output2", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
				link("input3", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("output3", Manager.TCP(NetworkConnection.CH2_SFP1)));
			m.build();

			System.out.println("Manager test: UDP / TCP multi");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A);
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, EthernetTypes.rxType.getTotalBits(), EthernetTypes.txType.getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
				link("output1", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
				link("input2", Manager.TCP(NetworkConnection.CH2_SFP2)),
				link("output2", Manager.TCP(NetworkConnection.CH2_SFP2)));
			m.build();

			System.out.println("Manager test: ETHERNET / UDP / TCP both SFPs");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A);
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 6, 6, EthernetTypes.rxType.getTotalBits(), EthernetTypes.txType.getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("output1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("input2", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
				link("output2", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
				link("input3", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("output3", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("input4", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
				link("output4", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
				link("input5", Manager.ETHERNET(NetworkConnection.CH2_SFP2)),
				link("output5", Manager.ETHERNET(NetworkConnection.CH2_SFP2)),
				link("input6", Manager.TCP(NetworkConnection.CH2_SFP2)),
				link("output6", Manager.TCP(NetworkConnection.CH2_SFP2)));
			m.build();
*/

			// Same protocol, different SFP
			System.out.println("Manager test: ETHERNET / ETHERNET");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new EthernetRXType().getTotalBits(), new EthernetTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
				link("output1", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
				link("input2", Manager.ETHERNET(NetworkConnection.CH2_SFP2)),
				link("output2", Manager.ETHERNET(NetworkConnection.CH2_SFP2)));
			m.build();

			System.out.println("Manager test: UDP / UDP");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new UDPOneToManyRXType().getTotalBits(), new EthernetTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("output1", Manager.UDP(NetworkConnection.CH2_SFP1, Manager.UDPConnectionMode.OneToMany)),
				link("input2", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
				link("output2", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)));
			m.build();

			System.out.println("Manager test: TCP / TCP");
			m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
			m.setAllowNonMultipleTransitions(true);
			k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new TCPType().getTotalBits(), new EthernetTXType().getTotalBits());
			m.setKernel(k);
			m.setBuildConfig(b);
			m.setIO(
				link("input1", Manager.TCP(NetworkConnection.CH2_SFP2)),
				link("output1", Manager.TCP(NetworkConnection.CH2_SFP2)),
				link("input2", Manager.TCP(NetworkConnection.CH2_SFP1)),
				link("output2", Manager.TCP(NetworkConnection.CH2_SFP1)));
			m.build();

			// Same protocol, same SFP --> should throw exception.
			detectedFail = false;
			try {
				System.out.println("Manager test: ETHERNET / ETHERNET exception");
				m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
				m.setAllowNonMultipleTransitions(true);
				k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new EthernetRXType().getTotalBits(), new EthernetTXType().getTotalBits());
				m.setKernel(k);
				m.setBuildConfig(b);
				m.setIO(
					link("input1", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
					link("output1", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
					link("input2", Manager.ETHERNET(NetworkConnection.CH2_SFP1)),
					link("output2", Manager.ETHERNET(NetworkConnection.CH2_SFP1)));
				m.build();
			}
			catch (MaxCompilerAPIError e) {
				if (e.toString().contains("cannot have more that one")) {
					detectedFail = true;
					System.out.println("API error returned from compiler (GOOD): " + e);
				} else
					System.out.println("Incorrect API error returned from compiler: " + e);
			}
			if (!detectedFail) throw new RuntimeException("Test failure: should have triggered an API error");

			detectedFail = false;
			try {
				System.out.println("Manager test: UDP / UDP exception");
				m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
				m.setAllowNonMultipleTransitions(true);
				k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new UDPOneToManyRXType().getTotalBits(), new EthernetTXType().getTotalBits());
				m.setKernel(k);
				m.setBuildConfig(b);
				m.setIO(
					link("input1", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
					link("output1", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
					link("input2", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)),
					link("output2", Manager.UDP(NetworkConnection.CH2_SFP2, Manager.UDPConnectionMode.OneToMany)));
				m.build();
			}
			catch (MaxCompilerAPIError e) {
				if (e.toString().contains("cannot have more that one")) {
					detectedFail = true;
					System.out.println("API error returned from compiler (GOOD): " + e);
				} else
					System.out.println("Incorrect API error returned from compiler: " + e);
			}
			if (!detectedFail) throw new RuntimeException("Test failure: should have triggered an API error");

			detectedFail = false;
			try {
				System.out.println("Manager test: TCP / TCP exception");
				m = new Manager(new _EngineParameters("ManagerBuildTest", MAX3BoardModel.MAX3424A, EngineParameters.Target.MAXFILE_FOR_HARDWARE));
				m.setAllowNonMultipleTransitions(true);
				k = new NetworkTestKernel(m.makeKernelParameters(), 2, 2, new TCPType().getTotalBits(), new EthernetTXType().getTotalBits());
				m.setKernel(k);
				m.setBuildConfig(b);
				m.setIO(
					link("input1", Manager.TCP(NetworkConnection.CH2_SFP1)),
					link("output1", Manager.TCP(NetworkConnection.CH2_SFP1)),
					link("input2", Manager.TCP(NetworkConnection.CH2_SFP1)),
					link("output2", Manager.TCP(NetworkConnection.CH2_SFP1)));
				m.build();
			}
			catch (MaxCompilerAPIError e) {
				if (e.toString().contains("cannot have more that one")) {
					detectedFail = true;
					System.out.println("API error returned from compiler (GOOD): " + e);
				} else
					System.out.println("Incorrect API error returned from compiler: " + e);
			}
			if (!detectedFail) throw new RuntimeException("Test failure: should have triggered an API error");
		}
	}

	public static void main(String[] args) {
		System.out.printf("Running test of standard Manager and SimulationManager\n\n");
		//simulationTests();
		buildTests(false, false, false, true);
		System.out.printf("\n\n\n ALL TESTS COMPLETE \n\n\n");
	}
}
