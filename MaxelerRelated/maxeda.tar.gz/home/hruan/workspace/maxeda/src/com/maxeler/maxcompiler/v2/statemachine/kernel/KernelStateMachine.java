package com.maxeler.maxcompiler.v2.statemachine.kernel;

import com.maxeler.maxcompiler.v2.kernelcompiler.KernelLib;
import com.maxeler.maxcompiler.v2.statemachine.StateMachine;

public abstract class KernelStateMachine extends StateMachine {
	/** Library for creating inputs and outputs. */
	public final KernelIO io;

	protected KernelStateMachine(KernelLib owner) {
		super(owner.getManager());
		io = new KernelIO(this);
	}
}
