package com.maxeler.maxcompiler.v2.managers.custom;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import com.maxeler.maxcompiler.v0.kernelcompiler.KernelDesign;
import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._KernelConfiguration;
import com.maxeler.maxcompiler.v2.managers.BuildConfig;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.MAX3BoardModel;
import com.maxeler.maxcompiler.v2.managers.MAXBoardModel;
import com.maxeler.maxcompiler.v2.managers._BuildConfig;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxcompiler.v2.managers.custom._ManagerSimulator.ManagerSimType;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.CustomHDLBlock;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.CustomHDLNode;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.Demux;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.Fanout;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.KernelBlock;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.Mux;
import com.maxeler.maxcompiler.v2.managers.custom.blocks.StateMachineBlock;
import com.maxeler.maxcompiler.v2.managers.custom.blocks._ManagerBlocks;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.DebugLevel;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.Max2RingConnection;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.Max3RingConnection;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MaxRingBidirectionalStream;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MaxRingConnection;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControlGroup;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControlGroup.MemoryAccessPattern;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib.MemoryControllerConfig;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib._BoardIOInterface;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib._MAX2BoardIOInterface;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib._MAX3ComputeIOInterface;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib._MAX3InterfaceIOInterface;
import com.maxeler.maxcompiler.v2.managers.custom.stdlib._ManagerStdlib;
import com.maxeler.maxcompiler.v2.managers.engine_interfaces.EngineInterface;
import com.maxeler.maxcompiler.v2.statemachine.manager.ManagerStateMachine;
import com.maxeler.maxcompilersim.AddSimObjectToMaxFilePass;
import com.maxeler.maxcompilersim.SimCompilePass;
import com.maxeler.maxcompilersim.SimCompilePass.Mode;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.Entity;
import com.maxeler.maxdc.GenerateMaxFileDataFile;
import com.maxeler.maxdc.MaxFileManager;
import com.maxeler.maxdc.MaxFileXMacros;
import com.maxeler.maxdc.Platform;
import com.maxeler.maxdc.xilinx.Virtex6Part;
import com.maxeler.maxdc.xilinx.XilinxPlatform;
import com.maxeler.maxeleros.MappedElementsInfo;
import com.maxeler.maxeleros.MappedElementsManager;
import com.maxeler.maxeleros.MaxelerOSPlatform;
import com.maxeler.maxeleros.managerblocks.Flushing;
import com.maxeler.maxeleros.managerblocks.TinyFIFO;
import com.maxeler.maxeleros.managercompiler.core.NodeImplementationManager;
import com.maxeler.maxeleros.managercompiler.core.UserMaxDCPass;
import com.maxeler.maxeleros.managercompiler.core.WrapperClock;
import com.maxeler.maxeleros.managercompiler.core.WrapperCompileManager;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignData;
import com.maxeler.maxeleros.managercompiler.core.WrapperDesignEntity;
import com.maxeler.maxeleros.managercompiler.core.WrapperNode;
import com.maxeler.maxeleros.managercompiler.hw.MAX3InterfaceFPGAManager;
import com.maxeler.maxeleros.managercompiler.libs.AsymmetricInterChipDefinition;
import com.maxeler.maxeleros.managercompiler.libs.AsymmetricInterChipDefinition.AIStream;
import com.maxeler.maxeleros.managercompiler.libs.FPGAWrapperEntity;
import com.maxeler.maxeleros.managercompiler.libs.PCIExpressDefinition;
import com.maxeler.maxeleros.managercompiler.libs.PCIExpressDefinition.PCIeStream;
import com.maxeler.maxeleros.managercompiler.libs.PhotonFactory;
import com.maxeler.maxeleros.managercompiler.libs.StreamRoutingFactory;
import com.maxeler.maxeleros.managercompiler.libs.TimestampingIOFactory.TimestampingIOFormat;
import com.maxeler.maxeleros.managercompiler.libs.WrapperDefinition;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeFileSink;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeFileSource;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeMemoryControllerPro;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodePhoton;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeStateMachine;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodeV0Photon;
import com.maxeler.maxeleros.platforms.BoardCapabilities;
import com.maxeler.maxeleros.platforms.MAX2Board;
import com.maxeler.maxeleros.platforms.MAX2Board.MAX2BoardCapabilities;
import com.maxeler.maxeleros.platforms.MAX3Board.MAX3BoardCapabilities;
import com.maxeler.maxeleros.platforms.MAX3ComputeFPGA;
import com.maxeler.maxeleros.platforms.MAX3InterfaceFPGA;
import com.maxeler.photon.compile_managers.HDLSimCompileManager;
import com.maxeler.photon.compile_managers.MaxDCCompileManager;
import com.maxeler.photon.compile_managers.SoftwareSimCompileManager;
import com.maxeler.photon.configuration.MaxBoardModel;
import com.maxeler.photon.configuration.PhotonKernelConfiguration.BuildTarget;
import com.maxeler.photon.core.PhotonCompileManager.Factory;
import com.maxeler.photon.core.PhotonIOInformation;
import com.maxeler.photon.input_arbitration.ArbitratedInput;
import com.maxeler.photon.input_arbitration.InputArbitrator;
import com.maxeler.photon.maxcompilersim.formatterBitAccurate.FormatterBitAccurate;
import com.maxeler.utils.MaxCompilerHide;


public class CustomManager extends DFEManager {
	public enum Target {
		HDL_SIMULATION,
		MAXFILE_FOR_SIMULATION,
		MAXFILE_FOR_HARDWARE;

		private static Target get(EngineParameters configuration) {
			switch (configuration.getTarget()) {
				case HDL_SIMULATION:
					return Target.HDL_SIMULATION;
				case MAXFILE_FOR_HARDWARE:
					return Target.MAXFILE_FOR_HARDWARE;
				case MAXFILE_FOR_SIMULATION:
					return Target.MAXFILE_FOR_SIMULATION;
				default:
					throw new MaxCompilerInternalError("Unknown build target '%s'.", configuration.getTarget().toString());
			}
		}
	}

	public enum DRAMFrequency {
		MAX2_200(200.0, MAX2BoardModel.MAX24412C),
		MAX2_250(250.0, MAX2BoardModel.MAX24412C),
		MAX2_300(300.0, MAX2BoardModel.MAX24412C),
		MAX3_333(333.333333, MAX3BoardModel.MAX3424A),
		MAX3_350(350.0, MAX3BoardModel.MAX3424A),
		MAX3_300(300.0, MAX3BoardModel.MAX3424A),
		MAX3_400(400.0, MAX3BoardModel.MAX3424A);

		private final double frequency;
		private final MAXBoardModel board_model;
		DRAMFrequency(double frequency, MAXBoardModel board_type) {
			this.frequency = frequency;
			this.board_model = board_type;
		}

		double frequency() {
			return frequency;
		}

		BoardCapabilities board_type() {
			return _Managers.getBoardCapabilities(board_model);
		}
	}

	private static final int m_default_app_id = 0;
	private static final int m_default_rev_id = 0;
	private static final int m_maximum_memory_streams = 15;

	private WrapperDesignData m_data;
	private StreamRoutingFactory m_routing;
	private _BoardIOInterface m_board_io;
	private PhotonFactory m_photon_factory;
	private WrapperClock m_default_stream_clock;
	private final Stack<ManagerClock> m_default_clock_stack = new Stack<ManagerClock>();

	private BoardCapabilities m_board_capabilties;

	private FPGAWrapperEntity m_wrapper;

	private boolean m_enable_stream_status = false;
	private boolean m_address_generators_in_slow_clock = false;

	private static final int m_default_stream_clock_frequency = 100;

	private int m_num_memory_streams = 0;

	private enum MemoryDirection {
		READ_FROM_MEMORY,
		WRITE_TO_MEMORY
	};

	private final LinkedList<MemoryControlGroup> m_memory_control_groups =
		new LinkedList<MemoryControlGroup>();
	private final Map<String, MemoryDirection> m_memory_stream_direction =
		new LinkedHashMap<String, MemoryDirection>();

	public class Debug {
		private Debug() {
		}

		public void setDebugLevel(DebugLevel debug_level) {
			m_enable_stream_status = debug_level.hasStreamStatus();
			m_data.setDebugLevel(debug_level);
		}

		public DFELink streamStatus(DFELink to_probe, boolean checksum) {
			_CustomManagers.streamToImp(to_probe).enableStreamStatus(checksum);
			return to_probe;
		}
	}

	public class Config {
		private Config() {
		}

		public void setDefaultStreamClockFrequency(int freq_mhz) {
			m_default_stream_clock.setRate(freq_mhz);
		}

		public void setForwardResetsOverIFPGALink(boolean should_forward) {
			m_data.setForwardResetsOverIFPGALink(should_forward);
		}

		public void setApplicationRevisionIds(int app_id, int rev_id) {
			m_data.setApplicationRevisionIds(app_id, rev_id);
		}

		public void setNumberOfPCIExpressLanes(int num_lanes) {
			m_board_io.setNumberOfPCIExpressLanes(num_lanes);
		}

		public void setEnablePCIExpressFastClock(boolean fast_clock) {
			m_board_io.setEnablePCIExpressFastClock(fast_clock);
		}

		public void setMaxRingNumLanes(Max2RingConnection connection, int num_lanes) {
			m_board_io.setMaxRingNumLanes(connection, num_lanes);
		}

		public void setMaxRingNumLanes(Max3RingConnection connection, int num_lanes) {
			m_board_io.setMaxRingNumLanes(connection, num_lanes);
		}

		public void setMaxRingNumLanes(MaxRingConnection connection, int num_lanes) {
			m_board_io.setMaxRingNumLanes(connection, num_lanes);
		}

		public void setMemoryControllerConfig(MemoryControllerConfig config) {
			m_data.setMemoryControllerConfig(config);
			m_board_io.setMemoryControllerConfig(config);
		}

		public void setEnableAddressGeneratorsInSlowClock(boolean enable) {
			m_address_generators_in_slow_clock = enable;
		}

		public void setAllowNonMultipleTransitions(boolean enable) {
			m_data.setAllowNonMultipleTransitions(enable);
		}

		public void setOnCardMemoryFrequency(double freq_mhz) {
			m_board_io.setOnCardMemoryFrequency(freq_mhz);
		}

		public void setOnCardMemoryFrequency(DRAMFrequency clock) {
			if ((m_board_capabilties instanceof MAX2BoardCapabilities &&
				clock.board_type() instanceof MAX2BoardCapabilities) ||
				(m_board_capabilties instanceof MAX3BoardCapabilities &&
				clock.board_type() instanceof MAX3BoardCapabilities)) {
					m_board_io.setOnCardMemoryFrequency(clock.frequency());
			} else {
				throw new MaxCompilerAPIError("DRAMFrequency " + clock.toString() +
					" is not supported for this board type");
			}

		}

		public void setStreamToCPUMaxNumber(int num) {
			if(!(m_board_io instanceof _MAX3ComputeIOInterface)) {
				throw new MaxCompilerAPIError("Custom maximum number of streams to CPU is not supported for this board type");
			}
			_MAX3ComputeIOInterface board_io = (_MAX3ComputeIOInterface)m_board_io;
			board_io.setStreamToCPUMaxNum(num);
		}

		public void setStreamFromCPUMaxNumber(int num) {
			if(!(m_board_io instanceof _MAX3ComputeIOInterface)) {
				throw new MaxCompilerAPIError("Custom maximum number of streams from CPU is not supported for this board type");
			}
			_MAX3ComputeIOInterface board_io = (_MAX3ComputeIOInterface)m_board_io;
			board_io.setStreamFromCPUMaxNum(num);
		}

		public void setPipelinedComputeController(boolean enable) {
			m_data.setPipelinedComputeControllerEnabled(enable);
		}
	}


	public class _SimulationOptions {
		private _SimulationOptions() {}

		public void setUseNativeFloatTypes (boolean on) {
			m_data.getSimulationOptions().native_floating_point = on;
		}

		public boolean getUseNativeFloatTypes() {
			return m_data.getSimulationOptions().native_floating_point;
		}
	}

	public class _Config extends Config {

		public _SimulationOptions simulation = new _SimulationOptions();

		public void setImplementationManager(NodeImplementationManager mgr) {
			m_data.setImplementationManager(mgr);
		}

		public void setEnablePCIExpressSlaveStreaming(boolean slave_streaming) {
			if(!(m_board_io instanceof _MAX3InterfaceIOInterface)) {
				throw new MaxCompilerAPIError("PCIe Slave Interface cannot be enabled on this type of board");
			}
			_MAX3InterfaceIOInterface board_io = (_MAX3InterfaceIOInterface)m_board_io;
			board_io.setEnablePCIExpressSlaveStreaming(slave_streaming);
		}

		public void setSystemJitter(int picoseconds) {
			if(!(m_board_io instanceof _MAX3ComputeIOInterface)) {
				throw new MaxCompilerAPIError("Custom system jitter is not supported for this board type");
			}
			_MAX3ComputeIOInterface board_io = (_MAX3ComputeIOInterface)m_board_io;
			board_io.setSystemJitter(picoseconds);
		}

		public void setMultiCycleMappedMemories(boolean enableMultiCycle) {
			m_data.setMultiCycleMappedMemBusEnabled(enableMultiCycle);
		}

		public void forcePCIeGen1Capability(boolean force_gen1) {
			if(!(m_board_io instanceof _MAX3InterfaceIOInterface)) {
				throw new MaxCompilerAPIError("Forcing PCIe capability to Gen1 is not supported for this board type");
			}
			_MAX3InterfaceIOInterface board_io = (_MAX3InterfaceIOInterface)m_board_io;
			board_io.forcePCIeGen1Capability(force_gen1);
		}
	}

	public final Config config = new _Config();
	public final Debug debug = new Debug();

	private String m_name;
	private boolean m_simulate_in_modelsim;
	private _ManagerSimulator m_manager_sim = null;
	private HDLTestBench m_sim_transactor = null;

	/**
	 * See {@link #CustomManager(EngineParameters)}.
	 *
	 * @param board_model
	 * @param name
	 * @deprecated
	 */
	@Deprecated
	public CustomManager(
		MAXBoardModel board_model,
		String name)
	{
		this(board_model, name, Target.MAXFILE_FOR_HARDWARE);
	}

	/**
	 * The use of this constructor is discouraged. See {@link #CustomManager(EngineParameters)}.
	 *
	 * @param board_model
	 * @param name
	 * @param target
	 */
	@Deprecated
	public CustomManager(
		MAXBoardModel board_model,
		String name,
		Target target)
	{
		this(target != Target.MAXFILE_FOR_HARDWARE, board_model, name, true, target == Target.HDL_SIMULATION);
	}

	/**
	 * Creates a new CustomManager with a given configuration.
	 * The constructor will call {@code logParameters} and
	 * {@code writeParametersToMaxFile} on the configuration object.
	 *
	 * @param configuration configuration for this manager.
	 */
	public CustomManager(EngineParameters configuration) {
		this (configuration.getBoard(),
		      configuration.getMaxFileName(),
		      configuration.getBuildName(),
		      Target.get(configuration));
		configuration.logParameters(this);
		configuration.writeParametersToMaxFile(this);
	}

	/**
	 * CustomManager constructor.
	 * The use of this constructor is discouraged. See {@link #CustomManager(EngineParameters)}.
	 * @param board_model board targeted by the build
	 * @param name name of the build, used in naming the maxfile and the generated
	 *        function of the SLiC interface
	 * @param build_directory directory in which the build happens (see {@link #BuildManager(String,String,boolean,String)}
	 * @param target target if the build (see {@link #Target}
	 */
	@Deprecated
	public CustomManager(
		MAXBoardModel board_model,
		String name,
		String build_directory,
		Target target)
	{
		//this(target != Target.MAXFILE_FOR_HARDWARE, board_model, name, true, target == Target.HDL_SIMULATION);
		this(target != Target.MAXFILE_FOR_HARDWARE,
			board_model,
			name,
			build_directory,
			true,
			target == Target.HDL_SIMULATION);
	}

	/**
	 * The use of this constructor is discouraged. See {@link #CustomManager(EngineParameters)}.
	 *
	 * @param board_model
	 * @param name
	 * @deprecated
	 */
	@Deprecated
	public CustomManager(
		boolean generate_max_file_for_simulation,
		MAXBoardModel board_model,
		String name)
	{
		super(name, generate_max_file_for_simulation, board_model);

		fullConstructor(_Managers.getBoardCapabilities(board_model), true, false);
	}

	@MaxCompilerHide
	public CustomManager(
		boolean generate_max_file_for_simulation,
		BoardCapabilities board_caps,
		String name,
		boolean use_mapped_elements_controller,
		boolean simulate_in_modelsim)
	{
		// as we must not create a protected constructor with BoardCapabilities
		// in DFEManager, we need to do this hack:
		MaxBoardModel board_model = MaxBoardModel.get(board_caps);
		_KernelConfiguration.setBoardModel(
			_Managers.getKernelConfiguration(this),
			board_model);

		setBuildConfig(new _BuildConfig(BuildConfig.Level.FULL_BUILD));

		if (simulate_in_modelsim) {
			simConstructor(
				board_caps.getMajorVersion() == 3,
				new File(name).getName(),
				name,
				use_mapped_elements_controller,
				null);
		} else {
			_Managers.forceBuildManager(this, new BuildManager(name, generate_max_file_for_simulation), null);
		}

		fullConstructor(board_caps, use_mapped_elements_controller, simulate_in_modelsim);
	}

	private void simConstructor(
		boolean is_max3,
		String name,
		String build_directory,
		boolean use_mec,
		MAXBoardModel board_model)
	{
		if (is_max3) {
			m_manager_sim = new _ManagerSimulator(name, build_directory, ManagerSimType.MAX3);
			_HDLTestBench compute = new _HDLTestBench("compute", m_manager_sim);
			_HDLTestBench iface = new _HDLTestBench("interface", m_manager_sim);
			iface.setManager(new MAX3InterfaceFPGAManager(iface.getBuildManager(), use_mec, true));
			compute.setManager(this);
			_Managers.forceBuildManager(this, compute.getBuildManager(), board_model);
			iface.setForwardedManager(this);
			m_sim_transactor = iface;
		} else {
			m_manager_sim = new _ManagerSimulator(name, build_directory, ManagerSimType.MAX2_SINGLEFPGA);
			_HDLTestBench sim = new _HDLTestBench("max2fpga", m_manager_sim);
			sim.setManager(this);
			_Managers.forceBuildManager(this, sim.getBuildManager(), board_model);
			m_sim_transactor = sim;
		}
	}

	@MaxCompilerHide
	@Deprecated
	protected CustomManager(
		boolean generate_max_file_for_simulation,
		MAXBoardModel board_model,
		String name,
		String build_directory,
		boolean use_mapped_elements_controller,
		boolean simulate_in_modelsim)
	{
		setBuildConfig(new _BuildConfig(BuildConfig.Level.FULL_BUILD));

		if(simulate_in_modelsim)
			simConstructor(
				board_model instanceof MAX3BoardModel,
				name,
				build_directory,
				use_mapped_elements_controller,
				board_model);
		else
			_Managers.forceBuildManager(this, new BuildManager(name, build_directory, generate_max_file_for_simulation), board_model);

		fullConstructor(_Managers.getBoardCapabilities(board_model), use_mapped_elements_controller, simulate_in_modelsim);
	}

	@MaxCompilerHide
	public CustomManager(
		boolean generate_max_file_for_simulation,
		MAXBoardModel board_model,
		String name,
		boolean use_mapped_elements_controller,
		boolean simulate_in_modelsim)
	{
		this(generate_max_file_for_simulation,
			board_model,
			new File(name).getName(),
			name,
			use_mapped_elements_controller,
			simulate_in_modelsim);
	}

	// constructor previously used for modelsim simulation
	@MaxCompilerHide
	public CustomManager(
		BuildManager build_manager,
		BoardCapabilities board_caps,
		boolean use_mapped_elements_controller,
		boolean simulate_in_modelsim)
	{
		_Managers.forceBuildManager(this, build_manager, null);
		fullConstructor(
			board_caps,
			use_mapped_elements_controller,
			simulate_in_modelsim);
	}

	void fullConstructor(
		BoardCapabilities board_caps,
		boolean use_mapped_elements_controller,
		boolean simulate_in_modelsim)
	{
		if (!use_mapped_elements_controller)
			throw new MaxCompilerAPIError("Building without the Mapped Elements Controller is deprecated in MaxCompiler 2011.3 and later.");
		m_name = _getBuildManager().getBuildName();
		m_data = new WrapperDesignData(
			_getBuildManager(),
			"Manager_" + m_name,
			m_default_app_id,
			m_default_rev_id,
			use_mapped_elements_controller,
			simulate_in_modelsim);

		m_simulate_in_modelsim = simulate_in_modelsim;

		Factory compileFactory = null;
		if (isTargetSimulation()) {
			if (simulate_in_modelsim)
				compileFactory = new HDLSimCompileManager.Factory();
			else
				compileFactory = new SoftwareSimCompileManager.Factory(new FormatterBitAccurate.Factory());
		} else
			compileFactory = new MaxDCCompileManager.Factory();

		_Managers.setCompileManagerFactory(this, compileFactory);

		m_board_capabilties = board_caps;

		Platform<?, ?> platform;
		if(!_getBuildManager().hasPlatformSet()) {
			platform = m_board_capabilties.getPlatform();
			_getBuildManager().setPlatform(platform);
		} else
			platform = _getBuildManager().getPlatform();

		if(this instanceof UserMaxDCPass)
			m_data.addUserMaxDCPass((UserMaxDCPass)this);

		m_routing = new StreamRoutingFactory(m_data);
		m_photon_factory = new PhotonFactory(m_data);

		m_default_stream_clock =
			m_data.generateStreamClock("STREAM", m_default_stream_clock_frequency);
		m_default_clock_stack.push(new ManagerClock(m_default_stream_clock));

		if (platform instanceof MAX2Board) {
			m_board_io = new _MAX2BoardIOInterface(m_data, (MAX2Board) platform, m_default_stream_clock);
		} else if (platform instanceof MAX3InterfaceFPGA) {
			m_board_io = new _MAX3InterfaceIOInterface(m_data, (MAX3InterfaceFPGA) platform, m_default_stream_clock);
		} else if (platform instanceof MAX3ComputeFPGA) {
			m_board_io = new _MAX3ComputeIOInterface(m_data, (MAX3ComputeFPGA) platform, m_default_stream_clock);
		} else {
			throw new MaxCompilerAPIError(this, "Unknown platform specified for manager design");
		}

		if (isTargetSimulation()) {
			if (simulate_in_modelsim)
				_KernelConfiguration.setBuildTarget(m_kernel_configuration, BuildTarget.HDL_SIM);
			else
				_KernelConfiguration.setBuildTarget(m_kernel_configuration, BuildTarget.MAXCOMPILERSIM_HOST_DRIVEN);
		}
		else {
			if (XilinxPlatform.get(_getBuildManager()).getFPGAPart() instanceof Virtex6Part)
				_KernelConfiguration.setBuildTarget(m_kernel_configuration, BuildTarget.HW_BUILD_VIRTEX6);
			else
				_KernelConfiguration.setBuildTarget(m_kernel_configuration, BuildTarget.HW_BUILD_VIRTEX5);
		}
	}

	@MaxCompilerHide
	public void forceBuildName_hackForMAX3InterfaceFPGA(String name) {
		m_name = name;
	}

	@MaxCompilerHide
	public void setDisableModelsimLogEverything(boolean disabled) {
		getManagerSimulator().setDisableLogEverything(disabled);
	}

	@MaxCompilerHide
	public void setEnableUseGlbl(boolean enabled) {
		getManagerSimulator().setEnableUseGlbl(enabled);
	}

	private BuildManager _getBuildManager() {
		return _Managers.getBuildManager(this);
	}

	public ManagerClock generateStreamClock(String name, int freq_mhz) {
		return new ManagerClock(m_data.generateStreamClock(name, freq_mhz));
	}

	Entity buildSim(String fpga_name) {
		FPGAWrapperEntity wrapper = buildInternal();

		Entity top = m_board_capabilties.createSimTop(
			fpga_name,
			_getBuildManager(),
			wrapper,
			m_data.getTopLevelParameterisation());

		return top;
	}

	@MaxCompilerHide
	public _BoardIOInterface getBoardIOInterface() {
		return m_board_io;
	}

	private void buildCPUCodeSim() {
		preBuildOperations();

		WrapperCompileManager manager = new WrapperCompileManager(m_data);
		manager.setEnableStreamStatus(m_enable_stream_status);
		manager.setEnableStreamStatusChecksums(m_data.getDebugLevel().hasStreamStatusChecksums());

		manager.buildHostCodeSim();

		// keep the code below in sync with code found in buildInternal()!
		if (m_memory_control_groups.size() != 0)//  m_data.m_simulated_memory_controller != null)
		{
			// ... for memory controller as a whole
			// FIXME! multiple memory controllers...
			int bzise = m_data.getMemoryControllerConfig().getBurstSize();
			int blength = m_data.getBuildManager().getPlatform() instanceof MAX3ComputeFPGA ? (bzise==8 ? 384 : 192) :96;
			if (m_data.getMemoryControllerConfig().getMAX2CompatibilityMode())
				blength /= 4;

			if (!m_memory_control_groups.isEmpty()) {
				MaxFileXMacros mem_macro = new MaxFileXMacros("MANAGER_MEMCTL");
				MaxFileManager.getMaxFileManager(_getBuildManager()).addMaxFileDataSegment(mem_macro);
				mem_macro.addMacro(
					_ManagerStdlib.getMemoryControlGroupControllerName(m_memory_control_groups.get(0)),
					WrapperNodeMemoryControllerPro.defaultName + ".MemoryControllerPro",
					blength);
			}

			// ... for control groups
			MaxFileXMacros memctrl_macros = new MaxFileXMacros("MANAGER_MEMCTL_CONTROL_GROUP");
			MaxFileManager.getMaxFileManager(_getBuildManager()).addMaxFileDataSegment(memctrl_macros);

			for (MemoryControlGroup grp : m_memory_control_groups) {
				memctrl_macros.addMacro(
					_ManagerStdlib.getMemoryControlGroupControllerName(grp),
					_ManagerStdlib.getMemoryControlGroupName(grp),
					"addrgen_" + _ManagerStdlib.getMemoryControlGroupName(grp) + ".",
					_ManagerStdlib.getMemoryControlGroupType(grp));
			}

			// ... for data streams
			MaxFileXMacros memdata_macros = new MaxFileXMacros("MANAGER_MEMCTL_DATA_STREAM");
			MaxFileManager.getMaxFileManager(_getBuildManager()).addMaxFileDataSegment(memdata_macros);

			int streamnr = 0; // read before write, in the order as were added.
			for (MemoryDirection dir : Arrays.asList(MemoryDirection.READ_FROM_MEMORY,
				MemoryDirection.WRITE_TO_MEMORY)) {
				for (MemoryControlGroup grp : m_memory_control_groups) {
					for (String stream_name : _ManagerStdlib.getMemoryControlGroupStreams(grp)) {
						if (m_memory_stream_direction.get(stream_name) == dir)
						{
							memdata_macros.addMacro(
								_ManagerStdlib.getMemoryControlGroupControllerName(grp),
								_ManagerStdlib.getMemoryControlGroupName(grp),
								stream_name,
								grp.getStreamIndexIdWithinGroup(stream_name),
								streamnr,
								m_memory_stream_direction.get(stream_name).toString());
							streamnr++;
						}
					}
				}
			}
		}
	}

	@MaxCompilerHide
	protected void finalise() {
		buildDebugStreams();

	}

	private void preBuildOperations() {
		finalise();
		m_board_io.finalise();

		// set address generators in the right clock domain
		if (m_address_generators_in_slow_clock)
			for (MemoryControlGroup grp : m_memory_control_groups) {
				if (!_ManagerStdlib.isStreamSource(grp)) {  // non addr gen CMD q's can stay as they are
				_ManagerStdlib.setMemoryControlGroupCommandStreamClock(
					grp,
					m_data.getWrapperParameterisation().m_cclk);
				}
			}
	}

	private FPGAWrapperEntity buildInternal() {
		preBuildOperations();

		WrapperCompileManager manager = new WrapperCompileManager(m_data);
		manager.setEnableStreamStatus(m_enable_stream_status);
		manager.setEnableStreamStatusChecksums(m_data.getDebugLevel().hasStreamStatusChecksums());
		WrapperDesignEntity test_entity = manager.build();

		m_wrapper = new FPGAWrapperEntity(_getBuildManager(), m_data, test_entity);

		// make X macros -- keep the code below IN SYNC with code found in buildHostCodeSim()!

		// ... for memory controller as a whole
		// FIXME! multiple memory controllers...
		int bzise = m_data.getMemoryControllerConfig().getBurstSize();
		int blength = m_data.getBuildManager().getPlatform() instanceof MAX3ComputeFPGA ? (bzise==8 ? 384 : 192) :96;
		if (m_data.getMemoryControllerConfig().getMAX2CompatibilityMode())
			blength /= 4;

		if (!m_memory_control_groups.isEmpty()) {
			MaxFileXMacros mem_macro = new MaxFileXMacros("MANAGER_MEMCTL");
			MaxFileManager.getMaxFileManager(_getBuildManager()).addMaxFileDataSegment(mem_macro);
			mem_macro.addMacro(
				_ManagerStdlib.getMemoryControlGroupControllerName(m_memory_control_groups.get(0)),
				"MemoryControllerPro.MemoryControllerPro",
				blength);
		}

		// ... for control groups
		MaxFileXMacros memctrl_macros = new MaxFileXMacros("MANAGER_MEMCTL_CONTROL_GROUP");
		MaxFileManager.getMaxFileManager(_getBuildManager()).addMaxFileDataSegment(memctrl_macros);

		for (MemoryControlGroup grp : m_memory_control_groups) {
			memctrl_macros.addMacro(
				_ManagerStdlib.getMemoryControlGroupControllerName(grp),
				_ManagerStdlib.getMemoryControlGroupName(grp),
				_ManagerStdlib.getMemoryControlGroupRegName(grp),
				_ManagerStdlib.getMemoryControlGroupType(grp));
		}
		// ... for data streams
		MaxFileXMacros memdata_macros = new MaxFileXMacros("MANAGER_MEMCTL_DATA_STREAM");
		MaxFileManager.getMaxFileManager(_getBuildManager()).addMaxFileDataSegment(memdata_macros);

		for (MemoryDirection dir : Arrays.asList(MemoryDirection.READ_FROM_MEMORY,
			MemoryDirection.WRITE_TO_MEMORY)) {
			for (MemoryControlGroup grp : m_memory_control_groups) {
				for (String stream_name : _ManagerStdlib.getMemoryControlGroupStreams(grp)) {
					if (m_memory_stream_direction.get(stream_name) == dir)
						memdata_macros.addMacro(
							_ManagerStdlib.getMemoryControlGroupControllerName(grp),
							_ManagerStdlib.getMemoryControlGroupName(grp),
							stream_name,
							grp.getStreamIndexIdWithinGroup(stream_name),
							m_wrapper.getMemoryStreamId(
								_ManagerStdlib.getMemoryControlGroupControllerName(grp),
								stream_name),
							m_memory_stream_direction.get(stream_name).toString());
				}
			}
		}

		MaxFileManager.getMaxFileManager(_getBuildManager()).addMaxFileConstant("ON_CARD_MEMORY_FREQUENCY",
			(int) m_board_io.getOnCardMemoryFrequency());

		return m_wrapper;
	}

	/*
	 * Stream routing
	 */

	public Mux mux(String name) {
		return _ManagerBlocks.mux(m_routing.mux(name));
	}

	public Demux demux(String name) {
		return _ManagerBlocks.demux(m_routing.demux(name));
	}

	public Fanout fanout(String name) {
		return _ManagerBlocks.fanout(m_routing.fanout(name));
	}

	/*
	 * Kernel
	 */

	public KernelBlock addKernel(Kernel kernel) {
		final WrapperNodePhoton photon = m_photon_factory.addPhotonCore(kernel);
		photon.setClock(peekDefaultClock().toImp());

		final PhotonIOInformation io_info = _Kernel.getPhotonDesignData(kernel).getIOInformation();
		final int almostEmptyLatency = photon.getInputAlmostEmptyLatency();

		// create manager blocks to handle arbitrated inputs
		final List<WrapperNodeStateMachine> arbitrators = new ArrayList<WrapperNodeStateMachine>();
		for (Map.Entry<String, ArbitratedInput> arb_input : io_info.getArbitratedInputs().entrySet()) {
			InputArbitrator sm = new InputArbitrator(this, arb_input.getValue(), almostEmptyLatency);
			String name = kernel.getName() + "_" + arb_input.getKey();
			WrapperNodeStateMachine input_arbitrator = new WrapperNodeStateMachine(getWrapperDesignData(), name, sm);

			// connect state machine output to arbitrated kernel input
			photon.getInput(arb_input.getKey()).connect(input_arbitrator.getOutput("output"));
			arbitrators.add(input_arbitrator);
		}

		// create manager blocks to handle non-blocking inputs
		final Map<String, WrapperNodeStateMachine> non_blockers = new HashMap<String, WrapperNodeStateMachine>();
		for (Map.Entry<String, PhotonIOInformation.NonBlockingInput> input : io_info.getNonBlockingInputs().entrySet()) {
			final String input_name = input.getKey();
			final PhotonIOInformation.NonBlockingInput inputInfo = input.getValue();

			// block that is connected to by users in the manager
			WrapperNodeStateMachine intermediateBlock;
			// stream that gets connected to the kernel
			com.maxeler.maxeleros.managercompiler.core.Stream streamIntoKernel;

			switch (inputInfo.mode) {
				case NO_TRICKLING:
					Flushing sm1 = new Flushing(
						this,
						inputInfo.width,
						inputInfo.eomPosition,
						almostEmptyLatency
					);
					WrapperNodeStateMachine smNode1 = addStateMachineInternal(
						kernel.getName() + "_non_block1_" + input_name,
						sm1
					);

					TinyFIFO sm2 = new TinyFIFO(
						this,
						inputInfo.width,
						almostEmptyLatency,
						true
					);
					WrapperNodeStateMachine smNode2 = addStateMachineInternal(
						kernel.getName() + "_non_block2_" + input_name,
						sm2
					);

					smNode2.getInput("input").connect(smNode1.getOutput("output"));

					intermediateBlock = smNode1;
					streamIntoKernel = smNode2.getOutput("output");
					break;
				case TRICKLING:
					Flushing sm = new Flushing(
						this,
						inputInfo.width,
						inputInfo.eomPosition,
						almostEmptyLatency,
						true
					);
					WrapperNodeStateMachine smNode = addStateMachineInternal(
						kernel.getName() + "_non_block",
						sm
					);

					intermediateBlock = smNode;
					streamIntoKernel = smNode.getOutput("output");
					break;
				default:
					throw new MaxCompilerInternalError(kernel.getManager(), "Unknown non-blocking mode '%s'.", inputInfo.mode);
			}

			// connect state machines to kernel input
			photon.getInput(input_name).connect(streamIntoKernel);
			non_blockers.put(input_name, intermediateBlock);
		}

		return _ManagerBlocks.kernel(photon, arbitrators, non_blockers);
	}

	DFELink addStreamFromFile(String file_name, int bit_width) {
		WrapperNodeFileSource file_source =
			new WrapperNodeFileSource(m_data, file_name, bit_width);

		return new DFELink(file_source.getOutput("output"));
	}

	DFELink addStreamToFile(String file_name, int bit_width) {
		WrapperNodeFileSink file_sink =
			new WrapperNodeFileSink(m_data, file_name, bit_width);

		return new DFELink(file_sink.getInput("input"));
	}

	KernelBlock addKernel(KernelDesign kernel) {
		WrapperNodeV0Photon photon = m_photon_factory.addPhotonCore(kernel);
		photon.setClock(peekDefaultClock().toImp());
		return _ManagerBlocks.kernel(photon);
	}

	/*
	 * State machine
	 */

	@MaxCompilerHide
	private WrapperNodeStateMachine addStateMachineInternal(String name, ManagerStateMachine stateMachine) {
		WrapperNodeStateMachine node = new WrapperNodeStateMachine(m_data, name, stateMachine);
		node.setClock(peekDefaultClock().toImp());
		return node;
	}

	public StateMachineBlock addStateMachine(String name, ManagerStateMachine stateMachine) {
		WrapperNodeStateMachine node = addStateMachineInternal(name, stateMachine);
		return _ManagerBlocks.stateMachine(node);
	}

	/*
	 * Custom VHDL
	 */

	public CustomHDLBlock addCustomHDL(CustomHDLNode node) {
		return _ManagerBlocks.customVHDLBlock(node);
	}

	private void buildDebugStreams() {
		boolean hasDebugStreams = false;
		for (WrapperNode node : m_data.getNodes()) {
			if (node.getDebugStream() != null) {
				hasDebugStreams = true;
				break;
			}
		}

		if (!hasDebugStreams)
			return;

		final DFELink hostPrintfStream = addStreamToCPU("debug_dfeprintf");

		m_data.setDebugHostStream(_CustomManagers.streamToImp(hostPrintfStream));
	}

	/*
	 *  Streams from/to CPU
	 */

	public DFELink addStreamFromCPU(String name) {
		return m_board_io.addStreamFromHost(name);
	}

	public DFELink addStreamToCPU(String name) {
		return m_board_io.addStreamToHost(name);
	}


	/*
	 *  Inter-FPGA streams
	 */

	public MaxRingBidirectionalStream addMaxRingBidirectionalStream(String name, Max2RingConnection connection) {
		return m_board_io.addMaxRingBirectionalStream(name, connection);
	}

	public MaxRingBidirectionalStream addMaxRingBidirectionalStream(String name, Max3RingConnection connection) {
		return m_board_io.addMaxRingBirectionalStream(name, connection);
	}

	public MaxRingBidirectionalStream addMaxRingBidirectionalStream(String name, MaxRingConnection connection) {
		return m_board_io.addMaxRingBirectionalStream(name, connection);
	}

	/*
	 * Memory streams
	 */

	public DFELink addStreamToOnCardMemory(String name, MemoryAccessPattern pattern) {
		return addStreamToOnCardMemory(name, addMemoryControlGroup("cmd_" + name, pattern));
	}

	public DFELink addStreamFromOnCardMemory(String name, MemoryAccessPattern pattern) {
		return addStreamFromOnCardMemory(name, addMemoryControlGroup("cmd_" + name, pattern));
	}

	// debug stream
	public DFELink getDebugStreamFromOnCardMemory(String name) {
		return getDebugStreamFromCardMemory(name);
	}

	public DFELink addStreamToOnCardMemory(String name, DFELink control_stream) {
		return addStreamToOnCardMemory(name, addMemoryControlGroup("cmd_" + name, control_stream));
	}

	public DFELink addStreamFromOnCardMemory(String name, DFELink control_stream) {
		return addStreamFromOnCardMemory(name, addMemoryControlGroup("cmd_" + name, control_stream));
	}

	private void addMemoryStream(String name, MemoryDirection dir) {
		m_memory_stream_direction.put(name, dir);
		if (m_num_memory_streams++ > m_maximum_memory_streams)
			throw new MaxCompilerAPIError(this, "Tried to create > " + m_maximum_memory_streams + " memory streams.");
	}

	public DFELink addStreamToOnCardMemory(String name, MemoryControlGroup control_stream) {
		addMemoryStream(name, MemoryDirection.WRITE_TO_MEMORY);
		return m_board_io.addStreamToOnCardMemory(name, control_stream);
	}

	public DFELink addStreamFromOnCardMemory(String name, MemoryControlGroup control_stream) {
		addMemoryStream(name, MemoryDirection.READ_FROM_MEMORY);
		return m_board_io.addStreamFromOnCardMemory(name, control_stream);
	}

	public DFELink getDebugStreamFromCardMemory(String name) {
		return m_board_io.getDebugStreamFromCardMemory(name);
	}


	public MemoryControlGroup addMemoryControlGroup(String name, DFELink control_stream) {
		MemoryControlGroup grp = m_board_io.addMemoryControlGroup(name, control_stream);
		m_memory_control_groups.add(grp);
		return grp;
	}

	public MemoryControlGroup addMemoryControlGroup(String name, MemoryAccessPattern pattern) {
		MemoryControlGroup grp = m_board_io.addMemoryControlGroup(name, pattern);
		m_memory_control_groups.add(grp);
		return grp;
	}

	int getPCIeStreamFromHostIdFromName(String name) {
		for (WrapperDefinition def : m_data.m_wrapper_args.iterateDefinitions()) {
			if (def instanceof PCIExpressDefinition) {
				PCIExpressDefinition pcie_def = (PCIExpressDefinition) def;
				int i=0;
				for (PCIeStream sfh : pcie_def.m_pcie_from_host) {
					if (sfh.getName().equals(name))
						return i;
					i++;
				}
			} else if (def instanceof AsymmetricInterChipDefinition) {
				int stream_no = 0;
				for (AIStream stream : ((AsymmetricInterChipDefinition)def).m_from_other_fpga) {
					if (stream.getName().equals(name))
						return stream_no;
					stream_no++;
				}
			}
		}
		throw new MaxCompilerAPIError(this, "Stream from CPU '" + name + "' does not exist.");
	}

	int getControlStreamFromHost() {
		int i=0;
		for (WrapperDefinition def : m_data.m_wrapper_args.iterateDefinitions()) {
			if (def instanceof PCIExpressDefinition) {
				PCIExpressDefinition pcie_def = (PCIExpressDefinition) def;
				i += pcie_def.m_pcie_from_host.size();
			}
		}
		return i;
	}

	int getPCIeStreamToHostIdFromName(String name) {
		for (WrapperDefinition def : m_data.m_wrapper_args.iterateDefinitions()) {
			if (def instanceof PCIExpressDefinition) {
				PCIExpressDefinition pcie_def = (PCIExpressDefinition) def;
				int i=0;
				for (PCIeStream sth : pcie_def.m_pcie_to_host) {
					if (sth.getName().equals(name))
						return i;
					i++;
				}
			} else if (def instanceof AsymmetricInterChipDefinition) {
				int stream_no = 0;
				for (AIStream stream : ((AsymmetricInterChipDefinition)def).m_to_other_fpga) {
					if (stream.getName().equals(name))
						return stream_no;
					stream_no++;
				}
			}
		}
		throw new MaxCompilerAPIError(this, "Stream to CPU '" + name + "' does not exist.");
	}

	boolean hasMemory() {
		return m_num_memory_streams > 0 ? true : false;
	}

    boolean fullCalSim() {
      return m_data.getDebugLevel().hasFullCalSim();
    }

	@MaxCompilerHide
	public void setIFPGALinkClock(WrapperClock clock) {
		m_board_io.setIFPGALinkClock(clock);
	}

	@MaxCompilerHide
	public void setMemoryStreamClock(WrapperClock clock) {
		m_board_io.setMemoryStreamClock(clock);
	}

	MappedElementsManager getMappedElementsManager() {
		return m_wrapper.getMappedElementsManager();
	}

	DFELink addFWStreamToCompute(String name) {
		_MAX3InterfaceIOInterface iface_io = (_MAX3InterfaceIOInterface) m_board_io;
		return iface_io.addFWStreamToCompute(name);
	}

	DFELink addFWStreamFromCompute(String name) {
		_MAX3InterfaceIOInterface iface_io = (_MAX3InterfaceIOInterface) m_board_io;
		return iface_io.addFWStreamFromCompute(name);
	}

	WrapperDesignData getWrapperDesignData() {
		return m_data;
	}

	WrapperClock getStreamClock() {
		return m_default_stream_clock;
	}

	MappedElementsInfo getMappedElementsInfo() {
		return m_wrapper.getMappedElementsInfo();
	}

	public void setEnableHideMemoryParityBits(DFELink stream, boolean hide_parity_bits) {
		m_board_io.setEnableHideParityBitsForStream(stream, hide_parity_bits);
	}

	/**
	 * GPS timestamping stream format.
	 * All format variants have the two most significant bits as flags:
	 *   msb:   Valid bit, set when the timestamp is considered valid
	 *   msb-1: Doubt bit, set when external input has been lost and the timestamp unit is free-running
	 */
	public enum TimestampFormat {
		/**
		 * Date+Time in BCD format, YYYYMMDDHHMMSSXXXXXXX
		 * with the number of 'X' being equal to the decimal_precision
		 * Width in bits = 2 + 4*(14+decimal_precision)
		 */
		BCD,
		/**
		 * Date+Time as a number of time units since 1970-01-01 00:00:00
		 * where the time unit depends on the decimal precision
		 * time_unit = 10^(decimal_precision) s
		 * Width in bits = 2 + 64
		 */
		COUNT,
		/**
		 * Date+Time in BCD format (upper part) and in number of time units (lower part)
		 * Width in bits = 2 + 4*(14+decimal_precision) + 64
		 */
		BOTH
	}

	/**
	 * Get a stream from a GPS timestamping unit.
	 * @param name Name of the timestamp stream
	 * @param format Format of the timestamp stream (see {@link #TimestampFormat})
	 * @param decimal_precision Number of decimal digits, from 1 to 7 inclusive (3=ms, 6=us)
	 */
	public DFELink addTimestampStream(String name, TimestampFormat format, int decimal_precision) {
		TimestampingIOFormat fmt;
		switch (format) {
			case BCD: fmt = TimestampingIOFormat.BCD;		break;
			case COUNT: fmt = TimestampingIOFormat.COUNT;	break;
			case BOTH: fmt = TimestampingIOFormat.BOTH;		break;
			default: throw new MaxCompilerAPIError(this, "Unsupported timestamp format: " + format);
		}
		return m_board_io.addTimestampStream(name,
											 m_default_clock_stack.peek().toImp(),
											 fmt,
											 decimal_precision);
	}

	@Override
	protected final void realBuild() {
		if(isTargetSimulation() && !m_simulate_in_modelsim) {
			buildCPUCodeSim();
			Platform<?,?> platform = _getBuildManager().getPlatform();
			if(!(platform instanceof MaxelerOSPlatform))
				throw new MaxCompilerInternalError(this, "Not a MaxelerOS platform.");

			MaxelerOSPlatform maxPlatform = (MaxelerOSPlatform)platform;

			MaxFileManager mgm = MaxFileManager.getMaxFileManager(_getBuildManager());
			mgm.addMaxFileDataSegment(maxPlatform.getMaxFileCapabilitiesData());

			// Set up the build passes
			_getBuildManager().addBuildPass(new GenerateMaxFileDataFile());
			_getBuildManager().addBuildPass(new SimCompilePass(Mode.SHARED_OBJECT, m_data));
			_getBuildManager().addBuildPass(new AddSimObjectToMaxFilePass());

			// Build
			_getBuildManager().runBuildPasses();
			_getBuildManager().finalizeBuild();
		} else if (m_simulate_in_modelsim) {
			throw new MaxCompilerAPIError(this, "When targetting HDL simulation a design cannot be built. Use HDLTestBench.runTest() to run a simulation.");
		} else {
			FPGAWrapperEntity wrapper = buildInternal();

			Entity top = m_board_capabilties.createTop(
				"max_compiler_top",
				_getBuildManager(),
				wrapper,
				m_data.getTopLevelParameterisation());

			_Managers.runBuild(this, top);
		}
	}

	_ManagerSimulator getManagerSimulator() {
		return m_manager_sim;
	}

	public HDLTestBench getHDLTestBench() {
		if(m_sim_transactor == null)
			throw new MaxCompilerAPIError(
				this,
				"Cannot get a HDL Test Bench as this manager has not been constructed with support for " +
				"HDL simulation. Enable this by using the appopriate CustomManager constructor.");

		if (m_sim_transactor.m_manager_regs.hasMemory() == true && m_sim_transactor.isMAX3() == true)
			getManagerSimulator().setEnableUseGlbl(true);

		return m_sim_transactor;
	}

	/**
	 * Add an engine interface to the manager.
	 * @param engine_interface the engine interface to add
	 * The name must be distinct from any interface already added to the manager
	 */
	@Deprecated
	public void addInterface(EngineInterface engine_interface) {
		createSLiCinterface(engine_interface);
	}

	/**
	 * Add a SLiC interface for this maxfile. The mode name must be distinct from any
	 * mode already added to the manager.
	 *
	 * @param engineInterface the engine interface to add.
	 */
	public void createSLiCinterface(EngineInterface engineInterface) {
		m_data.addMode(engineInterface.getImplementation());
	}

	/**
	 * Suppress the "default" interface from being generated in the SLiC static interface.
	 */
	public void suppressDefaultInterface() {
		m_data.suppressDefaultMode();
	}

	public Map<String, EngineInterface> getEngineInterfaces() {
		Map<String, EngineInterface> result = new HashMap<String, EngineInterface>();
		Map<String, com.maxeler.maxeleros.managercompiler.software.modeinfo.EngineMode> ems =
			m_data.getEngineModes();
		for(Iterator<String> it= ems.keySet().iterator(); it.hasNext(); ) {
			String key = it.next();
			result.put(key, new EngineInterface(ems.get(key)));
		}
		return Collections.unmodifiableMap(result);
	}

	/**
	 * Set the clock that will be assigned when adding Kernels and state-machines.
	 * This will initially be the "stream clock" which is a special clock, adjustable
	 * at run-time from CPU code.
	 *
	 * @param clock to be used when adding new manager blocks.
	 */
	public void pushDefaultClock(ManagerClock clock) {
		m_default_clock_stack.push(clock);
	}

	/**
	 * @see {@link #pushDefaultClock(ManagerClock)}
	 */
	public ManagerClock peekDefaultClock() {
		return m_default_clock_stack.peek();
	}

	/**
	 * @see {@link #pushDefaultClock(ManagerClock)}
	 */
	public void popDefaultClock() {
		m_default_clock_stack.pop();
	}

	/**
	 * On supported platforms sets the clock to use for all IFPGA data streams.
	 */
	public void setIFPGALinkClock(ManagerClock clock) {
		m_board_io.setIFPGALinkClock(clock.toImp());
	}

	/**
	 * On supported platforms sets the clock to use for the memory controller.
	 */
	public void setMemoryStreamClock(ManagerClock clock) {
		m_board_io.setMemoryStreamClock(clock.toImp());
	}

	/**
	 * On supported platforms sets the clock to use for all host data streams.
	 */
	public void setCPUStreamClock(ManagerClock clock) {
		m_board_io.setIFPGALinkClock(clock.toImp());
	}
}
