package com.maxeler.maxcompiler.v2.statemachine.stdlib.buffer;

import java.math.BigInteger;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmExpr;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmValue;
import com.maxeler.maxcompiler.v2.statemachine.DFEsmVariable;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmEnumType;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmTypeFactory;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmUntypedConst;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.ExprUtils;
import com.maxeler.statemachine.Utils;
import com.maxeler.statemachine.buffers.Fifo;
import com.maxeler.statemachine.expressions.Constant;
import com.maxeler.statemachine.expressions.ControlSignal;
import com.maxeler.statemachine.expressions.Expression;
import com.maxeler.statemachine.expressions.FifoSource;
import com.maxeler.statemachine.expressions.ReadableFifoControlSignal;
import com.maxeler.statemachine.expressions.WriteableFifoControlSignal;
import com.maxeler.statemachine.statements.StatementAssign;

public final class DFEsmFifoReadDomain {

	static class ReadEnableAssigner extends DFEsmVariable {
		protected final StateMachineLib m_stateMachine;
		protected final WriteableFifoControlSignal m_readEnable;

		public ReadEnableAssigner(StateMachineLib stateMachine, WriteableFifoControlSignal readEnable) {
			m_stateMachine = stateMachine;
			m_readEnable = readEnable;
		}

		@Override
		public <E extends Enum<E>> void connect(E value) {
			throw new MaxCompilerAPIError("Cannot use an enum as write enable signal.");
		}

		@Override
		public void connect(boolean value) { assign(new Constant(value ? 1 : 0)); }

		@Override
		public void connect(long value) {
			Utils.checkIsAllowedLiteralValue(value, getType());
			connect(BigInteger.valueOf(value));
		}

		@Override
		public void connect(BigInteger value) { assign(new Constant(value)); }

		@Override
		public void connect(DFEsmExpr expr) { assign(_StateMachine.getExpression(expr));}

		protected void assign(Expression expr) {
			if (expr.getType() instanceof DFEsmEnumType)
				throw new MaxCompilerAPIError("Cannot assign enums to the read enable port.");
			if ((expr.getType() instanceof DFEsmValueType) && ( !((DFEsmValueType)expr.getType()).isBool() ))
				throw new MaxCompilerAPIError("Cannot assign non-boolean integer value to read enable port.");
			if (expr.getType() instanceof DFEsmUntypedConst)
				expr = ExprUtils.implicitCast(getType(), "Read Enable", expr);
			_StateMachine.addStatement(m_stateMachine, new StatementAssign(m_readEnable,  expr, _StateMachine.getBuildManager(m_stateMachine)));
		}

		private static DFEsmValueType getType() { return DFEsmTypeFactory.dfeBool(); }

		@Override
		protected DFEsmExpr getDFEsmExpr() {
			return _StateMachine.Create.DFEsmExpr(m_readEnable);
		}
	}

	final DFEsmValueType m_type;
	final Fifo m_fifo;

	public final DFEsmVariable readEnable;
	public final DFEsmValue dataOut;
	public final DFEsmValue valid;
	public final DFEsmValue empty;
	public final DFEsmValue progEmpty;


	DFEsmFifoReadDomain(StateMachineLib stateMachine, DFEsmValueType type, Fifo aFifo) {
		m_type = type;
		m_fifo = aFifo;

		dataOut = _StateMachine.Create.DFEsmValue(new FifoSource(aFifo,"data_out",type));
		readEnable = new ReadEnableAssigner(stateMachine, new WriteableFifoControlSignal(aFifo, ControlSignal.FIFO_READ_ENABLE));
		valid = _StateMachine.Create.DFEsmValue(new ReadableFifoControlSignal(aFifo,ControlSignal.FIFO_VALID));
		empty = _StateMachine.Create.DFEsmValue(new ReadableFifoControlSignal(aFifo,ControlSignal.FIFO_EMPTY));
		progEmpty = _StateMachine.Create.DFEsmValue(new ReadableFifoControlSignal(aFifo,ControlSignal.FIFO_PROG_EMPTY));
	}
}
