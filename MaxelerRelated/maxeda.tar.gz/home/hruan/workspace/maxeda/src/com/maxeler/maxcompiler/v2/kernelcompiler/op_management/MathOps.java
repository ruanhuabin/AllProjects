package com.maxeler.maxcompiler.v2.kernelcompiler.op_management;

public enum MathOps {
	ADD, SUB, MUL, DIV, NEG,
	ALL,
	ADD_SUB,
	MUL_DIV
}
