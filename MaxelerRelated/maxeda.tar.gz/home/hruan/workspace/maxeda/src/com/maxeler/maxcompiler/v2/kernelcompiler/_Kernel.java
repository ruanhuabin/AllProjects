package com.maxeler.maxcompiler.v2.kernelcompiler;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Flush.FlushHostControlled;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Bitops;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.Reductions;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.photon.compile_managers.HardwareCompileManager;
import com.maxeler.photon.core.PhotonCompileManager;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.hw.streaming_adapter.PhotonStreamingBlockAdapter;

public class _Kernel {

	public static PhotonDesignData getPhotonDesignData(KernelLib kernelLib) {
		return kernelLib.m_design_data;
	}

	public static PhotonCompileManager prepareForBuild(Kernel design) {
		return design.prepareForBuild();
	}

	public static PhotonStreamingBlockAdapter buildPhotonSBA(Kernel design) {
		PhotonCompileManager compile_manager = prepareForBuild(design);

		if( ! (compile_manager instanceof HardwareCompileManager) )
			throw new MaxCompilerInternalError(design.getManager(),
				"Cannot build PhotonStreamingBlockAdapter without HardwareCompileManager.");

		return
			((HardwareCompileManager)compile_manager).buildPhotonSBA();
	}

	public static com.maxeler.photon.core.Var[] toImp(DFEVar[] a) {
		com.maxeler.photon.core.Var a_imp[] = new com.maxeler.photon.core.Var[a.length];

		for (int i = 0; i < a.length; ++i)
			a_imp[i] = _KernelBaseTypes.toImp(a[i]);

		return a_imp;
	}

    public static <T extends DFEVar> com.maxeler.photon.core.Var[][] toImp(T[][] var) {
    	com.maxeler.photon.core.Var[][] var_imp = new com.maxeler.photon.core.Var[var.length][];

    	for (int i = 0; i < var.length; ++i)
    		var_imp[i] = toImp(var[i]);

    	return var_imp;
    }

    public static List<com.maxeler.photon.core.Var> toImp(List<DFEVar> var) {
    	List<com.maxeler.photon.core.Var> var_imp = new ArrayList<com.maxeler.photon.core.Var>(var.size());

    	for(DFEVar v : var)
    		var_imp.add(_KernelBaseTypes.toImp(v));

    	return var_imp;
    }

    public static Reductions getGlobalReductionsInst(Kernel design) {
    	return design.getGlobalReductionInst();
    }

    public static Bitops getGlobalBitopsInst(Kernel design) {
    	return design.getGlobalBitopsInst();
    }

    public static boolean isCPUControlled(Kernel design) {
    	return design.flush.m_flush_strategy instanceof FlushHostControlled;
    }

	public static KernelParameters makeKernelParameters(
		DFEManager manager, String name, KernelConfiguration config)
	{
		return new KernelParameters(manager, name, config);
	}

	public static void callSimPrintf(Kernel kernel, String message, DFEVar value) {
		kernel.debug.printf(message, value);
	}

	public static void callSimPrintf(Kernel kernel, DFEVar condition, String message, DFEVar value) {
		kernel.debug.printf(condition, message, value);
	}

	public static DFEVar checksum(Kernel kernel, DFEVar data, DFEVar en) {
		return kernel.debug.checksum(data, en);
	}
}
