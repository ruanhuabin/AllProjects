package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.maxeler.maxblox.utils.MaxBloxException;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.KernelMath.Range;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager.DualSimMode;

/**
 * This class only tests the API, it does not check that the outputed values of the simulation
 * are correct.
 */
public class KernelMathTest extends Kernel {

	private static final int NUM_PIPES = 3;
	private static final DFEFix smallFixType = dfeFix(4, 4, SignMode.TWOSCOMPLEMENT);
	private static final DFEFix fixType = dfeFix(4, 20, SignMode.TWOSCOMPLEMENT);
	private static final DFEFix fix32Type = dfeFix(8, 24, SignMode.TWOSCOMPLEMENT);
	private static final DFEVectorType<DFEVar> fixTypeMP = new DFEVectorType<DFEVar>(fixType, NUM_PIPES);
	private static final DFEFloat floatType = dfeFloat(8, 24);
	private static final DFEVectorType<DFEVar> floatTypeMP = new DFEVectorType<DFEVar>(floatType, NUM_PIPES);

	private final ArrayList<DFEVar> input = new ArrayList<DFEVar>();
	private final ArrayList<DFEVar> output = new ArrayList<DFEVar>();
	private final ArrayList<String> inputName = new ArrayList<String>();
	private final ArrayList<String> outputName = new ArrayList<String>();
	private final ArrayList<DFEVectorBase<DFEVar, ?, ?, ?>> inputMP = new ArrayList<DFEVectorBase<DFEVar, ?, ?, ?>>();
	private final ArrayList<DFEVectorBase<DFEVar, ?, ?, ?>> outputMP = new ArrayList<DFEVectorBase<DFEVar, ?, ?, ?>>();
	private final ArrayList<String> inputMPName = new ArrayList<String>();
	private final ArrayList<String> outputMPName = new ArrayList<String>();

	private DFEVar getNewInput(DFEType type) {
		String name = "input" + input.size();
		inputName.add(name);
		DFEVar x = io.input(name, type);
		input.add(x);
		return x;
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	> M getNewInput(T type) {
		String name = "inputMP" + inputMP.size();
		inputMPName.add(name);
		M x = io.input(name, type);
		inputMP.add(x);
		return x;
	}

	private DFEVar getNewOutput(DFEVar x) {
		return getNewOutput(x, x.getType());
	}

	private DFEVar getNewOutput(DFEVar x, DFEType type) {
		String name = "output" + output.size();
		outputName.add(name);
		DFEVar y = io.output(name, type) <== x;
		output.add(y);
		return y;
	}

	private <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	> M getNewOutput(M x) {
		return getNewOutput(x, x.getType());
	}

	private <
	M extends DFEVectorBase<DFEVar, M, C, T>,
	C extends DFEVectorBase<DFEVar, C, ?, ?>,
	T extends DFEVectorTypeBase<DFEVar, M, C>
	> M getNewOutput(M x, T type) {
		String name = "outputMP" + outputMP.size();
		outputMPName.add(name);
		M y = io.output(name, type).connect(x);
		outputMP.add(y);
		return y;
}

	public KernelMathTest(KernelParameters parameters) {
		super(parameters);

		// The two dummy inputs are used as inputs for all the nodes that should throw an Exception
		DFEVar dummy = io.input("dummy", fixType, dfeBool().newInstance(this, false));
		DFEVector<DFEVar> dummyMP = io.input("dummyMP", fixTypeMP, dfeBool().newInstance(this, false));

		boolean caughtError;

		// Ceil
		getNewOutput(KernelMath.ceil(getNewInput(fixType)),     fixType);
		getNewOutput(KernelMath.ceil(getNewInput(floatType)),   floatType);
		getNewOutput(KernelMath.ceil(getNewInput(floatType),    fixType),   fixType);
		getNewOutput(KernelMath.ceil(getNewInput(fixType),      floatType), floatType);
		getNewOutput(KernelMath.ceil(getNewInput(fixTypeMP)),   fixTypeMP);
		getNewOutput(KernelMath.ceil(getNewInput(floatTypeMP)), floatTypeMP);
		getNewOutput(KernelMath.ceil(getNewInput(floatTypeMP),  fixType),   fixTypeMP);

		// Floor
		getNewOutput(KernelMath.floor(getNewInput(fixType)),     fixType);
		getNewOutput(KernelMath.floor(getNewInput(floatType)),   floatType);
		getNewOutput(KernelMath.floor(getNewInput(floatType),    fixType),   fixType);
		getNewOutput(KernelMath.floor(getNewInput(fixType),      floatType), floatType);
		getNewOutput(KernelMath.floor(getNewInput(fixTypeMP)),   fixTypeMP);
		getNewOutput(KernelMath.floor(getNewInput(floatTypeMP)), floatTypeMP);
		getNewOutput(KernelMath.floor(getNewInput(floatTypeMP),  fixType),   fixTypeMP);

		// Min
		getNewOutput(KernelMath.min(getNewInput(fixType), getNewInput(fixType)));
		getNewOutput(KernelMath.min(getNewInput(fixTypeMP), getNewInput(fixTypeMP)));
		getNewOutput(KernelMath.min(getNewInput(floatType), getNewInput(floatType)));
		getNewOutput(KernelMath.min(getNewInput(floatTypeMP), getNewInput(floatTypeMP)));

		// Max
		getNewOutput(KernelMath.max(getNewInput(fixType), getNewInput(fixType)));
		getNewOutput(KernelMath.max(getNewInput(fixTypeMP), getNewInput(fixTypeMP)));
		getNewOutput(KernelMath.max(getNewInput(floatType), getNewInput(floatType)));
		getNewOutput(KernelMath.max(getNewInput(floatTypeMP), getNewInput(floatTypeMP)));

		// COS
		getNewOutput(KernelMath.cos(getNewInput(fixType)));
		getNewOutput(KernelMath.cos(getNewInput(fixType), fixType));
		getNewOutput(KernelMath.cos(getNewInput(fixTypeMP)));
		getNewOutput(KernelMath.cos(getNewInput(fixTypeMP), fixTypeMP));
		getNewOutput(KernelMath.cos(getNewInput(floatType)));
		getNewOutput(KernelMath.cos(getNewInput(floatType), floatType));
		getNewOutput(KernelMath.cos(getNewInput(floatTypeMP)));
		getNewOutput(KernelMath.cos(getNewInput(floatTypeMP), floatTypeMP));

		// SIN
		getNewOutput(KernelMath.sin(getNewInput(fixType)));
		getNewOutput(KernelMath.sin(getNewInput(fixType), fixType));
		getNewOutput(KernelMath.sin(getNewInput(fixTypeMP)));
		getNewOutput(KernelMath.sin(getNewInput(fixTypeMP), fixTypeMP));
		getNewOutput(KernelMath.sin(getNewInput(floatType)));
		getNewOutput(KernelMath.sin(getNewInput(floatType), floatType));
		getNewOutput(KernelMath.sin(getNewInput(floatTypeMP)));
		getNewOutput(KernelMath.sin(getNewInput(floatTypeMP), floatTypeMP));

		// LOG2
		getNewOutput(KernelMath.log2(new Range(1, 2), getNewInput(fixType), fixType));
		getNewOutput(KernelMath.log2(new Range(1, 2), getNewInput(fixTypeMP), fixTypeMP));
		getNewOutput(KernelMath.log2(new Range(1, 2), getNewInput(floatType), floatType));
		getNewOutput(KernelMath.log2(new Range(1, 2), getNewInput(floatTypeMP), floatTypeMP));
		try {
			caughtError = false;
			KernelMath.log2(new Range(1, 2), dummy.cast(smallFixType), smallFixType);
		} catch(MaxBloxException error) {
			caughtError = true;
		}
		if(!caughtError) {
			throw new MaxCompilerInternalError("Exception was not thrown.");
		}

		// LOG
		getNewOutput(KernelMath.log(new Range(1, 2), getNewInput(fixType), fixType));
		getNewOutput(KernelMath.log(new Range(1, 2), getNewInput(fixTypeMP), fixTypeMP));
		getNewOutput(KernelMath.log(new Range(1, 2), getNewInput(floatType), floatType));
		getNewOutput(KernelMath.log(new Range(1, 2), getNewInput(floatTypeMP), floatTypeMP));
		try {
			caughtError = false;
			KernelMath.log(new Range(1, 2), dummy.cast(smallFixType), smallFixType);
		} catch(MaxBloxException error) {
			caughtError = true;
		}
		if(!caughtError) {
			throw new MaxCompilerInternalError("Exception was not thrown.");
		}

		// POW2
		getNewOutput(KernelMath.pow2(getNewInput(fixType), fixType));
		getNewOutput(KernelMath.pow2(getNewInput(fixTypeMP), fixTypeMP));
		getNewOutput(KernelMath.pow2(dummy.cast(floatType), floatType));

		// EXP
		getNewOutput(KernelMath.exp(getNewInput(fix32Type)));
		getNewOutput(KernelMath.exp(getNewInput(fixType)));
		getNewOutput(KernelMath.exp(getNewInput(fixType), fixType));
		getNewOutput(KernelMath.exp(getNewInput(fixTypeMP)));
		getNewOutput(KernelMath.exp(getNewInput(fixTypeMP), fixTypeMP));
		getNewOutput(KernelMath.exp(dummy.cast(floatType)));
		getNewOutput(KernelMath.exp(dummyMP.cast(floatTypeMP)));

		// SQRT
		try {
			caughtError = false;
			KernelMath.sqrt(dummy.cast(fixType));
		} catch(MaxCompilerAPIError error) {
			caughtError = true;
		}
		if(!caughtError) {
			throw new MaxCompilerInternalError("Exception was not thrown.");
		}
		getNewOutput(KernelMath.sqrt(new Range(1, 1000), getNewInput(dfeFix(33, 14, SignMode.UNSIGNED)), dfeFix(17, 7, SignMode.UNSIGNED)));
		getNewOutput(KernelMath.sqrt(new Range(1, 2), getNewInput(fixType), fixType));
		try {
			caughtError = false;
			KernelMath.sqrt(dummyMP.cast(fixTypeMP));
		} catch(MaxCompilerAPIError error) {
			caughtError = true;
		}
		if(!caughtError) {
			throw new MaxCompilerInternalError("Exception was not thrown.");
		}
		getNewOutput(KernelMath.sqrt(new Range(1, 2), getNewInput(fixTypeMP), fixTypeMP));
		getNewOutput(KernelMath.sqrt(getNewInput(floatType)));
		getNewOutput(KernelMath.sqrt(getNewInput(floatTypeMP)));
		getNewOutput(KernelMath.sqrt(new Range(1, 2), getNewInput(floatType), floatType));
		getNewOutput(KernelMath.sqrt(new Range(1, 2), getNewInput(floatTypeMP), floatTypeMP));
	}

	/**
	 * @param args
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	public static void main(String[] args) {
		_DualSimulationManager manager = new _DualSimulationManager("KernelMathTest", DualSimMode.PARALLEL);
		KernelMathTest kernel_a = new KernelMathTest(manager.makeKernelParameters_A());
		KernelMathTest kernel_b = new KernelMathTest(manager.makeKernelParameters_B());
		manager.setKernels(kernel_a, kernel_b);

		double input[] = new double[]{1.5};
		Double _inputMP[] = new Double[]{1.5, 1.5, 1.5};
		List<Double> inputMP = Arrays.asList(_inputMP);

		for(int i = 0; i < kernel_a.inputName.size(); i++) {
			String name = kernel_a.inputName.get(i);
			System.out.println("Feeding input " +name);
			manager.setInputData(name, input);
		}
		for(int i = 0; i < kernel_a.inputMP.size(); i++) {
			String name = kernel_a.inputMPName.get(i);
			DFEVectorType<DFEVar> typeMP = (DFEVectorType)kernel_a.inputMP.get(i).getType();
			System.out.println("Feeding inputMP " + name + " with type " + typeMP);
			manager.setInputDataRaw(name, typeMP.encodeConstant(inputMP));
		}
		manager.setKernelCycles(1);
		manager.runTest();

		System.out.println("TEST PASSED");
	}
}
