package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core;

import static com.maxeler.utils.EnumTranslator.convert;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.MathOps;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.photon.nodes.NodeCounterV1;
import com.maxeler.photon.nodes.NodePulse;

/**
 * Contains classes for creating and configuring counters
 * in a Kernel.
 * <p>
 * See the
 * <a href="{@docRoot}/../maxcompiler-tutorial.pdf#destination.counters">MaxCompiler Tutorial</a> for more
 * details on using counters.
 */
public class Count {
	private final com.maxeler.photon.libs.CounterFactoryV1 m_imp;
	private final Kernel m_design;

	/**
	 * Modes for counting which determine the value
	 * of a counter's output.
	 */
	public enum CountMode {
		/** Counter will count numerically e.g.&nbsp;0, 1, 2, 3... */
		NUMERIC_INCREMENTING,
		/** Each output from the counter will be the previous value shifted-left by
		 * the increment value.
		 * <p>
		 * e.g. if initialized with 1 and an increment of
		 * 2, the output will be 1, 4, 16 ... */
		SHIFT_LEFT,
		/** Each output from the counter will be the previous value shifted-right
		 * by the increment value.
		 * <p>
		 * e.g. if initialized with 64 and an increment of
		 * 2, the output will be 64, 16, 4 ... */
		SHIFT_RIGHT
	}

	/**
	 * Defines a counter's behavior when its maximum is reached.
	 */
	public enum WrapMode {
		/**
		 * Wrap when the count value is >= max, restarting at 0.
		 * <p>
		 * E.g. if the max is 3, a numeric incrementing counter with an increment
		 * of 1 will count 0, 1, 2, 0, 1, 2...
		 * </p>
		 * <p>
		 * E.g. if the max is 4, a numeric incrementing counter with an increment
		 * of 3 will count 0, 3, 0, 3, 0...
		 * </p>
		 * */
		COUNT_LT_MAX_THEN_WRAP,
		/**
		 * The counter will stop at the greatest multiple of the increment not
		 * exceeding the maximum value until the kernel is
		 * reset.
		 * <p>
		 * E.g. if the max is 5 and the increment is 2 the the count will
		 * be 0, 2, 4, 4, 4, 4...
		 * </p>
		 */
		STOP_AT_MAX,
		/**
		 * The counter's value is calculated modulo the maximum value.
		 * <p>
		 * E.g. if the max is 5 and increment is 2 the count will be:
		 * 0, 2, 4, 1, 3, 0, 2, 4...
		 * </p>
		 */
		MODULO_MAX_OF_COUNT

	}

	/**
	 * Configuration object used to define the behavior of counters.
	 * <p>
	 * Instances
	 * of this object are immutable, and calling the {@code with...} methods result
	 * in a new {@code Params} object with the configuration of the current {@code Params} plus
	 * the additional configuration.
	 */
	public class Params {
		private final com.maxeler.photon.libs.CounterFactoryV1.Params m_imp;

		private Params(com.maxeler.photon.libs.CounterFactoryV1.Params imp) {
			m_imp = imp;
		}

		/**
		 * Returns a new instance of the Params object in which the supplied parameter
		 * is used to set initial value of the counter when the Kernel is reset.
		 * @param value sets the initial value of the counter when the Kernel is reset. <br>
		 *              This value must be positive.
		 * @return a new Params instance with initial value set to the supplied value.
		 */
		public Params withInitValue(long value) {
			if(value < 0)
				throw new MaxCompilerAPIError(m_design.getManager(), "Initial counter values must be positive.");

			return new Params(m_imp.withInitValue(value));
		}

		/**
		 * Returns a new instance of the Params object with increment set to the given value.
		 * @param inc is the static increment to use for the counter.
		 * @return a new Params instance with increment set to the supplied value.
		 */
		public Params withInc(long inc) {
			return new Params(m_imp.withInc(inc));
		}

		/**
		 * Returns a new instance of the Params object with reset signal set to the given value.
		 * @param reset is the reset signal to be used for the counter.
		 * @return a new Params instance with the supplied reset signal.
		 */
		public Params withReset(DFEVar reset) {
			// FIXME: May want to move this stream offset into Photon
			// It is needed to get the expected behaviour from counters with reset
			// where reset acts in the same cycle from the user's perspective
			DFEVar r = reset.getKernel().stream.offset(reset,1);
			return new Params(m_imp.withReset(_KernelBaseTypes.toImp(r)));
		}

		/**
		 * Returns a new instance of the Params object with the maximum/wrap-point
		 * value set to the supplied parameter.
		 * <p>
		 * See the {@link WrapMode} enumerated types for more details
		 * on what happens when a counter reaches a maximum value.
		 *
		 * @param max is the maximum/wrap-point value to be used for the counter.
		 * @return a new Params instance with the supplied maximum.
		 */
		public Params withMax(DFEVar max) {
			return new Params(m_imp.withMax(_KernelBaseTypes.toImp(max)));
		}

		/**
		 * Returns a new instance of the Params object with the maximum/wrap-point
		 * value set to the supplied parameter.
		 * <p>
		 * See the {@link WrapMode} enumerated types for more details
		 * on what happens when a counter reaches a maximum value.
		 *
		 * @param max is the maximum/wrap-point value to be used for the counter.
		 * @return a new Params instance with the supplied maximum.
		 */
		public Params withMax(long max) {
			return new Params(m_imp.withMax(max));
		}

		/**
		 * Returns a new instance of the Params object in which the supplied
		 * parameter is used as the wrap value; this is the value which the counter
		 * will receive when it wraps in <b>COUNT_LT_MAX_THEN_WRAP</b> mode. <br>
		 * <b>Note</b>: behavior is undefined in any other mode. See {@link WrapMode}.
		 * @param wrap_value is the wrap-point value to be used for the counter.
		 * @return a new Params instance with the supplied wrap value.
		 */
		public Params withWrapValue(long wrap_value) {
			return new Params(m_imp.withWrapValue(wrap_value));
		}

		/**
		 * Returns a new instance of the Params object that has the count mode
		 * set to the supplied input parameter.
		 * @param count_mode is the counting mode to use; see {@link CountMode} for details.
		 * @return a new instance of the Params object with count mode set.
		 */
		public Params withCountMode(CountMode count_mode) {
			NodeCounterV1.CountMode count_mode_imp = convert(count_mode, NodeCounterV1.CountMode.class);
			return new Params(m_imp.withCountMode(count_mode_imp));
		}

		/**
		 * Returns a new instance of the Params object that has the wrap mode
		 * set to the supplied parameter.
		 * @param wrap_mode is the wrapping mode to use; see {@link WrapMode} for details.
		 * @return a new instance of the Params object with wrap mode set.
		 */
		public Params withWrapMode(WrapMode wrap_mode) {
			NodeCounterV1.WrapMode wrap_mode_imp = convert(wrap_mode, NodeCounterV1.WrapMode.class);
			return new Params(m_imp.withWrapMode(wrap_mode_imp));
		}

		/**
		 * Returns a new instance of the Params object that has its Enable signal
		 * set to the supplied input parameter.
		 * @param enable specifies a {@code false}/{@code true} Boolean-compliant
		 *               enable signal which will, respectively, pause/run the counter.
		 * @return a new instance of the Params object with enable signal set.
		 */
		public Params withEnable(DFEVar enable) {
			if(enable.getType().isConcreteType() && !enable.getType().isBool())
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Enable signal must be a Boolean type, not " + enable.getType() + ".");

			return new Params(m_imp.withEnable(_KernelBaseTypes.toImp(enable)));
		}

		DFEType getExpectedType() {
			return _KernelBaseTypes.fromImp(m_imp.getExpectedType());
		}
	}

	/**
	 * Instance of a counter which has both a count and wrap value.
	 */
	public class Counter {
		private final com.maxeler.photon.libs.CounterFactoryV1.Counter m_imp;

		private Counter(com.maxeler.photon.libs.CounterFactoryV1.Counter imp) {
			m_imp = imp;
		}

		/**
		 * Returns an {@code DFEVar} with the stream of counts produced by this counter.
		 */
		public DFEVar getCount() {
			return _KernelBaseTypes.fromImp(m_design, m_imp.getCount());
		}

		/**
		 *  Returns a Boolean {@code DFEVar} stream which is {@code 1} at
		 *  the point when the counter will wrap on the next cycle,
		 *  and {@code 0} otherwise.
		 *  <p>
		 *  e.g. If the count is 0, 1, 2, 0, 1, 2, 0... the wrap value
		 *  will be              0, 0, 1, 0, 0, 1, 0...
		 *  </p>
		 */
		public DFEVar getWrap() {
			return _KernelBaseTypes.fromImp(m_design, m_imp.getWrap());
		}
	}

	/**
	 * Instance of a multipipe counter which has both a count and a wrap value.
	 * <p>
	 * <b>Note:</b> the maximum value must be a multiple of the number of pipes.
	 */
	public class CounterVectBase<M extends DFEVectorBase<DFEVar, M, ?, ?>> {
		private final M m_count;
		private final DFEVar m_wrap;

		private CounterVectBase(M mp_obj, Params params, boolean warn) {
			if (params.m_imp.getMax() % mp_obj.getNElements() != 0)
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Cannot make a multi-pipe counter with a max_value " +
					"(" + params.m_imp.getMax() + ") that is not a multiple of the " +
					"number of pipes (" + mp_obj.getNElements() + ")" );

			if (warn && params.m_imp.getMax() == 0)
				_Kernel.getPhotonDesignData(m_design).getBuildManager().logWarning(
					"When creating a multi-pipe counter with a DFEVar-type maximum value, it is " +
					"required that all provided maximum values are multiples of the number of pipes.");

			// Scale up increment by number of pipes.
			long orig_inc = params.m_imp.getInc();
			params = params.withInc(orig_inc * mp_obj.getNElements());

			Counter base_counter = makeCounter(params);
			m_wrap = base_counter.getWrap();

			DFEVectorTypeBase<DFEVar, M, ?> mp_type = mp_obj.getType();

			m_count = mp_type.newInstance(m_design);
			m_design.optimization.pushFixOpModeDefault(MathOps.ALL);
			for(int i = 0; i < mp_type.getNElements(); i++) {
				switch(params.m_imp.getCountMode())
				{
					case NUMERIC_INCREMENTING:
						m_count.connect(i, base_counter.getCount().add(i));
						break;

					case SHIFT_LEFT:
						m_count.connect(i, base_counter.getCount().shiftLeft(i));
						break;

					case SHIFT_RIGHT:
						m_count.connect(i, base_counter.getCount().shiftRight(i));
						break;
				}
			}
			m_design.optimization.popFixOpMode(MathOps.ALL);
		}

		/**
		 * Gets a multipipe stream of counts with each pipe in the stream
		 * being off by the counter increment from the previous pipe.
		 */
		public M getCount() {
			return m_count;
		}

		/**
		 *  Returns a Boolean {@code DFEVar} stream which is {@code 1} at
		 *  the point when the counter will wrap on the next cycle,
		 *  and {@code 0} otherwise.
		 */
		public DFEVar getWrap() {
			return m_wrap;
		}
	}

	/**
	 * Specialization of {@link CounterVectBase} for {@code DFEVector<DFEVar>}.
	 */
	public class CounterVect extends CounterVectBase<DFEVector<DFEVar>> {
		private CounterVect(int n_pipes, Params params) {
			super(
				new DFEVectorType<DFEVar>(params.getExpectedType(), n_pipes).newInstance(m_design),
				params, true);
		}
	}

	Count(Kernel data) {
		m_design = data;
		m_imp = new com.maxeler.photon.libs.CounterFactoryV1(_Kernel.getPhotonDesignData(data));
	}

	/**
	 * Creates a new counter parameterization object.
	 *
	 * @param bit_width The number of bits to use when creating counters
	 *        with this parameterization.
	 * @return A {@link Params} object initialized with the specified bit-width.
	 */
	public Params makeParams(int bit_width) {
		return new Params(m_imp.makeParams(bit_width));
	}

	/**
	 * Makes a new {@link Counter} based on the supplied {@code params} object.
	 *
	 * @param params A {@link Params} object defining how this counter will behave.
	 * @return A configured {@link Counter}.
	 */
	public Counter makeCounter(Params params) {
		return new Counter(m_imp.makeCounter(params.m_imp));
	}

	/**
	 * Makes a new multipipe counter based on the supplied {@code params} object.
	 * <p>
	 * Note that the number of pipes will place some constraints on how the counter
	 * will operate. Particularly, the increment and maximum values must be multiples
	 * of the number of pipes. If these conditions do not hold the counter will
	 * produce undefined results.
	 * </p>
	 *
	 * @param n_elements The number of pipes in the counter.
	 * @param params A {@link Params} object defining how this counter will behave.
	 * @return A configured {@link CounterVect}.
	 */
	public CounterVect makeCounterVect(int n_elements, Params params) {
		return new CounterVect(n_elements, params);
	}

	/**
	 * Makes a new multipipe counter based on the supplied {@code params} object.
	 * <p>
	 * As for {@link Count#makeCounterMP(int, Params)}, but with a template
	 * multipipe type used to define the number of pipes.
	 *
	 * @param mp_type A multipipe type whose definition includes the
	 *                number of pipes.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, ?>
	>
	CounterVectBase<M> makeCounterVect(T mp_type, Params params) {
		return new CounterVectBase<M>(mp_type.newInstance(m_design), params, true);
	}

	/**
	 * Makes a new multipipe counter based on the supplied {@code params} object.
	 * <p>
	 * As for {@link Count#makeCounterMP(int, Params)}, but with a template
	 * multipipe type used to define the number of pipes.
	 * <p>
	 * This method is identical to {@link #makeCounterMP(DFEVectorTypeBase, Params)}
	 * except that it does not generate a warning. You should only use this method if
	 * you are sure that your counter obeys the constraints imposed by multi-piping
	 * (i.e. the maximum value is a multiple of the number of pipes).
	 *
	 * @see #makeCounterMP(DFEVectorTypeBase, Params)
	 * @param mp_type A multipipe type whose definition includes the
	 *                number of pipes.
	 */
	<
		M extends DFEVectorBase<DFEVar, M, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, ?>
	>
	CounterVectBase<M> makeCounterMPNoWarn(T mp_type, Params params) {
		return new CounterVectBase<M>(mp_type.newInstance(m_design), params, false);
	}

	/**
	 * Makes a new multipipe counter based on the supplied {@code params} object.
	 * <p>
	 * As for {@link Count#makeCounterMP(int, Params)}, but with a template
	 * multipipe object used to define the number of pipes.
	 *
	 * @param mp_template_obj A multipipe object which is used to define
	 *                the number of pipes.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, ?>
	>
	CounterVectBase<M> makeCounterVect(M mp_template_obj, Params params) {
		return makeCounterVect(mp_template_obj.getType(), params);
	}

	/**
	 * Creates a counter chain.
	 *
	 * @return An empty counter chain.
	 */
	public CounterChain makeCounterChain() {
		return makeCounterChain(m_design.constant.var(true));
	}

	/**
	 * Creates a counter chain with a Boolean enable signal to
	 * control the entire chain of counters.
	 *
	 * @param enable An {@link DFEVar} with a Boolean-compliant type.
	 * @return An empty counter chain.
	 */
	public CounterChain makeCounterChain(DFEVar enable) {
		if(enable.getType().isConcreteType() && !enable.getType().isBool())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Enable signal of counter-chain must be of a boolean type, " +
				"not " + enable.getType() + ".");

		return new CounterChain(m_design, enable, false);
	}

	/**
	 * Creates a counter chain which saves one bit for counters with max=2<sup>x</sup>.
	 *
	 * @return An empty counter chain.
	 */
	public CounterChain makeCounterChainLessBits() {
		return makeCounterChainLessBits(m_design.constant.var(true));
	}

	/**
	 * Creates a counter chain with a Boolean enable signal to
	 * control the entire chain of counters. This version saves one
	 * bit for counters with max=2<sup>x</sup>.
	 *
	 * @param enable An {@link DFEVar} with a Boolean-compliant type.
	 * @return An empty counter chain.
	 */
	public CounterChain makeCounterChainLessBits(DFEVar enable) {
		if(enable.getType().isConcreteType() && !enable.getType().isBool())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Enable signal of counter-chain must be of a boolean type, " +
				"not " + enable.getType() + ".");

		return new CounterChain(m_design, enable, true);
	}

	/**
	 * Creates a counting stream with values sequentially increasing
	 * from 0 to {@code (2^bit_width - 1)} inclusive before repeating
	 * from 0 again.
	 *
	 * @param bit_width The number of bits used for the counter.
	 * @return An {@code DFEVar} with type {@code dfeUInt(bit_width)}.
	 */
	public DFEVar simpleCounter(int bit_width) {
		Params params = makeParams(bit_width);

		return makeCounter(params).getCount();
	}

	/**
	 * Creates a counting stream with values sequentially increasing from 0
	 * to {@code (wrap_point - 1)} inclusive before repeating from 0 again.
	 * <p>
	 * <b>Note</b>: the specified {@code bit_width} must be wide enough to represent the
	 * {@code wrap_point} fully.
	 *
	 * @param bit_width Number of bits used for the counter.
	 * @param wrap_point The counter will count up to this value minus 1.
	 * @return An {@code DFEVar} with type {@code dfeUInt(bit_width)}.
	 */
	public DFEVar simpleCounter(int bit_width, int wrap_point) {
		Params params = makeParams(bit_width).withMax(wrap_point);

		return makeCounter(params).getCount();
	}

	/**
	 * Creates a counting stream with values sequentially increasing from 0
	 * to {@code (wrap_point - 1)} inclusive before repeating from 0 again.
	 * <p>
	 * As {@link Count#simpleCounter(int, int)} but with the wrap point
	 * variable at run-time by a stream.
	 *
	 * @param wrap_point An DFEVar providing a stream of wrap points. Type
	 *                   must be an unsigned integer {@code bit_width}
	 *                   bits wide.
	 */
	public DFEVar simpleCounter(int bit_width, DFEVar wrap_point) {
		if(wrap_point.getType().isConcreteType() &&
		   (!wrap_point.getType().isUInt() ||
			 wrap_point.getType().getTotalBits() != bit_width))
					throw new MaxCompilerAPIError(m_design.getManager(),
						"Wrap-point stream must be an unsigned integer " + bit_width +
						" bits wide. Not " + wrap_point.getType());

		Params params = makeParams(bit_width).withMax(wrap_point);

		return makeCounter(params).getCount();
	}

	/**
	 * Creates a multipipe counter where each pipe increments from {@code pipe_id} by {@code n_pipes}
	 * to {@code wrap_point-pipe_id-1} inclusive before repeating from {@code pipe_id} again.
	 * <p>
	 * <b>Note</b>: the specified {@code bit_width} must be wide enough to represent the
	 * {@code wrap_point} fully, and {@code wrap_point} must be a multiple of
	 * {@code n_pipes}.
	 * </p>
	 *
	 * @param n_elements The number of pipes in the counter.
	 * @param bit_width The number of bits used for the counter.
	 * @param wrap_point The counter will count up to this value minus 1.
	 * @return An {@code DFEVar} with type {@code dfeUInt(bit_width)}.
	 */
	public DFEVector<DFEVar> simpleCounterVect(int n_elements, int bit_width, int wrap_point) {
		if((wrap_point % n_elements) != 0)
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Cannot make a multi-pipe counter with a max_value " +
				"(" + wrap_point + ") that is not a multiple of the " +
				"number of pipes (" + n_elements + ")" );

		Params params = makeParams(bit_width).withMax(wrap_point);

		return makeCounterVect(n_elements, params).getCount();
	}

	/**
	 * Creates a multipipe counter where each pipe increments from {@code pipe_id} by {@code n_pipes}
	 * to {@code wrap_point-pipe_id-1} inclusive before repeating from {@code pipe_id} again.
	 * <p>
	 * As {@link Count#simpleCounterMP(int, int, int)} but with the wrap point
	 * variable at run-time by a stream.
	 * <p>
	 * <b>Note</b>: if {@code wrap_point} is not a multiple of of the number of pipes then the
	 * output is undefined.
	 * </p>
	 *
	 * @param wrap_point An {@code DFEVar} providing a stream of wrap points. Type
	 *                   must be an unsigned integer {@code bit_width}
	 *                   bits wide.
	 */
	public DFEVector<DFEVar> simpleCounterVect(int n_elements, int bit_width, DFEVar wrap_point) {
		if(wrap_point.getType().isConcreteType() &&
		   (!wrap_point.getType().isUInt() ||
			 wrap_point.getType().getTotalBits() != bit_width))
				throw new MaxCompilerAPIError(m_design.getManager(),
					"Wrap-point stream must be an unsigned integer " + bit_width +
					" bits wide. Not " + wrap_point.getType());

		Params params = makeParams(bit_width).withMax(wrap_point);

		return makeCounterVect(n_elements, params).getCount();
	}


	/**
	 * Creates a multipipe counter where each pipe increments from {@code pipe_id} by {@code n_pipes}
	 * to {@code wrap_point-pipe_id-1} inclusive before repeating from {@code pipe_id} again.
	 * <p>
	 * As {@link Count#simpleCounterMP(int, int, DFEVar)} but with the
	 * number of pipes {code n_pipes} defined by the multipipe type template.
	 * <p>
	 * <b>Note</b>: if {@code wrap_point} is not a multiple of of the number of pipes then the
	 * output is undefined.
	 * </p>
	 *
	 * @param template_type A multipipe type from which the number
	 *                   of pipes can be ascertained.
	 * @param wrap_point An {@code DFEVar} providing a stream of wrap points. Type
	 *                   must be an unsigned integer {@code bit_width}
	 *                   bits wide, and must be the same as the type that
	 *                   is contained in the {@code template_type}.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M simpleCounterVect(T template_type, DFEVar wrap_point) {
		if(wrap_point.getType().isConcreteType() && !wrap_point.getType().isUInt())
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Wrap-point stream must be an unsigned integer. " +
				"Not " + wrap_point.getType());

		if(template_type.getContainedType().equals(wrap_point.getType()))
			throw new MaxCompilerAPIError(m_design.getManager(),
				"Contained type in template multi-pipe type must be the same type" +
				"as wrap-point. (" +  template_type.getContainedType() + " != " +
				wrap_point.getType() +")");

		Params params = makeParams(wrap_point.getType().getTotalBits()).withMax(wrap_point);

		return makeCounterVect(template_type, params).getCount();
	}

	/**
	 * Creates a multipipe counter where each pipe increments from {@code pipe_id} by {@code n_pipes}
	 * to {@code wrap_point-pipe_id-1} inclusive before repeating from {@code pipe_id} again.
	 * <p>
	 * As {@link Count#simpleCounterMP(DFEVectorTypeBase, DFEVar)} but with
	 * the number of pipes {code n_pipes} defined by a multipipe type object.
	 * <p>
	 * <b>Note</b>: if {@code wrap_point} is not a multiple of of the number of pipes then the
	 * output is undefined.
	 * </p>
	 *
	 * @param template_mp A multipipe object from which the number
	 *                   of pipes can be ascertained.
	 * @param wrap_point An {@code DFEVar} providing a stream of wrap points. Type
	 *                   must be an unsigned integer {@code bit_width}
	 *                   bits wide, and must be the same as the type that
	 *                   is contained in the {@code template_mp}.
	 */
	public <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M simpleCounterVect(M template_mp, DFEVar wrap_point) {
		return simpleCounterVect(template_mp.getType(), wrap_point);
	}

	/**
	 * Create a Boolean stream that is {@code true} for a fixed number of
	 * ticks before permanently changing to {@code false}.
	 * <p>
	 * For example, {@code pulse(1)} will create the stream:
	 * <pre><code>1, 0, 0, 0, 0, &hellip;</code></pre>
	 * @param numTicks The number of ticks that the stream will initially be
	 * {@code true} for.
	 * @return A stream of type {@code dfeBool()}.
	 * @see #pulse(int, boolean)
	 */
	public DFEVar pulse(int numTicks) { return pulse(numTicks, true); }

	/**
	 * Create a Boolean stream that has the same value for a fixed number of
	 * ticks before permanently changing to the negated value.
	 * <p>
	 * For example, {@code pulse(1)} will create the stream:
	 * <pre><code>1, 0, 0, 0, 0, &hellip;</code></pre>
	 * and {@code pulse(3, false)} will create the stream:
	 * <pre><code>0, 0, 0, 1, 1, 1, 1, &hellip;</code></pre>
	 * @param numTicks The number of ticks that the stream will take it's initial
	 * value for.
	 * @param initialValue The initial value for the stream.
	 * @return A stream of type {@code dfeBool()}.
	 * @see #pulse(int)
	 */
	public DFEVar pulse(int numTicks, boolean initialValue) {
		if (numTicks < 1)
			throw new MaxCompilerAPIError(m_design.getManager(), "Number of ticks must be greater than 0, not %d.", numTicks);

		final NodePulse node = new NodePulse(
			_Kernel.getPhotonDesignData(m_design),
			numTicks,
			initialValue
		);

		return _KernelBaseTypes.fromImp(m_design, node.connectOutput("output"));
	}
}
