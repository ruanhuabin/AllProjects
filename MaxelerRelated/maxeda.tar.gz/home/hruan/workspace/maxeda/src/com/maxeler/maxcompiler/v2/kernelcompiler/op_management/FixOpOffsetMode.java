package com.maxeler.maxcompiler.v2.kernelcompiler.op_management;

public class FixOpOffsetMode {
	final com.maxeler.photon.op_management.TypeModeMax m_imp;

	FixOpOffsetMode(com.maxeler.photon.op_management.TypeModeMax imp) {
		m_imp = imp;
	}

	@Override
	public String toString() {
		return m_imp.toString();
	}
}
