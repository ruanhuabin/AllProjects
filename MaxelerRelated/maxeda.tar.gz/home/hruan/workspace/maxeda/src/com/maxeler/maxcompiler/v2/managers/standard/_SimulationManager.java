package com.maxeler.maxcompiler.v2.managers.standard;

import com.maxeler.maxcompiler.v2.managers.SimulationParams;

public class _SimulationManager extends SimulationManager {
	public _SimulationManager(String name, SimulationParams parameters) {
		super(name, parameters);
	}

	public _SimulationManager(String name) {
		super(name, SimulationManager.s_default_simparams);
	}

	public void enableSimOnCluster(){
		m_photon_tester.enableSimOnCluster();
	}

	public void enableSimGUI() {
		m_photon_tester.enableSimGUI();
	}

	public void setTerminationCount(String output_name, int num_words) {
		m_photon_tester.setTerminationCount(output_name, num_words);
	}
}
