package com.maxeler.maxcompiler.v2.managers.custom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.managers.custom._HDLTestBench.InterruptFlags;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.BuildPass;
import com.maxeler.maxdc.Entity;
import com.maxeler.maxdc.EntityMaxDCDesign;
import com.maxeler.maxeleros.MappedElementsInfo;
import com.maxeler.maxeleros.MappedMemInfo;
import com.maxeler.maxeleros.MaxelerOSException;
import com.maxeler.maxeleros.ip.MappedElements.Switch.MappedElementSwitch;
import com.maxeler.maxeleros.ip.MappedElements.sim.MappedElemSimUtil;
import com.maxeler.maxeleros.ip.PCIe.sim.DynPCIeSimCore;
import com.maxeler.maxeleros.ip.PCIe.sim.PageFileGen;
import com.maxeler.maxeleros.platforms.PCIeSimulationCore;

/**
 * The {@code HDLTestBench} class allows non-interactive driving of a full-chip HDL simulation.
 */
public class HDLTestBench {

	final List<SimCmd> m_cmds = new LinkedList<SimCmd>();
	PageFileGen m_pfg;
	CustomManager m_manager;
	CustomManager m_manager_regs;
	DynPCIeSimCore m_core;
	private final Map<String, OutputData> m_output_data =
			new LinkedHashMap<String, OutputData>();
	private final String m_build_name;
	private Entity m_top = null;
	boolean m_remote_regs = false;
	private final _ManagerSimulator m_manager_sim;

	private final BuildManager m_build_manager;

	/**
	 * A {@code ScalarInput} defines a name and value for a scalar
	 * input.
	 */
	public static class ScalarInput {
		private final String m_name;
		private final long m_value;

		/**
		 * @param name The name of the scalar input to set.
		 * @param value 64-bit value (will be truncated to the
		 * appropriate width for the named scalar input).
		 */
		public ScalarInput(String name, long value) {
			m_name = name; m_value = value;
		}
	}

	abstract class SimCmd {
		abstract void exec();
	}

	private static class OutputData {
		final long m_data_base;
		final int m_size;
		OutputData(long data_base, String name, int size) {
			m_data_base = data_base;
			m_size = size;
		}
	}

	class BarWR extends SimCmd {
		private final int m_bar;
		private final long m_data;
		private final long m_addr;
		BarWR(int bar, long data, long addr) {
			m_bar = bar; m_data = data; m_addr = addr;
		}
		@Override
		void exec() {
			long addr = m_addr;
			m_core.addRegisterWrite(m_bar, m_data, addr);
		}
	}

	class BarRd extends SimCmd {
		private final int m_bar;
		private final long m_addr;
		private final int m_tag;
		BarRd(int bar, long addr, int tag) {
			m_bar = bar; m_addr = addr; m_tag = tag;
		}
		@Override
		void exec() {
			long addr = m_addr;
			m_core.addRegisterRead(m_bar, addr, m_tag);
		}
	}

	private class BarMemWR extends SimCmd {
		private final int m_bar;
		private final List<Long> m_data;
		private final long m_addr;
		BarMemWR(int bar, List<Long> data, long addr) {
			m_bar = bar; m_data = data; m_addr = addr;
		}
		@Override
		void exec() {
			m_core.addBARMemoryWrite(m_bar, m_data, m_addr);
		}
	}

	private class BarMemRD extends SimCmd {
		private final int m_bar;
		private final long m_addr;
		private final int m_len;
		private final int m_tag;
		BarMemRD(int bar, long addr, int len, int tag) {
			m_bar = bar; m_addr = addr; m_len = len; m_tag = tag;
		}
		@Override
		void exec() {
			m_core.addBARMemoryRead(m_bar, m_addr, m_len, m_tag);
		}
	}

	private class Wait extends SimCmd {
		public int m_cyc;
		Wait(int cyc) { m_cyc = cyc; }
		@Override
		void exec() {
			m_core.addSleep(m_cyc);
		}
	}

	private class WaitNs extends SimCmd {
		public int m_time;
		WaitNs(int time) { m_time = time; }
		@Override
		void exec() {
			m_core.addSleepNs(m_time);
		}
	}

	class SFH extends SimCmd {
		String m_name; List<Long> m_data; int m_id;
		SFH(String name, List<Long> data) { m_name = name; m_data = data; }
		SFH(int id, List<Long> data) { m_id = id; m_name = null; m_data = data; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamFromHostIdFromName(m_name);

			List<String> sfh_output_files = m_pfg.genPageFiles(m_data, true);
			for (String filename : sfh_output_files) {
				m_build_manager.logInfo("SFH%d: Generated data file: %s", id, filename);
			}
			m_core.setupStreamFromHost(id, m_pfg);
			m_core.addSleep(1000);
		}
	}

	class STH extends SimCmd {
		String m_name; int m_size_in_quads; int m_id;
		STH(String name, int size_in_quads) { m_name = name; m_size_in_quads = size_in_quads; }
		STH(int id, int size_in_quads) { m_id = id; m_name = null; m_size_in_quads = size_in_quads; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamToHostIdFromName(m_name);
			m_build_manager.logInfo("Adding %s to stream to host (output) data", m_name);
			m_output_data.put(m_name, new OutputData(PageFileGen.global_data_base, m_name, m_size_in_quads));
			List<String> sth_output_files = m_pfg.genPageFiles(m_size_in_quads);
			for (String filename : sth_output_files) {
				m_build_manager.logInfo("STH%d: Generated data file: %s", id, filename);
			}
			m_core.setupStreamToHost(id, m_pfg);
			m_core.addSleep(1000);
		}
	}

	class SetupSlaveSFH extends SimCmd {
		String m_name; int m_id;
		boolean m_release;
		SetupSlaveSFH(String name, boolean release) { m_name = name; m_release = release;}
		SetupSlaveSFH(int id, boolean release) { m_id = id; m_name = null; m_release = release;}
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamFromHostIdFromName(m_name);

			m_core.configureSlaveSFH(id, m_release);
		}
	}

	class SetupSlaveSTH extends SimCmd {
		String m_name; int m_id;
		boolean m_release;
		SetupSlaveSTH(String name, boolean release) { m_name = name; m_release = release;}
		SetupSlaveSTH(int id, boolean release) { m_id = id; m_name = null; m_release = release;}
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamToHostIdFromName(m_name);

			m_core.configureSlaveSTH(id, m_release);
		}
	}

	class SlaveSFH extends SimCmd {
		String m_name; List<Long> m_data; int m_id;
		SlaveSFH(String name, List<Long> data) { m_name = name; m_data = data; }
		SlaveSFH(int id, List<Long> data) { m_id = id; m_name = null; m_data = data; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamFromHostIdFromName(m_name);

			// zero_pad size to a multiple of 4K bytes (512 qwords), otherwise there is an issue in PageFileGen
			if (m_data.size()%512 != 0) {
				for (int i = (m_data.size()%512); i < 512; i++)
					m_data.add(0L);
			}

			// Grab the current global base address, which the address to read the data at
			long data_base_addr = PageFileGen.global_data_base;

			List<String> sfh_output_files = m_pfg.genPageFiles(m_data, true);
			for (String filename : sfh_output_files) {
				System.out.printf("Slave SFH%d: Generated data file: %s\n", id, filename);
			}
			m_core.addSlaveSFH(id, data_base_addr, m_data.size());
			m_core.addSleep(1000);
		}
	}

	class SlaveSTH extends SimCmd {
		String m_name; int m_size_in_quads; int m_id;
		SlaveSTH(String name, int size_in_quads) { m_name = name; m_size_in_quads = size_in_quads; }
		SlaveSTH(int id, int size_in_quads) { m_id = id; m_name = null; m_size_in_quads = size_in_quads; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamToHostIdFromName(m_name);

			// page size to a multiple of 4K bytes (513 qwords), otherwise PageFileGen does weird things.
//			int size_in_quads_padded = ((m_size_in_quads % 512 != 0) ? MaxDCMath.nextMultiple(m_size_in_quads, 512) : m_size_in_quads);

			// Grab the current global base address, which the address to write the returned data to
			long data_base_addr = PageFileGen.global_data_base;

			//System.out.printf("Adding %s to stream to host (output) data\n", m_name);
			m_output_data.put(m_name, new OutputData(PageFileGen.global_data_base, m_name, m_size_in_quads));
//			List<String> sth_output_files = m_pfg.genPageFiles(size_in_quads_padded);
//			for (String filename : sth_output_files) {
//				System.out.printf("Slave STH%d: Generated data file: %s\n", id, filename);
//			}
			m_core.addSlaveSTH(id, data_base_addr, m_size_in_quads);
			m_core.addSleep(1000);
		}
	}

//	private class MRWr extends SimCmd {
//		String m_name; int m_value;
//		MRWr(String name, long value) { m_name = name; m_value = (int) value; }
//		@Override
//		void exec() {
//			MappedElementsInfo info = m_manager_regs.getMappedElementsInfo();
//			int chain_len = info.getRegisterChainLength();
//			m_core.addMappedRegWrite((chain_len - 1) - info.getRegisterAddress(m_name),
//				m_value,
//				info.getRegisterMask(m_name));
//		}
//	}

	protected class MMWrMEC extends SimCmd {
		private final long m_addr;
		private final List<Long> m_data;
		private final String m_name;
		private final boolean m_assert_stop;

		MMWrMEC(String name, long addr, List<Long> data) {
			this(name, addr, data, false);
		}

		MMWrMEC(String name, long addr, List<Long> data, boolean stop) { m_name = name; m_addr = addr; m_data = data; m_assert_stop = stop; }
		@Override
		void exec() {
			int ctrl_stream = m_manager.getControlStreamFromHost();

			List<Integer> response_targets =
				Arrays.asList(MappedElementSwitch.MappedElementAddressBit.PCI_EXPRESS); // FIXME!
			boolean remote = isMAX3();

			if (isMAX3()) {
				// setup all the quirky muxes
				m_core.addSleep(25);
				m_core.addRegisterWrite(0, 0x2, 0x70);
				m_core.addRegisterWrite(0, 0x2, 0x10);
				m_core.addSleep(25);
			}

			if (remote) {
				response_targets =
					Arrays.asList(MappedElementSwitch.MappedElementAddressBit.INTER_FPGA_LINK, MappedElementSwitch.MappedElementAddressBit.PCI_EXPRESS);
			}

			List<Long> packets = new ArrayList<Long>();

			MappedElementsInfo info = m_manager_regs.getMappedElementsInfo();

			String split_name[] = m_name.split("\\.");

			if (split_name.length == 3)
				split_name[1]=split_name[1] + "." + split_name[2];
			else if (split_name.length != 2)
				throw new MaxelerOSException("Mapped memory '" + m_name + "' does not have format <core name>.<mem name>");

			String core_name = split_name[0];
			String mem_name = split_name[1];
			int mem_addr = -1;

			for (MappedMemInfo ifo : info.getMappedMemInfos()) {
				if (mem_name.equals(ifo.getName()) &&
					core_name.equals(ifo.getCoreName())) {
					mem_addr = ifo.getAddress();
					break;
				}
			}

			if (mem_addr == -1)
				throw new MaxelerOSException("Mapped memory '" + m_name + "' does not exist.");

			int core_id = 0;
			int mem_id = mem_addr >> 16;
			int index = ((int)m_addr);

			List<Long> packet = MappedElemSimUtil.buildMappedMemoriesControllerPacket(
				remote, core_id << 8 | mem_id, index, 0, response_targets, true, m_data, m_assert_stop);

			packets.addAll(packet);

			List<String> mec_output_files = m_pfg.genPageFiles(packets, true);
			for (String filename : mec_output_files) {
				m_build_manager.logInfo("Mapped memory write MEC : Generated data file: %s", filename);
			}

			// DMA packets
			m_core.setupStreamFromHost(ctrl_stream, m_pfg);

			int timeout = packets.size()*2+1000;
			if (isMAX3()) {
				m_core.addWaitForInterruptX(1L<<ctrl_stream, timeout, InterruptFlags.SFH_FLAG);
			} else {
				m_core.addWaitForInterruptX(1L<<(ctrl_stream), timeout, InterruptFlags.SFH_FLAG);
			}

			// wait a little bit for register values to stick
			m_core.addSleep(info.getRegisterChainLength()*(250/50)+1000);
		}
	}

	private class MRWrMEC extends SimCmd {
		List<ScalarInput> m_regs;
		MRWrMEC(List<ScalarInput> registers) { m_regs = registers; }
		@Override
		void exec() {
			int ctrl_stream = m_manager.getControlStreamFromHost();
			List<Integer> response_targets =
				Arrays.asList(MappedElementSwitch.MappedElementAddressBit.PCI_EXPRESS);
			boolean remote = isMAX3();

			if (isMAX3()) {
				// setup all the quirky muxes
				m_core.addSleep(25);
				m_core.addRegisterWrite(0, 0x2, 0x70);
				m_core.addRegisterWrite(0, 0x2, 0x10);
				m_core.addSleep(25);
			}

			if (remote) {
				response_targets =
					Arrays.asList(MappedElementSwitch.MappedElementAddressBit.INTER_FPGA_LINK, MappedElementSwitch.MappedElementAddressBit.PCI_EXPRESS);
			}

			MappedElementsInfo info = m_manager_regs.getMappedElementsInfo();
			int bytes[] = new int[info.getRegisterChainLength()];
			boolean mask[] = new boolean[info.getRegisterChainLength()];

			for (int i=0; i<info.getRegisterChainLength(); i++)
				mask[i] = false;

			for (ScalarInput r : m_regs) {
				// process each register write
				int addr = info.getRegisterAddress(r.m_name);
				int size = 0;

				switch (info.getRegisterMask(r.m_name)) {
					case 0x1: size = 1; break;
					case 0x3: size = 2; break;
					case 0x7: size = 3; break;
					case 0xf: size = 4; break;
					case 0x1f: size = 5; break;
					case 0x3f: size = 6; break;
				}

				for (int i=0; i<size; i++) {
					bytes[addr + i]=(int)(((r.m_value) >> (i*8)) & 0xff);
					mask[addr + i] = true;
				}
			}

			List<Long> packets = new ArrayList<Long>();

			// build packets
			int chain_rotations = 0;
			for (int i=0; i<info.getRegisterChainLength(); i++) {
				List<Integer> bytes_here = new LinkedList<Integer>();
				int size_here = 0;
				int addr_here = i;
				while(i <info.getRegisterChainLength() && mask[i]) {
					bytes_here.add(bytes[i]);
					i++;
					size_here++;
				}

				if (size_here > 0) {
					// assemble packet
					++chain_rotations;
					List<Long> packet = MappedElemSimUtil.buildRegisterControllerPacket(
						remote, addr_here, addr_here + size_here, response_targets, true, bytes_here);
					int index = 0;
					m_build_manager.logInfo("Sending MEC register write packet start=%x end=%x", addr_here, addr_here+size_here);
					for (Long item : packet) {
						m_build_manager.logInfo("[%02d] 0x%08x\n", index, item);
						index++;
					}
					packets.addAll(packet);
				}
			}

			List<String> mec_output_files = m_pfg.genPageFiles(packets, true);
			for (String filename : mec_output_files) {
				m_build_manager.logInfo("Mapped register write MEC : Generated data file: %s", filename);
			}

			// DMA packets
			m_core.setupStreamFromHost(ctrl_stream, m_pfg);

			int timeout = packets.size()*2+1000;
			if (isMAX3()) {
				m_core.addWaitForInterruptX(1L<<ctrl_stream, timeout, InterruptFlags.SFH_FLAG);
			} else {
				m_core.addWaitForInterruptX(1L<<(ctrl_stream), timeout, InterruptFlags.SFH_FLAG);
			}

			// wait a little bit for register values to stick
			m_core.addSleep((info.getRegisterChainLength()*(250/50)+1000)*chain_rotations);
		}
	}

	class SFAWrMEC extends SimCmd {
		private final List<Integer> m_bits_to_toggle;
		private final boolean m_remote;

		SFAWrMEC(List<Integer> bits_to_toggle, boolean remote) {
			m_bits_to_toggle = bits_to_toggle;
			m_remote = remote;
		}
		@Override
		void exec() {
			int ctrl_stream = m_manager.getControlStreamFromHost();
			List<Integer> response_targets =
				Arrays.asList(MappedElementSwitch.MappedElementAddressBit.PCI_EXPRESS); // FIXME!
			List<Integer> switch_targets =
				Arrays.asList(MappedElementSwitch.MappedElementAddressBit.SIGNAL_FORWARDING);
//			boolean remote = false; // FIXME!

			if(m_remote) {
				response_targets = Arrays.asList(MappedElementSwitch.MappedElementAddressBit.INTER_FPGA_LINK, MappedElementSwitch.MappedElementAddressBit.PCI_EXPRESS);
				switch_targets = Arrays.asList(MappedElementSwitch.MappedElementAddressBit.INTER_FPGA_LINK, MappedElementSwitch.MappedElementAddressBit.SIGNAL_FORWARDING);
			}

			List<Long> packets = new ArrayList<Long>();

			MappedElementsInfo info = m_manager_regs.getMappedElementsInfo();

			List<Long> packet = MappedElemSimUtil.buildSignalForwardingPacket(m_bits_to_toggle, switch_targets, response_targets, false);

			packets.addAll(packet);

			List<String> mec_output_files = m_pfg.genPageFiles(packets, true);
			for (String filename : mec_output_files) {
				m_build_manager.logInfo("SFA write MEC : Generated data file: %s", filename);
			}

			// DMA packets
			m_core.setupStreamFromHost(ctrl_stream, m_pfg);

			int timeout = packets.size()*2+1000;
			if (isMAX3()) {
				m_core.addWaitForInterruptX(1L<<ctrl_stream, timeout, InterruptFlags.SFH_FLAG);
			} else {
				m_core.addWaitForInterruptX(1L<<(ctrl_stream), timeout, InterruptFlags.SFH_FLAG);
			}

			// wait a little bit for register values to stick
			m_core.addSleep(info.getRegisterChainLength()*(250/50)+1000);
		}

	}

	class WaitInt extends SimCmd {
		int m_int_num;
		WaitInt(int int_num) { m_int_num = int_num; }
		@Override
		void exec() {
			m_core.addWaitForInterrupt(m_int_num);
		}
	}

	class SyncSTH extends SimCmd {
		String m_name = null;
		int m_timeout;
		int m_id;
		SyncSTH(String name, int timeout) { m_timeout = timeout; m_name = name; }
		SyncSTH(int id, int timeout) { m_timeout = timeout; m_id = id; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamToHostIdFromName(m_name);
			if (isMAX3()) {
				m_core.addWaitForInterruptX(1L<<id, m_timeout, InterruptFlags.STH_FLAG);
			} else {
				m_core.addWaitForInterruptX(1L<<(id+8), m_timeout, InterruptFlags.STH_FLAG);
			}
		}
	}

	class SyncSFH extends SimCmd {
		String m_name = null;
		int m_timeout;
		int m_id;
		SyncSFH(String name, int timeout) { m_timeout = timeout; m_name = name; }
		SyncSFH(int id, int timeout) { m_timeout = timeout; m_id = id; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamFromHostIdFromName(m_name);
			if (isMAX3()) {
				m_core.addWaitForInterruptX(1L<<id, m_timeout, InterruptFlags.SFH_FLAG);
			} else {
				m_core.addWaitForInterruptX(1L<<(id), m_timeout, InterruptFlags.SFH_FLAG);
			}
		}
	}

	class SyncSlaveSFH extends SimCmd {
		String m_name = null;
		int m_timeout;
		int m_id;
		SyncSlaveSFH(String name, int timeout_us) { m_name = name; m_timeout = timeout_us; }
		SyncSlaveSFH(int id     , int timeout_us) { m_id = id; m_timeout = timeout_us; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamFromHostIdFromName(m_name);

			m_core.addSyncSlaveSFH(id, m_timeout);
		}
	}

	class SyncSlaveSTH extends SimCmd {
		String m_name = null;
		int m_timeout;
		int m_id;
		SyncSlaveSTH(String name, int timeout_us) { m_name = name; m_timeout = timeout_us; }
		SyncSlaveSTH(int id,      int timeout_us) { m_id = id; m_timeout = timeout_us; }
		@Override
		void exec() {
			int id;
			if (m_name == null) {
				id = m_id;
				m_name = "" + m_id;
			} else
				id = m_manager_regs.getPCIeStreamToHostIdFromName(m_name);
			m_core.addSyncSlaveSTH(id, m_timeout);
		}
	}

	class WaitIntX extends SimCmd {
		long m_one_hot_ints;
		int m_timeout;
		InterruptFlags m_flag;
		WaitIntX(long one_hot_ints, int timeout, InterruptFlags flag) { m_one_hot_ints = one_hot_ints;
								m_timeout = timeout; m_flag = flag;}
		@Override
		void exec() {
			m_core.addWaitForInterruptX(m_one_hot_ints, m_timeout, m_flag);
		}
	}

	/**
	 * Initiates write to an input stream from the CPU to the Manager.
	 * <p>
	 * The amount of data to write is determined from the number of items
	 * in the {@code data} list.
	 * <p>
	 * Use {@link #syncStreamFromCPU} to wait for the write to complete.
	 * <p>
	 * @param name The name of the input stream to write to.
	 * @param data The data to write, packed into a list of 64-bit words.
	 */
	public void streamFromCPU(String name, List<Long> data) {
		m_cmds.add(new SFH(name, data));
	}

	/**
	 * Initiates read from an output stream from the Manager to the CPU.
	 * <p>
	 * Use {@link #syncStreamToCPU} to wait for the read to complete.
	 * <p>
	 * @param name The name of the output stream to read from.
	 * @param size_in_quads The number of 64-bit words to read.
	 */
	public void streamToCPU(String name, int size_in_quads) {
		m_cmds.add(new STH(name, size_in_quads));
	}

	/**
	 * Waits for a number of clock cycles.
	 * <p>
	 * @param num_cycles Number of clock cycles to wait for.
	 */
	public void waitCycles(int num_cycles) {
		m_cmds.add(new Wait(num_cycles));
	}


	/**
	 * Waits for a number of nanoseconds.
	 * <p>
	 * @param time Number of nanoseconds to wait for.
	 */
	public void waitNanoSeconds(int time) {
		m_cmds.add(new WaitNs(time));
	}

	/**
	 * Passes the reset signal to all Manager blocks in the design.
	 */
	public void resetDevice() {

		if (isMAX3()) {
			// setup all the quirky muxes
			waitNanoSeconds(25);
			barWrite(0, 0x2, 0x70);
			barWrite(0, 0x2, 0x10);
			waitNanoSeconds(25);
		}

		// Do the same as MaxCompilerRT does...
		if (isMAX3()) {
			// set IFPGA session key to 1 (if MAX3)
			waitNanoSeconds(25);
			barWrite(0, 0x1, 0x3c);
			waitNanoSeconds(25);
			// toggle signal 0 on interface FPGA
			toggleSFABits(Arrays.asList(0), false);
		}

		// toggle signal 0 on compute FPGA (or MAX2 single FPGA)
		toggleSFABits(Arrays.asList(0), isMAX3());

		if (isMAX3()) {
			// set IFPGA session key to 0 (if MAX3)
			waitNanoSeconds(25);
			barWrite(0, 0x0, 0x3c);
			waitNanoSeconds(25);
			// toggle signal 0 on interface FPGA
			toggleSFABits(Arrays.asList(0), false);
		}
	}

	/**
	 * Sends a PCC Start
	 */
	public void pccStart() {
		// toggle pcc start signal via SFA
		toggleSFABits(Arrays.asList(5), isMAX3());
	}

	/**
	 * Sends a PCC Switch
	 */
	public void pccSwitch() {
		// toggle pcc switch signal via SFA
		toggleSFABits(Arrays.asList(4), isMAX3());
	}

	/**
	 * Writes a group of scalar inputs.
	 * <p>
	 * @param registers A list of scalar inputs to set.
	 */
	public void setScalarInputsGroup(List<ScalarInput> registers) {
		m_cmds.add(new MRWrMEC(registers));
	}

	/**
	 * Writes one or more words to the mapped memory bus.
	 * <p>
	 * Writes the list of data items in {@code data},
	 * starting at address {@code addr}.
	 * <p>
	 * <b>Note</b>:The 64-bit arguments for address and data
	 * are truncated to the appropriate width (16 bits for the
	 * address and 36 bits for the data).
	 * <p>
	 * @param name The name of the mapped memory to set.
	 * @param addr The start address.
	 * @param data The data to write.
	 */
	public void setMappedMemory(String name, long addr, List<Long> data) {
		setMappedMemory(name, addr, data, false);
	}

	void setMappedMemory(String name, long addr, List<Long> data, boolean assert_stop) {
		m_cmds.add(new MMWrMEC(name, addr, data, assert_stop));
	}

	/**
	 * Waits for completion of a write to an input stream from the CPU to the Manager.
	 * <p>
	 * If the write completes, the testbench
	 * will continue. If the timeout is reached before the write completes,
	 * the simulation will terminate immediately.
	 * <p>
	 * @param name Name of the input stream to wait on.
	 * @param timeout Timeout in clock cycles.
	 */
	public void syncStreamFromCPU(String name, int timeout) {
		m_cmds.add(new SyncSFH(name, timeout));
	}

	/**
	 * Waits for completion of a read from an output stream from the Manager to the CPU.
	 * <p>
	 * If the read completes, the testbench
	 * will continue. If the timeout is reached before the read completes,
	 * the simulation will terminate immediately.
	 * <p>
	 * @param name Name of the output stream to wait on.
	 * @param timeout Timeout in clock cycles.
	 */
	public void syncStreamToCPU(String name, int timeout) {
		m_cmds.add(new SyncSTH(name, timeout));
	}

	void waitInterrupt(long one_hot_int, int timeout, InterruptFlags flag) {
		m_cmds.add(new WaitIntX(one_hot_int, timeout, flag));
	}

	/**
	 * Waits for an interrupt from any memory stream.
	 * <p>
	 * If an interrupt is raised by any memory streams, the testbench
	 * will continue. If the timeout is reached before a
	 * memory stream interrupt is received, the simulation will terminate
	 * immediately.
	 * <p>
	 * @param timeout Timeout in clock cycles.
	 */
	public void waitForMemoryInterrupt(int timeout) {
		if (isMAX3())
			waitInterrupt(2, timeout, InterruptFlags.MEM_FLAG);
		else
			waitInterrupt(1L<<16, timeout, InterruptFlags.MEM_FLAG);
	}

	// Note: Sim_transactor: Only the lower 32 bits from data (1 dword) will be written.
	void barWrite(int bar, long data, long addr) {
		m_cmds.add(new BarWR(bar, data, addr));
	}

	// Note: Sim_transactor: The Read Request will be for 32 bits only (1dword)
	void barRead(int bar, long addr, int tag) {
		m_cmds.add(new BarRd(bar, addr, tag));
	}

	void barMemoryWrite(int bar, List<Long> data, long addr) {
		m_cmds.add(new BarMemWR(bar, data, addr));
	}

	// length in qwords
	void barMemoryRead(int bar, long addr, int len, int tag) {
		m_cmds.add(new BarMemRD(bar, addr, len, tag));

	}

	void setupSlaveStreamFromCPU(String name, boolean release) {
		m_cmds.add(new SetupSlaveSFH(name, release));
	}

	void setupSlaveStreamToCPU(String name, boolean release) {
		m_cmds.add(new SetupSlaveSTH(name, release));
	}

	void slaveStreamFromCPU(String name, List<Long> data) {
		m_cmds.add(new SlaveSFH(name, data));
	}

	void slaveStreamToCPU(String name, int size_in_quads) {
		m_cmds.add(new SlaveSTH(name, size_in_quads));
	}

	void syncSlaveStreamFromCPU(String name, int timeout_us) {
		m_cmds.add(new SyncSlaveSFH(name, timeout_us));
	}

	void syncSlaveStreamToCPU(String name, int timeout_us) {
		m_cmds.add(new SyncSlaveSTH(name, timeout_us));
	}

	void toggleSFABits(List<Integer> bits_to_toggle, boolean remote) {
		m_cmds.add(new SFAWrMEC(bits_to_toggle, remote));
	}

	/**
	 * Reads the data from a stream output.
	 *
	 * The data is returned packed into a list of 64-bit words.
	 *
	 * <b>Note</b>: The expected amount of data is <em>always</em> returned, regardless
	 * of how much data was produced in the simulation.
	 *
	 * @param output_name The name of the output stream.
	 * @return The output data.
	 */
	public List<Long> getOutputData(String output_name) {
		if (!m_output_data.containsKey(output_name))
			throw new MaxCompilerAPIError(m_manager, "Stream to CPU '" + output_name + "' does not exist.");
		OutputData dat = m_output_data.get(output_name);
		List<Long> data_out = m_pfg.readPageFiles(dat.m_data_base, dat.m_size * 8 /* bytes */);
		return data_out;
	}

	HDLTestBench(String build_name, _ManagerSimulator sim) {
		m_build_manager = sim.getSubBuildManager(build_name);
		m_build_name = build_name;
		sim.addSubManager(this);
		m_manager_sim = sim;
	}

	BuildManager getBuildManager() {
		return m_build_manager;
	}

	void setForwardedManager(CustomManager manager) {
		m_manager_regs = manager;
		m_remote_regs = true;
	}

	Entity buildSubDesign(BuildManager bm) {
		Entity top = m_manager.buildSim(m_build_name);
		if (top instanceof PCIeSimulationCore) {
			class FinalizePass implements BuildPass {
				@Override
				public void pass(BuildManager build_manager) {
					// initial wait for initialization
					m_core.addInitDelay(m_manager_regs.hasMemory(), isMAX3() && m_manager_regs.fullCalSim());
					if (m_manager_regs.hasMemory() && isMAX3()) {
						MRWrMEC init_mem_int = 	new MRWrMEC(Arrays.asList(
							new ScalarInput("SignalForwardingAdapter.SFA_FORWARD_EN", 0x02)));
						init_mem_int.exec();
					}

					for (SimCmd cmd : m_cmds) {
						cmd.exec();
					}

					m_core.addSleep(1000);

					m_core.addExit();
				}
			};

			m_build_manager.addBuildPass( new FinalizePass() );
			m_core = ((PCIeSimulationCore)top).getDynamicPCIeSimulationCore();
			m_pfg = new PageFileGen(m_build_manager, m_core.getPageDir());
		}
		m_top = top;

		return new EntityMaxDCDesign(bm, m_build_manager, top);
	}

	Entity getTopLevel() {
		return m_top;
	}

	 boolean isMAX3() {
		return m_manager_sim.isMAX3();
	}

	/**
	 * Enables or disables the ModelSim GUI during simulation.
	 * <p>
	 * The ModelSim GUI is disabled by default.
	 * <p>
	 * @param enabled If {@code true} then the ModelSim GUI is enabled,
	 * otherwise it is disabled.
	 */
	public void setEnableSimGUI(boolean enabled) {
		m_manager_sim.setEnableGui(enabled);
	}

	private boolean m_ran_test = false;

	/**
	 * Launches ModelSim and runs the test.
	 * <p>
	 * With the ModelSim GUI disabled, ModelSim will exit when the simulation is complete.
	 * With the ModelSim GUI enabled, ModelSim must be run manually (for example with
	 * {@code run -all}) and closed when the simulation is complete.
	 * <p>
	 * @see #setEnableSimGUI(boolean)
	 */
	public void runTest() {
		if(m_ran_test)
			throw new MaxCompilerAPIError(
				m_manager,
				"Currently only one test can be run per-CustomManager instance.");
		m_ran_test = true;
		m_manager_sim.runTest();

	}
}
