package com.maxeler.maxcompiler.v2.managers.custom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.BuildPass;
import com.maxeler.maxdc.Entity;
import com.maxeler.maxdc.mentor.ModelSim;
import com.maxeler.maxeleros.platforms.MAX2BoardDualTop;
import com.maxeler.maxeleros.platforms.MAX2BoardSingleTop;
import com.maxeler.maxeleros.platforms.MAX3BoardTop;
import com.maxeler.maxeleros.platforms.MAX3ComputeFPGATop;
import com.maxeler.maxeleros.platforms.MAX3InterfaceFPGATop;

public class _ManagerSimulator {

	public enum ManagerSimType {
		MAX2_SINGLEFPGA, MAX2_DUALFPGA, MAX3
	};

	private final ArrayList<HDLTestBench> m_devices = new ArrayList<HDLTestBench>();
	private final BuildManager m_build_manager;
	private final ManagerSimType m_type;

	private boolean m_enable_gui;
	private boolean m_disable_log_everything;
	private boolean m_use_glbl;

	public _ManagerSimulator(String build_name, String build_directory, ManagerSimType type) {
		m_build_manager = new BuildManager(build_name, build_directory, true);
		m_type = type;
	}

	public _ManagerSimulator(String build_name, ManagerSimType type) {
		this(build_name, build_name, type);
	}

	public void setEnableGui(boolean enabled) {
		m_enable_gui = enabled;
	}

	public void setDisableLogEverything(boolean disabled) {
		m_disable_log_everything = disabled;
	}

	public void setEnableUseGlbl(boolean enabled) {
		m_use_glbl = enabled;
	}

	public void runTest() {
		ModelSim msim = new ModelSim();
		if (m_enable_gui) msim.enableSimGUI();
		if (m_disable_log_everything) msim.disableLogEverything();

		msim.setRunCommand("vsim -t 1ps -novopt -lib work", false);
		switch(m_type) {
			case MAX2_DUALFPGA:
			case MAX2_SINGLEFPGA:
				// Hack to pick up Verilog header files that get stuck in sub-build dirs
				for (String sub_build : m_sub_build_names)
					msim.setVerilogCommand("vlog +incdir+../" + sub_build);
				break;
			case MAX3:
				if (m_use_glbl)
					msim.setRunCommand("vsim -t ps -novopt +notimingchecks -L unisims_ver glbl", false);
				else
					msim.setRunCommand("vsim -t ps -novopt +notimingchecks -L unisims_ver", false);
				break;
		}

		runTest(Arrays.asList((BuildPass)msim));
	}

	private void runTest(List<BuildPass> build_passes)  {

		/* Run simulation */
		//BuildManager build_manager = _Managers.getBuildManager(this);

		Entity built_sim_top[] = new Entity[m_devices.size()];
		Entity real_top[] = new Entity[m_devices.size()];
		int i=0;
		for (HDLTestBench dev : m_devices) {
			built_sim_top[i] = dev.buildSubDesign(getBuildManager());
			real_top[i] = dev.getTopLevel();
			i++;
		}

		Entity top = null;

		switch(m_type) {
			case MAX2_SINGLEFPGA:
				top = new MAX2BoardSingleTop(getBuildManager(), built_sim_top[0], false);
				break;
			case MAX2_DUALFPGA:
				top = new MAX2BoardDualTop(getBuildManager(), built_sim_top, false, true);
				break;
			case MAX3:
				Entity iface, compute;
				Entity iface_top, compute_top;

				if (built_sim_top.length < 2) {
					iface = built_sim_top[0]; compute = null;
					iface_top = real_top[0]; compute_top = null;
				} else {
					if (real_top[0] instanceof MAX3InterfaceFPGATop &&
						real_top[1] instanceof MAX3ComputeFPGATop) {
						iface = built_sim_top[0]; compute = built_sim_top[1];
						iface_top = real_top[0]; compute_top = real_top[1];
					} else if (real_top[1] instanceof MAX3InterfaceFPGATop &&
						real_top[0] instanceof MAX3ComputeFPGATop) {
						iface = built_sim_top[1]; compute = built_sim_top[0];
						iface_top = real_top[1]; compute_top = real_top[0];
					} else {
						throw new MaxCompilerAPIError("For MAX3 simulation, one chip must be an Interface FPGA and the other chip must be a Compute FPGA." +
							" real_top[0]=" + real_top[0].getClass().getName() +
							" real_top[1]=" + real_top[1].getClass().getName());
					}
				}
				top = new MAX3BoardTop(getBuildManager(),
					iface, iface_top,
					compute,
					compute_top);
				break;
			default:
				throw new MaxCompilerAPIError("Unknown board type: " + m_type);
		}


		if (build_passes != null) {
			for (BuildPass pass : build_passes) {
				m_build_manager.addBuildPass(pass);
			}
		}

		m_build_manager.build(top);
	}

	private BuildManager getBuildManager() {
		return m_build_manager;
	}

	private final List<String> m_sub_build_names = new LinkedList<String>();

	BuildManager getSubBuildManager(String build_name) {
		m_sub_build_names.add(build_name);
		return getBuildManager().getSubBuildManager(build_name);
	}

	public void addSubManager(HDLTestBench sim) {
		m_devices.add(sim);
	}

	boolean isMAX3() {
		return m_type == ManagerSimType.MAX3;
	}

}
