package com.maxeler.maxcompiler.v2.kernelcompiler.op_management;

public class _KernelOpManagement {
	public static com.maxeler.photon.op_management.TypeModeBitSize toImp(FixOpBitSizeMode bit_size_mode) {
		return bit_size_mode.m_imp;
	}

	public static FixOpBitSizeMode fromImp(com.maxeler.photon.op_management.TypeModeBitSize bit_size_mode) {
		return new FixOpBitSizeMode(bit_size_mode);
	}

	public static com.maxeler.photon.op_management.TypeModeMax toImp(FixOpOffsetMode offset_mode) {
		return offset_mode.m_imp;
	}

	public static FixOpOffsetMode fromImp(com.maxeler.photon.op_management.TypeModeMax offset_mode) {
		return new FixOpOffsetMode(offset_mode);
	}
}
