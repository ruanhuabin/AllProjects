package com.maxeler.maxcompiler.v2.managers.custom;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxeleros.managercompiler.core.StreamSourceless;
import com.maxeler.maxeleros.managercompiler.nodes.WrapperNodePhoton;

public class DFELink {
	private final com.maxeler.maxeleros.managercompiler.core.Stream m_imp;

	DFELink(com.maxeler.maxeleros.managercompiler.core.Stream imp) {
		m_imp = imp;
	}

	com.maxeler.maxeleros.managercompiler.core.Stream toImp() {
		return m_imp;
	}

	public void connect(DFELink src) {
		m_imp.connect(src.m_imp);
	}

	void setBufferSpaceRequirement(int buffer_size_bits) {
		m_imp.getSource().getStreamingInterfaceType().setBufferSpaceRequirement(buffer_size_bits);
	}

	void setIOHysteresis(int hysteresis) {
		WrapperNodePhoton photon = null;
		String name;
		if ((!(m_imp instanceof StreamSourceless)) && (m_imp.getSource().getParentNode() instanceof WrapperNodePhoton)) {
			photon = (WrapperNodePhoton) m_imp.getSource().getParentNode();
			name = m_imp.getSource().getName();
		} else if ((m_imp.getSink().getParentNode() instanceof WrapperNodePhoton)) {
			photon = (WrapperNodePhoton) m_imp.getSink().getParentNode();
			name = m_imp.getSink().getName();
		} else
			throw new MaxCompilerAPIError("A Stream can only have a hysteresis set if it is the input or output of a Kernel.");

		photon.setIOHysteresis(name, hysteresis);
	}

	String getName() {
		return m_imp.getName();
	}
}
