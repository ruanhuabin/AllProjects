package com.maxeler.maxcompiler.v2.errors;

import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.utils.BuildManagerSupplier;
import com.maxeler.utils.MaxCompilerHide;
import com.maxeler.utils.MaxelerException;

public class MaxCompilerAPIError extends MaxelerException {
	private static final long serialVersionUID = 1L;

	public MaxCompilerAPIError(Throwable t) {
		super(null, t);
	}

	public MaxCompilerAPIError(String format, Object...args) {
		super(null, String.format(format, args));
	}

	public MaxCompilerAPIError(DFEManager build_manager, Throwable t) {
		super(_Managers.getBuildManager(build_manager), t);
	}

	public MaxCompilerAPIError(DFEManager build_manager, String format, Object...args) {
		super(_Managers.getBuildManager(build_manager), String.format(format, args));
	}

	@MaxCompilerHide
	public MaxCompilerAPIError(BuildManagerSupplier build_manager, String format, Object...args) {
		super(build_manager.getBuildManager(), String.format(format, args));
	}

	@MaxCompilerHide
	public MaxCompilerAPIError(BuildManager build_manager, String format, Object...args) {
		super(build_manager, String.format(format, args));
	}

	public static MaxCompilerAPIError nullParam(String paramName) {
		return new MaxCompilerAPIError("Parameter '%s' must not be null.", paramName);
	}

	public static MaxCompilerAPIError nullParam(DFEManager build_manager, String paramName) {
		return new MaxCompilerAPIError(build_manager, "Parameter '%s' must not be null.", paramName);
	}
}
