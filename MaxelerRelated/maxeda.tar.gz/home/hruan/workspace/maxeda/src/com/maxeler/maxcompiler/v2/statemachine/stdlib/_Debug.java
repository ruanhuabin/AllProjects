package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmEnumType;

public final class _Debug {
	private _Debug(){}

	public static Debug create(StateMachineLib owner) {return new Debug(owner);}

	public static List<DFEsmEnumType> getEnumTypesWhereStringConversionNeeded(Debug deb) {
		return deb.m_enumsStringConversionNeeded;
	}
}
