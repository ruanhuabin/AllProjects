package com.maxeler.maxcompiler.v2.managers;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import com.maxeler.maxcompiler.Version;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerInternalError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelConfiguration;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._KernelConfiguration;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.maxdc.BuildPass;
import com.maxeler.maxdc.Entity;
import com.maxeler.maxdc.MaxFileManager;
import com.maxeler.maxdc.proc_management.ProcessFailedException;
import com.maxeler.photon.compile_managers.MaxDCCompileManager;
import com.maxeler.photon.configuration.MaxBoardModel;
import com.maxeler.photon.core.PhotonCompileManager;
import com.maxeler.utils.MaxCompilerHide;

public abstract class DFEManager {
	private BuildManager m_build_manager;
	private BuildConfig m_build_config;

	private PhotonCompileManager.Factory m_compile_manager_factory =
		new MaxDCCompileManager.Factory();

	private final Set<String> m_used_kernel_names =
		new HashSet<String>();

	private boolean m_using_default_constructor_hack = false;

	public DFEManager() {
		m_using_default_constructor_hack = true;
	}

	private void setUpBuildManager(BuildManager build_manager, MAXBoardModel board_model) {
		m_build_manager = build_manager;
		MaxFileManager mgm = MaxFileManager.getMaxFileManager(getBuildManager());
		if(board_model != null) {
			mgm.addMaxFileStringConstant(false, "BOARD_MODEL", board_model.toString());

			build_manager.setPlatform( _Managers.getBoardCapabilities(board_model).getPlatform() );

			_KernelConfiguration.setBoardModel(m_kernel_configuration,
				MaxBoardModel.get(board_model.toString()));
		}

		checkSimulationBuildOnly();
	}

	void forceBuildManager(BuildManager build_manager, MAXBoardModel board_model) {
		if(!m_using_default_constructor_hack)
			throw new MaxCompilerInternalError(this, "Cannot force build manager in this instance.");

		setUpBuildManager(build_manager, board_model);
	}

	protected DFEManager(
		String name,
		String build_directory,
		boolean is_simulation,
		BuildConfig.Level build_level,
		MAXBoardModel board_model)
	{
		m_build_config = new _BuildConfig(build_level);
		setUpBuildManager(new BuildManager(name, build_directory, is_simulation), board_model);
	}

	protected DFEManager(
		String name,
		String build_directory,
		boolean is_simulation,
		MAXBoardModel board_model)
	{
		this(name, build_directory, is_simulation,
			BuildConfig.Level.FULL_BUILD, board_model);
	}

	protected DFEManager(
		String build_name,
		boolean is_simulation,
		MAXBoardModel board_model)
	{
		this(new File(build_name).getName(), build_name, is_simulation,
			BuildConfig.Level.FULL_BUILD, board_model);
	}

	DFEManager(BuildManager build_manager) {
		setUpBuildManager(build_manager, null);
	}

	private void checkSimulationBuildOnly() {
		if(Version.simulationOnly && !m_build_manager.isTargetSimulation())
			throw new MaxCompilerAPIError(this,
				"This version of MaxCompiler can only be used to target simulation. Please" +
				" use a different type of Manager or instantiate this Manager such that it" +
				" targets simulation. The later is usually achieved by using an alternate" +
				" constructor with a boolean is_simuation (or similar) parameter set to true.");
	}

	void setCompileManagerFactory(PhotonCompileManager.Factory compile_manager_factory) {
		m_compile_manager_factory = compile_manager_factory;
	}

	PhotonCompileManager.Factory getCompileManangerFactory() {
		return m_compile_manager_factory;
	}

	/**
	 * Create a {@link KernelParameters} object using the currently defined
	 * {@link KernelConfiguration} for this {@link DFEManager}.
	 * <p>
	 * The {@code KernelConfiguration} object used is the same as that returned
	 * by {@link #getCurrentKernelConfig()}.
	 * <p>
	 * This method is used to create a {@code KernelParameters} object which must
	 * passed to a {@link Kernel} constructor.
	 * @param kernel_name The name of the {@code Kernel}.
	 * @return A {@code KernelParameters} object which uses the specified name
	 * and the currently defined {@code KernelConfiguration}.
	 * @see #makeKernelParameters(String, KernelConfiguration)
	 * @see #getCurrentKernelConfig()
	 * @see #setCurrentKernelConfig(KernelConfiguration)
	 */
	public KernelParameters makeKernelParameters(String kernel_name) {
		return makeKernelParameters(kernel_name, getCurrentKernelConfig());
	}

	/**
	 * Create a {@link KernelParameters} object with a specific {@link KernelConfiguration}.
	 * <p>
	 * This method is used to create a {@code KernelParameters} object which must
	 * passed to the constructor of a {@link Kernel}.
	 * @param kernel_name The name of the {@code Kernel}.
	 * @param kernel_configuration The configuration options to apply to the {@code Kernel}.
	 * @return A {@code KernelParameters} object with the specified name and configuration
	 * options.
	 * @see #makeKernelParameters(String)
	 */
	public KernelParameters makeKernelParameters(String kernel_name, KernelConfiguration kernel_configuration) {
		if (kernel_name == null)
			throw MaxCompilerAPIError.nullParam(this, "kernel_name");
		if (kernel_configuration == null)
			throw MaxCompilerAPIError.nullParam(this, "kernel_configuration");

		if(m_used_kernel_names.contains(kernel_name))
			throw new MaxCompilerAPIError(this, "Kernel name '" + kernel_name + "' is already used.");
		if(m_build_manager.getBuildName().toLowerCase().equals(kernel_name.toLowerCase()))
			throw new MaxCompilerAPIError(this, "Kernel names can not be the same as your build name (" + m_build_manager.getBuildName() + "), consider appending 'Kernel' to the name.");

		return _Kernel.makeKernelParameters(this, kernel_name, kernel_configuration);
	}

	void logSetConsoleTag(String console_tag) {
		m_build_manager.logSetConsoleTag(console_tag);
	}

	void logSetLogTag(String log_tag) {
		m_build_manager.logSetLogTag(log_tag);
	}

	/**
	 * Log a message to stdout and the build-log file.
	 */
	public void logMsg(String msg, Object... args) {
		m_build_manager.logUser(msg, args);
	}

	/**
	 * Log a message to the build-log file and to stdout when the
	 * <code>build.verbose_output</code> configuration option is set.
	 */
	public void logInfo(String msg, Object... args) {
		m_build_manager.logInfo(msg, args);
	}

	/**
	 * Log a message to stderr and the build-log file.
	 */
	public void logWarning(String msg, Object... args) {
		m_build_manager.logWarning(msg, args);
	}

	/**
	 * Log a message to stderr and the build-log file.
	 */
	public void logError(String msg, Object... args) {
		m_build_manager.logError(msg, args);
	}

	public void setParameter(String name, String value) {
		m_build_manager.setParameter(name, value);
	}

	public void addMaxFileConstantFlag(String name, int value) {
		if (!MaxFileManager.getMaxFileManager(m_build_manager).constantIsAlreadyUsed(name)) {
			MaxFileManager.getMaxFileManager(m_build_manager).addMaxFileConstant(false, name, value);
		}
	}

	public void addMaxFileConstant(String name, int value) {
		MaxFileManager.getMaxFileManager(m_build_manager).addMaxFileConstant(true, name, value);
	}

	public void addMaxFileStringConstant(String name, String value) {
		MaxFileManager.getMaxFileManager(m_build_manager).addMaxFileStringConstant(true, name, value);
	}

	public void addMaxFileDoubleConstant(String name, double value) {
		MaxFileManager.getMaxFileManager(m_build_manager).addMaxFileDoubleConstant(true, name, value);
	}

	public boolean isTargetSimulation() {
		return m_build_manager.isTargetSimulation();
	}

	BuildManager getBuildManager() {
		return m_build_manager;
	}

	public String getName() {
		return m_build_manager.getBuildName();
	}

	public void setBuildConfig(BuildConfig build_config) {
		m_build_config = build_config;
	}

	public BuildConfig getBuildConfig() {
		return m_build_config;
	}

	// Please override realBuild() instead of build() as per #1141
	@edu.umd.cs.findbugs.annotations.SuppressWarnings("DM_EXIT")
	public final void build() {
		try {
			realBuild();
		} catch ( ProcessFailedException e ) {
			if ( m_build_manager.getParameterBool("build.intercept_build_failed_exceptions", true) ) {
				m_build_manager.logError( e.getMessage() );
				System.exit(1);
			} else {
				m_build_manager.logError( e.getMessage() );
				StringBuilder sb = new StringBuilder();
				for ( StackTraceElement ste : e.getStackTrace() )
					sb.append("\t\t" + ste + "\n");
				m_build_manager.logError( sb.toString() );
			}
		}
	}

	abstract protected void realBuild();

	void runBuild(Entity root) {
		if(m_build_config == null)
			throw new MaxCompilerAPIError(this, "No build-config specified, set one with setBuildConfig().");

		for(BuildPass pass : getBuildConfig().getBuildPasses(getBuildManager()))
			getBuildManager().addBuildPass(pass);

		getBuildManager().build(root);
	}


	/* MaxCompiler PhotonKernelConfiguration Infrastructure */
	protected KernelConfiguration m_kernel_configuration = new _KernelConfiguration();
	private boolean m_kernel_configuration_queried = false;

	/**
	 * @deprecated Replaced by {@link #getCurrentKernelConfig()}.
	 */
	@Deprecated
	@MaxCompilerHide
	public KernelConfiguration getDefaultKernelConfig() {
		return getCurrentKernelConfig();
	}

	/**
	 * Get the current {@link KernelConfiguration} for this {@link DFEManager}.
	 * <p>
	 * Note that this {@code KernelConfiguration} is mutable and will apply to
	 * all {@link Kernel}s created with {@link KernelParameters} created via
	 * the {@link #makeKernelParameters(String)} method.
	 * <p>
	 * To apply separate {@code KernelConfiguration}s to individual kernels,
	 * use the {@link #makeKernelParameters(String, KernelConfiguration)}
	 * method.
	 * @return A mutable {@code KernelConfiguration} that will be applied to {@code
	 * Kernel}s that use the default
	 * @see #setCurrentKernelConfig(KernelConfiguration)
	 * @see #makeKernelParameters(String)
	 * @see #makeKernelParameters(String, KernelConfiguration)
	 */
	public KernelConfiguration getCurrentKernelConfig() {
		m_kernel_configuration_queried = true;
		return m_kernel_configuration;
	}

	/**
	 * @deprecated Replaced by {@link #setCurrentKernelConfig(KernelConfiguration)}.
	 */
	@Deprecated
	@MaxCompilerHide
	public void setDefaultKernelConfig(KernelConfiguration newConfiguration) {
		setCurrentKernelConfig(newConfiguration);
	}

	/**
	 * Specify the {@link KernelConfiguration} that will apply to {@link Kernel}s
	 * created by the {@link #makeKernelParameters(String)} method.
	 * <p>
	 * To apply separate {@code KernelConfiguration}s to individual kernels,
	 * use the {@link #makeKernelParameters(String, KernelConfiguration)}
	 * method.
	 * @param newConfiguration The new {@code KernelConfiguration} object to use.
	 * @see #getCurrentKernelConfig()
	 * @see #makeKernelParameters(String)
	 * @see #makeKernelParameters(String, KernelConfiguration)
	 */
	public void setCurrentKernelConfig(KernelConfiguration newConfiguration) {
		if (newConfiguration == null)
			throw MaxCompilerAPIError.nullParam(this, "newConfiguration");
		if (m_kernel_configuration_queried)
			throw new MaxCompilerAPIError(this,"Cannot set default kernel " +
				"configuration after a call to 'getCurrentKernelConfig'.");

		MaxBoardModel current_board =
			_KernelConfiguration.getPhotonKernelConfig(m_kernel_configuration).getMaxBoard();
		MaxBoardModel new_board =
			_KernelConfiguration.getPhotonKernelConfig(newConfiguration).getMaxBoard();
		if (! current_board.equals(new_board) )
			throw new MaxCompilerAPIError(this,"Cannot set default kernel " +
			"configuration: New configuration is for a different board. (Expected: " +
			current_board.toString() + " Got: " + new_board);

		m_kernel_configuration = newConfiguration;
	}
}
