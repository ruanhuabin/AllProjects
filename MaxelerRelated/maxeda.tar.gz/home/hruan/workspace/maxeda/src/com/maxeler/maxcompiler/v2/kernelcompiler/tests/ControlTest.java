package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import static com.maxeler.maxcompiler.v2.utils.MathUtils.bitsToAddress;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.photon.core.PhotonException;

public class ControlTest {

	private static final int     data_len  = 100;
	private static final int     nchoices  = 5;
	private static final int     num_pipes = 4;
	private static final DFEType  int_type  = Kernel.dfeInt(32);
	private static final DFEVectorType<DFEVar> int_pipe = new DFEVectorType<DFEVar>(int_type, num_pipes);
	private static       long    s_seed;
	private static       Random  s_random  = null;

	private static class ControlTest1 extends Kernel {

		private static final double[] x_cst_d = new double[nchoices];
		{
			resetRandom();
			for (int i = 0; i < nchoices; i++) {
				x_cst_d[i] = s_random.nextInt();
			}
		}

		ControlTest1(KernelParameters parameters) {
			super(parameters);

			// ----- exercise single pipe mux methods
			DFEVar[] x = new DFEVar[nchoices];
			DFEVar[] x_cst = new DFEVar[nchoices];
			DFEVar[] x_mix = new DFEVar[nchoices];
			x_mix[0] = constant.var(x_cst_d[0]);
			for (int i = 0; i < nchoices; i++) {
				x[i]       = io.input("x" + i, int_type);
				x_cst[i]   = constant.var(x_cst_d[i]);
				if(i > 0) {
					x_mix[i] = io.input("x_mix"+i, int_type);
				}
			}

			DFEVar sel = io.input("sel", dfeUInt(bitsToAddress(nchoices)));
			DFEVar sel_rev = nchoices - 1 - sel;
			DFEVar sel_hot = constant.var(dfeUInt(nchoices), 1) << sel;
			DFEVar sel_hot_rev = constant.var(dfeUInt(nchoices), 1) << sel_rev;
			DFEVar sel_cst = constant.var(2);

			DFEType xtype = x[0].getType();
			io.output("z", xtype).connect(control.mux(sel, x));
			io.output("zrev", xtype).connect(control.mux(sel_rev, x));
			io.output("zhot", xtype).connect(control.oneHotMux(sel_hot, x));
			io.output("zhotrev", xtype).connect(control.oneHotMux(sel_hot_rev, x));
			io.output("zcst", xtype).connect(control.mux(sel_cst, x));
			io.output("zallcst", int_type).connect(control.mux(sel_cst, x_cst).cast(int_type));
			io.output("zmix", xtype).connect(control.mux(sel, x_mix));

			boolean caught_exception = false;

			// ----- throw in a few nasties...
			try {
				caught_exception = false;
				DFEVar signed = constant.var(dfeInt(3), 3);
				DFEVar z1 = control.mux(signed, x);
				z1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg("caught exception: " + e);
				caught_exception = true;
			}
			if(!caught_exception) {
				throw new RuntimeException(
					"Expected MaxCompilerAPIError but did not get one!");
			}

			try {
				caught_exception = false;
				DFEVar s1 = constant.var(dfeUInt(2), 2);
				DFEVar z1 = control.mux(s1, x);
				z1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg("caught exception: " + e);
				caught_exception = true;
			}
			if(!caught_exception) {
				throw new RuntimeException(
					"Expected MaxCompilerAPIError but did not get one!");
			}

			try {
				caught_exception = false;
				DFEVar s1 = constant.var(dfeUInt(8), 2);
				DFEVar z1 = control.oneHotMux(s1, x);
				z1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg("caught exception: " + e);
				caught_exception = true;
			}
			if(!caught_exception) {
				throw new RuntimeException(
					"Expected MaxCompilerAPIError but did not get one!");
			}


			try {
				caught_exception = false;
				DFEVar s1 = constant.var(true);
				DFEVar z1 = control.oneHotMux(s1, x);
				z1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError e) {
				logMsg("caught exception: " + e);
				caught_exception = true;
			}
			if(!caught_exception) {
				throw new RuntimeException(
					"Expected MaxCompilerAPIError but did not get one!");
			}
		}
	}

	public static void runTest1(String main_name) {
		String name = main_name + "_1";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters paramsA = manager.makeKernelParameters_A();
		KernelParameters paramsB = manager.makeKernelParameters_B();

		manager.logMsg("*** using random seed = " + s_seed );
		manager.setKernels( new ControlTest1(paramsA), new ControlTest1(paramsB) );
		manager.setKernelCycles( data_len );

		double[]   sel = initToRandom(data_len, nchoices);
		double[][] x   = new double[nchoices][];
		for ( int i=0 ; i<x.length ; i++ )
			x[i] = initToRandom(data_len, 100);

		double[] z = new double[data_len];
		for ( int i=0 ; i<z.length ; i++ )
			z[i] = x[ (int)sel[i] ][ i ];

		double[] zrev = new double[data_len];
		for ( int i=0 ; i<zrev.length ; i++ )
			zrev[i] = x[ nchoices - 1 - (int)sel[i] ][ i ];

		double[] zcst = new double[data_len];
		for ( int i=0 ; i<zcst.length ; i++ )
			zcst[i] = x[2][ i ];

		double[] zallcst = new double[data_len];
		for ( int i=0 ; i<zallcst.length ; i++ )
			zallcst[i] = ControlTest1.x_cst_d[2];

		double[] zmix = new double[data_len];
		for(int i = 0; i < zmix.length; i++) {
			if(i == 0)
				zmix[i] = ControlTest1.x_cst_d[(int)sel[i]];
			else
				zmix[i] = z[i];
		}

		for ( int i=0 ; i<nchoices ; i++ ) {
			manager.setInputData("x" + i, x[i] );
			if(i > 0) {
				manager.setInputData("x_mix"+i, x[i]);
			}
		}
		manager.setInputData("sel", sel);
		manager.runTest();
		manager.checkOutputData("z",       z      );
		manager.checkOutputData("zrev",    zrev   );
		manager.checkOutputData("zhot",    z      );
		manager.checkOutputData("zhotrev", zrev   );
		manager.checkOutputData("zcst",    zcst   );
		manager.checkOutputData("zallcst", zallcst);
		System.out.println("Test 1 OK!");
	}

	private static class ControlTest2 extends Kernel {
		@SuppressWarnings("unchecked")
		public ControlTest2(KernelParameters parameters) {
			super(parameters);

			//----- exercise multi-pipe mux methods
			DFEVector<DFEVar>   a = io.input("a", int_pipe);
			DFEVector<DFEVar>   b = io.input("b", int_pipe);
			DFEVector<DFEVar>   c = io.input("c", int_pipe);
			DFEVector<DFEVar>   d = io.input("d", int_pipe);
			DFEVector<DFEVar>   e = io.input("e", int_pipe);
			DFEVector<DFEVar>[] x = new DFEVector[]{ a, b, c, d, e };

			List<DFEVector<DFEVar>> xlist = Arrays.asList( x );

			DFEVectorType<DFEVar> sel_pipe     = new DFEVectorType<DFEVar>( dfeUInt(bitsToAddress(nchoices)), num_pipes );
			DFEVectorType<DFEVar> sel_hot_pipe = new DFEVectorType<DFEVar>( dfeUInt(nchoices), num_pipes );
			DFEVector<DFEVar>     one          = constant.vect(sel_hot_pipe, 1.0);

			DFEVector<DFEVar> sel         = io.input("sel", sel_pipe);
			DFEVector<DFEVar> sel_rev     = nchoices - 1 - sel;
			DFEVector<DFEVar> sel_hot     = one << sel;
			DFEVector<DFEVar> sel_hot_rev = one << sel_rev;

			io.output("z",       int_pipe).connect( control.mux(sel,     x    ) );
			io.output("zrev",    int_pipe).connect( control.mux(sel_rev, xlist) );
			io.output("zhot",    int_pipe).connect( control.oneHotMux(sel_hot,     x    ) );
			io.output("zhotrev", int_pipe).connect( control.oneHotMux(sel_hot_rev, xlist) );


			//----- throw in a few nasties...
			boolean caught_exception = false;
			try {
				caught_exception = false;
				List<DFEVector<DFEVar>> y = new ArrayList<DFEVector<DFEVar>>();
				DFEVector<DFEVar>      z1 = control.mux( sel, y);
				z1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError exc) {
				logMsg("caught exception: " + exc );
				caught_exception = true;
			}
			if(!caught_exception) {
				throw new RuntimeException(
					"Expected MaxCompilerAPIError but did not get one!");
			}

			try {
				caught_exception = false;
				DFEVector<DFEVar> sel2 = (new DFEVectorType<DFEVar>( dfeUInt(bitsToAddress(nchoices)), 0 )).newInstance(this);
				DFEVector<DFEVar> z1   = control.mux( sel2, x );
				z1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError exc) {
				logMsg("caught exception: " + exc );
				caught_exception = true;
			}
			if(!caught_exception) {
				throw new RuntimeException(
					"Expected MaxCompilerAPIError but did not get one!");
			}

			try {
				caught_exception = false;
				DFEVector<DFEVar> sel2 = (new DFEVectorType<DFEVar>( dfeUInt(bitsToAddress(nchoices)), num_pipes-1 )).newInstance(this);
				DFEVector<DFEVar> z1   = control.mux( sel2, x );
				z1.setReportOnUnused(false);
			} catch (MaxCompilerAPIError exc) {
				logMsg("caught exception: " + exc );
				caught_exception = true;
			}
			if(!caught_exception) {
				throw new RuntimeException(
					"Expected MaxCompilerAPIError but did not get one!");
			}
		}
	}

	public static void runTest2(String main_name) {
		String name = main_name + "_2";
		_DualSimulationManager manager = new _DualSimulationManager(name);
		KernelParameters paramsA = manager.makeKernelParameters_A();
		KernelParameters paramsB = manager.makeKernelParameters_B();
		manager.logMsg("*** using random seed = " + s_seed );
		manager.setKernels( new ControlTest2(paramsA), new ControlTest2(paramsB) );
		manager.setKernelCycles( data_len );

		double[][] sel  = initToRandom( num_pipes, data_len, nchoices);
		double[][] a    = initToRandom( num_pipes, data_len, 100 );
		double[][] b    = initToRandom( num_pipes, data_len, 100 );
		double[][] c    = initToRandom( num_pipes, data_len, 100 );
		double[][] d    = initToRandom( num_pipes, data_len, 100 );
		double[][] e    = initToRandom( num_pipes, data_len, 100 );

		double[][] z    = new double[data_len][num_pipes];
		double[][] zrev = new double[data_len][num_pipes];
		for ( int i=0 ; i<data_len ; i++ ) {
			for ( int j=0; j<num_pipes ; j++ ) {
				switch ( (int)sel[i][j] ) {
					case 0: z[i][j] = a[i][j]; break;
					case 1: z[i][j] = b[i][j]; break;
					case 2: z[i][j] = c[i][j]; break;
					case 3: z[i][j] = d[i][j]; break;
					case 4: z[i][j] = e[i][j]; break;
				}
				switch ( nchoices-1-(int)sel[i][j] ) {
					case 0: zrev[i][j] = a[i][j]; break;
					case 1: zrev[i][j] = b[i][j]; break;
					case 2: zrev[i][j] = c[i][j]; break;
					case 3: zrev[i][j] = d[i][j]; break;
					case 4: zrev[i][j] = e[i][j]; break;
				}
			}
		}

		Bits[] bsel  = new Bits[data_len];
		Bits[] ba    = new Bits[data_len];
    	Bits[] bb    = new Bits[data_len];
    	Bits[] bc    = new Bits[data_len];
    	Bits[] bd    = new Bits[data_len];
    	Bits[] be    = new Bits[data_len];
    	Bits[] bz    = new Bits[data_len];
    	Bits[] bzrev = new Bits[data_len];
    	for ( int i = 0 ; i < data_len ; i++ ) {
    		bsel [i] = SimulationManager.packToBits( Kernel.dfeUInt(bitsToAddress(nchoices)), sel[i] );
    		ba   [i] = SimulationManager.packToBits( int_type, a[i]    );
    		bb   [i] = SimulationManager.packToBits( int_type, b[i]    );
    		bc   [i] = SimulationManager.packToBits( int_type, c[i]    );
    		bd   [i] = SimulationManager.packToBits( int_type, d[i]    );
    		be   [i] = SimulationManager.packToBits( int_type, e[i]    );
    		bz   [i] = SimulationManager.packToBits( int_type, z[i]    );
    		bzrev[i] = SimulationManager.packToBits( int_type, zrev[i] );
    	}

		manager.setInputDataRaw("sel", bsel);
		manager.setInputDataRaw("a",   ba  );
		manager.setInputDataRaw("b",   bb  );
		manager.setInputDataRaw("c",   bc  );
		manager.setInputDataRaw("d",   bd  );
		manager.setInputDataRaw("e",   be  );
		manager.runTest();
		manager.checkOutputDataRaw("z",       bz   );
		manager.checkOutputDataRaw("zrev",    bzrev);
		manager.checkOutputDataRaw("zhot",    bz   );
		manager.checkOutputDataRaw("zhotrev", bzrev);
		System.out.println("Test 2 OK!");
	}

	private static class ControlTest3 extends Kernel {

		private static final double[] x_cst_d = new double[nchoices];
		{
			resetRandom();
			for (int i = 0; i < nchoices; i++) {
				x_cst_d[i] = s_random.nextDouble();
			}
		}

		protected ControlTest3(KernelParameters parameters, double val) {
			super(parameters);

			DFEVar[] x = new DFEVar[nchoices];
			DFEVar[] x_cst = new DFEVar[nchoices];
			for (int i = 0; i < nchoices; i++) {
				x[i]       = io.input("x" + i, int_type);
				x_cst[i]   = constant.var(x_cst_d[i]);
			}

			DFEType xtype = x[0].getType();

			DFEVar select = constant.var(val);
			DFEVar z = control.oneHotMux(select, x);

			io.output("output", xtype).connect(z);
		}

	}

	public static void runTest3(String main_name) {
		String name = main_name + "_3";

		double vals[] = {6, 3.1415};
		for(int i = 0; i < vals.length; i++) {
			SimulationManager manager = new SimulationManager(name + "_" + i);
			try {
				Kernel kernel = new ControlTest3(manager.makeKernelParameters(), vals[i]);
				manager.setKernel( kernel );
			} catch(PhotonException e) {
				System.out.println("Test 3." + i + " OK!");
				continue;
			}
			throw new RuntimeException();
		}
	}

	public static void main(String[] args) {
		String name = "ControlTest";
		resetRandom();
		runTest1(name);
		runTest2(name);
		runTest3(name);
		System.out.println("All tests OK!");
    	System.exit(0);
	}

	private static double[] initToRandom( int len, int max ) {
		double[] arr = new double[len];
		for ( int i = 0 ; i < len ; i++ )
				arr[i] = s_random.nextInt( max );
		return arr;
	}

	private static double[][] initToRandom( int npipes, int len, int max ) {
		double[][] arr = new double[len][npipes];
		for ( int i = 0 ; i < len ; i++ ) {
			for ( int j = 0 ; j < npipes ; j++ ) {
				arr[i][j] = s_random.nextInt( max );
			}
		}
		return arr;
	}

	private static void resetRandom() {
		if ( s_random == null ) {
			s_seed = System.currentTimeMillis();
		}
		System.out.println("*** Using seed: " + s_seed);
		s_random = new Random( s_seed );
	}

	@SuppressWarnings("unused")
	private static void printArrayValues( String title, double[][] x) {
		System.out.println( title + " = {" );
		for ( int i = 0 ; i < x.length ; i++ ) {
			for ( int j = 0 ; j <x[i].length ; j++ ) {
				System.out.printf( "    [%2d][%2d] = %f\n", i, j, x[i][j] );
			}
		}
		System.out.println( "}" );
	}

}
