package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.DoubtType;

public class DFEVectorDoubtType extends DoubtType {
	private final DFEArrayDoubtType m_karray_doubt_type;

	DFEVectorDoubtType(DFEArrayDoubtType karray_doubt_type) {
		m_karray_doubt_type = karray_doubt_type;
	}

	DFEArrayDoubtType getDFEArrayDoubtType() {
		return m_karray_doubt_type;
	}

	@Override
	public boolean equals(Object other) {
		return
			other instanceof DFEVectorDoubtType &&
			((DFEVectorDoubtType)other).m_karray_doubt_type.equals(m_karray_doubt_type);
	}

	@Override
	public int hashCode() {
		return m_karray_doubt_type.hashCode();
	}

	@Override
	public boolean hasDoubtInfo() {
		return m_karray_doubt_type.hasDoubtInfo();
	}

	@Override
	public int getTotalBits() {
		return m_karray_doubt_type.getTotalBits();
	}

	@Override
	public String toString() {
		return "DFEVectorDoubtType<" + m_karray_doubt_type + ">";
	}

	@Override
	public DFEVectorDoubtType union(DoubtType other_type) {
		if(!(other_type instanceof DFEVectorDoubtType))
			throw new MaxCompilerAPIError(
				"Can only union with another DFEVectorDoubtType object.");

		return new DFEVectorDoubtType(
			m_karray_doubt_type.union(((DFEVectorDoubtType)other_type).m_karray_doubt_type));
	}
}
