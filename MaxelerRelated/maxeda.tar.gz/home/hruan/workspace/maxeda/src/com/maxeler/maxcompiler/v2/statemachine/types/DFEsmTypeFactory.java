package com.maxeler.maxcompiler.v2.statemachine.types;

import java.util.HashMap;
import java.util.Map;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType.SignMode;
import com.maxeler.statemachine.StateMachineInternalException;
import com.maxeler.statemachine.Utils;

/**
 * Utility class for generating types for use with state machines.
 */
public final class DFEsmTypeFactory {

	// hide the constructor
	private DFEsmTypeFactory() {}

	/**
	 * Create a Boolean type.
	 * <p>
	 * This is equivalent to a 1-bit, unsigned integer.
	 * @return A 1-bit {@link DFEsmValueType} type.
	 */
	public static DFEsmValueType dfeBool() { return dfeUInt(1); }

	private static final Map<Integer, DFEsmValueType> s_uints = new HashMap<Integer, DFEsmValueType>();

	/**
	 * Create an unsigned integer type.
	 * @param numBits The number of bits to use for the type.
	 * @return An unsigned {@link DFEsmValueType} with the specified number of bits.
	 */
	public static DFEsmValueType dfeUInt(int numBits) { return dfeValue(numBits, SignMode.Unsigned); }

	private static final Map<Integer, DFEsmValueType> s_sints = new HashMap<Integer, DFEsmValueType>();

	/**
	 * Create a signed integer type.
	 * @param numBits The number of bits to use for the type.
	 * @return A signed {@link DFEsmValueType} with the specified number of bits.
	 */
	public static DFEsmValueType dfeInt(int numBits) { return dfeValue(numBits, SignMode.Signed); }

	/**
	 * Create an integer type.
	 * @param numBits The number of bits to use for the type.
	 * @param signMode The sign mode of the type.
	 * @return A signed {@link DFEsmValueType} with the specified number of bits.
	 */
	public static DFEsmValueType dfeValue(int numBits, DFEsmValueType.SignMode signMode) {
		if (numBits <= 0)
			throw new MaxCompilerAPIError("Number of bits must be greater than 0, not %d.", numBits);

		Integer i = Integer.valueOf(numBits);
		DFEsmValueType s;
		if ( signMode == SignMode.Signed )
			s = s_sints.get(i);
		else
			s = s_uints.get(i);

		if (s == null) {
			s = new DFEsmValueType(numBits, signMode);
			if (signMode == SignMode.Signed)
				s_sints.put(i, s);
			else
				s_uints.put(i, s);
		}
		return s;
	}


	private static final Map<Class<?>, DFEsmEnumType> s_enums = new HashMap<Class<?>, DFEsmEnumType>();
	static <E extends Enum<?>> DFEsmEnumType dfeEnum(Class<E> enumClass) {
		DFEsmEnumType e = s_enums.get(enumClass);

		if (e == null) {
			e = new DFEsmEnumType(enumClass);
			s_enums.put(enumClass, e);
		}

		return e;
	}

	private static final DFEsmUntypedConst s_untyped = new DFEsmUntypedConst();
	static DFEsmUntypedConst dfeUntypedConst() { return s_untyped; }


	/**
	 * Converts an DFEsmValueType to a DFEType. (This conversion is not available for
	 * DFEsmEnum types.)
	 * @param type An DFEsmValueType to be converted
	 * @return A DFEType that can be used in kernels.
	 */
	public static DFEType convert(DFEsmValueType type) {
		return _KernelBaseTypes.fromImp(Utils.convertToHWType(type));
	}

	/**
	 * Converts a DFEFix to an DFEsmValueType. Notice, this only works for
	 * DFEFix types with an offset of 0 (i.e. integer types).
	 * @param type The DFEFixType to be converted
	 * @return An DFEsmValueType that can be used inside a state machine.
	 */
	public static DFEsmValueType convert(DFEFix type) {
		if (type.isBool())
			return dfeBool();
		else {
			if (type.getOffset() != 0 )
				throw new MaxCompilerAPIError("Cannot convert a DFEFix with an offset != 0 to an DFEsmValueType (offset was %d).", type.getOffset());
			switch (type.getSignMode()) {
				case TWOSCOMPLEMENT:
					return dfeValue(type.getTotalBits(), SignMode.Signed);
				case UNSIGNED:
					return dfeValue(type.getTotalBits(), SignMode.Unsigned);
				default:
					throw new StateMachineInternalException("Unknown sign mode.");
			}
		}
	}
}
