package com.maxeler.doclet;

import java.io.File;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;

import com.maxeler.doclet.Utils.Visibility;
import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.ConstructorDoc;
import com.sun.javadoc.Doclet;
import com.sun.javadoc.FieldDoc;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.Parameter;
import com.sun.javadoc.RootDoc;
import com.sun.javadoc.Type;

/**
 * Doclet that determines if any internal types have been exposed in public
 * interfaces.
 * <p>
 * Requires 2 command-line options:
 * <ul>
 * <li>{@code -base_package}: specifies the package that all types should be
 * part of. For example, specifying the base package as
 * {@code com.maxeler.maxcompiler.v2} will check that all types fall within this
 * package or a sub-package (e.g.
 * {@code com.maxeler.maxcompiler.v2.kernelcompiler}).</li>
 * <li>{@code -log_file}: specifies the name of a file to write the log to.
 * </ol>
 */
public class ExposedInternalsDoclet extends Doclet {
	/** Command-line options for the Doclet. */
	private enum CommandLineOptions implements Utils.CommandLineOption {
		BASE_PACKAGE,
		LOG_FILE;

		public final String m_optionName;

		private CommandLineOptions() { m_optionName = "-" + name().toLowerCase(); }

		@Override
		public String optionName() { return m_optionName; }
	}

	public static boolean start(RootDoc root) {
		final String basePackageList = Utils.getOption(CommandLineOptions.BASE_PACKAGE, root.options());
		final File logFile = new File(Utils.getOption(CommandLineOptions.LOG_FILE, root.options()));

		PrintStream log = null;
		try {
			log = new PrintStream(logFile);

			String[] basePackages =
				basePackageList.split(":");

			Exposed exposed = new Exposed(log, basePackages);

			for (ClassDoc c : root.classes()) {
				if (Utils.getVisibility(c) == Visibility.PUBLISHED)
					checkExposedInternals(exposed, c);
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			if (log != null)
				log.close();
		}

		return true;
	}

	/**
	 * Called by the {@code javadoc} utility.
	 */
	public static int optionLength(String option) {
		for (CommandLineOptions validOption : CommandLineOptions.values()) {
			if (option.equals(validOption.m_optionName))
				return 2;
		}

		return 0;
	}

	private static class Exposed {
		private final PrintStream m_log;
		private final String[] m_basePackages;

		public Exposed(PrintStream log, String[] basePackages) {
			m_log = log;
			m_basePackages = basePackages;
		}

		public void checkMember(FieldDoc field) {
			if (Utils.getVisibility(field) != Visibility.PUBLISHED)
				return;

			if (isInternalType(field.type())) {
				m_log.println(field.qualifiedName() + ": field");
				m_log.printf("\t%s\n", field.type());
			}
		}

		public void checkMember(ConstructorDoc constructor) {
			if (Utils.getVisibility(constructor) != Visibility.PUBLISHED)
				return;

			boolean exposed = false;

			final Parameter[] params = constructor.parameters();
			for (Parameter param : params) {
				if (isInternalType(param.type())) {
					exposed = true;
					break;
				}
			}

			if (exposed) {
				m_log.println(constructor.qualifiedName() + ": constructor");
				for (int i = 0; i < params.length; ++i)
					m_log.printf("\tparam[%d] = %s\n", i, params[i].type());
			}
		}

		public void checkMember(MethodDoc method) {
			if (Utils.getVisibility(method) != Visibility.PUBLISHED)
				return;

			boolean exposed = false;

			if (isInternalType(method.returnType()))
				exposed = true;

			final Parameter[] params = method.parameters();
			for (Parameter param : params) {
				if (isInternalType(param.type())) {
					exposed = true;
					break;
				}
			}

			if (exposed) {
				m_log.println(method.qualifiedName() + ": method");
				m_log.printf("\treturn = %s\n", method.returnType());

				for (int i = 0; i < params.length; ++i)
					m_log.printf("\tparam[%d] = %s\n", i, params[i].type());
			}
		}

		private static final Set<String> javaInternalTypes = new HashSet<String>();
		static {
			javaInternalTypes.add("void");
			javaInternalTypes.add("boolean");
			javaInternalTypes.add("byte");
			javaInternalTypes.add("char");
			javaInternalTypes.add("short");
			javaInternalTypes.add("int");
			javaInternalTypes.add("long");
			javaInternalTypes.add("float");
			javaInternalTypes.add("double");
		}

		private boolean isInternalType(Type type) {
			final String typeName = type.qualifiedTypeName();

			// is this an internal Java type or part of the Java standard library?
			if (javaInternalTypes.contains(typeName) || typeName.startsWith("java"))
				return false;

			for(String basePackage : m_basePackages)
				if(typeName.startsWith(basePackage))
					return false;

			return true;
		}
	}

	private static void checkExposedInternals(Exposed e, ClassDoc c) {
		if (Utils.getVisibility(c) != Visibility.PUBLISHED)
			return;

		// show visible fields
		for (FieldDoc field : c.fields())
			e.checkMember(field);

		// show visible constructors
		for (ConstructorDoc constructor : c.constructors())
			e.checkMember(constructor);

		// show visible methods
		for (MethodDoc method : c.methods())
			e.checkMember(method);
	}
}
