package com.maxeler.maxcompiler.v2.statemachine.stdlib;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.maxeler.maxcompiler.v2.errors._Error;
import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine._StateMachine;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.buffer.DFEsmFifo;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.buffer._DFEsmFifo;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.maxdc.BuildManager;

public final class Buffer extends Lib {
	Buffer (StateMachineLib sm) {super(sm);}

	/** List of all FIFOs */
	private final List<DFEsmFifo> m_fifos = new ArrayList<DFEsmFifo>();

	public static enum BufferSpec {
		Default,
		UseLUTRam,
		UseBlockRam
	}

	public static final class DFEsmFifoConfig {
		private BufferSpec m_bufferSpec = BufferSpec.Default;
		private boolean m_firstWordFallThrough = false;
		private Integer m_programmableFull = null;
		private Integer m_programmableEmpty = null;
		private boolean m_dataCount = false;
		private boolean m_haveValidFlag = false;

		public DFEsmFifoConfig setBufferSpec(BufferSpec s) {m_bufferSpec = s; return this;}
		/**
		 * The first-word fall-through (FWFT) feature provides the ability to look-ahead
		 * to the next word available from the FIFO without issuing a read operation. When
		 * data is available in the FIFO, the first word falls through the FIFO and appears
		 * automatically on the output bus (DOUT). FWFT is useful in applications that
		 * require low-latency access to data and to applications that require throttling
		 * based on the contents of the data that are read. FWFT support is included in FIFOs
		 * created with block RAM, distributed RAM, or built-in FIFOs in the Virtex-6 or
		 * Virtex-5 devices. (From Xilinx Data Sheet).
		 */
		public DFEsmFifoConfig setIsFirstWordFallThrough() {m_firstWordFallThrough = true; return this;}
		/**
		 * Programmable Full: This signal is asserted when the number of words in the FIFO
		 * is greater than or equal to the assert threshold. It is deasserted when the number
		 * of words in the FIFO is less than the negate threshold. (From Xilinx Data Sheet)
		 */
		public DFEsmFifoConfig setProgrammableFull(int level) {m_programmableFull = Integer.valueOf(level); return this;}
		/**
		 * Programmable Empty: This signal is asserted when the number of words in the FIFO
		 * is less than or equal to the programmable threshold. It is deasserted when the number
		 * of words in the FIFO exceeds the programmable threshold. (From Xilinx Data Sheet)
		 */
		public DFEsmFifoConfig setProgrammableEmpty (int level) {m_programmableEmpty = Integer.valueOf(level); return this;}
		/**
		 * Data Count: This bus indicates the number of words stored in the FIFO.
		 * If C is less than log2(FIFO depth)-1, the bus is truncated by removing the
		 * least-significant bits. (From Xilinx Data Sheet)
		 */
		public DFEsmFifoConfig setHasDataCount(){m_dataCount = true; return this;}
		/**
		 * Valid: This signal indicates that valid data is available on the output bus (DOUT).
		 */
		public DFEsmFifoConfig setHasValidFlag() {m_haveValidFlag = true; return this;}

		public BufferSpec getBufferSpec() {return m_bufferSpec;}
		public boolean isFirstWordFallThrough() {return m_firstWordFallThrough;}
		public Integer getProgrammableFull() {return m_programmableFull;}
		public boolean hasProgrammableFull() {return m_programmableFull != null;}
		public Integer getProgrammableEmpty () {return m_programmableEmpty;}
		public boolean hasProgrammableEmpty() {return m_programmableEmpty != null;}
		public boolean hasDataCount(){return m_dataCount;}
		public boolean hasValidFlag() {return m_haveValidFlag;}

		void validate(
			StateMachineLib stateMachine,
			DFEsmValueType inputType,
			int depth)
		{
			final BuildManager manager = _StateMachine.getBuildManager(stateMachine);
			if (hasProgrammableEmpty()) {
				// see cgfifo_base.getAllowedLatency() for the case input1.width == input2.width
				if (m_programmableEmpty < 7)
					throw _Error.errorAPI(manager, "Programmable empty threshold must be >= 7");
			}
			if (hasProgrammableFull()) {
				if (m_programmableFull < 0)
					throw _Error.errorAPI(manager, "Programmable full threshold cannot be < 0");
			}
		}
	}

	public DFEsmFifo fifo(DFEsmValueType type, int depth)
		{return fifo(type, depth, new DFEsmFifoConfig());}


	public DFEsmFifo fifo(DFEsmValueType type, int depth, DFEsmFifoConfig fifoConfig) {
		final BuildManager manager = _StateMachine.getBuildManager(getStateMachine());

		checkIsInConstructor();
		if (type == null)
			throw _Error.errorAPI(manager,"Argument 'type' must not be null.");
		if (fifoConfig == null)
			throw _Error.errorAPI(manager,"Argument 'fifoSpec' must not be null.");
		if (depth <= 0)
			throw _Error.errorAPI(manager,"FIFOs must have a depth > 0.");
		if ((depth & (depth -1)) != 0)
			throw _Error.errorAPI(manager,"FIFO depth must be a power of two.");

		fifoConfig.validate(getStateMachine(),type,depth);

		DFEsmFifo result = _DFEsmFifo.Create(getFifoID(), type, depth, fifoConfig, getStateMachine() );
		m_fifos.add(result);
		return result;
	}

	private String getFifoID() {
		return "fifo_" + Integer.toString(m_fifos.size());
	}

	List<DFEsmFifo> getFifos() {
		return Collections.unmodifiableList(m_fifos);
	}
}
