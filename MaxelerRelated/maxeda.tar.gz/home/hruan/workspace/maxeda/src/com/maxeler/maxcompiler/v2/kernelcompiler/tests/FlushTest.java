package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;

public class FlushTest extends Kernel {

	protected FlushTest(KernelParameters parameters) {
		super(parameters);
		DFEVar a = io.input("a", dfeBool());
		DFEVar b = io.output("b", dfeBool());

		b.connect(a);
	}

	public static void main(String[] args) {
		SimulationManager manager =
			new SimulationManager("FlushTest");

		manager.setKernel( new FlushTest(manager.makeKernelParameters()) );

		manager.setKernelCycles(6);
		manager.setInputData("a", 1, 0, 1, 1, 0);
		manager.runTest();
		manager.checkOutputData("b", 1, 0, 1, 1, 0);

		manager.setKernelCycles(4);
		manager.setInputData("a", 1, 0, 1, 1, 0);
		manager.runTest();
		manager.checkOutputData("b", 1, 0, 1, 1);

		manager.setKernelCycles(5);
		manager.setInputData("a", 1, 0, 1, 1, 0);
		manager.runTest();
		manager.checkOutputData("b", 1, 0, 1, 1, 0);
	}

}
