package com.maxeler.maxcompiler.v2.kernelcompiler.stdlib;

import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.fromImp;
import static com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes.toImp;

import java.util.ArrayList;
import java.util.List;

import com.maxeler.maxblox.funceval.FunctionCosine;
import com.maxeler.maxblox.funceval.FunctionLog2;
import com.maxeler.maxblox.funceval.FunctionSine;
import com.maxeler.maxblox.funceval.FunctionSqrt;
import com.maxeler.maxblox.funceval.MathPow;
import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler._Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.MathOps;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base._KernelBaseTypes;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVector;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorBase;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEVectorTypeBase;
import com.maxeler.maxcompiler.v2.utils.Bits;
import com.maxeler.maxcompiler.v2.utils.MathUtils;
import com.maxeler.photon.core.PhotonDesignData;
import com.maxeler.photon.core.Var;
import com.maxeler.photon.libs.RoundFactory;
import com.maxeler.photon.nodes.NodeCMath;
import com.maxeler.photon.nodes.NodeDivMod;
import com.maxeler.photon.nodes.NodeScalb;
import com.maxeler.photon.nodes.NodeSqrt;



/**
 * Provides common math functions for Kernel designs.
 * <p>
 * Square-root ({@link #sqrt(DFEVar)}).
 * <p>
 * Transcendental functions for exponentiation ({@link #exp(DFEVar)}), cosine ({@link #cos(DFEVar)}) and sine ({@link #sin(DFEVar)}).
 * <p>
 * Floor and ceiling functions ({@link #floor(DFEVar)} and {@link #ceil(DFEVar)}).
 */
public class KernelMath {

	public static class Range {
		private final com.maxeler.maxblox.funceval.Function.Range m_imp;

		public Range(double start, double end) {
			m_imp = new com.maxeler.maxblox.funceval.Function.Range(start, end);
		}

		/**
		 * @return the start
		 */
		public double getStart() {
			return m_imp.getStart();
		}

		/**
		 * @return the end
		 */
		public double getEnd() {
			return m_imp.getEnd();
		}

		public double getLength() {
			return m_imp.getLength();
		}

		@Override
		public String toString() {
			return m_imp.toString();
		}

		private com.maxeler.maxblox.funceval.Function.Range getImp() {
			return m_imp;
		}
	}

	private static void assertRoundTypes(DFEType in_type, DFEType out_type) {
		//System.out.println("Enter into here");
		if(!(in_type instanceof DFEFloat) && !(in_type instanceof DFEFix))
			throw new MaxCompilerAPIError(
				"Floor/ceil input DFEVar type must be DFEFloat or DFEFix, not " + in_type);

		if(!(out_type instanceof DFEFloat) && !(out_type instanceof DFEFix))
			throw new MaxCompilerAPIError(
				"Floor/ceil output type must be DFEFloat or DFEFix, not " + out_type);
	}

	/**
	 * Returns a stream of the smallest integer value not less than {@code x}.
	 * <p>
	 * <b>Note</b>: the {@code return} stream is of the same type as the input
	 * stream, so the resultant integer value will be to the precision of that
	 * type.
	 * @param x A real number stream.
	 * @return A new stream containing the resultant integer data.
	 */
	public static DFEVar ceil(DFEVar x)
	{
		return ceil(x, x.getType());
	}

	/**
	 * Returns a stream of the smallest integer not less than {@code x}, cast to the specified Kernel type.
	 * @param x A real number stream.
	 * @param out_type The Kernel type to which to cast the output stream.
	 * @return A new stream containing the the resultant integer data.
	 */
	public static DFEVar ceilDFEFixType(DFEVar x, DFEType out_type) {
		Kernel kd = x.getKernel();

		kd.optimization.pushFixOpModeDefault(MathOps.ALL);
		try {
			//assertRoundTypes(x.getType(), out_type);
			com.maxeler.photon.types.HWType inType = toImp(x.getType());

			if(out_type instanceof DFEFloat) {
				RoundFactory r = new RoundFactory(_Kernel.getPhotonDesignData(kd), inType, inType);
				Var rx = r.ceil(toImp(x));

				return fromImp(kd, rx).cast(out_type);
			} else {
				com.maxeler.photon.types.HWType outType = toImp(out_type);
				RoundFactory r = new RoundFactory(_Kernel.getPhotonDesignData(kd), inType, outType);
				Var rx = r.ceil(toImp(x));

				return fromImp(kd, rx);
			}
		} finally {
			kd.optimization.popFixOpMode(MathOps.ALL);
		}
	}


	/**
	 * Returns a stream of the smallest integer not less than {@code x}, cast to the specified Kernel type.
	 * @param x A real number stream.
	 * @param out_type The Kernel type to which to cast the output stream.
	 * @return A new stream containing the the resultant integer data.
	 */
	public static DFEVar ceil(DFEVar x, DFEType out_type) {
		Kernel instKernel = x.getKernel();

		instKernel.optimization.pushFixOpModeDefault(MathOps.ALL);
		try {
			DFEType inType = x.getType();
			assertRoundTypes(inType, out_type);

			if(inType instanceof DFEFloat)
			{
				DFEFloat floatType    = (DFEFloat)inType;
				int actualMantiBits  = floatType.getMantissaBits() - 1;
				int bias             = floatType.getExponentBias();
				int totalBits        = floatType.getTotalBits();
				DFEVar unBiasExponent = FloatingPoint.getExponent(x);

				DFEVar bits      = x.slice(0, floatType.getTotalBits());
				DFEVar fracBits  = actualMantiBits - unBiasExponent;
				Bits allOneBits = new Bits(totalBits);
				allOneBits.setOthers(1);
				DFEVar allOne    = instKernel.constant.var(Kernel.dfeUInt(totalBits), allOneBits);

				DFEVar integralMask = (fracBits > 0) ?  allOne<<fracBits.cast(Kernel.dfeUInt(MathUtils.bitsToAddress(totalBits))) : allOne;

				DFEVar output       = bits.and(integralMask).cast(floatType);
				DFEVar constantOne  = instKernel.constant.var(floatType, 1.0);
				DFEVar constantZero = instKernel.constant.var(floatType, 0);
				DFEVar result       = x > 0 ? constantOne: constantZero;
				DFEVar isExpZero    = unBiasExponent.eq(-bias);

				/*Construct result so as to using control.mux to return the value*/
				DFEVar possibleResult[] = new DFEVar[8];
				DFEVar subSelect_1      = unBiasExponent < 0 & ~isExpZero;
				DFEVar subSelect_2      = isExpZero;
				DFEVar subSelect_3      = x > 0 & output.neq(x);
				DFEVar select           = subSelect_1#subSelect_2#subSelect_3;

				possibleResult[0] = output;
				possibleResult[1] = output+1;
				possibleResult[2] = constantZero;
				possibleResult[3] = constantZero;
				possibleResult[4] = result;
				possibleResult[5] = result;
				possibleResult[6] = result;
				possibleResult[7] = result;

				return instKernel.control.mux(select, possibleResult).cast(out_type);
			}
			else //dealing with dfeFix Type
			{
				return ceilDFEFixType(x, out_type);
			}

		} finally {
			instKernel.optimization.popFixOpMode(MathOps.ALL);
		}
	}


	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M ceil(M x) {
		return ceil(x, (DFEType) x.getType().getContainedType());
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M ceil(M x, DFEType out_type) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(x.getNElements());
		for (int i = 0; i < x.getNElements(); ++i)
			new_pipes.add(ceil(x.getElement(i), out_type));
		return x.getType().newInstance(x.getKernel(), new_pipes);
	}

	/**
	 * Returns a stream of the largest integer value not greater than {@code x}.
	 * <p>
	 * <b>Note</b>: the {@code return} stream is of the same type as the input
	 * stream, so the resultant integer value will be to the precision of that
	 * type.
	 * @param x A real number stream.
	 * @return A new stream containing the resultant integer data.
	 */
	public static DFEVar floor(DFEVar x) {
		return floor(x, x.getType());
	}

	/**
	 * Returns a stream of the largest integer not greater than {@code x}, cast to the specified Kernel type.
	 * @param x A real number stream.
	 * @param out_type The Kernel type to which to cast the output stream.
	 * @return A new stream containing the the resultant integer data.
	 */
	public static DFEVar floor(DFEVar x, DFEType out_type) {
		Kernel kd = x.getKernel();
		kd.optimization.pushFixOpModeDefault(MathOps.ALL);
		try {

			DFEType inType = x.getType();
			assertRoundTypes(inType, out_type);

			if(inType instanceof DFEFloat)
			{
				return (-ceil(-x)).cast(out_type);
			}
			else
			{
				if(out_type instanceof DFEFloat) {
					// need to add a bit to x to avoid overflows in intermediate
					// computation even though floor can be represented in out_type
					DFEFix fixType = ((DFEFix)inType);
					inType = Kernel.dfeFix(1+fixType.getIntegerBits(), fixType.getFractionBits(), fixType.getSignMode());
					x = x.cast(inType);

					com.maxeler.photon.types.HWType newInType = toImp(inType);
					RoundFactory r = new RoundFactory(_Kernel.getPhotonDesignData(kd), newInType, newInType);
					Var rx = r.floor(toImp(x));
					return fromImp(kd, rx).cast(out_type);
				} else {
					com.maxeler.photon.types.HWType newInType = toImp(inType);
					com.maxeler.photon.types.HWType outType = toImp(out_type);
					RoundFactory r = new RoundFactory(_Kernel.getPhotonDesignData(kd), newInType, outType);
					Var rx = r.floor(toImp(x));
					return fromImp(kd, rx);
				}
			}
		} finally {
			kd.optimization.popFixOpMode(MathOps.ALL);
		}
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M floor(M x) {
		return floor(x, (DFEType) x.getType().getContainedType());
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M floor(M x, DFEType out_type) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(x.getNElements());
		for (int i = 0; i < x.getNElements(); ++i)
		{
			new_pipes.add(floor(x.getElement(i), out_type));

		}
		return x.getType().newInstance(x.getKernel(), new_pipes);
	}

	/**
	 * Returns a stream of the absolute value of {@code x}.
	 * @param x A real number stream.
	 * @return A new stream containing the resultant non negative real data.
	 */
	public static DFEVar abs(DFEVar x) {
		if(!x.getType().isConcreteType()) { // for untyped constants
			return x > 0 ? x : -x;
		}
		if(!(x.getType() instanceof DFEFix) && !(x.getType() instanceof DFEFloat))
			throw new MaxCompilerAPIError(x.getKernel().getManager(), "DFEVar input must be of float/fixed type, not: " + x.getType());

		Kernel kd = x.getKernel();

		if(x.getType() instanceof DFEFix) {
			DFEFix type = (DFEFix)x.getType();
			if(type.getSignMode().equals(SignMode.TWOSCOMPLEMENT) ) {
				return (x < 0 ? -x : x);
			} else if (type.getSignMode().equals(SignMode.UNSIGNED)) {
				return x;
			} else {
				throw new MaxCompilerAPIError(x.getKernel().getManager(), "Fixed point type must have sign mode TWOSCOMPLEMENT or UNSIGNED");
			}
		} else {
			DFEFloat type = (DFEFloat)x.getType();
			DFEVar sign = Kernel.dfeRawBits(1).newInstance(kd, 0);
			DFEVar mantissa_exp = x.slice(0, type.getTotalBits()-1);
			DFEVar raw = sign.cat(mantissa_exp);
			return raw.cast(type);
		}
	}

	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M abs(M x) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(x.getNElements());
		for (int i = 0; i < x.getNElements(); ++i)
			new_pipes.add(abs(x.getElement(i)));
		return x.getType().newInstance(x.getKernel(), new_pipes);
	}

	/**
	 * Returns the square root of {@code x}.
	 * <p>
	 * <b>Note</b>: Only {@link DFEFloat} is currently supported.
	 */
	public static DFEVar sqrt(DFEVar x) {
		if( !(x.getType() instanceof DFEFloat) ) {
			throw new MaxCompilerAPIError("Only floats are supported without specifying an input range. Use KernelMath.sqrt(Range, DFEVar, DFEType) instead.");
		}
		return sqrt(null, x, x.getType());
	}

	/**
	 * Returns the square root of {@code x}.
	 * <p>
	 *
	 * @param inputRange	This can be null if x is of type DFEFloat. Otherwise it should be the expected range of x.
	 * @param x				Input value
	 * @param outputType	Output type
	 * @return				Square root of x
	 */
	public static DFEVar sqrt(Range inputRange, DFEVar x, DFEType outputType) {
		Kernel kernel = x.getKernel();
		if(x.getType() instanceof DFEFloat) {
			NodeSqrt sqrt_node = new NodeSqrt(_Kernel.getPhotonDesignData(kernel));
			sqrt_node.connectInput("a", _KernelBaseTypes.toImp(x));
			return _KernelBaseTypes.fromImp(kernel, sqrt_node.connectOutput("result")).cast(outputType);
		} else {
			int precision = outputType.getTotalBits();
			if(((DFEFix)outputType).getSignMode().equals(SignMode.UNSIGNED)) {
				precision++;
			}
			FunctionSqrt sqrt = new FunctionSqrt(inputRange.getImp(), precision);
			return sqrt.funcEval(x, outputType);
		}
	}

	/**
	 * Returns the square root of each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M sqrt(M x) {
		if( !(x.getType().getContainedType() instanceof DFEFloat) ) {
			throw new MaxCompilerAPIError("Only floats are supported without specifying an input range. Use KernelMath.sqrt(Range, M, T) instead.");
		}
		return sqrt(null, x, x.getType());
	}

	/**
	 * Returns the square root of each pipe in {@code x}.
	 *
	 * @param inputRange	This can be null if x is of type DFEFloat. Otherwise it should be the expected range of x.
	 * @param x				Input value
	 * @param outputType	Output type
	 * @return				Square root of x
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M sqrt(Range inputRange, M x, T outputType) {
		if(x.getType().getContainedType() instanceof DFEFix) {
			return sqrtFix(inputRange, x, outputType);
		}
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(x.getNElements());
		for (int i = 0; i < x.getNElements(); ++i)
			new_pipes.add(sqrt(x.getElement(i)));
		return x.getType().newInstance(x.getKernel(), new_pipes);
	}



	/**
	 * Returns the sqrt of each pipe in {@code x}.
	 */
	private static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M sqrtFix(Range inputRange, M x, T outputType) {
		FunctionSqrt sqrt = new FunctionSqrt(inputRange.getImp(), ((DFEType)outputType.getContainedType()).getTotalBits());
		return sqrt.funcEval(x, outputType);
	}

	/**
	 * Returns the log2 of {@code x}.
	 * <p>
	 *
	 * @param inputRange	This should be the expected range of x.
	 * @param x				Input value
	 * @param outputType	Output type
	 * @return				Log2 of x
	 */
	public static DFEVar log2(Range inputRange, DFEVar x, DFEType outputType) {
		int precision = 0;
		if(outputType instanceof DFEFix) {
			precision = ((DFEFix)outputType).getFractionBits()+1;
		} else if(outputType instanceof DFEFloat) {
			precision = ((DFEFloat)outputType).getMantissaBits() + 1;
		} else {
			throw new MaxCompilerAPIError("Only fixed point or floating point types supported.");
		}
		FunctionLog2 log2 = new FunctionLog2(inputRange.getImp(), precision);
		return log2.funcEval(x, outputType);
	}

	/**
	 * Returns the log2 of {@code x}.
	 * <p>
	 *
	 * @param inputRange	This should be the expected range of x.
	 * @param x				Input value
	 * @param outputType	Output type
	 * @return				Log2 of x
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	> M log2(Range inputRange, M x, T outputType) {
		int precision = 0;
		DFEType innerType = (DFEType)outputType.getContainedType();
		if(innerType instanceof DFEFix) {
			precision = ((DFEFix)innerType).getFractionBits()+1;
		} else if(innerType instanceof DFEFloat) {
			precision = ((DFEFloat)innerType).getMantissaBits() + 1;
		} else {
			throw new MaxCompilerAPIError("Only fixed point or floating point types supported.");
		}
		FunctionLog2 log2 = new FunctionLog2(inputRange.getImp(), precision);
		return log2.funcEval(x, outputType);
	}

	/**
	 * Returns the natural logarithm of {@code x}.
	 * <p>
	 *
	 * @param inputRange	This should be the expected range of x.
	 * @param x				Input value
	 * @param outputType	Output type
	 * @return				Log of x
	 */
	public static DFEVar log(Range inputRange, DFEVar x, DFEType outputType) {
		Kernel kernel = x.getKernel();

		if (kernel.debug.peekEnableNativeSimulationMath()) {
			return simulationMath(x, "log");
		}

		try {
			kernel.optimization.pushFixOpModeDefault(MathOps.ALL);

			int precision = 0;
			if(outputType instanceof DFEFix) {
				precision = ((DFEFix)outputType).getFractionBits()+4;
			} else if(outputType instanceof DFEFloat) {
				precision = ((DFEFloat)outputType).getMantissaBits()+4;
			} else {
				throw new MaxCompilerAPIError("Only fixed point or floating point types supported.");
			}
			double invLog2e = Math.log(2);
			FunctionLog2 log2 = new FunctionLog2(inputRange.getImp(), precision);
			return log2.funcEval(x, outputType)*invLog2e;
		} finally {
			kernel.optimization.popFixOpMode(MathOps.ALL);
		}
	}

	/**
	 * Returns the natural logarithm of {@code x}.
	 * <p>
	 *
	 * @param inputRange	This should be the expected range of x.
	 * @param x				Input value
	 * @param outputType	Output type
	 * @return				Log of x
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	> M log(Range inputRange, M x, T outputType) {
		Kernel kernel = x.getKernel();

		if (kernel.debug.peekEnableNativeSimulationMath()) {
			return simulationMath(x, "log");
		}

		try {
			kernel.optimization.pushFixOpModeDefault(MathOps.ALL);

			int precision = 0;
			DFEType innerType = (DFEType)outputType.getContainedType();
			if(innerType instanceof DFEFix) {
				precision = ((DFEFix)innerType).getFractionBits()+1;
			} else if(innerType instanceof DFEFloat) {
				precision = ((DFEFloat)innerType).getMantissaBits() + 1;
			} else {
				throw new MaxCompilerAPIError("Only fixed point or floating point types supported.");
			}
			double invLog2e = Math.log(2);
			FunctionLog2 log2 = new FunctionLog2(inputRange.getImp(), precision);
			return log2.funcEval(x, outputType)*invLog2e;
		} finally {
			kernel.optimization.popFixOpMode(MathOps.ALL);
		}
	}

	public static class DivModResult {
		private final DFEVar m_quot;
		private final DFEVar m_rem;

		DivModResult(DFEVar quot, DFEVar rem) {
			m_quot = quot;
			m_rem = rem;
		}

		public DFEVar getQuotient() { return m_quot; }
		public DFEVar getRemainder() { return m_rem; }
	}

	public static DFEVar sin(DFEVar x) {
		return sin(x, x.getType());
	}

	public static DFEVar sin(DFEVar x, DFEType outputType) {
		FunctionSine sine = new FunctionSine(outputType.getTotalBits());
		return sine.funcEval(x, outputType);
	}

	/**
	 * Returns the sine of each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M sin(M x, T outputType) {
		FunctionSine sine = new FunctionSine(((DFEType)outputType.getContainedType()).getTotalBits());
		return sine.funcEval(x, outputType);
	}

	/**
	 * Returns the sine of each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M sin(M x) {
		return sin(x, x.getType());
	}

	public static DFEVar cos(DFEVar x) {
		return cos(x, x.getType());
	}

	public static DFEVar cos(DFEVar x, DFEType outputType) {
		FunctionCosine cosine = new FunctionCosine(outputType.getTotalBits());
		return cosine.funcEval(x, outputType);
	}

	/**
	 * Returns 2^pipe for each pipe in {@code x}. Input and output have to be fixed point.
	 *
	 * Deprecated: use pow2(M x, T outputType) instead.
	 */
	@Deprecated
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M pow2(Range inputRange, M x, T outputType) {
		return pow2(x, outputType);
	}

	/**
	 * Returns 2^pipe for each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M pow2(M x, T outputType) {
		return MathPow.pow(x, outputType, 2);
	}

	/**
	 * Returns 2^x.
	 *
	 * Deprecated: use pow2(DFEVar x, DFEType outputType) instead.
	 */
	@Deprecated
	public static DFEVar pow2(Range inputRange, DFEVar x, DFEType outputType) {
		return pow2(x, outputType);
	}

	/**
	 * Returns 2^x.
	 */
	public static DFEVar pow2(DFEVar x, DFEType outputType) {
		return MathPow.pow(x, outputType, 2);
	}

	/**
	 * Returns e^pipe for each pipe in {@code x}.
	 *
	 * Deprecated: use exp(M x, T outputType) instead.
	 */
	@Deprecated
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M exp(Range inputRange, M x, T outputType) {
		return exp(x, outputType);
	}

	/**
	 * Returns e^pipe for each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M exp(M x, T outputType) {
		return MathPow.pow(x, outputType, Math.E);
	}

	/**
	 * Returns e^x.
	 *
	 * Deprecated: use exp(DFEVar x, DFEType outputType) instead.
	 */
	@Deprecated
	public static DFEVar exp(Range inputRange, DFEVar x, DFEType outputType) {
		return exp(x, outputType);
	}


	/**
	 * Returns e^x.
	 */
	public static DFEVar exp(DFEVar x, DFEType outputType) {
		return MathPow.pow(x, outputType, Math.E);
	}


	/**
	 * Returns e^x.
	 */
	public static DFEVar exp(DFEVar x) {
		return exp(x, x.getType());
	}

	/**
	 * Returns e^pipe for each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	> M exp(M x) {
		return exp(x, x.getType());
	}

	/**
	 * Returns the cosine of each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M cos(M x, T outputType) {
		FunctionCosine cosine = new FunctionCosine(((DFEType)outputType.getContainedType()).getTotalBits());
		return cosine.funcEval(x, outputType);
	}

	/**
	 * Returns the cosine of each pipe in {@code x}.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M cos(M x) {
		return cos(x, x.getType());
	}

	public static DivModResult divMod(DFEVar num, DFEVar denom) {
		return divMod(num, denom, num.getType().getTotalBits());
	}

	public static DivModResult divMod(DFEVar num, DFEVar denom, int quot_bits) {
		Kernel kernel = num.getKernel();
		PhotonDesignData container = _Kernel.getPhotonDesignData(kernel);

		NodeDivMod n = new NodeDivMod(container, quot_bits);
		n.connectInput("numerator", _KernelBaseTypes.toImp(num));
		n.connectInput("denominator", _KernelBaseTypes.toImp(denom));

		DFEVar quot = _KernelBaseTypes.fromImp(kernel, n.connectOutput("quotient"));
		DFEVar rem = _KernelBaseTypes.fromImp(kernel, n.connectOutput("remainder"));

		return new DivModResult(quot, rem);
	}

	/**
	 * Compute modulo a constant base.
	 * The return type is dfeUInt(MathUtils.bitsToAddress(base)).
	 *
	 * @param input	A stream of integers (signed or unsigned).
	 * @param base	A positive number.
	 * @return		A stream of unsigned integer all < base.
	 */
	public static DFEVar modulo(DFEVar input, int base) {
		_ModuloLib mod = new _ModuloLib(input.getKernel());
		return mod.modulo(input, base);
	}

	/**
	 * Compute modulo a constant base.
	 * The return type is dfeUInt(MathUtils.bitsToAddress(base)).
	 *
	 * @param x		A stream of integers (signed or unsigned).
	 * @param base	A positive number.
	 * @return		A stream of unsigned integer all < base.
	 */
	public static DFEVector<DFEVar> modulo(DFEVector<DFEVar> x, int base) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(x.getNElements());
		for (int i = 0; i < x.getNElements(); ++i)
			new_pipes.add(modulo(x.getElement(i), base));
		DFEVectorType<DFEVar> retType = new DFEVectorType<DFEVar>(new_pipes.get(0).getType(), x.getNElements());
		return retType.newInstance(x.getKernel(), new_pipes);
	}

	/**
	 * Utility that returns smaller of two supplied parameters via <code>a > b ? b : a</code>.
	 *
	 * @param a Stream of numeric values.
	 * @param b Stream of numeric values.
	 * @return Stream of numeric values.
	 */
	public static DFEVar min(DFEVar a, DFEVar b) {
		return a > b ? b : a;
	}

	/**
	 * Multi-pipe version of {@link KernelMath#min(DFEVar, DFEVar)}, computing the minimum
	 * value for each pair of pipes from <code>a</code> <code>b</code> into a new set of pipes.
	 * Number of pipes most be the same for both parameters.
	 *
	 * @param a Stream of multi-pipe numeric values.
	 * @param b Stream of multi-pipe numeric values.
	 * @return Stream of multi-pipe numeric values.
	 */
	public static DFEVector<DFEVar> min(DFEVector<DFEVar> a, DFEVector<DFEVar> b) {
		if(b.getNElements() != a.getNElements())
			throw new MaxCompilerAPIError(
				a.getKernel().getManager(), "Inputs have different number of pipes.");

		List<DFEVar> new_pipes = new ArrayList<DFEVar>(a.getNElements());
		for (int i = 0; i < a.getNElements(); ++i)
			new_pipes.add( min(a.getElement(i), b.getElement(i)) );
		DFEVectorType<DFEVar> retType =
			new DFEVectorType<DFEVar>(new_pipes.get(0).getType(), a.getNElements());

		return retType.newInstance(a.getKernel(), new_pipes);
	}

	/**
	 * Utility to return larger of two supplied parameters via <code>a > b ? a : b</code>.
	 *
	 * @param a Stream of numeric values.
	 * @param b Stream of numeric values.
	 * @return Stream of numeric values.
	 */
	public static DFEVar max(DFEVar a, DFEVar b) {
		return a > b ? a : b;
	}

	/**
	 * Multi-pipe version of {@link KernelMath#min(DFEVar, DFEVar)}, computing the maximum
	 * value for each pair of pipes from <code>a</code> <code>b</code> into a new set of pipes.
	 * Number of pipes most be the same for both parameters.
	 *
	 * @param a Stream of multi-pipe numeric values.
	 * @param b Stream of multi-pipe numeric values.
	 * @return Stream of multi-pipe numeric values.
	 */
	public static DFEVector<DFEVar> max(DFEVector<DFEVar> a, DFEVector<DFEVar> b) {
		if(b.getNElements() != a.getNElements())
			throw new MaxCompilerAPIError(
				a.getKernel().getManager(), "Inputs have different number of pipes.");

		List<DFEVar> new_pipes = new ArrayList<DFEVar>(a.getNElements());
		for (int i = 0; i < a.getNElements(); ++i)
			new_pipes.add( max(a.getElement(i), b.getElement(i)) );
		DFEVectorType<DFEVar> retType =
			new DFEVectorType<DFEVar>(new_pipes.get(0).getType(), a.getNElements());

		return retType.newInstance(a.getKernel(), new_pipes);
	}

	private static DFEVar simulationMath(DFEVar input, String method_name) {
		PhotonDesignData design = _Kernel.getPhotonDesignData(input.getKernel());
		NodeCMath node = new NodeCMath(design, design.getGroupPath(), method_name);

		Var impIn = _KernelBaseTypes.toImp(input);
		node.connectInput("a", impIn);
		Var impOut = node.connectOutput("result");

		return _KernelBaseTypes.fromImp(input.getKernel(), impOut);
	}

	private static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	> M simulationMath(M x, String method_name) {
		List<DFEVar> result = new ArrayList<DFEVar>();

		for (int i=0; i<x.getNElements(); i++)
			result.add(simulationMath(x.getElement(i), method_name));

		return x.getType().newInstance(x.getKernel(), result);
	}

	/**
	 * Multiply a floating-point value by a power of 2.
	 * <p>
	 * The resulting value is {@code data * pow(2, scale)}. This is equivalent
	 * to the Java library's {@link Math#scalb} (and {@code ldexp} in C).
	 * @param data The floating-point value to scale.
	 * @param scale The exponent of the scale.
	 * @return A floating-point value multiplied by the specified power of 2.
	 */
	public static DFEVar scalb(DFEVar data, DFEVar scale) {
		final DFEType dataType = data.getType();
		if (!(dataType instanceof DFEFloat))
			throw new MaxCompilerAPIError(data.getKernel().getManager(), "Type for 'data' must be DFEFloat, not %s.", dataType);

		final DFEType scaleType = scale.getType();
		if (!scaleType.isInt())
			throw new MaxCompilerAPIError(data.getKernel().getManager(), "Type for 'scale' must be DFEInt, not %s.", scaleType);
		if (scaleType.getTotalBits() != ((DFEFloat) dataType).getExponentBits() + 1) {
			throw new MaxCompilerAPIError(
				data.getKernel().getManager(),
				"Type for 'scale' must be %d bits wide (not %d) for floating-point type %s.",
				((DFEFloat) dataType).getExponentBits() + 1, scaleType.getTotalBits(), dataType
			);
		}

		final Kernel kernel = data.getKernel();
		final NodeScalb node = new NodeScalb(_Kernel.getPhotonDesignData(kernel));
		final Var dataV = _KernelBaseTypes.toImp(data);
		final Var scaleFactorV = _KernelBaseTypes.toImp(scale);

		node.connectInput("data", dataV);
		node.connectInput("scale", scaleFactorV);

		return _KernelBaseTypes.fromImp(kernel, node.connectOutput("result"));
	}

	/**
	 * Multiply a floating-point value by a power of 2 (multi-pipe version).
	 * <p>
	 * The resulting value is {@code data * pow(2, scale)}. This is equivalent
	 * to the Java library's {@link Math#scalb} (and {@code ldexp} in C).
	 * @param data The floating-point value to scale.
	 * @param scale The exponent of the scale.
	 * @return A floating-point value multiplied by the specified power of 2.
	 */
	public static <
		M extends DFEVectorBase<DFEVar, M, C, T>,
		C extends DFEVectorBase<DFEVar, C, ?, ?>,
		T extends DFEVectorTypeBase<DFEVar, M, C>
	>
	M scalb(M data, DFEVar scale) {
		List<DFEVar> new_pipes = new ArrayList<DFEVar>(data.getNElements());
		for (int i = 0; i < data.getNElements(); ++i)
			new_pipes.add(scalb(data.getElement(i), scale));
		return data.getType().newInstance(data.getKernel(), new_pipes);
	}
}
