package com.maxeler.maxcompiler.v2.managers.custom.stdlib;

public enum Max3RingConnection implements MaxRingConnection {
	MAXRING_A,
	MAXRING_B,
	MAXRING_LITE_A,
	MAXRING_LITE_B
}
