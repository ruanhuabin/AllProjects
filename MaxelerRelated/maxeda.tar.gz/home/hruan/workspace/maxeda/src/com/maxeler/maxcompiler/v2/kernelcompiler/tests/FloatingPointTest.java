package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import java.util.List;
import java.util.Random;

import com.maxeler.maxcompiler.v2.errors.MaxConstantEncodingException;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.FloatingPoint;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFloat;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFETypeFactory;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager.DualSimMode;
import com.maxeler.maxcompiler.v2.utils.Bits;

public class FloatingPointTest extends Kernel {

	private static final long m_seed = System.currentTimeMillis();

	private static final int SIZE = 100;

	private static final int MAX_EXP_WIDTH_SW = 11;
	private static final int MAX_MAN_WIDTH_SW = 52;

	private static final int MIN_EXP_WIDTH_HW = 4;
	private static final int MIN_MAN_WIDTH_HW = 4;
	private static final int MAX_EXP_WIDTH_HW = 16;
	//private static final int MAX_MAN_WIDTH_HW = 64;

	private enum FloatType {
		NORMAL,
		NAN,
		INF
	}

	public FloatingPointTest(KernelParameters parameters, DFEFloat f_type, DFEFix m_type, DFEFix e_type) {
		super(parameters);

		DFEVar f = io.input("f", f_type);
		DFEVar m = io.input("m", m_type);
		DFEVar e = io.input("e", e_type);
		DFEVar inf_nan = io.input("inf_nan", f_type);

		DFEVar exp = FloatingPoint.getExponent(f);
		DFEVar man = FloatingPoint.getMantissa(f);
		DFEVar exp_bits = FloatingPoint.getExponentBits(f);
		DFEVar man_bits = FloatingPoint.getMantissaBits(f);
		DFEVar sign_bit = FloatingPoint.getSignBit(f);
		DFEVar new_inst = FloatingPoint.newInstance(m, e);
		DFEVar inf = FloatingPoint.isInfinity(inf_nan);
		DFEVar nan = FloatingPoint.isNaN(inf_nan);

		io.output("exp", exp, dfeInt(f_type.getExponentBits()+1));
		io.output("man", man, dfeFix(2, f_type.getMantissaBits()-1, SignMode.TWOSCOMPLEMENT));
		io.output("exp_bits", exp_bits, dfeRawBits(f_type.getExponentBits()));
		io.output("man_bits", man_bits, dfeRawBits(f_type.getMantissaBits()-1));
		io.output("sign_bit", sign_bit, dfeRawBits(1));
		io.output("new_inst", new_inst, dfeFloat(e_type.getTotalBits() - 1, m_type.getFractionBits() + 1));
		io.output("new_inst_raw", new_inst.cast(dfeRawBits(f_type.getTotalBits())), dfeRawBits(f_type.getTotalBits()));
		io.output("inf", inf, dfeBool());
		io.output("nan", nan, dfeBool());
	}


	public static void main(String[] args) {

		System.out.println("Running FloatingPointTest with seed " + m_seed);
		Random rnd = new Random(m_seed);

		_DualSimulationManager manager = new _DualSimulationManager("FloatingPointTest", DualSimMode.SEQUENTIAL);

		int exp_width = MIN_EXP_WIDTH_HW + rnd.nextInt(Math.min(MAX_EXP_WIDTH_HW, MAX_EXP_WIDTH_SW) + 1 - MIN_EXP_WIDTH_HW);
		int man_width = MIN_MAN_WIDTH_HW + rnd.nextInt(Math.min(getMaxManForExpHW(exp_width), MAX_MAN_WIDTH_SW + 1) - MIN_MAN_WIDTH_HW);
		DFEFloat f_type = DFETypeFactory.dfeFloat(exp_width, man_width);
		DFEFix e_type = DFETypeFactory.dfeInt(exp_width + 1);
		DFEFix m_type = DFETypeFactory.dfeFix(2, man_width - 1, SignMode.TWOSCOMPLEMENT);

		double[] f = new double[SIZE];
		Bits[] exp_raw = new Bits[SIZE];
		Bits[] man_raw = new Bits[SIZE];
		Bits[] sign_raw = new Bits[SIZE];

		double[] new_inst = new double[SIZE];
		double[] exp_typed = new double[SIZE];
		double[] man_typed = new double[SIZE];

		double[] inf_nan = new double[SIZE];
		FloatType[] inf_nan_res = new FloatType[SIZE];

		// Corner case zero
		f[0] = 0;
		exp_raw[0] = Bits.allZeros(exp_width);
		man_raw[0] = Bits.allZeros(man_width - 1);
		sign_raw[0] = Bits.allZeros(1);

		new_inst[0] = 0;
		exp_typed[0] = -f_type.getExponentBias();
		man_typed[0] = 0;

		// Corner case one
		f[1] = 1;
		exp_raw[1] = Bits.allOnes(exp_width); exp_raw[1].setBit(exp_width - 1, 0);
		man_raw[1] = Bits.allZeros(man_width - 1);
		sign_raw[1] = Bits.allZeros(1);

		new_inst[1] = 1;
		exp_typed[1] = 0;
		man_typed[1] = 0;

		boolean encoding_ex;

		for (int i = 2; i < SIZE; ++i) {

			// Yes, this is ugly...
			int max_tries = 1000;
			do {
				exp_raw[i] = new Bits(exp_width);
				man_raw[i] = new Bits(man_width - 1);
				sign_raw[i] = new Bits(1);

				exp_raw[i].setBits(1 + ((rnd.nextLong() % ((long)Math.pow(2, exp_width-1) - 2))));
				man_raw[i].setBits(1 + ((rnd.nextLong() % ((long)Math.pow(2, man_width-2) - 2))));
				sign_raw[i].setBits(rnd.nextBoolean() ? 1 : 0);

				try {
					encoding_ex = false;
					f[i] = f_type.decodeConstant(man_raw[i].concat(exp_raw[i]).concat(sign_raw[i]));
					exp_typed[i] = e_type.decodeConstant(e_type.encodeConstant(1 + rnd.nextInt((int)Math.pow(2, exp_width) - 3)));
					man_typed[i] = m_type.decodeConstant(m_type.encodeConstant((1 + rnd.nextDouble()) * (rnd.nextBoolean() ? 1.0 : -1.0)));
				}
				catch (MaxConstantEncodingException e) {
					encoding_ex = true;
				}

				if (Math.abs(man_typed[i]) >= 2.0)
					man_typed[i] = 1.0;

				new_inst[i] = man_typed[i] * Math.pow(2, exp_typed[i]);
				Bits bits;
				try {
					bits = f_type.encodeConstant(new_inst[i]);
				}
				catch (MaxConstantEncodingException e) {
					bits = e.getPackedValue();
				}
				new_inst[i] = f_type.decodeConstant(bits);

				max_tries--;
			} while ((encoding_ex || f[i] == 0 || Double.isInfinite(f[i]) || Double.isNaN(f[i])) && max_tries >= 0);
		}

		for (int i = 0; i < SIZE; ++i) {

			switch(FloatType.values()[rnd.nextInt(FloatType.values().length)]) {
				case NORMAL:
					inf_nan[i] = f[i];
					inf_nan_res[i] = FloatType.NORMAL;
					break;
				case NAN: {
					Bits sign = rnd.nextBoolean() ? Bits.allOnes(1) : Bits.allZeros(1);
					Bits exp = Bits.allOnes(exp_width);
					Bits man = Bits.allZeros(man_width - 1);
					man.setBit(rnd.nextInt(man_width - 2), 1);
					inf_nan[i] = f_type.decodeConstant(man.concat(exp).concat(sign));
					inf_nan_res[i] = FloatType.NAN;
					break;
				}
				case INF:
					Bits sign = rnd.nextBoolean() ? Bits.allOnes(1) : Bits.allZeros(1);
					Bits exp = Bits.allOnes(exp_width);
					Bits man = Bits.allZeros(man_width - 1);
					inf_nan[i] = f_type.decodeConstant(man.concat(exp).concat(sign));					inf_nan_res[i] = FloatType.INF;
					break;
			}
		}

		manager.setKernels(
			new FloatingPointTest(manager.makeKernelParameters_A(), f_type, m_type, e_type),
			new FloatingPointTest(manager.makeKernelParameters_B(), f_type, m_type, e_type));

		manager.setKernelCycles(SIZE);

		manager.setInputData("f", f);
		manager.setInputData("m", man_typed);
		manager.setInputData("e", exp_typed);
		manager.setInputData("inf_nan", inf_nan);

		manager.runTest();

		List<Double> res_exp = manager.getOutputData("exp");
		List<Double> res_man = manager.getOutputData("man");

		List<Bits> res_exp_bits = manager.getOutputDataRaw("exp_bits");
		List<Bits> res_man_bits = manager.getOutputDataRaw("man_bits");
		List<Bits> res_sign_bit = manager.getOutputDataRaw("sign_bit");

		List<Double> res_new_inst = manager.getOutputData("new_inst");

		List<Double> res_inf = manager.getOutputData("inf");
		List<Double> res_nan = manager.getOutputData("nan");

		boolean fail = false;
		for (int i = 0; i < SIZE; ++i) {
			double res = res_man.get(i) * Math.pow(2, res_exp.get(i));

			if (Math.abs(res - f[i]) > 0.0001) {
				System.out.printf("Error at [%d]: %f * 2^%f = %f but expecting %f\n", i, res_man.get(i), res_exp.get(i), res, f[i]);
				fail = true;
			}

			if (!res_man_bits.get(i).equals(man_raw[i])) {
				System.out.printf("Error at [%d]: mantissa = %s but expecting %s (d = %f)\n", i, res_man_bits.get(i), man_raw[i], f[i]);
				fail = true;
			}

			if (!res_exp_bits.get(i).equals(exp_raw[i])) {
				System.out.printf("Error at [%d]: exponent = %s but expecting %s (d = %f)\n", i, res_exp_bits.get(i), exp_raw[i], f[i]);
				fail = true;
			}

			if (!res_sign_bit.get(i).equals(sign_raw[i])) {
				System.out.printf("Error at [%d]: sign = %s but expecting %s (d = %f)\n", i, res_sign_bit.get(i), sign_raw[i], f[i]);
				fail = true;
			}

			if (Math.abs(res_new_inst.get(i) - new_inst[i]) > 0.0001) {
				System.out.printf("Error at [%d]: newInstance(%f, %f) = %f but expecting %f\n", i, man_typed[i], exp_typed[i], res_new_inst.get(i), new_inst[i]);
				fail = true;
			}

			if ((res_inf.get(i) == 1) != (inf_nan_res[i] == FloatType.INF)) {
				System.out.printf("Error at [%d]: isInfinity(%f) = %f but expecting %f\n", i, inf_nan[i], res_inf.get(i), (inf_nan_res[i] == FloatType.INF) ? 1.0 : 0.0);
				fail = true;
			}

			if ((res_nan.get(i) == 1) != (inf_nan_res[i] == FloatType.NAN)) {
				System.out.printf("Error at [%d]: isNaN(%f) = %f but expecting %f\n", i, inf_nan[i], res_nan.get(i), (inf_nan_res[i] == FloatType.NAN) ? 1.0 : 0.0);
				fail = true;
			}
		}

		if (fail) {
			System.out.println("Test failed");
			System.exit(1);
		}

		System.out.println("Test passed");
	}

	private static int getMaxManForExpHW(int exp) {

		final int max_mantissa_length[] = new int[] {
			0,  // 0
			0,  // 1
			0,  // 2
			0,  // 3
			5,  // 4
			13, // 5
			29, // 6
			61, // 7
			64, // 8
			64, // 9
			64, // 10
			64, // 11
			64, // 12
			64, // 13
			64, // 14
			64, // 15
			64, // 16
		};

		if (exp < 4 || exp > 16)
			throw new RuntimeException();

		return max_mantissa_length[exp];
	}
}
