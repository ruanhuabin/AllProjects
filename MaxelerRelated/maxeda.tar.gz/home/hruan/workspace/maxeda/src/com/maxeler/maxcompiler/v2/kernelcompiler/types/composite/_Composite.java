package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import java.util.Map;

import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectNotVector;


public class _Composite {
	public static DFEArrayDoubtType getDFEArrayDoubtTypeFromDFEVectorDoubtType(
		DFEVectorDoubtType kmpdt)
	{
		return kmpdt.getDFEArrayDoubtType();
	}

	public static DFEVectorDoubtType newDFEVectorDoubtType(DFEArrayDoubtType kadt) {
		return new DFEVectorDoubtType(kadt);
	}

	public static Map<String, KernelObjectNotVector<?>> getFields(DFEStruct ks) {
		return ks.getFields();
	}
}
