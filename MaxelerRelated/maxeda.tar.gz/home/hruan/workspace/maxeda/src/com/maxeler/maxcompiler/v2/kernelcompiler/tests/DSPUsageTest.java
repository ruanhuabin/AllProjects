package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.build.EngineParameters;
import com.maxeler.maxcompiler.v2.build._EngineParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.op_management.MathOps;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEFix.SignMode;
import com.maxeler.maxcompiler.v2.managers.BuildConfig;
import com.maxeler.maxcompiler.v2.managers.MAX2BoardModel;
import com.maxeler.maxcompiler.v2.managers.BuildConfig.Level;
import com.maxeler.maxcompiler.v2.managers.standard.Manager;
import com.maxeler.maxcompiler.v2.managers.standard.Manager.IOType;

public class DSPUsageTest extends Kernel {
	private static DFEType s_fix_type = dfeFix(16, 16, SignMode.TWOSCOMPLEMENT);
	private static DFEType s_float_type = dfeFloat(8, 24);

	protected DSPUsageTest(KernelParameters parameters) {
		super(parameters);

		DFEVar x_fix = io.input("x_fix", s_fix_type);
		DFEVar x_float = io.input("x_float", s_float_type);

		// addition
		optimization.pushDSPFactor(0, MathOps.ADD);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.25, MathOps.ADD);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.5, MathOps.ADD);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.75, MathOps.ADD);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(1, MathOps.ADD);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();



		// multiplication
		optimization.pushDSPFactor(0, MathOps.MUL);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.25, MathOps.MUL);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.5, MathOps.MUL);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.75, MathOps.MUL);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(1, MathOps.MUL);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();



		// addition & multiplication
		optimization.pushDSPFactor(0);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.25);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.5);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(0.75);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		optimization.pushDSPFactor(1);
		x_fix = x_fix + x_fix;
		x_fix = x_fix * x_fix;
		x_float = x_float + x_float;
		x_float = x_float * x_float;
		optimization.popDSPFactor();

		io.output("x_fix_out", x_fix, s_fix_type);
		io.output("x_float_out", x_float, s_float_type);
	}

	public static void main(String[] args) {
		Manager m = new Manager(new _EngineParameters("DSPUsageTest", MAX2BoardModel.MAX24412C, EngineParameters.Target.MAXFILE_FOR_HARDWARE));

		m.setKernel( new DSPUsageTest(m.makeKernelParameters()) );

		BuildConfig config = m.getBuildConfig();
		config.setBuildLevel(Level.MAP);

		m.setIO(IOType.NOIO);

		m.build();
	}
}
