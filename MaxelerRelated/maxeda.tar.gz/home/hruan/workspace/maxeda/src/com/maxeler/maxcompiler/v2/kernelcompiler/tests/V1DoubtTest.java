package com.maxeler.maxcompiler.v2.kernelcompiler.tests;

import com.maxeler.maxcompiler.v2.kernelcompiler.Kernel;
import com.maxeler.maxcompiler.v2.kernelcompiler.KernelParameters;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.DualPortMemOutputs;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamDoubtMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamPortParams;
import com.maxeler.maxcompiler.v2.kernelcompiler.stdlib.core.Mem.RamWriteMode;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArray;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEArrayType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplex;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEComplexType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStruct;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.composite.DFEStructType;
import com.maxeler.maxcompiler.v2.managers.standard.SimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager;
import com.maxeler.maxcompiler.v2.managers.standard._DualSimulationManager.DualSimMode;
import com.maxeler.maxcompiler.v2.utils.Bits;

public class V1DoubtTest extends Kernel {

	private static final DFEType doubt_type = dfeBool();

	// Pack test
	private static final DFEType pack_i1_type = dfeInt(32);
	private static final DFEType pack_i1_doubt_type = doubt_type;

	private static final DFEArrayType<DFEVar> pack_i2_type =
		new DFEArrayType<DFEVar>(dfeFloat(8, 24), 5);
	private static final DFEArrayType<DFEVar> pack_i2_doubt_type =
		new DFEArrayType<DFEVar>(doubt_type, pack_i2_type.getSize());

	private static final DFEComplexType pack_i3_type =
		new DFEComplexType(dfeFloat(8, 24));
	private static final DFEComplexType pack_i3_doubt_type =
		new DFEComplexType(doubt_type);

	private static final DFEStructType pack_i4_type =
		new DFEStructType(
			DFEStructType.sft("a", dfeFloat(8, 24)),
			DFEStructType.sft("b", dfeFloat(8, 24)));
	private static final DFEStructType pack_i4_doubt_type =
		new DFEStructType(
			DFEStructType.sft("a", doubt_type),
			DFEStructType.sft("b", doubt_type));

	private static final DFEArrayType<DFEComplex> pack_i5_type =
		new DFEArrayType<DFEComplex>(pack_i3_type, 5);

	private static final DFEArrayType<DFEComplex> pack_i5_doubt_type =
		new DFEArrayType<DFEComplex>(pack_i3_doubt_type, pack_i5_type.getSize());

	// I/O test
	// If you change theses types make sure you change testIO() as well...
	private static final DFEType io_i1_type = dfeInt(4);
	private static final DFEType io_i1_doubt_type = doubt_type;

	private static final DFEType io_i2_type = dfeInt(32);
	private static final DFEType io_i2_doubt_type = doubt_type;

	private static final DFEType io_i3_type = dfeInt(4);
	private static final DFEType io_i3_doubt_type = doubt_type;

	private static final DFEType io_i4_type = dfeUInt(1);
	private static final DFEType io_i5_type = dfeInt(32);
	private static final DFEType io_i6_type = dfeInt(32);
	private static final DFEType io_i7_type = dfeInt(32);

	// RAM test
	private static final DFEStructType ram_i1_type =
		new DFEStructType(
			DFEStructType.sft("a", dfeFloat(8, 24)),
			DFEStructType.sft("b", dfeFloat(8, 24)));

	private static final DFEStructType ram_i1_doubt_type =
		new DFEStructType(
			DFEStructType.sft("a", doubt_type),
			DFEStructType.sft("b", doubt_type));

	private static final DFEType ram_i2_type = dfeUInt(3); // Address a
	private static final DFEType ram_i2_doubt_type = doubt_type;

	private static final DFEType ram_i3_type = dfeUInt(1); // WE a
	private static final DFEType ram_i3_doubt_type = doubt_type;

	private static final DFEStructType ram_i4_type =
		new DFEStructType(
			DFEStructType.sft("a", dfeFloat(8, 24)),
			DFEStructType.sft("b", dfeFloat(8, 24)));

	private static final DFEStructType ram_i4_doubt_type =
		new DFEStructType(
			DFEStructType.sft("a", doubt_type),
			DFEStructType.sft("b", doubt_type));

	private static final DFEType ram_i5_type = dfeUInt(3); // Address b
	private static final DFEType ram_i5_doubt_type = doubt_type;

	private static final DFEType ram_i6_type = dfeUInt(1); // WE b
	private static final DFEType ram_i6_doubt_type = doubt_type;


	private static class TestFailedException extends RuntimeException {
		private static final long serialVersionUID = 1L;
	}


	public V1DoubtTest(KernelParameters parameters) {
		super(parameters);
	}


	@SuppressWarnings("unchecked")
	private void createClearCastTest() {

		//  DFEVar
		DFEVar i1 = io.input("i1", pack_i1_type);
		i1 = i1.addDoubtInfo().setDoubt(true);
		DFEVar o1a = i1.addDoubtInfo().setDoubt(false);
		DFEVar o1b = i1.castDoubtType(pack_i1_type.getFullTypeWithoutDoubtInfo().getDoubtType());
		DFEVar o1c = o1b.castDoubtType(pack_i1_type.getFullTypeWithDoubtInfo().getDoubtType());
		io.output("o1a", o1a.hasDoubt(), pack_i1_doubt_type);
		io.output("o1b", o1b.hasDoubt(), pack_i1_doubt_type);
		io.output("o1c", o1c.hasDoubt(), pack_i1_doubt_type);

		// Test DFEArray
		DFEArray<DFEVar> i2 = io.input("i2", pack_i2_type);

		DFEArray<DFEVar> i2d = (DFEArray<DFEVar>) pack_i2_type.getFullTypeWithDoubtInfo().newInstance(this);
		for (int i = 0; i < pack_i2_type.getSize(); ++i)
			i2d.connect(i, i2.get(i).addDoubtInfo().setDoubt(true));

		DFEArray<DFEVar> o2a = i2d.setDoubt(false);
		DFEArray<DFEVar> o2b = i2d.castDoubtType(pack_i2_type.getFullTypeWithoutDoubtInfo().getDoubtType());
		DFEArray<DFEVar> o2c = o2b.castDoubtType(pack_i2_type.getFullTypeWithDoubtInfo().getDoubtType());

		DFEArray<DFEVar> o2a_doubt = pack_i2_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i2_type.getSize(); ++i)
			o2a_doubt.connect(i, o2a.get(i).hasDoubt());

		DFEArray<DFEVar> o2b_doubt = pack_i2_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i2_type.getSize(); ++i)
			o2b_doubt.connect(i, o2b.get(i).hasDoubt());

		DFEArray<DFEVar> o2c_doubt = pack_i2_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i2_type.getSize(); ++i)
			o2c_doubt.connect(i, o2c.get(i).hasDoubt());

		io.output("o2a", o2a_doubt, pack_i2_doubt_type);
		io.output("o2b", o2b_doubt, pack_i2_doubt_type);
		io.output("o2c", o2c_doubt, pack_i2_doubt_type);


		// Test DFEComplex
		DFEComplex i3 = io.input("i3", pack_i3_type);

		DFEComplex i3d = pack_i3_type.getFullTypeWithDoubtInfo().newInstance(this);
		i3d.setImaginary(i3.getImaginary().addDoubtInfo().setDoubt(true));
		i3d.setReal(i3.getReal().addDoubtInfo().setDoubt(true));

		DFEComplex o3a = i3d.setDoubt(false);
		DFEComplex o3b = i3d.castDoubtType(pack_i3_type.getFullTypeWithoutDoubtInfo().getDoubtType());
		DFEComplex o3c = o3b.castDoubtType(pack_i3_type.getFullTypeWithDoubtInfo().getDoubtType());

		DFEComplex o3a_doubt =  pack_i3_doubt_type.newInstance(this);
		o3a_doubt.setImaginary(o3a.getImaginary().hasDoubt());
		o3a_doubt.setReal(o3a.getReal().hasDoubt());

		DFEComplex o3b_doubt =  pack_i3_doubt_type.newInstance(this);
		o3b_doubt.setImaginary(o3b.getImaginary().hasDoubt());
		o3b_doubt.setReal(o3b.getReal().hasDoubt());

		DFEComplex o3c_doubt =  pack_i3_doubt_type.newInstance(this);
		o3c_doubt.setImaginary(o3c.getImaginary().hasDoubt());
		o3c_doubt.setReal(o3c.getReal().hasDoubt());

		io.output("o3a", o3a_doubt, pack_i3_doubt_type);
		io.output("o3b", o3b_doubt, pack_i3_doubt_type);
		io.output("o3c", o3c_doubt, pack_i3_doubt_type);


		// Test DFEStruct
		DFEStruct i4 = io.input("i4", pack_i4_type);

		DFEStruct i4d = pack_i4_type.getFullTypeWithDoubtInfo().newInstance(this);
		i4d.set("a", ((DFEVar)i4.get("a")).addDoubtInfo().setDoubt(true));
		i4d.set("b", ((DFEVar)i4.get("b")).addDoubtInfo().setDoubt(true));

		DFEStruct o4a = i4d.setDoubt(false);
		DFEStruct o4b = i4d.castDoubtType(pack_i4_type.getFullTypeWithoutDoubtInfo().getDoubtType());
		DFEStruct o4c = o4b.castDoubtType(pack_i4_type.getFullTypeWithDoubtInfo().getDoubtType());

		DFEStruct o4a_doubt =  pack_i4_doubt_type.newInstance(this);
		o4a_doubt.set("a", ((DFEVar)o4a.get("a")).hasDoubt());
		o4a_doubt.set("b", ((DFEVar)o4a.get("b")).hasDoubt());

		DFEStruct o4b_doubt =  pack_i4_doubt_type.newInstance(this);
		o4b_doubt.set("a", ((DFEVar)o4b.get("a")).hasDoubt());
		o4b_doubt.set("b", ((DFEVar)o4b.get("b")).hasDoubt());

		DFEStruct o4c_doubt =  pack_i4_doubt_type.newInstance(this);
		o4c_doubt.set("a", ((DFEVar)o4c.get("a")).hasDoubt());
		o4c_doubt.set("b", ((DFEVar)o4c.get("b")).hasDoubt());

		io.output("o4a", o4a_doubt, pack_i4_doubt_type);
		io.output("o4b", o4b_doubt, pack_i4_doubt_type);
		io.output("o4c", o4c_doubt, pack_i4_doubt_type);

		// Nested
		DFEArray<DFEComplex> i5 = io.input("i5", pack_i5_type);

		DFEArray<DFEComplex> i5d = (DFEArray<DFEComplex>) pack_i5_type.getFullTypeWithDoubtInfo().newInstance(this);
		for (int i = 0; i < pack_i5_type.getSize(); ++i) {
			DFEComplex k = pack_i5_type.getContainedType().getFullTypeWithDoubtInfo().newInstance(this);
			k.setImaginary(i5.get(i).getImaginary().addDoubtInfo().setDoubt(true));
			k.setReal(i5.get(i).getReal().addDoubtInfo().setDoubt(true));
			i5d.connect(i, k);
		}

		DFEArray<DFEComplex> o5a = i5d.setDoubt(false);
		DFEArray<DFEComplex> o5b = i5d.castDoubtType(pack_i5_type.getFullTypeWithoutDoubtInfo().getDoubtType());
		DFEArray<DFEComplex> o5c = o5b.castDoubtType(pack_i5_type.getFullTypeWithDoubtInfo().getDoubtType());

		DFEArray<DFEComplex> o5a_doubt = pack_i5_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i5_type.getSize(); ++i) {
			DFEComplex k = pack_i5_doubt_type.getContainedType().newInstance(this);
			k.setImaginary(o5a.get(i).getImaginary().hasDoubt());
			k.setReal(o5a.get(i).getReal().hasDoubt());
			o5a_doubt.connect(i, k);
		}

		DFEArray<DFEComplex> o5b_doubt = pack_i5_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i5_type.getSize(); ++i) {
			DFEComplex k = pack_i5_doubt_type.getContainedType().newInstance(this);
			k.setImaginary(o5b.get(i).getImaginary().hasDoubt());
			k.setReal(o5b.get(i).getReal().hasDoubt());
			o5b_doubt.connect(i, k);
		}

		DFEArray<DFEComplex> o5c_doubt = pack_i5_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i5_type.getSize(); ++i) {
			DFEComplex k = pack_i5_doubt_type.getContainedType().newInstance(this);
			k.setImaginary(o5c.get(i).getImaginary().hasDoubt());
			k.setReal(o5c.get(i).getReal().hasDoubt());
			o5c_doubt.connect(i, k);
		}

		io.output("o5a", o5a_doubt, pack_i5_doubt_type);
		io.output("o5b", o5b_doubt, pack_i5_doubt_type);
		io.output("o5c", o5c_doubt, pack_i5_doubt_type);
	}

	private static void testClearCast(_DualSimulationManager m) {

		V1DoubtTest a = new V1DoubtTest(m.makeKernelParameters_A());
		a.createClearCastTest();
		V1DoubtTest b = new V1DoubtTest(m.makeKernelParameters_B());
		b.createClearCastTest();

		m.setKernels(a, b);
		m.setKernelCycles(6);

		double[] i1 			= {  1,   2,   3,   4,   5,   6};
		double[] i1_doubt 		= {  0,   0,   0,   0,   0,   0};

		double[] i2				= {  1,   2,   3,   4,   5,
									11,  22,  33,  44,  55,
									 1,   2,   3,   4,   5,
									11,  22,  33,  44,  55,
									 1,   2,   3,   4,   5,
								   111, 222, 333, 444,  555 };

		double[] i2_doubt		= {  0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0 };

		double[] i3 			= {  1,  11,   2,  22,   3,  33,
									 4,  44,   5,  55,   6,  66};

		double[] i3_doubt 		= {  0,   0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,   0};

		double[] i4 			= {  1,  11,   2,  22,   3,  33,
			 						 4,  44,   5,  55,   6,  66};

		double[] i4_doubt 		= {  0,   0,   0,   0,   0,   0,
									 0,   0,   0,   0,   0,   0};

		double[] i5 			= {  1,  11,   1,  11,   1,  11,   1,  11,   1,  11,
									 2,  22,   2,  22,   2,  22,   2,  22,   2,  22,
									 3,  33,   3,  33,   3,  33,   3,  33,   3,  33,
									 4,  44,   4,  44,   4,  44,   4,  44,   4,  44,
									 5,  55,   5,  55,   5,  55,   5,  55,   5,  55,
									 6,  66,   6,  66,   6,  66,   6,  66,   6,  66 };

		double[] i5_doubt 		= {  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			 						 0,   0,   0,   0,   0,   0,   0,   0,   0,   0 };


		m.setInputData("i1", i1);
		m.setInputDataRaw("i2", SimulationManager.packToBits((DFEType) pack_i2_type.getContainedType(), 5, i2));
		m.setInputDataRaw("i3", SimulationManager.packToBits((DFEType) pack_i3_type.getImaginaryType(), 2, i3));
		m.setInputDataRaw("i4", SimulationManager.packToBits((DFEType) pack_i4_type.getTypeForField("a"), 2, i4));
		m.setInputDataRaw("i5", SimulationManager.packToBits((DFEType) ((DFEComplexType) pack_i5_type.getContainedType()).getImaginaryType(), 10, i5));

		m.runTest();
		m.dumpOutput();

		checkResults(m, "o1a", pack_i1_doubt_type, null, i1_doubt, null, null);
		checkResults(m, "o1b", pack_i1_doubt_type, null, i1_doubt, null, null);
		checkResults(m, "o1c", pack_i1_doubt_type, null, i1_doubt, null, null);
		checkResults(m, "o2a", (DFEType) pack_i2_doubt_type.getContainedType(), null, i2_doubt, null, null);
		checkResults(m, "o2b", (DFEType) pack_i2_doubt_type.getContainedType(), null, i2_doubt, null, null);
		checkResults(m, "o2c", (DFEType) pack_i2_doubt_type.getContainedType(), null, i2_doubt, null, null);
		checkResults(m, "o3a", (DFEType) pack_i3_doubt_type.getImaginaryType(), null, i3_doubt, null, null);
		checkResults(m, "o3b", (DFEType) pack_i3_doubt_type.getImaginaryType(), null, i3_doubt, null, null);
		checkResults(m, "o3c", (DFEType) pack_i3_doubt_type.getImaginaryType(), null, i3_doubt, null, null);
		checkResults(m, "o4a", (DFEType) pack_i4_doubt_type.getTypeForField("a"), null, i4_doubt, null, null);
		checkResults(m, "o4b", (DFEType) pack_i4_doubt_type.getTypeForField("a"), null, i4_doubt, null, null);
		checkResults(m, "o4c", (DFEType) pack_i4_doubt_type.getTypeForField("a"), null, i4_doubt, null, null);
		checkResults(m, "o5a", (DFEType) ((DFEComplexType) pack_i5_doubt_type.getContainedType()).getImaginaryType(), null, i5_doubt, null, null);
		checkResults(m, "o5b", (DFEType) ((DFEComplexType) pack_i5_doubt_type.getContainedType()).getImaginaryType(), null, i5_doubt, null, null);
		checkResults(m, "o5c", (DFEType) ((DFEComplexType) pack_i5_doubt_type.getContainedType()).getImaginaryType(), null, i5_doubt, null, null);
	}

	private void createIOTest() {

		// Stream in/out doubted data (4 bits data, 1 doubt bit)
		DFEVar i1 = io.input("i1", io_i1_type.getFullTypeWithDoubtInfo());
		io.output("o1", i1, io_i1_type.getFullTypeWithDoubtInfo());
		io.output("o1_doubt", i1.hasDoubt(), io_i1_doubt_type);

		// Generate doubt on input
		DFEVar i2 = io.input("i2", io_i2_type).addDoubtInfo();
		io.output("o2", i2.removeDoubtInfo(), io_i2_type);
		io.output("o2_doubt", i2.hasDoubt(), io_i2_doubt_type);

		// Test scalar IOs
		DFEVar i3 = io.scalarInput("i3", io_i3_type.getFullTypeWithDoubtInfo());
		io.scalarOutput("o3", i3, io_i3_type.getFullTypeWithDoubtInfo());
		io.scalarOutput("o3_doubt", i3.hasDoubt(), io_i3_doubt_type);

		// Test doubt on I/O control
		DFEVar i4 = io.input("i4", io_i4_type.getFullTypeWithDoubtInfo());
		DFEVar i5 = io.input("i5", io_i5_type.getFullTypeWithDoubtInfo(), i4);
		io.output("o5", i5, io_i5_type.getFullTypeWithDoubtInfo());

		DFEVar i6 = io.input("i6", io_i6_type.getFullTypeWithoutDoubtInfo());
		io.output(
			"o6",
			i6.addDoubtInfo(),
			io_i6_type.getFullTypeWithDoubtInfo(),
			i4);

		DFEVar i7 = io.scalarInput("i7", io_i7_type);
		io.scalarOutput("o7", i7.addDoubtInfo(), io_i7_type.getFullTypeWithDoubtInfo(), i4);
	}

	private static void testIO(_DualSimulationManager m) {
		V1DoubtTest a = new V1DoubtTest(m.makeKernelParameters_A());
		a.createIOTest();
		V1DoubtTest b = new V1DoubtTest(m.makeKernelParameters_B());
		b.createIOTest();
		m.setKernels(a, b);
		m.setKernelCycles(6);

		DFEType t1 = dfeInt(io_i1_type.getFullTypeWithDoubtInfo().getTotalBits());
		Bits[] i1 = {
			t1.encodeConstant(-16), // 0?
			t1.encodeConstant(  2), // 2
			t1.encodeConstant(-13), // 3?
			t1.encodeConstant(-12), // 4?
			t1.encodeConstant(  5), // 5
			t1.encodeConstant(  6)  // 6
		};

		double[] i1_doubt 		= {  1,   0,   1,   1,   0,   0};

		double[] i2 			= {  1,   2,   3,   4,   5,   6};
		double[] i2_doubt 		= {  0,   0,   0,   0,   0,   0};

		DFEType t4 = dfeInt(io_i4_type.getFullTypeWithDoubtInfo().getTotalBits());
		Bits[] i4 = {
			t4.encodeConstant( 1), // 1
			t4.encodeConstant( 1), // 1
			t4.encodeConstant(-1), // 1?
			t4.encodeConstant( 0), // 0
			t4.encodeConstant(-2), // 0?
			t4.encodeConstant(-1)  // 1?
		};

		double dval = -Math.pow(2, 32);

		double[] i5 			= {  1,   2,   3,   4,   5,   6};
		double[] o5             = {  1,   2,   dval + 3,   dval + 3,   dval + 3,   dval + 4};

		double[] i6 			= {  6,   5,   4,   3,   2,   1};
		double[] o6             = {  6,   5,   dval + 4,   /*4,  dval + 4,*/   dval + 1};

		m.setInputDataRaw("i1", i1);
		m.setInputData("i2", i2);
		DFEType t3 = dfeInt(io_i3_type.getFullTypeWithDoubtInfo().getTotalBits());
		m.setScalarInput("i3", t3.encodeConstant(-11)); // 5?
		m.setInputDataRaw("i4", i4);
		m.setInputData("i5", i5);
		m.setInputData("i6", i6);
		m.setScalarInput("i7", 13);

		m.runTest();
		m.dumpOutput();

		m.checkOutputDataRaw("o1", i1);
		checkResults(m, "o1_doubt", io_i1_doubt_type, null, i1_doubt, null, null);
		checkResults(m, "o2", io_i2_type, io_i2_doubt_type, i2, i2_doubt, null);

		Bits o3 = m.getScalarOutputRaw("o3");
		Bits o3_doubt = m.getScalarOutputRaw("o3_doubt");
		long o3_doubt_d = o3_doubt.getBits(0, 1);
		long o3_d = o3.getBits(io_i3_type.getTotalBits(), 1);
		double o3_data = io_i3_type.decodeConstant(o3.getBitsRaw(0, io_i3_type.getTotalBits()));
		if (o3_d != 1) {
			System.out.printf("Doubt mismatch for o3.\nGot %d, expected %d\n", o3_d, 1);
			throw new TestFailedException();
		}
		if (o3_doubt_d != 1) {
			System.out.printf("Data mismatch for o3_doubt.\nGot %d, expected %d\n", o3_d, 1);
			throw new TestFailedException();
		}
		if (o3_data != 5.0) {
			System.out.printf("Data mismatch for o3.\nGot %f, expected %f\n", o3_data, 5.0f);
			throw new TestFailedException();
		}

		checkResults(m, "o5", dfeInt(io_i5_type.getFullTypeWithDoubtInfo().getTotalBits()), null, o5, null, null);
		checkResults(m, "o6", dfeInt(io_i6_type.getFullTypeWithDoubtInfo().getTotalBits()), null, o6, null, null);

		Bits o7 = m.getScalarOutputRaw("o7");
		long o7_doubt = o7.getBits(io_i7_type.getTotalBits(), 1);
		double o7_data = io_i7_type.decodeConstant(o7.getBitsRaw(0, io_i7_type.getTotalBits()));

		if (o7_doubt != 1) {
			System.out.printf("Doubt mismatch for o7.\nGot %d, expected %d\n", o7_doubt, 1);
			throw new TestFailedException();
		}
		if (o7_data != 13.0) {
			System.out.printf("Data mismatch for o7.\nGot %f, expected %f\n", o3_data, 13.0f);
			throw new TestFailedException();
		}
	}


	@SuppressWarnings("unchecked")
	private void createPackTest() {

		//  DFEVar
		DFEVar i1 = io.input("i1", pack_i1_type);
		DFEVar i1_doubt = io.input("i1_doubt", pack_i1_doubt_type);
		i1 = i1.addDoubtInfo().setDoubt(i1_doubt);

		DFEVar i1_p = i1.packWithoutDoubt();
		DFEVar i1_pd = i1.packWithDoubt();
		DFEVar o1_p = i1.getType().getFullTypeWithoutDoubtInfo().unpack(i1_p);
		DFEVar o1_pd = i1.getType().unpackWithDoubt(i1_pd, i1.getDoubtType());

		io.output("o1_p", o1_p, pack_i1_type);
		io.output("o1_pd", o1_pd.removeDoubtInfo(), pack_i1_type);
		io.output("o1_pd_doubt", o1_pd.hasDoubt(), doubt_type);


		// Test DFEArray
		DFEArray<DFEVar> i2 = io.input("i2", pack_i2_type);
		DFEArray<DFEVar> i2_doubt = io.input("i2_doubt", pack_i2_doubt_type);

		DFEArray<DFEVar> i2d = (DFEArray<DFEVar>) pack_i2_type.getFullTypeWithDoubtInfo().newInstance(this);
		for (int i = 0; i < pack_i2_type.getSize(); ++i)
			i2d.connect(i, i2.get(i).addDoubtInfo().setDoubt(i2_doubt.get(i)));

		DFEVar i2_p = i2d.packWithoutDoubt();
		DFEVar i2_pd = i2d.packWithDoubt();
		DFEArray<DFEVar> o2_p = (DFEArray<DFEVar>) pack_i2_type.getFullTypeWithoutDoubtInfo().unpack(i2_p);
		DFEArray<DFEVar> o2_pd = pack_i2_type.unpackWithDoubt(i2_pd, i2d.getDoubtType());

		DFEArray<DFEVar> o2_pd_doubt = pack_i2_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i2_type.getSize(); ++i)
			o2_pd_doubt.connect(i, o2_pd.get(i).hasDoubt());

		io.output("o2_p", o2_p, pack_i2_type);
		io.output("o2_pd", o2_pd.removeDoubtInfo(), pack_i2_type);
		io.output("o2_pd_doubt", o2_pd_doubt, pack_i2_doubt_type);
		io.output("o2_pd_doubt2", o2_pd.hasDoubt(), doubt_type);


		// Test DFEComplex
		DFEComplex i3 = io.input("i3", pack_i3_type);
		DFEComplex i3_doubt = io.input("i3_doubt", pack_i3_doubt_type);

		DFEComplex i3d = pack_i3_type.getFullTypeWithDoubtInfo().newInstance(this);
		i3d.setImaginary(i3.getImaginary().addDoubtInfo().setDoubt(i3_doubt.getImaginary()));
		i3d.setReal(i3.getReal().addDoubtInfo().setDoubt(i3_doubt.getReal()));

		DFEVar i3_p = i3d.packWithoutDoubt();
		DFEVar i3_pd = i3d.packWithDoubt();
		DFEComplex o3_p = pack_i3_type.getFullTypeWithoutDoubtInfo().unpack(i3_p);
		DFEComplex o3_pd = pack_i3_type.unpackWithDoubt(i3_pd, i3d.getDoubtType());

		DFEComplex o3_pd_doubt =  pack_i3_doubt_type.newInstance(this);
		o3_pd_doubt.setImaginary(o3_pd.getImaginary().hasDoubt());
		o3_pd_doubt.setReal(o3_pd.getReal().hasDoubt());

		io.output("o3_p", o3_p, pack_i3_type);
		io.output("o3_pd", o3_pd.removeDoubtInfo(), pack_i3_type);
		io.output("o3_pd_doubt", o3_pd_doubt, pack_i3_doubt_type);
		io.output("o3_pd_doubt2", o3_pd.hasDoubt(), doubt_type);


		// Test DFEStruct
		DFEStruct i4 = io.input("i4", pack_i4_type);
		DFEStruct i4_doubt = io.input("i4_doubt", pack_i4_doubt_type);

		DFEStruct i4d = pack_i4_type.getFullTypeWithDoubtInfo().newInstance(this);
		i4d.set("a", ((DFEVar)i4.get("a")).addDoubtInfo().setDoubt((DFEVar) i4_doubt.get("a")));
		i4d.set("b", ((DFEVar)i4.get("b")).addDoubtInfo().setDoubt((DFEVar) i4_doubt.get("b")));

		DFEVar i4_p = i4d.packWithoutDoubt();
		DFEVar i4_pd = i4d.packWithDoubt();
		DFEStruct o4_p = pack_i4_type.getFullTypeWithoutDoubtInfo().unpack(i4_p);
		DFEStruct o4_pd = pack_i4_type.unpackWithDoubt(i4_pd, i4d.getDoubtType());

		DFEStruct o4_pd_doubt =  pack_i4_doubt_type.newInstance(this);
		o4_pd_doubt.set("a", ((DFEVar)o4_pd.get("a")).hasDoubt());
		o4_pd_doubt.set("b", ((DFEVar)o4_pd.get("b")).hasDoubt());

		io.output("o4_p", o4_p, pack_i4_type);
		io.output("o4_pd", o4_pd.removeDoubtInfo(), pack_i4_type);
		io.output("o4_pd_doubt", o4_pd_doubt, pack_i4_doubt_type);
		io.output("o4_pd_doubt2", o4_pd.hasDoubt(), doubt_type);


		// Nested
		DFEArray<DFEComplex> i5 = io.input("i5", pack_i5_type);
		DFEArray<DFEComplex> i5_doubt = io.input("i5_doubt", pack_i5_doubt_type);

		DFEArray<DFEComplex> i5d = (DFEArray<DFEComplex>) pack_i5_type.getFullTypeWithDoubtInfo().newInstance(this);
		for (int i = 0; i < pack_i5_type.getSize(); ++i) {
			DFEComplex k = pack_i5_type.getContainedType().getFullTypeWithDoubtInfo().newInstance(this);
			k.setImaginary(i5.get(i).getImaginary().addDoubtInfo().setDoubt(i5_doubt.get(i).getImaginary()));
			k.setReal(i5.get(i).getReal().addDoubtInfo().setDoubt(i5_doubt.get(i).getReal()));
			i5d.connect(i, k);
		}

		DFEVar i5_p = i5d.packWithoutDoubt();
		DFEVar i5_pd = i5d.packWithDoubt();
		DFEArray<DFEComplex> o5_p = (DFEArray<DFEComplex>) pack_i5_type.getFullTypeWithoutDoubtInfo().unpack(i5_p);
		DFEArray<DFEComplex> o5_pd = pack_i5_type.unpackWithDoubt(i5_pd, i5d.getDoubtType());

		DFEArray<DFEComplex> o5_pd_doubt = pack_i5_doubt_type.newInstance(this);
		for (int i = 0; i < pack_i5_type.getSize(); ++i) {
			DFEComplex k = pack_i5_doubt_type.getContainedType().newInstance(this);
			k.setImaginary(o5_pd.get(i).getImaginary().hasDoubt());
			k.setReal(o5_pd.get(i).getReal().hasDoubt());
			o5_pd_doubt.connect(i, k);
		}

		io.output("o5_p", o5_p, pack_i5_type);
		io.output("o5_pd", o5_pd.removeDoubtInfo(), pack_i5_type);
		io.output("o5_pd_doubt", o5_pd_doubt, pack_i5_doubt_type);
		io.output("o5_pd_doubt2", o5_pd.hasDoubt(), doubt_type);
	}


	private static void testPack(_DualSimulationManager m) {

		V1DoubtTest a = new V1DoubtTest(m.makeKernelParameters_A());
		a.createPackTest();
		V1DoubtTest b = new V1DoubtTest(m.makeKernelParameters_B());
		b.createPackTest();

		m.setKernels(a, b);
		m.setKernelCycles(6);

		double[] i1 			= {  1,   2,   3,   4,   5,   6};
		double[] i1_doubt 		= {  1,   0,   0,   1,   0,   1};

		double[] i2				= {  1,   2,   3,   4,   5,
									11,  22,  33,  44,  55,
									 1,   2,   3,   4,   5,
									11,  22,  33,  44,  55,
									 1,   2,   3,   4,   5,
								   111, 222, 333, 444,  555 };

		double[] i2_doubt		= {  0,   1,   1,   1,   0,
			 						 1,   0,   1,   0,   1,
			 						 1,   1,   1,   1,   1,
			 						 0,   0,   0,   0,   0,
			 						 1,   0,   0,   1,   1,
			 						 0,   1,   1,   0,   0 };

		double[] i2_doubt2		= {  1,   1,   1,   0,   1,   1};

		double[] i3 			= {  1,  11,   2,  22,   3,  33,
									 4,  44,   5,  55,   6,  66};

		double[] i3_doubt 		= {  1,   0,   0,   0,   0,   1,
			 						 1,   0,   1,   1,   0,   0};

		double[] i3_doubt2		= {  1,   0,   1,   1,   1,   0};

		double[] i4 			= {  1,  11,   2,  22,   3,  33,
			 						 4,  44,   5,  55,   6,  66};

		double[] i4_doubt 		= {  1,   0,   0,   0,   0,   1,
									 1,   0,   1,   1,   0,   0};

		double[] i4_doubt2		= {  1,   0,   1,   1,   1,   0};

		double[] i5 			= {  1,  11,   1,  11,   1,  11,   1,  11,   1,  11,
									 2,  22,   2,  22,   2,  22,   2,  22,   2,  22,
									 3,  33,   3,  33,   3,  33,   3,  33,   3,  33,
									 4,  44,   4,  44,   4,  44,   4,  44,   4,  44,
									 5,  55,   5,  55,   5,  55,   5,  55,   5,  55,
									 6,  66,   6,  66,   6,  66,   6,  66,   6,  66 };

		double[] i5_doubt 		= {  1,   0,   1,   1,   1,   0,   1,   1,   0,   1,
			 						 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
			 						 1,   1,   1,   1,   1,   1,   1,   1,   1,   1,
			 						 0,   1,   1,   1,   1,   1,   1,   1,   1,   0,
			 						 1,   1,   1,   1,   1,   1,   1,   1,   1,   1,
			 						 0,   0,   1,   1,   0,   0,   1,   1,   0,   0 };

		double[] i5_doubt2		= {  1,   0,   1,   1,   1,   1};



		m.setInputData("i1", i1);
		m.setInputData("i1_doubt", i1_doubt);
		m.setInputDataRaw("i2", SimulationManager.packToBits((DFEType) pack_i2_type.getContainedType(), 5, i2));
		m.setInputDataRaw("i2_doubt", SimulationManager.packToBits((DFEType) pack_i2_doubt_type.getContainedType(), 5, i2_doubt));
		m.setInputDataRaw("i3", SimulationManager.packToBits((DFEType) pack_i3_type.getImaginaryType(), 2, i3));
		m.setInputDataRaw("i3_doubt", SimulationManager.packToBits((DFEType) pack_i3_doubt_type.getImaginaryType(), 2, i3_doubt));
		m.setInputDataRaw("i4", SimulationManager.packToBits((DFEType) pack_i4_type.getTypeForField("a"), 2, i4));
		m.setInputDataRaw("i4_doubt", SimulationManager.packToBits((DFEType) pack_i4_doubt_type.getTypeForField("a"), 2, i4_doubt));
		m.setInputDataRaw("i5", SimulationManager.packToBits((DFEType) ((DFEComplexType) pack_i5_type.getContainedType()).getImaginaryType(), 10, i5));
		m.setInputDataRaw("i5_doubt", SimulationManager.packToBits((DFEType) ((DFEComplexType) pack_i5_doubt_type.getContainedType()).getImaginaryType(), 10, i5_doubt));

		m.runTest();
		m.dumpOutput();

		checkResults(m, "o1_p", pack_i1_type, pack_i1_doubt_type, i1, null, null);
		checkResults(m, "o1_pd", pack_i1_type, pack_i1_doubt_type, i1, i1_doubt, null);
		checkResults(m, "o2_p", (DFEType) pack_i2_type.getContainedType(), null, i2, null, null);
		checkResults(m, "o2_pd",(DFEType) pack_i2_type.getContainedType(), (DFEType) pack_i2_doubt_type.getContainedType(), i2, i2_doubt, null);
		checkResults(m, "o2_pd_doubt2", pack_i1_doubt_type, null, i2_doubt2, null, null);
		checkResults(m, "o3_p", (DFEType) pack_i3_type.getImaginaryType(), null, i3, null, null);
		checkResults(m, "o3_pd",(DFEType) pack_i3_type.getImaginaryType(), (DFEType) pack_i3_doubt_type.getImaginaryType(), i3, i3_doubt, null);
		checkResults(m, "o3_pd_doubt2", pack_i1_doubt_type, null, i3_doubt2, null, null);
		checkResults(m, "o4_p", (DFEType) pack_i4_type.getTypeForField("a"), null, i4, null, null);
		checkResults(m, "o4_pd",(DFEType) pack_i4_type.getTypeForField("a"), (DFEType) pack_i4_doubt_type.getTypeForField("a"), i4, i4_doubt, null);
		checkResults(m, "o4_pd_doubt2", pack_i1_doubt_type, null, i4_doubt2, null, null);
		checkResults(m, "o5_p", (DFEType) ((DFEComplexType) pack_i5_type.getContainedType()).getImaginaryType(), null, i5, null, null);
		checkResults(m, "o5_pd",(DFEType) ((DFEComplexType) pack_i5_type.getContainedType()).getImaginaryType(), (DFEType) ((DFEComplexType) pack_i5_doubt_type.getContainedType()).getImaginaryType(), i5, i5_doubt, null);
		checkResults(m, "o5_pd_doubt2", pack_i1_doubt_type, null, i5_doubt2, null, null);
	}


	private void createRAMTest() {

		// DIn A
		DFEStruct i1 = io.input("i1", ram_i1_type);
		DFEStruct i1_doubt = io.input("i1_doubt", ram_i1_doubt_type);

		DFEStruct i1_d = ram_i1_type.getFullTypeWithDoubtInfo().newInstance(this);
		i1_d.set("a", ((DFEVar)i1.get("a")).addDoubtInfo().setDoubt((DFEVar) i1_doubt.get("a")));
		i1_d.set("b", ((DFEVar)i1.get("b")).addDoubtInfo().setDoubt((DFEVar) i1_doubt.get("b")));

		// Addr A
		DFEVar i2 = io.input("i2", ram_i2_type);
		DFEVar i2_doubt = io.input("i2_doubt", ram_i2_doubt_type);
		DFEVar i2_d = i2.addDoubtInfo().setDoubt(i2_doubt);

		// WE A
		DFEVar i3 = io.input("i3", ram_i3_type);
		DFEVar i3_doubt = io.input("i3_doubt", ram_i3_doubt_type);
		DFEVar i3_d = i3.addDoubtInfo().setDoubt(i3_doubt);

		// DIn B
		DFEStruct i4 = io.input("i4", ram_i4_type);
		DFEStruct i4_doubt = io.input("i4_doubt", ram_i4_doubt_type);

		DFEStruct i4_d = ram_i4_type.getFullTypeWithDoubtInfo().newInstance(this);
		i4_d.set("a", ((DFEVar)i4.get("a")).addDoubtInfo().setDoubt((DFEVar) i4_doubt.get("a")));
		i4_d.set("b", ((DFEVar)i4.get("b")).addDoubtInfo().setDoubt((DFEVar) i4_doubt.get("b")));

		// Addr B
		DFEVar i5 = io.input("i5", ram_i5_type);
		DFEVar i5_doubt = io.input("i5_doubt", ram_i5_doubt_type);
		DFEVar i5_d = i5.addDoubtInfo().setDoubt(i5_doubt);

		// WE B
		DFEVar i6 = io.input("i6", ram_i6_type);
		DFEVar i6_doubt = io.input("i6_doubt", ram_i6_doubt_type);
		DFEVar i6_d = i6.addDoubtInfo().setDoubt(i6_doubt);

		// Doubt everywhere
		int size = 6;
		RamWriteMode mode = RamWriteMode.READ_FIRST;

		RamPortParams<DFEStruct> port_a;
		RamPortParams<DFEStruct> port_b;
		DualPortMemOutputs<DFEStruct> ram;

		port_a = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i2_d,
			ram_i1_type)
			.withDataIn(i1_d)
			.withWriteEnable(i3_d);

		port_b = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i5_d,
			ram_i4_type)
			.withDataIn(i4_d)
			.withWriteEnable(i6_d);

		ram = mem.ramDualPort(size, mode, RamDoubtMode.STORE_DOUBT, port_a, port_b);

		DFEStruct o1a_doubt =  ram_i1_doubt_type.newInstance(this);
		o1a_doubt.set("a", ((DFEVar)ram.getOutputA().get("a")).hasDoubt());
		o1a_doubt.set("b", ((DFEVar)ram.getOutputA().get("b")).hasDoubt());

		io.output("o1a", ram.getOutputA().removeDoubtInfo(), ram_i1_type);
		io.output("o1a_doubt", o1a_doubt, ram_i1_doubt_type);

		DFEStruct o1b_doubt =  ram_i4_doubt_type.newInstance(this);
		o1b_doubt.set("a", ((DFEVar)ram.getOutputB().get("a")).hasDoubt());
		o1b_doubt.set("b", ((DFEVar)ram.getOutputB().get("b")).hasDoubt());

		io.output("o1b", ram.getOutputB().removeDoubtInfo(), ram_i4_type);
		io.output("o1b_doubt", o1b_doubt, ram_i4_doubt_type);

		// Doubt on one port
		port_a = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i2,
			ram_i1_type)
			.withDataIn(i1)
			.withWriteEnable(i3);

		port_b = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i5_d,
			ram_i4_type)
			.withDataIn(i4_d)
			.withWriteEnable(i6_d);

		ram = mem.ramDualPort(size, mode, RamDoubtMode.STORE_DOUBT, port_a, port_b);

		DFEStruct o2a_doubt =  ram_i1_doubt_type.newInstance(this);
		o2a_doubt.set("a", ((DFEVar)ram.getOutputA().get("a")).hasDoubt());
		o2a_doubt.set("b", ((DFEVar)ram.getOutputA().get("b")).hasDoubt());

		io.output("o2a", ram.getOutputA().removeDoubtInfo(), ram_i1_type);
		io.output("o2a_doubt", o2a_doubt, ram_i1_doubt_type);

		DFEStruct o2b_doubt =  ram_i4_doubt_type.newInstance(this);
		o2b_doubt.set("a", ((DFEVar)ram.getOutputB().get("a")).hasDoubt());
		o2b_doubt.set("b", ((DFEVar)ram.getOutputB().get("b")).hasDoubt());

		io.output("o2b", ram.getOutputB().removeDoubtInfo(), ram_i4_type);
		io.output("o2b_doubt", o2b_doubt, ram_i4_doubt_type);

		// Doubt on one port, address only
		port_a = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i2,
			ram_i1_type)
			.withDataIn(i1)
			.withWriteEnable(i3);

		port_b = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i5_d,
			ram_i4_type)
			.withDataIn(i4)
			.withWriteEnable(i6);

		ram = mem.ramDualPort(size, mode, RamDoubtMode.STORE_DOUBT, port_a, port_b);

		DFEStruct o3a_doubt =  ram_i1_doubt_type.newInstance(this);
		o3a_doubt.set("a", ((DFEVar)ram.getOutputA().get("a")).hasDoubt());
		o3a_doubt.set("b", ((DFEVar)ram.getOutputA().get("b")).hasDoubt());

		io.output("o3a", ram.getOutputA().removeDoubtInfo(), ram_i1_type);
		io.output("o3a_doubt", o3a_doubt, ram_i1_doubt_type);

		DFEStruct o3b_doubt =  ram_i4_doubt_type.newInstance(this);
		o3b_doubt.set("a", ((DFEVar)ram.getOutputB().get("a")).hasDoubt());
		o3b_doubt.set("b", ((DFEVar)ram.getOutputB().get("b")).hasDoubt());

		io.output("o3b", ram.getOutputB().removeDoubtInfo(), ram_i4_type);
		io.output("o3b_doubt", o3b_doubt, ram_i4_doubt_type);

		// Doubt on one port, data only, global doubt reg
		port_a = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i2,
			ram_i1_type)
			.withDataIn(i1_d)
			.withWriteEnable(i3);

		port_b = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i5,
			ram_i4_type)
			.withDataIn(i4)
			.withWriteEnable(i6);

		ram = mem.ramDualPort(size, mode, RamDoubtMode.GLOBAL_DOUBT_ONLY, port_a, port_b);

		DFEStruct o4a_doubt =  ram_i1_doubt_type.newInstance(this);
		o4a_doubt.set("a", ((DFEVar)ram.getOutputA().get("a")).hasDoubt());
		o4a_doubt.set("b", ((DFEVar)ram.getOutputA().get("b")).hasDoubt());

		io.output("o4a", ram.getOutputA().removeDoubtInfo(), ram_i1_type);
		io.output("o4a_doubt", o4a_doubt, ram_i1_doubt_type);

		DFEStruct o4b_doubt =  ram_i4_doubt_type.newInstance(this);
		o4b_doubt.set("a", ((DFEVar)ram.getOutputB().get("a")).hasDoubt());
		o4b_doubt.set("b", ((DFEVar)ram.getOutputB().get("b")).hasDoubt());

		io.output("o4b", ram.getOutputB().removeDoubtInfo(), ram_i4_type);
		io.output("o4b_doubt", o4b_doubt, ram_i4_doubt_type);

		// Single port, doubt everywhere
		port_a = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i2_d,
			ram_i1_type)
			.withDataIn(i1_d)
			.withWriteEnable(i3_d);

		DFEStruct r = mem.ram(size, mode, RamDoubtMode.STORE_DOUBT, port_a);

		DFEStruct o5_doubt =  ram_i1_doubt_type.newInstance(this);
		o5_doubt.set("a", ((DFEVar)r.get("a")).hasDoubt());
		o5_doubt.set("b", ((DFEVar)r.get("b")).hasDoubt());

		io.output("o5", r.removeDoubtInfo(), ram_i1_type);
		io.output("o5_doubt", o5_doubt, ram_i1_doubt_type);

		// Single port, doubt on data, global doubt reg
		port_a = mem.makeRamPortParams(
			RamPortMode.READ_WRITE,
			i2,
			ram_i1_type)
			.withDataIn(i1_d)
			.withWriteEnable(i3);

		r = mem.ram(size, mode, RamDoubtMode.GLOBAL_DOUBT_ONLY, port_a);

		DFEStruct o6_doubt =  ram_i1_doubt_type.newInstance(this);
		o6_doubt.set("a", ((DFEVar)r.get("a")).hasDoubt());
		o6_doubt.set("b", ((DFEVar)r.get("b")).hasDoubt());

		io.output("o6", r.removeDoubtInfo(), ram_i1_type);
		io.output("o6_doubt", o6_doubt, ram_i1_doubt_type);
	}

	private static void testRAM(_DualSimulationManager m) {

		V1DoubtTest a = new V1DoubtTest(m.makeKernelParameters_A());
		a.createRAMTest();
		V1DoubtTest b = new V1DoubtTest(m.makeKernelParameters_B());
		b.createRAMTest();

		m.setKernels(a, b);
		m.setKernelCycles(6);

		// DIn A
		double[] i1 			= {  1,  11,   2,  22,   3,  33,
			 						 4,  44,   5,  55,   6,  66};

		double[] i1_doubt 		= {  1,   0,   0,   1,   0,   0,
			 						 1,   0,   1,   1,   0,   0};

		// Addr A
		double[] i2				= {  0,   1,   2,   2,   1,   0};
		double[] i2_doubt		= {  0,   0,   0,   1,   0,   1};

		// WE A
		double[] i3				= {  1,   1,   1,   0,   0,   0};
		double[] i3_doubt		= {  0,   0,   0,   0,   0,   1};

		// DIn B
		double[] i4 			= { 10, 110,  20, 220,  30, 330,
			 						40, 440,  50, 550,  60, 660};

		double[] i4_doubt 		= {  1,   0,   0,   0,   0,   1,
			 						 1,   0,   1,   1,   0,   0};

		// Addr B
		double[] i5				= {  5,   4,   3,   3,   4,   5};
		double[] i5_doubt		= {  0,   0,   0,   0,   1,   1};

		// WE B
		double[] i6				= {  1,   1,   1,   0,   0,   0};
		double[] i6_doubt		= {  0,   0,   0,   0,   0,   0};


		double[] r_a 			= {  0,   0,   0,   0,   0,   0,
									 3,  33,   2,  22,   1,  11};

		double[] r_b 			= {  0,   0,   0,   0,   0,   0,
									30, 330,  20, 220,  10, 110};

		double[] r_invalid 		= {  1,   1,   1,   1,   1,   1,
			                         0,   0,   0,   0,   0,   0};


		double[] o1a_doubt 		= {  0,   0,   0,   0,   0,   0,
			 						 1,   1,   0,   1,   1,   1};

		double[] o1b_doubt 		= {  0,   0,   0,   0,   0,   0,
			                         0,   1,   1,   1,   1,   1};

		double[] o2a_doubt 		= {  0,   0,   0,   0,   0,   0,
                        			 0,   0,   0,   0,   0,   0};

		double[] o2b_doubt 		= {  0,   0,   0,   0,   0,   0,
                                     0,   1,   1,   1,   1,   1};

		double[] o3a_doubt 		= {  0,   0,   0,   0,   0,   0,
                        			 0,   0,   0,   0,   0,   0};

		double[] o3b_doubt 		= {  0,   0,   0,   0,   0,   0,
                                     0,   0,   1,   1,   1,   1};

		double[] o4a_doubt 		= {  1,   1,   1,   1,   1,   1,
		                             1,   1,   1,   1,   1,   1};

		double[] o4b_doubt 		= {  1,   1,   1,   1,   1,   1,
                                     1,   1,   1,   1,   1,   1};

		double[] o5_doubt 		= {  0,   0,   0,   0,   0,   0,
			                         1,   1,   0,   1,   1,   1};

		double[] o6_doubt 		= {  1,   1,   1,   1,   1,   1,
                                     1,   1,   1,   1,   1,   1};


		m.setInputDataRaw("i1", SimulationManager.packToBits((DFEType) ram_i1_type.getTypeForField("a"), 2, i1));
		m.setInputDataRaw("i1_doubt", SimulationManager.packToBits((DFEType) ram_i1_doubt_type.getTypeForField("a"), 2, i1_doubt));

		m.setInputData("i2", i2);
		m.setInputData("i2_doubt", i2_doubt);

		m.setInputData("i3", i3);
		m.setInputData("i3_doubt", i3_doubt);

		m.setInputDataRaw("i4", SimulationManager.packToBits((DFEType) ram_i4_type.getTypeForField("a"), 2, i4));
		m.setInputDataRaw("i4_doubt", SimulationManager.packToBits((DFEType) ram_i4_doubt_type.getTypeForField("a"), 2, i4_doubt));

		m.setInputData("i5", i5);
		m.setInputData("i5_doubt", i5_doubt);

		m.setInputData("i6", i6);
		m.setInputData("i6_doubt", i6_doubt);

		m.runTest();
		m.dumpOutput();

		checkResults(m, "o1a", (DFEType) ram_i1_type.getTypeForField("a"), (DFEType) ram_i1_doubt_type.getTypeForField("a"), r_a, o1a_doubt, r_invalid);
		checkResults(m, "o1b", (DFEType) ram_i4_type.getTypeForField("a"), (DFEType) ram_i4_doubt_type.getTypeForField("a"), r_b, o1b_doubt, r_invalid);

		checkResults(m, "o2a", (DFEType) ram_i1_type.getTypeForField("a"), (DFEType) ram_i1_doubt_type.getTypeForField("a"), r_a, o2a_doubt, r_invalid);
		checkResults(m, "o2b", (DFEType) ram_i4_type.getTypeForField("a"), (DFEType) ram_i4_doubt_type.getTypeForField("a"), r_b, o2b_doubt, r_invalid);

		checkResults(m, "o3a", (DFEType) ram_i1_type.getTypeForField("a"), (DFEType) ram_i1_doubt_type.getTypeForField("a"), r_a, o3a_doubt, r_invalid);
		checkResults(m, "o3b", (DFEType) ram_i4_type.getTypeForField("a"), (DFEType) ram_i4_doubt_type.getTypeForField("a"), r_b, o3b_doubt, r_invalid);

		checkResults(m, "o4a", (DFEType) ram_i1_type.getTypeForField("a"), (DFEType) ram_i1_doubt_type.getTypeForField("a"), r_a, o4a_doubt, r_invalid);
		checkResults(m, "o4b", (DFEType) ram_i4_type.getTypeForField("a"), (DFEType) ram_i4_doubt_type.getTypeForField("a"), r_b, o4b_doubt, r_invalid);

		checkResults(m, "o5", (DFEType) ram_i1_type.getTypeForField("a"), (DFEType) ram_i1_doubt_type.getTypeForField("a"), r_a, o5_doubt, r_invalid);

		checkResults(m, "o6", (DFEType) ram_i1_type.getTypeForField("a"), (DFEType) ram_i1_doubt_type.getTypeForField("a"), r_a, o6_doubt, r_invalid);
	}

	private static void checkResults(
		_DualSimulationManager m,
		String name,
		DFEType type,
		DFEType doubt_type,
		double[] data,
		double[] doubt,
		double[] invalid)
	{

		double[] res_data_a;
		double[] res_data_b;
		double[] res_doubt_a = null;
		double[] res_doubt_b = null;

		res_data_a = SimulationManager.unpackFromBits(type, m.getManager_A().getOutputDataRawArray(name));
		res_data_b = SimulationManager.unpackFromBits(type, m.getManager_A().getOutputDataRawArray(name));

		if (doubt != null) {
			res_doubt_a = SimulationManager.unpackFromBits(doubt_type, m.getManager_A().getOutputDataRawArray(name + "_doubt"));
			res_doubt_b = SimulationManager.unpackFromBits(doubt_type, m.getManager_B().getOutputDataRawArray(name + "_doubt"));
		}

		if (res_data_a.length != data.length ||
			res_data_b.length != data.length ||
			(doubt != null && res_doubt_a.length != doubt.length) ||
			(doubt != null && res_doubt_b.length != doubt.length) ||
			(doubt != null && data.length != doubt.length))
		{
			System.out.printf("Result length mismatch on %s!\n  Data length: A: %d, B: %d, expected: %d\n  Doubt length: A: %d, B: %d, expected: %d\n", name, res_data_a.length, res_data_b.length, data.length, res_doubt_a == null ? 0 : res_doubt_a.length, res_doubt_b == null ? 0 : res_doubt_b.length, doubt == null ? 0 : doubt.length);
			throw new TestFailedException();
		}

		for (int i = 0; i < data.length; ++i) {

			if (doubt != null) {
				if(res_doubt_a[i] != res_doubt_b[i]) {
					System.out.printf("Managers disagree on %s_doubt[%d].\nA (SW) got: %f, B (HW) got: %f, expected: %f\n", name, i, res_doubt_a[i], res_doubt_b[i], doubt[i]);
					throw new TestFailedException();
				}

				if(res_doubt_a[i] != doubt[i]) {
					System.out.printf("Doubt bit mismatch for %s_doubt[%d].\nGot: %f, expected: %f\n", name, i, res_doubt_a[i], doubt[i]);
					throw new TestFailedException();
				}
			}

			boolean ignore_res = (invalid != null && invalid[i] == 1);

			if (!ignore_res && res_data_a[i] != res_data_b[i]) {
				System.out.printf("Managers disagree on %s[%d].\nA (SW) got: %f, B (HW) got: %f, expected: %f\n", name, i, res_data_a[i], res_data_b[i], data[i]);
				throw new TestFailedException();
			}

			if (!ignore_res && res_data_a[i] != data[i]) {
				System.out.printf("Data mismatch for %s[%d].\nGot: %f, expected: %f\n", name, i, res_data_a[i], data[i]);
				throw new TestFailedException();
			}
		}
	}


	public static void main(String[] args) {
		DualSimMode sim_mode =  DualSimMode.SEQUENTIAL;
		_DualSimulationManager m;

		m = new _DualSimulationManager("V1DoubtTest_IO", sim_mode);
		System.out.printf("Running V1DoubtTest_IO\n");
		testIO(m);

		m = new _DualSimulationManager("V1DoubtTest_Pack", sim_mode);
		System.out.printf("Running V1DoubtTest_Pack\n");
		testPack(m);

		m = new _DualSimulationManager("V1DoubtTest_ClearCast", sim_mode);
		System.out.printf("Running V1DoubtTest_ClearCast\n");
		testClearCast(m);

		m = new _DualSimulationManager("V1DoubtTest_RAM", sim_mode);
		m.setParameter("maxcompiler.simplified_stack_traces", "false");
		System.out.printf("Running V1DoubtTest_RAM\n");
		testRAM(m);
	}
}
