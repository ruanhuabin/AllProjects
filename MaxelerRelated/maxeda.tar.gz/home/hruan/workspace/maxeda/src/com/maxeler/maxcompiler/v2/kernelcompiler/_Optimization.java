package com.maxeler.maxcompiler.v2.kernelcompiler;

import com.maxeler.photon.core.PhotonDesignData;

/*
 * ACHTUNG: Mixing the push/pop methods in this class with
 * PhotonDesignData.push/pop*OpFactory() calls may lead to unexpected results.
 * To be on the safe side:
 *   1. Push the desired factory first (through PhotonDesignData)
 *   2. Use this class to push/pop DSP settings
 *   3. Make sure you popped all DSP settings before pushing/popping
 *      PhotonDesignData factories again.
 *
 * Users don't have to worry about this as there is no way to access
 * PhotonDesignData.push/pop*OpFactory() through v1/v0.
 */

public class _Optimization extends Optimization {
	final PhotonDesignData m_design_data;

	protected _Optimization(Kernel kernel) {
		super(kernel);
		m_design_data = _Kernel.getPhotonDesignData(getKernel());
	}

	public void pushOptimiseConstPow2Mul(boolean optimise) {
		m_design_data.pushOptimiseConstPow2Mul(optimise);
	}

	public void popOptimiseConstPow2Mul() {
		m_design_data.popOptimiseConstPow2Mul();
	}
}
