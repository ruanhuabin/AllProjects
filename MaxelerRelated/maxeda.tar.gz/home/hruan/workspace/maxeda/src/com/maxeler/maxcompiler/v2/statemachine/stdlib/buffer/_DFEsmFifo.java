package com.maxeler.maxcompiler.v2.statemachine.stdlib.buffer;

import com.maxeler.maxcompiler.v2.statemachine.StateMachineLib;
import com.maxeler.maxcompiler.v2.statemachine.stdlib.Buffer.DFEsmFifoConfig;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.buffers.Fifo;

public final class _DFEsmFifo {
	private _DFEsmFifo() {}

	public static DFEsmFifo Create(String id, DFEsmValueType inputType, int depth, DFEsmFifoConfig fifoSpec, StateMachineLib sm) {
		return new DFEsmFifo(id, inputType, depth, fifoSpec, sm);
	}

	public static Fifo toImp(DFEsmFifo f) {return f.m_fifo;}

	public static Fifo getFifo(DFEsmFifoReadDomain fs) {return fs.m_fifo;}
	public static Fifo getFifo(DFEsmFifoWriteDomain snk) {return snk.m_fifo;}

	public static DFEsmValueType getType(DFEsmFifoReadDomain fs) {return fs.m_type;}
	public static DFEsmValueType getType(DFEsmFifoWriteDomain snk) {return snk.m_type;}
}
