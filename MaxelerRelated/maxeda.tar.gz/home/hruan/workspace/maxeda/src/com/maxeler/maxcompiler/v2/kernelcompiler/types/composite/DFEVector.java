package com.maxeler.maxcompiler.v2.kernelcompiler.types.composite;

import com.maxeler.maxcompiler.v2.errors.MaxCompilerAPIError;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObject;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelObjectVectorizable;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.KernelType;
import com.maxeler.maxcompiler.v2.kernelcompiler.types.base.DFEVar;

/**
 * A multipipe stream of {@code DFEVectorType} data.
 * <p>
 * Each pipe in the stream is a {@code ContainedT} stream.
 * @param <ContainedT> Kernel object for an individual pipe.
 */
public class DFEVector<ContainedT extends KernelObjectVectorizable<ContainedT>>
	extends DFEVectorBase<
		ContainedT,
		DFEVector<ContainedT>,
		DFEVector<DFEVar>,
		DFEVectorType<ContainedT>
	>
{
	DFEVector(DFEArray<ContainedT> array, DFEVectorType<ContainedT> type) {
		super(array, type);
	}

	/**
	 * Casts this multipipe stream to a multipipe stream of Kernel type {@code type}.
	 * <p>
	 * <b>Note</b>: multipipe streams can only be cast to other multipipe Kernel types.
	 * @param type The multipipe Kernel type to which to cast this stream.
	 * @return The resultant stream cast to {@code type}.
	 */
	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public KernelObject<?> cast(KernelType<?> type) {
		if(type instanceof DFEVectorType)
			return cast((DFEVectorType) type);

		throw new MaxCompilerAPIError(getKernel().getManager(), "Can only cast multi-pipe objects using a DFEVectorType.");
	}

	/**
	 * Casts this multipipe stream to a multipipe stream of Kernel type {@code type}.
	 * @param type The multipipe Kernel type to which to cast this stream.
	 * @return The new stream cast to {@code type}.
	 */
	@SuppressWarnings("unchecked")
	public DFEVector<ContainedT> cast(DFEVectorType<ContainedT> type) {
		if(getNElements() != type.getNElements())
			throw new MaxCompilerAPIError(getKernel().getManager(),
				"Cannot cast multi-pipe of type " + getType() + " to type " + type);

		DFEVector<ContainedT> ret = type.newInstance(getKernel());

		for(int i=0; i < getNElements(); i++)
			ret.getElement(i).connect((ContainedT)getElement(i).cast(type.getContainedType()));

		return ret;
	}

}
