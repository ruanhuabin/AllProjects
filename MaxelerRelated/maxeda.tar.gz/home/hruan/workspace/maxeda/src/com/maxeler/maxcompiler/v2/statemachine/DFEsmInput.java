package com.maxeler.maxcompiler.v2.statemachine;

import com.maxeler.maxcompiler.v2.statemachine.kernel.KernelStateMachine;
import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.expressions.Stream;
import com.maxeler.statemachine.expressions.StreamInput;

/**
 * An input stream to a {@link KernelStateMachine}.
 */
public final class DFEsmInput extends DFEsmValue {
	DFEsmInput(String name, DFEsmValueType type, Stream.StreamType streamType) { super(new StreamInput(name, type, streamType)); }

	StreamInput getInput() { return (StreamInput) getExpression(); }

	/**
	 * Get the name of this input.
	 * @return The name of this input.
	 */
	public String getName() { return getInput().getName(); }
}
