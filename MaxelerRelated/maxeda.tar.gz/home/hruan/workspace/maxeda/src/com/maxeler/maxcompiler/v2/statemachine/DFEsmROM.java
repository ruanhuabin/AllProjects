package com.maxeler.maxcompiler.v2.statemachine;

import java.math.BigInteger;
import java.util.List;

import com.maxeler.maxcompiler.v2.statemachine.types.DFEsmValueType;
import com.maxeler.statemachine.memory.ROM;

public abstract class DFEsmROM extends DFEsmMem {

	DFEsmROM(int numPorts, Latency latency, DFEsmValueType type, int romID, List<BigInteger> values) {
		super(new ROM(numPorts, latency.getCycles(), type, romID, values));
	}

	ROM getROM() { return (ROM) m_mem; }

	@Override
	public String toString() { return "rom(" + getNumPorts() + ", " + getType() + ", " + getDepth() + ")"; }
}
