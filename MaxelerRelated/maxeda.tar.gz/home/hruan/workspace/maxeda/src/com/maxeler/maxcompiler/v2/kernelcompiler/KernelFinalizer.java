package com.maxeler.maxcompiler.v2.kernelcompiler;

/**
 * If a class implements the {@code KernelFinalizer} interface and is added to
 * a Kernel, the {@code finalizeKernel} method on the object will be called
 * once the Kernel graph specified in the Kernel constructor has been constructed.
 */
public interface KernelFinalizer {
	/**
	 * Method that will be called after the Kernel construction is complete.
	 */
	public void finalizeKernel(Kernel kernel_design);
}
