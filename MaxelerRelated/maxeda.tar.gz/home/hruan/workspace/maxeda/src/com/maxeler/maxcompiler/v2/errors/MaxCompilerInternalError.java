package com.maxeler.maxcompiler.v2.errors;

import com.maxeler.maxcompiler.v2.managers.DFEManager;
import com.maxeler.maxcompiler.v2.managers._Managers;
import com.maxeler.maxdc.BuildManager;
import com.maxeler.utils.MaxelerException;

public class MaxCompilerInternalError extends MaxelerException {
	private static final long serialVersionUID = 1L;

	public MaxCompilerInternalError(Throwable t) {
		super(null, t);
	}

	public MaxCompilerInternalError(String format, Object...args) {
		super(null, String.format(format, args));
	}

	MaxCompilerInternalError(BuildManager build_manager, Throwable t) {
		super(build_manager, t);
	}

	public MaxCompilerInternalError(DFEManager build_manager, Throwable t) {
		super(_Managers.getBuildManager(build_manager), t);
	}

	MaxCompilerInternalError(BuildManager build_manager, String format, Object...args) {
		super(build_manager, String.format(format, args));
	}

	public MaxCompilerInternalError(DFEManager build_manager, String format, Object...args) {
		super(_Managers.getBuildManager(build_manager), String.format(format, args));
	}
}
