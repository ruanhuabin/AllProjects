. /etc/rc.d/init.d/functions

[ -r /etc/sysconfig/maxq ] && . /etc/sysconfig/maxq
[ -z "$MAXQ_WORKER" ] && exit 0
$MAXQ_WORKER $MAXQ_WORKER_ARGS  > /var/log/maxq/maxqworker-$$.log 2>&1 &
PID=$!
echo $PID > /tmp/maxq-worker.pid
sleep 2
PROCESS=`ps | grep $PID | grep -v grep`
echo -n " /var/log/maxq/maxqworker-$$.log"
if [ "$PROCESS" = "" ]
then
	failure
else
	success	
fi

