package com.maxeler.maxq.manager;

public enum KillJobStatus {
	SIGNAL_SENT,
	DEQUEUED,
	JOB_NOT_FOUND,
	JOB_NOT_RUNNING_NOR_QUEUED,
	SIGNAL_NOT_SENT,
	PID_ERROR,
	FAIL		
}
