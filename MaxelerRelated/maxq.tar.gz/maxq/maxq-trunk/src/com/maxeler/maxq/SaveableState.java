package com.maxeler.maxq;

public interface SaveableState {
	public void saveState();
}
