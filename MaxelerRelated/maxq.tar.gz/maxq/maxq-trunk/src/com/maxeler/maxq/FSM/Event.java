package com.maxeler.maxq.FSM;

public class Event {

	Integer m_EventID;
	String m_Name;
	

	// The Any Event is always a fallback/default event,
	// this means that a transition using the any_event only triggers if and only if
	// no other transition matches the received event
	public static final int ANY_EVENT = -1;
	public static final int STEP_EVENT = -2;
	public static final int ERROR_EVENT = -99;
	
	public Event(Integer Event, String name) {
		m_EventID = Event;
		m_Name = name;
	}
	
	public Event(Integer Event) {
		m_EventID = Event;
		if (Event.equals(ANY_EVENT)) {
			m_Name = "ANY_EVENT";
		} else if (Event.equals(STEP_EVENT)) {
			m_Name = "STEP_EVENT";
		} else if (Event.equals(ERROR_EVENT)) {
			m_Name = "ERROR_EVENT";
		} else {
			m_Name = Event.toString();
		}
	}


	public Integer getEventID() {
		return m_EventID;
	}
	
	public String getName() {
		return m_Name;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + m_EventID;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Event other = (Event) obj;
		if (m_EventID != other.getEventID())
			return false;
		return true;
	}

}
