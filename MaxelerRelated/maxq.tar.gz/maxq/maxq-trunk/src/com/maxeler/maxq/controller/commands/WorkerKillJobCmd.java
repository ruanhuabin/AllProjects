/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobID;
import com.maxeler.maxq.worker.KillJobResult;
import com.maxeler.maxq.worker.WorkerRequestCommands;

/**
 * @author itay
 *
 */
public class WorkerKillJobCmd extends ControllerCmd {

	JobID m_JobID;	
	KillJobResult m_KillJobResult = null;
	/**
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */ 
	public WorkerKillJobCmd(JobID jid, CommandRouter cr,
			Delegate OnCommandCompletion) throws Exception {
		super("WorkerKillJobCmd", cr, OnCommandCompletion);
		m_JobID = jid;
		
		State SendRequestCmd = new State("SendRequestCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerKillJobCmd wkjc = (WorkerKillJobCmd) m_Internal;
				try {
					wkjc.getControllerClient().getObjectStreams().SendObject(CommonCommands.REQUEST);
					wkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						wkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadRequestElabCmd = new State("ReadRequestElabCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerKillJobCmd wkjc = (WorkerKillJobCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) wkjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.REQUEST_ELAB)) {
						wkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						wkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
 					try {
						wkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State SendKillJobCmd = new State("SendKillJobCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerKillJobCmd wkjc = (WorkerKillJobCmd) m_Internal;
				try {
					wkjc.getControllerClient().getObjectStreams().SendObject(WorkerRequestCommands.KILL_JOB);
					wkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						wkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State ReadKillJobACK = new State("ReadKillJobACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerKillJobCmd wkjc = (WorkerKillJobCmd) m_Internal;
				try {
					ProtocolControlCommands pcc = (ProtocolControlCommands) wkjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (pcc.equals(ProtocolControlCommands.ACK)) {
						wkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						wkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
 					try {
						wkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State SendJobIDtoKill = new State("SendJobIDtoKill", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getControllerClient().getObjectStreams().SendObject(m_JobID);
					HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State ReadKilledJobResult = new State("ReadKilledJobResult", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					m_KillJobResult = (KillJobResult) getControllerClient().getObjectStreams().ReceiveObject();
					if (getOnCommandCompletion() != null) {
						getOnCommandCompletion().Invoke(m_KillJobResult);
					}
					HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				getControllerClient().Close();	
				return 0;
			}			
		});
		
		AddState(SendRequestCmd);
		AddState(ReadRequestElabCmd);
		AddState(SendKillJobCmd);
		AddState(ReadKillJobACK);
		AddState(SendJobIDtoKill);
		AddState(ReadKilledJobResult);
		AddState(EndState);
		
		setCurrentState(SendRequestCmd);
		setInitialState(SendRequestCmd);
		
		AddTransition(new Transition(SendRequestCmd, ReadRequestElabCmd, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadRequestElabCmd, SendKillJobCmd, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendKillJobCmd, ReadKillJobACK, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadKillJobACK, SendJobIDtoKill, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendJobIDtoKill, ReadKilledJobResult, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadKilledJobResult, EndState, CommonEvents.eSTEP_EVENT));
		
		
		AddTransition(new Transition(SendRequestCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadRequestElabCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendKillJobCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadKillJobACK, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendJobIDtoKill, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadKilledJobResult, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}

	public KillJobResult geResult() {
		return m_KillJobResult;
	}
}
