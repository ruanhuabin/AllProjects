/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Map;

import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.GeneralServer;
import com.maxeler.maxq.ObjectStreamChannel;
import com.maxeler.maxq.OperationsRouter;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerRequestCommands;
import com.maxeler.maxq.manager.ManagerServer;

/**
 * @author itay
 *
 */
public class ManagerRequestRouter extends OperationsRouter {

	private ManagerServer m_ms;
	private SocketChannel m_sc;
	private ObjectStreamChannel m_os;
	
	/**
	 * @param FSMName
	 */
	public ManagerRequestRouter(ManagerServer ms, SocketChannel sc) {
		super("ManagerRequestRouter");
		m_ms = ms;
		m_sc = sc;
		m_os = null;
	}

	@Override
	public OperationsRouter CreateNew(GeneralServer gs, SocketChannel sc) {
		return new ManagerRequestRouter((ManagerServer)gs, sc);
	}

	@Override
	public void Init() {
		m_os = new ObjectStreamChannel(m_sc, m_sc.socket().getInetAddress().getHostName());
		
		State wfwSendRequestElab = new State("wfwSendRequestElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// TODO Auto-generated method stub
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendRequestElab = new State("SendRequestElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerRequestRouter r = (ManagerRequestRouter) m_Internal;
				try {
					r.getObjectStreams().SendObject(CommonResponses.REQUEST_ELAB);
				} catch (Exception e) {
					try {
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State wfrReadRequestCommand = new State("wfrReadRequestCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadRequestCommand = new State("ReadRequestCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerRequestRouter r = (ManagerRequestRouter)m_Internal;
				try {
					ManagerRequestCommands mrc =  (ManagerRequestCommands) r.getObjectStreams().ReceiveObject();
					
					Map<SocketChannel, FSM> FSMSelector = r.getManagerServer().getMapChannelFSM();
					FSM newFSM = r;
					// Routing
					if (mrc.equals(ManagerRequestCommands.NEWJOB)) {
						newFSM = new ManagerNewJobOperation(r);
					} else if (mrc.equals(ManagerRequestCommands.DISCOVER)) {
						newFSM = new ManagerDiscoverOperation(r);
					} else if (mrc.equals(ManagerRequestCommands.KILL_JOB)) {
						newFSM = new ManagerKillJobOperation(r);
					}
					FSMSelector.put(r.getSocketChannel(), newFSM);
				} catch (Exception e) {
					try {
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}
		});
		
		State ErrorState = new State("ErrorState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerRequestRouter r = (ManagerRequestRouter)m_Internal;
				try {
					r.getSocketChannel().close();
				} catch (Exception e) {
				
				}
				return 0;
			}
		});
		
		AddState(wfwSendRequestElab);
		AddState(SendRequestElab);
		AddState(wfrReadRequestCommand);
		AddState(ReadRequestCommand);
		AddState(ErrorState);
		setInitialState(wfwSendRequestElab);
		setCurrentState(wfwSendRequestElab);
		
		AddTransition(new Transition(wfwSendRequestElab, SendRequestElab, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendRequestElab, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfwSendRequestElab, wfwSendRequestElab, CommonEvents.eANY_EVENT));
		
		
		AddTransition(new Transition(SendRequestElab, wfrReadRequestCommand, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendRequestElab, ReadRequestCommand, CommonEvents.eCHANNEL_READABLE));
		
		AddTransition(new Transition(wfrReadRequestCommand, ReadRequestCommand, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrReadRequestCommand, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfrReadRequestCommand, wfrReadRequestCommand, CommonEvents.eANY_EVENT));

		
		AddTransition(new Transition(ReadRequestCommand, ErrorState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ErrorState, ErrorState, CommonEvents.eANY_EVENT));
	}
	
	public ManagerServer getManagerServer() {
		return m_ms;
	}

	private SocketChannel getSocketChannel() {
		return m_sc;
	}

	public ObjectStreamChannel getObjectStreams() {
		return m_os;
	}
	
	public void Terminate() {
		Map<SocketChannel, FSM> selector = getManagerServer().getMapChannelFSM();
		selector.remove(getSocketChannel());
		
		try {
			getSocketChannel().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		m_sc = null;
		m_os = null;
		m_ms = null;
	}

}
