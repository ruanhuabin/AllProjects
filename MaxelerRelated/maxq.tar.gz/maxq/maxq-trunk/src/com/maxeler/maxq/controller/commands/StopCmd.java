package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.Event;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;

public class StopCmd extends ControllerCmd {

	public StopCmd(CommandRouter cr, Delegate OnCommandCompletion) throws Exception {
		super("StopCommand", cr, OnCommandCompletion);
		
		State SendCommand = new State("SendCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StopCmd s = (StopCmd)m_Internal;
				try {
					s.getControllerClient().getObjectStreams().SendObject(CommonCommands.STOP);
					s.HandleEvent(CommonEvents.eSTEP_EVENT, 0);
				} catch (Exception e) {
					try {
						s.HandleEvent(CommonEvents.eERROR_EVENT, -1);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StopCmd s = (StopCmd)m_Internal;
				s.getControllerClient().Close();
 				s.getOnCommandCompletion().Invoke(param);
				return 0;
			}
		});
		
		AddState(SendCommand);
		AddState(EndState);
		
		AddTransition(new Transition(SendCommand, EndState, new Event(Event.STEP_EVENT, "Step")));
		AddTransition(new Transition(SendCommand, EndState, new Event(Event.ERROR_EVENT, "Error")));
		AddTransition(new Transition(EndState, EndState, new Event(Event.ANY_EVENT, "ANY")));
		
		setInitialState(SendCommand);
		CreateDotGraph();
	}
}

