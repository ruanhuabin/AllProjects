package com.maxeler.maxq.worker;

public enum WorkerRequestCommands {
	NEWJOB,
	KILL_JOB
}
