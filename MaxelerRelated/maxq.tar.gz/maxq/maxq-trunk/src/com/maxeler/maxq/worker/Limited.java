package com.maxeler.maxq.worker;

public interface Limited {
	public int getTotal();
	public boolean CanAllocate(int amount);
	public void Allocate(int amount) throws Exception;
	public void Free(int amount) throws Exception;
}
