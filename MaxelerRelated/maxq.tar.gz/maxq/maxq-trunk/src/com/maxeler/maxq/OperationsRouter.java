package com.maxeler.maxq;

import java.nio.channels.SocketChannel;

import com.maxeler.maxq.FSM.FSM;

public abstract class OperationsRouter extends FSM {

	public OperationsRouter(String FSMName) {
		super(FSMName);
	}
	
	public abstract OperationsRouter CreateNew(GeneralServer gs, SocketChannel sc);
	public abstract void Init();
}
