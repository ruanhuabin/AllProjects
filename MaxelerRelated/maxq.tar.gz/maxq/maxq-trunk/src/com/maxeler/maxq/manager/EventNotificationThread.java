package com.maxeler.maxq.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.maxeler.maxq.Stoppable;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.FSM;

public abstract class EventNotificationThread implements Runnable, Stoppable,
		Comparable<Object> {

	private boolean m_Running = true;
	private Thread m_Thread;
	
	private List<JobID> m_NotificationList;

	private final ManagerServer m_Manager;
	
	private final String m_Name;
	
	public EventNotificationThread(ManagerServer ms, String name) {
		m_Manager = ms;
		m_NotificationList  = new ArrayList<JobID>();
		m_Name = name;
	}
	
	@Override
	public void run() {
		do {
			try {
				Thread.sleep(5000);
				synchronized (m_Manager.getState()) {
					if (!m_NotificationList.isEmpty()) {
						for (JobID jid : m_NotificationList) {
							doNotify(jid);
						}
						m_NotificationList.clear();
					}
				}
			} catch (InterruptedException e) {
				return;
			}
		} while (m_Running);
	}
	
	public void Start() {
		m_Thread = new Thread(this, "maxq_notifier_" + m_Name);
		m_Thread.start();
	}
	
	private void doNotify(JobID jid) {
		// Restore the waiting controller's interest set
		synchronized (m_Manager.getState()) {
			List<FSM> fsms = getMap().get(jid);
		    if (fsms != null) {
			   	for (FSM fsm : fsms) {
			   		try {
						fsm.HandleEvent(CommonEvents.eCHANNEL_WRITABLE);
					} catch (Exception e) {
					}
			   	}
			   	fsms.clear();
			   	getMap().remove(jid);
			   	doPostNotificationCleanup(jid);
			   	//m_State.getProcessedJobs().remove(jid);
		    }
		}
    }

	
	public void Notify(JobID jid) {
		synchronized (m_Manager.getState()) {
			m_NotificationList.add(jid);
		}
	}

	@Override
	public void Stop() {
		try {
			m_Running  = false;
			m_Thread.interrupt();
			m_Thread.join();
		} catch (Exception e) {
		}		
	}

	@Override
	public int compareTo(Object o) {
		return 1;
	}

	public abstract Map<JobID, List<FSM>> getMap();
	public abstract void doPostNotificationCleanup(JobID jid);
}
