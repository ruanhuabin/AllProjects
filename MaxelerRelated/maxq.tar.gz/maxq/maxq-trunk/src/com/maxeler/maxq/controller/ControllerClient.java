package com.maxeler.maxq.controller;

import java.io.IOException;
import java.nio.channels.ByteChannel;
import java.util.logging.Level;

import com.maxeler.maxq.GeneralClient;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.ObjectStreamChannel;

public class ControllerClient extends GeneralClient {

	private ByteChannel m_bc;
	private ObjectStreamChannel m_osc;
	private final String m_serverName;
	private final transient MaxQLogger log = MaxQLogger.getLogger("ControllerClient");
	
	public ControllerClient(String ServerName, int port) throws IOException {
		super(ServerName, port);
		m_serverName = ServerName;
		log.logf(Level.FINEST, "Remote name: %s:%d", m_serverName, port);
		
	}
	
	@Override
	protected void Ready(ByteChannel bc, String remoteName) throws Exception {
		m_bc = bc;
		m_osc = new ObjectStreamChannel(bc, remoteName);		
	}
	
	@Override
	public void Close() {
		try {
			if (m_bc != null) {
				super.Close();
			}
		} catch (Exception e) {
			
		}
		m_bc = null;
	}
	
	@Override
	public String getRemoteName() {
		return m_serverName;
	}
	
	public ObjectStreamChannel getObjectStreams() {
		return m_osc;
	}
	
	public ByteChannel getByteChannel() {
		return m_bc;
	}
}
