package com.maxeler.maxq.FSM;

public class Transition {
	State m_From;
	State m_To;
	Event m_Event;
	
	public Transition(State From, State To, Event Event) {
		m_From = From;
		m_To = To;
		m_Event = Event;
	}
	
	public Boolean Check(State state, Event Event) {
		return (m_From.isEqualState(state) && (Event.equals(m_Event)));
	}

	public State getFrom() {
		return m_From;
	}

	public State getTo() {
		return m_To;
	}
	
	public Event getEvent() {
		return m_Event;
	}	
}
