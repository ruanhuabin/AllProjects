package com.maxeler.maxq.FSM;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.logging.Level;

import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;

/**
 * @author itay
 *
 * @description This is an implementation of a trivially simple FSM engine
 * 				It is used to maintain the state of communications between 2 end points.
 *
 */
public class FSM {
	String m_Name;
	Hashtable<State, Boolean> m_States;
	Hashtable<State, Hashtable<Event, State>> m_Transitions;
	
	public static int FSM_INDEX = 1;
	
	private final int m_fsm_id = FSM_INDEX++;
	
	private final Event m_ANY_EVENT = CommonEvents.eANY_EVENT;

	State m_CurrentState;
	State m_InitialState;

	private final transient MaxQLogger fsmLog = MaxQLogger.getLogger("FSM["+m_fsm_id+"]");

	protected FSM(String FSMName) {		
		m_Name = FSMName;
		m_Transitions = new Hashtable<State, Hashtable<Event, State>>();
		m_States = new Hashtable<State, Boolean>();
	}

	public void AddState(State state) {
		fsmLog.logf(Level.FINEST, "%s: Adding State: %s", getName(), state.getName());
		if (!m_States.containsKey(state)) { 
			m_States.put(state, true);
		}
	}

	public void AddTransition(Transition transition) {
		Hashtable<Event, State> EventToState;
		if (m_Transitions.containsKey(transition.getFrom())) {
			EventToState = m_Transitions.get(transition.getFrom());
		} else {
			EventToState = new Hashtable<Event, State>();
		}
		if (EventToState.containsKey(transition.getEvent())) {
			fsmLog.logf(Level.FINEST,"%s: Transition already exists - Ignoring.", getName());
		}
		EventToState.put(transition.getEvent(), transition.getTo());
		m_Transitions.put(transition.getFrom(), EventToState);
	}

	public void setInitialState(State state) {
		m_InitialState = state;
	}

	public Integer HandleEvent(Event event) throws Exception {
		return HandleEvent(event, null);
	}

	public Integer HandleEvent(Event event, Object param) throws Exception {
		fsmLog.logf(Level.FINEST,"%s: Got Event: %s @ state: %s", getName(), event.getName(), 
				m_CurrentState.getName());
		Hashtable<Event, State> EventToState = m_Transitions.get(m_CurrentState);
		if (!EventToState.containsKey(event)) {
			if (!EventToState.containsKey(m_ANY_EVENT)) { 
				fsmLog.logf(Level.SEVERE,"%s: No appropriate transition defined, failing!", getName());
				throw new Exception("Invalid event recieved");
			}
			
			fsmLog.logf(Level.FINEST,"%s: Using ANY_EVENT Transition.", getName());
			event = CommonEvents.eANY_EVENT;
		}
		State nextState = EventToState.get(event);
		fsmLog.logf(Level.FINEST,"%s: State Change: %s -> %s", getName(), m_CurrentState.getName(), nextState.getName());
		m_CurrentState = nextState;
		// Call On Enter function
		return nextState.OnEnter(param);		
	}

	public void setCurrentState(State s) {
		m_CurrentState = s;
	}

	public Integer Reset(Object param) {
		m_CurrentState = m_InitialState;
		return m_InitialState.OnEnter(param);
	}

	public String getName() {
		return m_Name;
	}

	public void CreateDotGraph() {
		if (Globals.minLogLevel.intValue() <= Level.FINEST.intValue()) {
			try {
				FileWriter fw = new FileWriter(getName() + ".dot");
				fw.write("digraph \"" + getName() + "\"\n");
				fw.write("{\n");
				for (Enumeration<State> se = m_States.keys() ; se.hasMoreElements();) {
					State s = se.nextElement();

					fw.write("s" + Math.abs(s.getName().hashCode()) + " [label = \"" + s.getName() + "\"");
					if (s.equals(m_InitialState)) {
						fw.write(", color=blue");
					}
					fw.write("]\n");
				}

				for (Enumeration<State> se = m_Transitions.keys() ; se.hasMoreElements();) {
					State source = se.nextElement();
					Hashtable<Event, State> map = m_Transitions.get(source);
					for (Enumeration<Event> ee = map.keys() ; ee.hasMoreElements();) {
						Event e = ee.nextElement();
						State dest = map.get(e);
						String str = "s" + Math.abs(source.getName().hashCode()); 
						str = str + " -> s" + Math.abs(dest.getName().hashCode());
						String EventProps = "\"" + e.getName() + "\", fontcolor=darkgreen";
						// Substitutions
						if (e.getEventID() == Event.ANY_EVENT) {
							EventProps = "\"ANY\", fontcolor=orange";
						} else if (e.getEventID() == Event.STEP_EVENT) {
							EventProps = "\"Step\", fontcolor=green";
						} else if (e.getEventID() == Event.ERROR_EVENT) {
							EventProps = "\"ERROR\", fontcolor=red";
						}
						str = str + " [label = "+ EventProps + "]\n";
						fw.write(str);
					}
				}			
				fw.write("}\n");
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
