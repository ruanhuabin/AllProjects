package com.maxeler.maxq.manager;

public enum ManagerRequestCommands {
	NEWJOB,
	DISCOVER,
	KILL_JOB
}
