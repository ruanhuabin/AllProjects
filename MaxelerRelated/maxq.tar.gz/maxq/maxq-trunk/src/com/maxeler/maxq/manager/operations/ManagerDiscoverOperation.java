/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.nio.channels.SelectionKey;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;


/**
 * @author itay
 *
 */
public class ManagerDiscoverOperation extends Operation<ManagerRequestRouter> {

	private final transient MaxQLogger log = MaxQLogger.getLogger("ManagerDiscoverOperation");
	
	/**
	 * @param r
	 */
	public ManagerDiscoverOperation(ManagerRequestRouter r) {
		super("ManagerDiscoverOperation", r);
		
		State wfwSendAck = new State("wfwSendAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
			
		});
		
		State SendACK = new State("SendACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerDiscoverOperation mdo = (ManagerDiscoverOperation) m_Internal;
				try {
					log.log(Level.INFO, "Issuing discovery...");
					mdo.getRouter().getManagerServer().Discover();
					log.log(Level.INFO, "Sending Discovery ACK.");
					mdo.getRouter().getObjectStreams().SendObject(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						try {
							mdo.getRouter().getObjectStreams().SendObject(ProtocolControlCommands.NACK);
						} catch (Exception e2) {
						}
						mdo.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerDiscoverOperation mdo = (ManagerDiscoverOperation) m_Internal;
				try {
					mdo.getRouter().Terminate();
				} catch (Exception e) {
				}
				return 0;
			}			
		});
		
		AddState(wfwSendAck);
		AddState(SendACK);
		AddState(EndState);
		
		setInitialState(wfwSendAck);
		setCurrentState(wfwSendAck);
		
		AddTransition(new Transition(wfwSendAck, SendACK, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendAck, wfwSendAck, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(wfwSendAck, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendACK, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}

}
