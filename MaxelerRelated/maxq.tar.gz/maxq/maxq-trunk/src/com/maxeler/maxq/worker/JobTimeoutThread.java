/**
 * 
 */
package com.maxeler.maxq.worker;

import java.util.Date;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Stoppable;
import com.maxeler.maxq.manager.JobID;

/**
 * @author itay
 *
 */
public class JobTimeoutThread implements Runnable, Stoppable, Comparable<Object> {

	private final JobID m_JobID;
	private final int m_Timeout;
	private final Delegate m_onTimeout;
	private Thread m_Thread;
	private long m_StartTime;

	private boolean m_Stop = false;
	
	/**
	 * @param jid - job id to monitor
	 * @param timeout - in seconds
	 * @param OnTimeout - delegate to invoke when time is out
	 */
	public JobTimeoutThread(JobID jid, int timeout, Delegate OnTimeout) {
		m_JobID = jid;
		m_Timeout = timeout * 1000; // seconds to miliseconds
		m_onTimeout = OnTimeout;
		m_onTimeout.m_Internal = this;
	}
	
	public void Start() {
		if (m_onTimeout == null) {
			return;
		}
		m_Thread = new Thread(this, "maxq_thread_timeout_" + m_JobID.toString());
		m_StartTime = new Date().getTime();		
		m_Thread.start();		
	}
	
	@Override
	public void run() {
		try {
			while (m_Stop) {
				long now = new Date().getTime();
				if (now - m_StartTime >= m_Timeout) {
					m_onTimeout.Invoke(m_JobID);
					break;
				}
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
				}
			}
		} catch (Exception e) {			
			e.printStackTrace();
		}
	}

	@Override
	public void Stop() {
		try {
			m_Stop = true;
			m_Thread.join();
		} catch (InterruptedException e) {
		}
	}

	@Override
	public int compareTo(Object o) {
		return 1;
	}
}
