/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.nio.channels.SelectionKey;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerState;

/**
 * @author itay
 *
 */
public class ManagerGetStateOperation extends Operation<ManagerQueryRouter> {

	/**
	 * @param FSMName
	 * @param r
	 */
	public ManagerGetStateOperation(ManagerQueryRouter r) {
		super("ManagerGetStateOperation", r);
		
		State wfwSendManagerState = new State("wfwSendManagerState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendManagerState = new State("SendManagerState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				synchronized (getRouter().getManagerServer().getState()) {
					ManagerState ms = getRouter().getManagerServer().getState();
					try {
						getRouter().getObjectStreams().SendObject(ms);
					} catch (Exception e) {
						try {
							return HandleEvent(CommonEvents.eERROR_EVENT);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}					
				}
				
				return SelectionKey.OP_READ;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getRouter().Terminate();
				} catch (Exception e) {
				}
				return 0;
			}
		});
		
		AddState(wfwSendManagerState);
		AddState(SendManagerState);
		AddState(EndState);
		
		setInitialState(wfwSendManagerState);
		setCurrentState(wfwSendManagerState);
		
		AddTransition(new Transition(wfwSendManagerState, SendManagerState, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendManagerState, wfwSendManagerState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendManagerState, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(SendManagerState, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		CreateDotGraph();
	}
}
