package com.maxeler.maxq;

public enum CommonResponses {
	OK,
	ERROR,
	STATUS_REPLY,
	QUERY_ELAB,
	NOTIFY_ELAB,
	REQUEST_ELAB
}
