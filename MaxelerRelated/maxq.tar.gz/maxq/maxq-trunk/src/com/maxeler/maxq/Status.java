package com.maxeler.maxq;

public interface Status {
	public StatusCodes GetStatusCode();
}
