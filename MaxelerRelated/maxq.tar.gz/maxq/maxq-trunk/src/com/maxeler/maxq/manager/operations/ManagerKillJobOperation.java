/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.nio.channels.SelectionKey;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobSearchCriteria;
import com.maxeler.maxq.manager.KillJobResults;

/**
 * @author itay
 *
 */
public class ManagerKillJobOperation extends Operation<ManagerRequestRouter> {
	
	private final transient MaxQLogger log = MaxQLogger.getLogger("ManagerKillJobOperation");
	
	private JobSearchCriteria m_JobSearchCriteria;
	private KillJobResults m_KillJobResults;

	/**
	 * @param FSMName
	 * @param r
	 */
	public ManagerKillJobOperation(ManagerRequestRouter r) {
		super("ManagerKillJobOperation", r);
		
		State wfwSendAck = new State("wfwSendAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendACK = new State("SendACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
			   try {
					getRouter().getObjectStreams().SendObject(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						log.log(Level.INFO, e.getMessage());
						try {
							getRouter().getObjectStreams().SendObject(ProtocolControlCommands.NACK);
						} catch (Exception e2) {
							log.log(Level.INFO, e2.getMessage());
						}
						HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						log.log(Level.SEVERE, e1.getMessage());
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State wfrReadKillCriteria = new State("wfrReadKillCriteria", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadKillCriteria = new State("ReadKillCriteria", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					m_JobSearchCriteria = (JobSearchCriteria) getRouter().getObjectStreams().ReceiveObject();
					m_KillJobResults = getRouter().getManagerServer().KillJobs(m_JobSearchCriteria);
				} catch (Exception e) {					
					e.printStackTrace();
				}
				return SelectionKey.OP_WRITE;
			}			
		});

		State wfwSendKilledJobResults = new State("wfwSendKilledJobResults", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendKilledJobResults = new State("SendKillJobResults", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
			   try {				   				   
				   getRouter().getObjectStreams().SendObject(m_KillJobResults);
				   return HandleEvent(CommonEvents.eANY_EVENT);
				} catch (Exception e) {
					try {
						log.log(Level.WARNING, e.getMessage());
						HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						log.log(Level.SEVERE, e1.getMessage());
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});

		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getRouter().Terminate();
				} catch (Exception e) {
				}
				return 0;
			}			
		});
		
		AddState(wfwSendAck);
		AddState(SendACK);
		AddState(wfrReadKillCriteria);
		AddState(ReadKillCriteria);
		AddState(wfwSendKilledJobResults);
		AddState(SendKilledJobResults);
		AddState(EndState);

		setInitialState(wfwSendAck);
		setCurrentState(wfwSendAck);
		
		AddTransition(new Transition(wfwSendAck, SendACK, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendAck, wfwSendAck, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendAck, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(SendACK, ReadKillCriteria, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendACK, wfrReadKillCriteria, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendACK, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(wfrReadKillCriteria, ReadKillCriteria, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrReadKillCriteria, wfrReadKillCriteria, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrReadKillCriteria, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(ReadKillCriteria, SendKilledJobResults, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(ReadKillCriteria, wfwSendKilledJobResults, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadKillCriteria, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(wfwSendKilledJobResults, SendKilledJobResults, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendKilledJobResults, wfwSendKilledJobResults, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendKilledJobResults, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(SendKilledJobResults, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}

}
