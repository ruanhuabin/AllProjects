package com.maxeler.maxq.manager.operations;

import java.nio.channels.SelectionKey;
import java.util.logging.Level;

import com.maxeler.maxq.ChannelEvent;
import com.maxeler.maxq.ChannelEvents;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;


public class StatusOperation extends Operation<ManagerOperationsRouter> {

	private final transient MaxQLogger log = MaxQLogger.getLogger("StatusOperation");
	
	public StatusOperation(ManagerOperationsRouter r) {
		super("StatusOperation", r);
		State WaitForWritable = new State("Wait For Writable", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}		
		});
		State SendGeneralResponse = new State("Send General Response", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusOperation so = (StatusOperation)m_Internal;
				ManagerOperationsRouter r = so.getRouter();
				try {
					r.getObjectStreams().SendObject(CommonResponses.STATUS_REPLY);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State WaitForReadable = new State("Wait For Readable", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}		
		});
		
		State ReadGRACK = new State("Read GR ACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusOperation so = (StatusOperation)m_Internal;
				ManagerOperationsRouter r = so.getRouter();
				try {
					ProtocolControlCommands pcc =  (ProtocolControlCommands) r.getObjectStreams().ReceiveObject();
					if (!pcc.equals(ProtocolControlCommands.ACK)) {
						log.logf(Level.WARNING, "Did not get ACK, instead got: %s", pcc.toString());
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return SelectionKey.OP_WRITE;
			}		
		});
		
		State SendReply = new State("Send Specific Reply", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusOperation so = (StatusOperation)m_Internal;
				ManagerOperationsRouter r = so.getRouter();
				try {
					r.getObjectStreams().SendObject((r.getManagerServer().getManagerStatus()));
				} catch (Exception e) {
					e.printStackTrace();
				}
				r.Terminate();
				return 0;
			}			
		});
		
		State EndState = new State("End State", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusOperation so = (StatusOperation)m_Internal;
				so.getRouter().Terminate();
				return 0;
			}		
		});
		
		AddState(WaitForWritable);
		AddState(SendGeneralResponse);
		AddState(WaitForReadable);
		AddState(ReadGRACK);
		AddState(SendReply);
		AddState(EndState);
		
		AddTransition(new Transition(WaitForWritable, SendGeneralResponse, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(SendGeneralResponse, ReadGRACK, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendGeneralResponse, WaitForReadable, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(WaitForReadable, ReadGRACK, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(ReadGRACK, SendReply, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(SendReply, EndState, CommonEvents.eANY_EVENT));

		// Handle unexpected events
		AddTransition(new Transition(WaitForReadable, WaitForReadable, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadGRACK, EndState, new ChannelEvent(ChannelEvents.ERROR)));
		AddTransition(new Transition(WaitForWritable, EndState, new ChannelEvent(ChannelEvents.ERROR)));
		AddTransition(new Transition(EndState, EndState, new ChannelEvent(ChannelEvents.ERROR)));
		
		
		setInitialState(WaitForWritable);
		setCurrentState(WaitForWritable);
		
		CreateDotGraph();
	}
}
