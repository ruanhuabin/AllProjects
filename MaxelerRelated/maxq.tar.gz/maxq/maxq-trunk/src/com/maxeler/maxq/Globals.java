package com.maxeler.maxq;

import java.util.logging.Level;

public class Globals {
	public static final int ManagerPort = 7001;
	public static final int WorkerPort = 7002;
	public static final int ControllerPort = 7003;
	public static final String ManagerConfigPath = "/etc/maxq/manager.conf";
	public static final String WorkerConfigPath = "/etc/maxq/worker.conf";
	public static final String ManagerStateFile = "/etc/maxq/manager.state";
	public static final String WorkerStateFile = "/etc/maxq/worker.state";
	public static final String DefaultTempDirectory = "/network-scratch/maxq";
	
	public static Level minLogLevel = Level.INFO;
	
	public static final int ClientSocketTimeout = 180000; // Milliseconds
	public static final int ClientSocketConnectRetries = 500;
	public static final int ClientSocketLinger = 5; // Seconds
}
