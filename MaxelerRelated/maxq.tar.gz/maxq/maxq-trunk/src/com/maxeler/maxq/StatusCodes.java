package com.maxeler.maxq;

public enum StatusCodes {
	OK, 
	E_NOT_FOUND,
	E_UNKOWN
}
