package com.maxeler.maxq.manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.maxeler.maxq.worker.KillJobResult;

public class KillJobResults implements Serializable, Iterable<KillJobResult> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7253899083622929634L;

	private ArrayList<KillJobResult> m_Results = new ArrayList<KillJobResult>();

	public List<KillJobResult> getResults() {
		return m_Results;
	}

	@Override
	public Iterator<KillJobResult> iterator() {
		return m_Results.iterator();
	}
	
	@Override
	public String toString() {
		return "KillJobResults_" + m_Results.size()+"_elements";
	}
}
