/**
 * 
 */
package com.maxeler.maxq.manager;

import java.io.Serializable;
import java.util.LinkedList;

import com.maxeler.maxq.worker.WorkerJobDescriptor;

/**
 * @author itay
 *
 */
public class JobSearchResult implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7756736750825736040L;
	
	private LinkedList<WorkerJobDescriptor> m_Found = new LinkedList<WorkerJobDescriptor>();

	/**
	 * 
	 */
	public JobSearchResult() {
	}
	
	public LinkedList<WorkerJobDescriptor> getJobList() {
		return m_Found;
	}
}
