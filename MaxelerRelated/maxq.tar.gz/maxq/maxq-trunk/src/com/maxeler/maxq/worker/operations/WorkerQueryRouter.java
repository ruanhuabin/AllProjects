package com.maxeler.maxq.worker.operations;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Map;

import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.GeneralServer;
import com.maxeler.maxq.ObjectStreamChannel;
import com.maxeler.maxq.OperationsRouter;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.worker.WorkerQueryCommands;
import com.maxeler.maxq.worker.WorkerServer;

public class WorkerQueryRouter extends OperationsRouter {

	WorkerServer m_ws;
	SocketChannel m_sc;
	ObjectStreamChannel m_os;
	
	public WorkerQueryRouter(WorkerServer ws, SocketChannel sc) {
		super("WorkerQueryRouter");
		m_ws = ws;
		m_sc = sc;
		m_os = null;
	}

	@Override
	public OperationsRouter CreateNew(GeneralServer gs, SocketChannel sc) {
		return new WorkerQueryRouter((WorkerServer) gs, sc);
	}

	@Override
	public void Init() {
		m_os = new ObjectStreamChannel(m_sc, m_sc.socket().getInetAddress().getHostName());
		
		State wfwQueryElab = new State("wfwQueryElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		
		State SendQueryElab = new State("SendQueryElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerQueryRouter r = (WorkerQueryRouter)m_Internal;
				try {
					r.getObjectStreams().SendObject(CommonResponses.QUERY_ELAB);
				} catch (Exception e) {
					try {
						return r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}
		});
		
		State wfrWorkerQuery = new State("wfrWorkerQuery", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadWorkerQueryCommandAndRoute = new State("ReadWorkerQueryCommandAndRoute", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerQueryRouter r = (WorkerQueryRouter)m_Internal;
				try {
					WorkerQueryCommands wqc =  (WorkerQueryCommands) r.getObjectStreams().ReceiveObject();
					
					Map<SocketChannel, FSM> FSMSelector = r.getWorkerServer().getMapChannelFSM();
					FSM newFSM = r;
					// Routing
					if (wqc.equals(WorkerQueryCommands.DISCOVER)) {
						newFSM = new WorkerDiscoverOperation(r);
					} else if (wqc.equals(WorkerQueryCommands.RUNNING)) {
						newFSM = new WorkerRunningOperation(r);
					} 
					FSMSelector.put(r.getSocketChannel(), newFSM);
				} catch (Exception e) {
					try {
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State ErrorState = new State("ErrorState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerOperationsRouter r = (WorkerOperationsRouter)m_Internal;
				r.Terminate();
				return 0;
			}			
		});
		
		AddState(wfwQueryElab);
		AddState(SendQueryElab);
		AddState(wfrWorkerQuery);
		AddState(ReadWorkerQueryCommandAndRoute);
		AddState(ErrorState);
		setInitialState(wfwQueryElab);
		setCurrentState(wfwQueryElab);

		AddTransition(new Transition(wfwQueryElab, wfwQueryElab, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwQueryElab, SendQueryElab, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(SendQueryElab, ReadWorkerQueryCommandAndRoute, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendQueryElab, wfrWorkerQuery, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrWorkerQuery, ReadWorkerQueryCommandAndRoute, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrWorkerQuery, wfrWorkerQuery, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(wfwQueryElab, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfrWorkerQuery, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadWorkerQueryCommandAndRoute, ErrorState, CommonEvents.eANY_EVENT));
		CreateDotGraph();
	}
	
	private SocketChannel getSocketChannel() {
		return m_sc;
	}

	public ObjectStreamChannel getObjectStreams() {
		return m_os;
	}
	
	public WorkerServer getWorkerServer() {
		return m_ws;
	}

	public void Terminate() {
		Map<SocketChannel, FSM> selector = getWorkerServer().getMapChannelFSM();
		selector.remove(getSocketChannel());
		
		try {
			getSocketChannel().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		m_sc = null;
		m_os = null;
		m_ws = null;
	}

	public String getRemoteAddress() {
		return getSocketChannel().socket().getInetAddress().getHostAddress();
	}
}
