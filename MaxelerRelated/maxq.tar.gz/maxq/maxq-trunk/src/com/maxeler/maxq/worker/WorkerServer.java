/**
 * 
 */
package com.maxeler.maxq.worker;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.OperationsServer;
import com.maxeler.maxq.SaveableState;
import com.maxeler.maxq.StateSaverThread;
import com.maxeler.maxq.Stoppable;
import com.maxeler.maxq.controller.commands.CommandRouter;
import com.maxeler.maxq.controller.commands.NotifyManagerJobCompleteCmd;
import com.maxeler.maxq.manager.JobID;
import com.maxeler.maxq.manager.KillJobStatus;
import com.maxeler.maxq.worker.operations.WorkerOperationsRouter;

/**
 * @author itay
 *
 */
public class WorkerServer extends OperationsServer implements SaveableState {

	private final transient MaxQLogger log = MaxQLogger.getLogger("WorkerServer");
	
	private final WorkerState m_State;
	private final StateSaverThread m_StateSaver;	
	private final Set<Stoppable> m_Threads;
	
	/**
	 * @param port
	 * @throws Exception 
	 */
	public WorkerServer(WorkerConfiguration wc, String ConfigFile) throws Exception {
		super(wc.getListenPort(), new WorkerOperationsRouter(null, null));
		
		m_State = new WorkerState();
		m_StateSaver = new StateSaverThread(this);	
		m_Threads = new ConcurrentSkipListSet<Stoppable>();
		
		String address = System.getenv("HOSTNAME");
		try {
			address = InetAddress.getLocalHost().getHostAddress();
		} catch (Exception e) {
			
		}
		
		log.logf(Level.INFO, "Worker ID --> name: %s, address: %s, port: %d", wc.getName(), address, wc.getListenPort());
		
		getState().setID(new WorkerID(wc.getName(), address, wc.getListenPort()));
		getState().setConfiguration(wc);
		getState().setAvailableResources(wc.getResources());
		getState().getAvailableResources().setOwner(getState().getID());
		getState().setRunningJobs(new Hashtable<JobID, WorkerJobDescriptor>(2));
		getState().setJobMonitors(new Hashtable<JobID, JobMonitoringThread>(2));
		rebuildState();
		registerThread(m_StateSaver);
		m_StateSaver.Start();
	}
	
	public WorkerState getState() {
		return m_State;
	}

	@Override
	public void Exit() {
		log.log(Level.INFO, "Shutting down");
		saveState();
		Stop();
		synchronized (m_Threads) {
			for (Stoppable s : m_Threads) {
				s.Stop();
			}
		}		
	}
	
	
	public WorkerConfiguration getWorkerConfiguration() {
		return getState().getConfiguration();		
	}
	
	public WorkerJobDescriptor SubmitJob(JobRequest jr) {
		// Build a Worker Resource Request from a Job Request
		WorkerJobDescriptor jd = null;
		if (getState().getAvailableResources().isAvailable(jr.getRequiredResources())) {
			JobExecutor je = new JobExecutor(this, jr);
			// Execute
			try {
				log.log(Level.FINEST, "About to Execute()...");
				try {
					jd = je.Execute();
					HandleNewJobDescriptor(jd);
				} catch (Exception e) {
					log.log(Level.INFO, "Failed executing, callstack:");
					e.printStackTrace();
				}
				
			} catch (Exception e) {
				log.logf(Level.WARNING, "Got Exception: %s", e.getMessage());
				e.printStackTrace();
				//OnJobComplete(jd);
			}
		} else {
			log.logf(Level.SEVERE, "%s: Incapable of handling new job (%s).", getState().getConfiguration().getName(), jr.getJobID().getJobIDString());
			jd = new WorkerJobDescriptor(jr, jr.getJobID(), "", "", "", getWorkerID());
			jd.setStarted(false);
			jd.setExecutionError(1, getState().getConfiguration().getName() + ": Incapable of handling new job.");
			jd.setExitCode(-1);
			//OnJobComplete(jd);
		}
		return jd;
	}
	
	private void HandleNewJobDescriptor(WorkerJobDescriptor jd) {
		// Mark resources as used
		Allocate(jd.getJobRequest().getRequiredResources());
		
		jd.setExecutionError(0, "No Execution Error");

		synchronized (getState()) {
			getState().getRunningJobs().put(jd.getJobID(), jd);
		}				

		JobMonitoringThread jmt = new JobMonitoringThread(jd, new Delegate(null) {
			@Override
			public Integer Invoke(Object param) {
				// Free Resources and Notify Manager of completion 
				JobMonitoringThread thread = (JobMonitoringThread)m_Internal;
				OnJobComplete((WorkerJobDescriptor)param);
				deregisterThread(thread);				
				return 0;
			}					
		});
		
		synchronized (getState()) {
			getState().getJobMonitors().put(jd.getJobID(), jmt);
		}
		
		registerThread(jmt);
		
		if (jd.getJobRequest().getTimeout() != null && jd.getJobRequest().getTimeout() > 0) {
			log.logf(Level.INFO, "Creating timeout thread: Job %s has %d seconds to exit.", jd.getJobID().getJobIDString(), jd.getJobRequest().getTimeout());
			JobTimeoutThread jtt = new JobTimeoutThread(jd.getJobID(), jd.getJobRequest().getTimeout(),  
					new Delegate(null) {
						@Override
						public Integer Invoke(Object param) {
							JobTimeoutThread thread = (JobTimeoutThread) m_Internal;
							JobID jid = (JobID) param;
							log.logf(Level.INFO, "Job %s timed out - killing.", jid.getJobIDString());
							KillJobResult kjr = KillJob(jid);
							log.logf(Level.FINE, "Job %s kill status: %s", jid.getJobIDString(), kjr.getStatus().toString());
							deregisterThread(thread);
							return 0;
						}
			});
			registerThread(jtt);
			jtt.Start();
		}
		
		jmt.Start();
	}
	
	protected void OnJobComplete(WorkerJobDescriptor jd) {
		if (jd.shouldNotifyOnCompletion()) {
			// Notify the manager of the completion
			log.logf(Level.FINE, "Job %s: Completed... trying to notify...", jd.getJobID().getJobIDString());
			CommandRouter cr = new CommandRouter(getState().getConfiguration().getManagerAddress(),getState().getConfiguration().getManagerPort());
			NotifyManagerJobCompleteCmd njcc = null;
			
			while (true) {
				try {
					log.logf(Level.FINE, "Job %s: Constructing notification command...", jd.getJobID().getJobIDString());
					njcc = new NotifyManagerJobCompleteCmd(jd, cr, new Delegate(this) {
							@Override
							public Integer Invoke(Object param) {
								// Do nothing.
								return null;
							}
						});
					
					log.logf(Level.FINE, "Job %s: Executing notification command...", jd.getJobID().getJobIDString());
					// Execute the command sequence
					njcc.Reset(null);
					if (njcc.isSuccess()) {
						log.logf(Level.INFO, "Job %s: Notified manager.", jd.getJobID().getJobIDString());
						break;
					}
					log.logf(Level.WARNING, "Job %s: Error occured while trying to notify manager...", jd.getJobID().getJobIDString());
				} catch (Exception e) {
					log.logf(Level.WARNING, "Job %s: Exception: Failed notifying manager: %s", jd.getJobID().getJobIDString(), e.getMessage());
				}
				log.logf(Level.WARNING, "Job %s: Sleeping for 5 seconds and retrying to notify....", jd.getJobID().getJobIDString());
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} else {
			log.logf(Level.WARNING, "Job %s: Will not notify the manager on completion.", jd.getJobID().getJobIDString());
		}
		
		// Free resources...
		log.logf(Level.FINE, "Job %s: Freeing resources...", jd.getJobID().getJobIDString());
		Boolean isRunning = false;
		synchronized (getState()) {
			isRunning = getState().getRunningJobs().containsKey(jd.getJobID());
			if (isRunning) {
				getState().getRunningJobs().remove(jd.getJobID());
				Free(jd.getJobRequest().getRequiredResources());
			}
			if (getState().getJobMonitors().containsKey(jd.getJobID()))
				getState().getJobMonitors().remove(jd.getJobID());
		}
		log.logf(Level.FINE, "Job %s: done.", jd.getJobID().getJobIDString());
	}

	protected void Free(WorkerResources wrr) {
		synchronized (getState()) {
			try {
				getState().getAvailableResources().Free(wrr);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private boolean Allocate(WorkerResources wrr) {
		Boolean allocated = false;
		synchronized (getState()) {
			allocated = getState().getAvailableResources().Allocate(wrr);
		}
		return allocated;
	}
	
	public WorkerResources getAvailableResources() {
		synchronized (getState()) {
			return getState().getAvailableResources();
		}				
	}
	
	public WorkerID getWorkerID() {
		return getState().getID();	
	}
	
	public KillJobResult KillJob(JobID jid) {
		KillJobResult kjr = null;
		WorkerJobDescriptor jd = null;
		try {		
			synchronized (getState()) {
				// Kill
				jd = getState().getRunningJobs().get(jid);
				if (jd != null) {
					Set<Integer> pids = jd.getPIDs();
					if (pids.size() > 0) {
						String pid_string = "";
						for (Integer pid : pids) {
							pid_string += pid.toString() + " ";
						}
						String command = "sudo kill -9 " + pid_string;
						log.logf(Level.FINE, "Executing: %s", command);
						Process killProc = Runtime.getRuntime().exec(command);
						int errorCode = killProc.waitFor();
						if (errorCode == 0) {
							kjr = new KillJobResult(jd, KillJobStatus.SIGNAL_SENT, getWorkerID().getName() +  ": Kill signal sent");
						} else {
							List<String> errors = WorkerJobDescriptor.readStdError(killProc);
							kjr = new KillJobResult(jd, KillJobStatus.SIGNAL_NOT_SENT, "The kill command returned code:" + errorCode + ", error stream was: " + (errors.size() > 0 ? errors.get(0) : "empty"));
						}
					} else {
						log.log(Level.INFO, "Couldn't find PIDs for given PPID.");
						kjr = new KillJobResult(jd, KillJobStatus.PID_ERROR, "Couldn't find PIDs, forcibly removing. (ppid=" + jd.getPPID() + ")");
						if (getState().getJobMonitors().containsKey(jid))
							getState().getJobMonitors().get(jid).setJobMissing();
					}				 
				} else {
					kjr = new KillJobResult(null, KillJobStatus.JOB_NOT_FOUND, "Job not registered with worker (phantom job?)");
				}			
			}
		} catch (Exception e) {
			kjr = new KillJobResult(jd, KillJobStatus.FAIL, "WorkerServer: Caught exception: " + e.getMessage());
			e.printStackTrace();
		}
		return kjr;
	}
	
	public boolean isRunning(JobID jid) {
		synchronized (getState()) {
			return getState().getRunningJobs().containsKey(jid);
		}
	}
	
	public static void DeleteFile(String path) {
		try {
			File f = new File(path);
			f.delete();
		}
		catch (Exception e) {
			
		}
	}

	public Map<JobID, WorkerJobDescriptor> getRunningJobs() {
		synchronized (getState()) {
			return getState().getRunningJobs();
		}		
	}
	
	private boolean rebuildState() {
		FileInputStream fis = null;
		synchronized (getState()) {
			try {
				log.logf(Level.INFO, "Reading state from file: %s", getState().getConfiguration().getStateFilePath());
				fis = new FileInputStream(getState().getConfiguration().getStateFilePath());
				ObjectInputStream ois = new ObjectInputStream(fis);
				WorkerState ws = (WorkerState) ois.readObject();
				
				if (ws != null) {
					if (ws.getRunningJobs() != null) {
						getRunningJobs().clear();
						for (WorkerJobDescriptor jd : ws.getRunningJobs().values()) {
							getRunningJobs().put(jd.getJobID(), jd);
							HandleNewJobDescriptor(jd);
						}
						return true;
					}
				}				
			} catch (Exception e) {
				log.logf(Level.WARNING, "Could not rebuild state from file: %s", e.getMessage());
			}
			finally {
				try {
					if (fis != null) fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}	
		return false;
	}
	
	@Override
	public void saveState() {
		synchronized (getState()) {
			try {
				log.logf(Level.FINE, "Saving state to file: %s", getState().getConfiguration().getStateFilePath());
				FileOutputStream faos = new FileOutputStream(getState().getConfiguration().getStateFilePath());
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(baos);
				
				oos.writeObject(getState());
				oos.flush();
				faos.write(baos.toByteArray());
				baos.flush();
				faos.flush();
				faos.close();				
			} catch (Exception e) {
				e.printStackTrace();
			}			
		}
	}
	
	public void deregisterThread(Stoppable thread) {
		synchronized (getState()) {
			m_Threads.remove(thread);
		}
	}
	
	public void registerThread(Stoppable thread) {
		synchronized (getState()) {
			m_Threads.add(thread);		
		}
	}
}
