/**
 * 
 */
package com.maxeler.maxq.worker;

import java.io.Serializable;

/**
 * @author itay
 *
 */
public class WorkerID implements Serializable, Comparable<WorkerID> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3053600035924706565L;
	private String m_Name;
	private String m_Address;
	private Integer m_Port;
	
	public WorkerID(String Name, String Address, Integer Port) {
		m_Name = Name;
		m_Address = Address;
		m_Port = Port;
	}

	public String getName() {
		return m_Name;
	}

	public String getAddress() {
		return m_Address;
	}
	
	public void setAddress(String addr) {
		m_Address = addr;
	}

	public Integer getPort() {
		return m_Port;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((m_Address == null) ? 0 : m_Address.hashCode());
		result = prime * result + ((m_Name == null) ? 0 : m_Name.hashCode());
		result = prime * result + ((m_Port == null) ? 0 : m_Port.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final WorkerID other = (WorkerID) obj;
		if (m_Address == null) {
			if (other.m_Address != null)
				return false;
		} else if (!m_Address.equals(other.m_Address))
			return false;
		if (m_Name == null) {
			if (other.m_Name != null)
				return false;
		} else if (!m_Name.equals(other.m_Name))
			return false;
		if (m_Port == null) {
			if (other.m_Port != null)
				return false;
		} else if (!m_Port.equals(other.m_Port))
			return false;
		return true;
	}

	@Override
	public int compareTo(WorkerID o) {
		return (getAddress() + getPort()).compareTo(o.getAddress() + o.getPort());
	}
}
