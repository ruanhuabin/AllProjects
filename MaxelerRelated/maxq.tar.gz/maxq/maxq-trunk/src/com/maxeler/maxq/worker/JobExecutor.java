/**
 * 
 */
package com.maxeler.maxq.worker;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.manager.JobID;

/**
 * @author itay
 * 
 */
public class JobExecutor { 

	public static final String ExitCodeCreationString = "start";
	private JobRequest m_JobRequest;
	private WorkerServer m_WorkerServer;
	private final transient MaxQLogger log = MaxQLogger.getLogger("JobExecutor");
	
	public JobExecutor(WorkerServer ws, JobRequest jr) {
		m_JobRequest = jr;
		m_WorkerServer = ws;
	}

	public WorkerJobDescriptor Execute() throws Exception {
		JobID jobID = m_JobRequest.getJobID();
		// Create FIFO
		String tmpDir = m_JobRequest.getTempDirectory();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MMM_dd_HH.mm.ss");
		String maxqPrefix = "maxq_" + m_JobRequest.getUsername() + "_" + sdf.format(new Date()).toLowerCase();
		String prefix = tmpDir + "/" + maxqPrefix + "_";
		
		
		String exitCodePath = prefix + "exit_code_" + jobID.getJobIDString();
		String PPIDFifoPath = prefix + "ppid_fifo_" + jobID.getJobIDString();
		String ScriptPath = prefix + "execute_" + jobID.getJobIDString() + ".sh";
		String SubScriptPath = prefix + "execute_sub_" + jobID.getJobIDString() + ".sh";
		String SubscriptExitCodePath = prefix + "execute_sub_" + jobID.getJobIDString() + ".code";
		String ExitScriptPath = prefix + "exit_" + jobID.getJobIDString() + ".sh";
		String PIDCodePath = prefix + jobID.getJobIDString() + ".pid";
		String LogPath = prefix + "log_stderr_stdout_" + jobID.getJobIDString() + ".log";

		String sudo = "sudo -u " + m_JobRequest.getUsername() + " ";
		
		log.logf(Level.FINER, "exitCodePath = %s\n" + "ScriptPath = %s\n"
				+ "SubScriptPath = %s\n" + "SubscriptExitCodePath = %s\n"
				+ "ExitScriptPath = %s\n" + "PIDCodePath = %s\n"
				+ "LogPath = %s", exitCodePath, LogPath, SubScriptPath,
				SubscriptExitCodePath, ExitScriptPath, PIDCodePath, LogPath);
 
		WorkerJobDescriptor jd = new WorkerJobDescriptor(m_JobRequest, jobID,
				LogPath, ScriptPath, exitCodePath, m_WorkerServer.getWorkerID());
		jd.setExitScriptPath(ExitScriptPath);
		jd.setSubscriptExitCodePath(SubscriptExitCodePath);
		jd.setSubScriptPath(SubScriptPath);
		jd.setInQueue(false);

		PrintStream ExecutionScript = new PrintStream(ScriptPath);
		
		PrintStream ExecutionSubScript = new PrintStream(SubScriptPath);
		String umaskCommand = m_JobRequest.getUmaskCmd();
		String Command = m_JobRequest.getCommand() + " "+ m_JobRequest.getArguments();
		ExecutionSubScript.printf("echo $$ > %s\n", PPIDFifoPath); // Avoid race
		ExecutionSubScript.printf("cd %s\n", m_JobRequest.getWorkingDirectory());
		for (String key : m_JobRequest.getEnvironment().keySet()) {
			ExecutionSubScript.printf("export %s=\"%s\"\n", key, 
					m_JobRequest.getEnvironment().get(key));
		}
		
		if (umaskCommand != null)
			ExecutionSubScript.printf("%s 2>&1\n", umaskCommand);
		
		ExecutionSubScript.printf("%s 2>&1\n", Command);
		ExecutionSubScript.close();

		PrintStream ExitScript = new PrintStream(ExitScriptPath);
		// Yes, ugly... but it's too short to bother.
		ExitScript.printf("#!bash\nif [ -e %s ]\n\tthen\n\t\tcat %s >> %s\n\telse\n\t\techo -1 >> %s\n\tfi\n\n",
						SubscriptExitCodePath, SubscriptExitCodePath, exitCodePath,
						exitCodePath);

		ExitScript.printf("rm -f %s\n", PPIDFifoPath + " " + 
				PIDCodePath + " " + SubscriptExitCodePath);
		ExitScript.close();

		ExecutionScript.printf("%s\n", "#!bash");
		ExecutionScript.printf("trap ' ' 2 EXIT\n", ExitScriptPath);
		//ExecutionScript.print("umask 0113\n");
		ExecutionScript.println("echo " + ExitCodeCreationString + " > " + exitCodePath);
		ExecutionScript.printf("( /bin/sh -x %s ; echo $? > %s ) | tee %s\n",
				SubScriptPath, SubscriptExitCodePath, LogPath);
		ExecutionScript.printf("/bin/sh -x %s\n", ExitScriptPath);
		ExecutionScript.close();

		log.log(Level.FINEST, "mkfifo ... " + sudo + " /usr/bin/mkfifo " + PPIDFifoPath);
		Process execProc = Runtime.getRuntime().exec(sudo + " /usr/bin/mkfifo " + PPIDFifoPath);
		execProc.waitFor();
		
		if (execProc.exitValue() == 0) {
			String cmd = sudo + " /usr/bin/screen -h 200 -dmOS " + "maxq" + jobID.getJobIDString() 	+ " bash -i " + ScriptPath;
			log.logf(Level.FINEST, "screen... %s", cmd);
			Runtime.getRuntime().exec(cmd);
			//screenProc.waitFor();
			log.logf(Level.FINEST, "waiting for ppid...", cmd);
			jd.setTimeStarted(new Date().getTime());
			jd.setStarted(true);
			jd.setRunning(true);
			jd.setPPID(getPPID(PPIDFifoPath));
			jd.setPIDCodePath(PIDCodePath);

			log.logf(Level.INFO, "Executed job %d (ppid=%d), screen name: %s",
					jobID.getJobIDCode(), jd.getPPID(), "maxq"
							+ jobID.getJobIDString());
		} else {
			List<String> error_list = WorkerJobDescriptor.readStdError(execProc);
			String error = "";
			for (String line : error_list) {
				error += line + " ";
			}
			log.log(Level.INFO, "exit value != 0 for " + sudo + " /usr/bin/mkfifo " + PPIDFifoPath);
			log.logf(Level.INFO, "Error Stream: %s", error);
			throw new Exception("exit value != 0 while creating " +  PPIDFifoPath + "\nError Stream: " + error);
		}

		return jd;
	}
	
	

	public Integer getPPID(String fifoPath) {
		Integer ret = 0;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(fifoPath));
			String ppid = br.readLine();
			ret = Integer.decode(ppid);
			log.logf(Level.FINE, "Read PPID: %d from fifo: %s", ret, fifoPath);
		} catch (Exception e) {
			log.logf(Level.WARNING, "Couldn't get PPID from %s", fifoPath);
		}
		finally {
			if (br != null) {
				try {
					br.close();
				} catch (Exception e) {
				}
			}
		}
		
		return ret;
	}

	public static void main(String[] args) {
		try {
			new JobExecutor(null, JobRequest.BuildFromFile("/home/itay/workspace/maxq/jobreq.txt")).Execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
