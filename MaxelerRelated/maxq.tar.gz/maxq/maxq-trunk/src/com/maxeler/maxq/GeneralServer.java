/**
 * 
 */
package com.maxeler.maxq;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.logging.Level;

/**
 * @author itay
 *
 */
public abstract class GeneralServer {

	private final transient MaxQLogger log = MaxQLogger.getLogger("GeneralServer");
	private final int FailThreshold = 50; 
	private final int m_port;
	private int m_selectorFailCount;
	protected Boolean m_Running = true;

	private final ServerSocketChannel m_ssChannel;
	private final Selector m_selector;
	
	private SelectionKey m_currentSelectionKey;


	protected GeneralServer(int port) throws IOException {
		m_port = port;
		m_selector = Selector.open();
		m_ssChannel = ServerSocketChannel.open();
		m_ssChannel.configureBlocking(false);
		m_ssChannel.socket().bind(new InetSocketAddress(m_port), 100);
		m_ssChannel.register(m_selector, SelectionKey.OP_ACCEPT);
		m_currentSelectionKey = null;
	}	
	
	public void WaitForEvents() throws Exception {
		int numKeysReady = m_selector.select();
		
		if (numKeysReady != 0) {
			m_selectorFailCount = 0;
		} else {
			// JVM bug... ?
			m_selectorFailCount++;
			log.logf(Level.FINE, "Useless selector wakeup #%d... ", m_selectorFailCount); 
			Thread.sleep(50);
			if (m_selectorFailCount > FailThreshold) {
				int cancelCount = 0;
				log.logf(Level.WARNING, 
						"Selector woke up %d time with no keys ready, canceling keys with interestOps = 0...\n",
						m_selectorFailCount,
						m_selector.keys().size());
				for (SelectionKey k : m_selector.keys()) {
					if (k.interestOps() == 0) {
						k.cancel();
						cancelCount++;
					}
				}				
				log.logf(Level.WARNING, "Canceled %d keys.\n", cancelCount);
				m_selectorFailCount = 0;
				return;
			}
		}
	
		
		// Dispatch
		Iterator<SelectionKey> it = m_selector.selectedKeys().iterator();
		while (m_Running && it.hasNext()) {
			SelectionKey selKey = it.next();
			it.remove();
			
			
			// Save current selection key, for access by event handlers
			m_currentSelectionKey = selKey;
			
			//Logger.logf("ReadyOps = %d", selKey.readyOps());
			if (selKey.isValid() && selKey.isAcceptable()) {
				//Logger.log("Acceptable Event");
				ServerSocketChannel channel = (ServerSocketChannel)selKey.channel();
				channel.register(m_selector, channel.validOps());
				SocketChannel sc = channel.accept();
				sc.configureBlocking(false);
				Integer nextOps = OnEvent(sc,  ChannelEvents.ACCEPTABLE);
				sc.register(m_selector, nextOps);
			} 

			if (selKey.isValid() && selKey.isConnectable()) {
				//Logger.log("Connectable Event");
				SocketChannel sChannel = (SocketChannel)selKey.channel();

				//Logger.log("Completing connection...");
				boolean success = sChannel.finishConnect();
				if (!success) {
					selKey.cancel();
				} else {
					OnEvent(sChannel, ChannelEvents.CONNECTABLE);
				}
			}

			if (selKey.isValid() && selKey.isReadable()) { 
				//Logger.log("Readable Event");
				SocketChannel sChannel = (SocketChannel)selKey.channel();
				if (sChannel.isConnected()) {
					Integer nextOps = OnEvent(sChannel, ChannelEvents.READABLE);
					if (sChannel.isOpen()) {
						selKey.interestOps(nextOps);
					}
				} else {
					OnEvent(sChannel, ChannelEvents.ERROR);
				}
			}

			if (selKey.isValid() && selKey.isWritable()) {
				//Logger.log("Writable Event");
				SocketChannel sChannel = (SocketChannel)selKey.channel();
				if (sChannel.isConnected()) {
					Integer nextOps = OnEvent(sChannel, ChannelEvents.WRITABLE);
					if (sChannel.isOpen()) {
						selKey.interestOps(nextOps);
					}
				} else {
					OnEvent(sChannel, ChannelEvents.ERROR);
				}
			}
		}
	}
	
	public void WakeUp() {
		m_selector.wakeup();
	}
	
	public SelectionKey getCurrentSelectionKey() {
		return m_currentSelectionKey;
	}
	
	public boolean isRunning() {
		return m_Running;
	}

	protected abstract Integer OnEvent(SocketChannel channel, ChannelEvents eventID) throws Exception;
}

