/**
 * 
 */
package com.maxeler.maxq.manager;

import java.io.Serializable;
import java.util.HashSet;

import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

/**
 * Defines a Job Search criteria
 * Implements a Match function that returns true if a given job descriptor matches the criteria
 * @author itay
 *
 */
public class JobSearchCriteria implements Serializable {

	private static final long serialVersionUID = 4534767803279271061L;
	
	private Boolean m_byID;
	private HashSet<JobID> m_IDs;
	private Boolean m_byJR;
	private HashSet<JobRequest> m_JRs;
	
	private Boolean m_AnythingMatches;

	/**
	 * 
	 * @param byID - if true, match JobID to any in the IDs list
	 * @param IDs - a list of JobIDs
	 * @param byJR - if true, match a JR to any of the parameters which are not null in any of the JobRequests in the JRs list
	 * @param JRs - a list of Job Requests
	 */
	public JobSearchCriteria(Boolean AnythingMatches, Boolean byID, HashSet<JobID> IDs, 
			Boolean byJR, HashSet<JobRequest> JRs) {
		m_byID = byID;
		m_IDs = IDs;
		m_byJR = byJR;
		m_JRs = JRs;
		m_AnythingMatches = AnythingMatches;
	}
	
	public Boolean Match(WorkerJobDescriptor jd) {
		
		if (jd == null) {
			return false;
		}
		
		if (m_AnythingMatches) {
			return true;
		}
		
		Boolean IDmatches = false;
		Boolean JRmatches = false;
		
		if (m_byID) {
			if (jd.getJobID() != null) {
				if (m_IDs.contains(jd.getJobID())) {
					IDmatches = true;
				}
			}
		}
		
		try {
			if (m_byJR) {
				for (JobRequest mJR : m_JRs) {
					JRmatches = true;
					
					if (mJR.getGroupName() != null) {
						if (!jd.getJobRequest().getGroupName().matches(mJR.getGroupName())) {
							JRmatches = false;
							continue;
						}
					}
					
					if (mJR.getUsername() != null) {
						if (!jd.getJobRequest().getUsername().matches(mJR.getUsername())) {
							JRmatches = false;
							continue;
						}
					}
					
					if (mJR.getCommand() != null) {
						if (!jd.getJobRequest().getCommand().matches(mJR.getCommand())) {
							JRmatches = false;
							continue;
						}
					}
					
					if (mJR.getArguments() != null) {
						if (!jd.getJobRequest().getArguments().matches(mJR.getArguments())) {
							JRmatches = false;
							continue;
						}
					}
					
					if (mJR.getJobName() != null) {
						if (!jd.getJobRequest().getJobName().matches(mJR.getJobName())) {
							JRmatches = false;
							continue;
						}
					}
				}
			} 
		} catch (Exception e) {
			JRmatches = false;
		}
		
		
		if (m_byID && m_byJR) {
			return (IDmatches && JRmatches);
		} 
		
		if (m_byID)
			return IDmatches;
		
		if (m_byJR)
			return JRmatches;		
		
 
		return false;
	}

}
