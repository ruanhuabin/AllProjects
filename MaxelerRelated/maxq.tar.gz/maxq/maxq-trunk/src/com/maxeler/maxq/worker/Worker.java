package com.maxeler.maxq.worker;

import java.util.logging.Level;
import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;
import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;

public class Worker {

	public static final String version = "0.1";
	private static MaxQLogger log = MaxQLogger.getLogger("Worker");
	
	public static void Syntax() {
		log.logf(Level.INFO, "Syntax: maxqWorker --action <start, stop> [--config file]");
		log.logf(Level.INFO, "\t--help, -h : This help message");
		log.logf(Level.INFO, "\t--action, -a <start,stop> : Either start or stop a worker");
		log.logf(Level.INFO, "\t--config,-c <file name> : A path to a worker.conf file");
	}
	
	public static void setVerboseLogging() {
		log.log(Level.INFO, "Verbose logging requested.");
		Globals.minLogLevel = Level.ALL;	
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Logger.ShowLog(false);
		log.logf(Level.INFO, "maxqWorker v"+ version);
		
		if (args.length == 0) {
			Syntax();
			return;
		}
		
		StringBuffer ActionBuffer = new StringBuffer();
		StringBuffer ConfigBuffer = new StringBuffer();
		LongOpt[] longopts = new LongOpt[4];
		longopts[0] = new LongOpt("help", LongOpt.NO_ARGUMENT, null, 'h');
		longopts[1] = new LongOpt("action", LongOpt.REQUIRED_ARGUMENT, ActionBuffer, 'a');
		longopts[2] = new LongOpt("config", LongOpt.REQUIRED_ARGUMENT, ConfigBuffer, 'c');
		longopts[3] = new LongOpt("verbose", LongOpt.NO_ARGUMENT, null, 'v');
		
		
		Getopt g = new Getopt("maxqctl", args, "-:c:f:a:hv", longopts);
		
		Integer c;
		String arg = "";
		String Action = "";
		String Config = "";
		
		while ((c = g.getopt()) != -1) {
			switch (c) {
			case 0:
				arg = g.getOptarg();
				switch (g.getLongind()) {
				case 0:
					Syntax();
					return;
				case 1:
					Action = arg;
					break;
				case 2: 
					Config = arg;
					break;
				case 3:
					setVerboseLogging();
				}
				break;
			case 'a':
				Action = g.getOptarg();
				break;
			case 'c':
				Config = g.getOptarg();
				break;
			case 'v':
				setVerboseLogging();
				break;
			default:
				Syntax();
				return;
			}
		}
		
		String [] OtherArgs = new String[args.length - g.getOptind()];
		for (int i = g.getOptind(); i < args.length; i++)
			OtherArgs[i] = args[i];
		
		if (Action.compareToIgnoreCase("start") == 0) {
			try {
				WorkerConfiguration wc = new WorkerConfiguration(Globals.WorkerConfigPath);
				WorkerServer ws = new WorkerServer(wc, Config);
				ws.Start();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (Action.compareToIgnoreCase("stop") == 0) {
			
		} else {
			Syntax();
			return;
		}

	}

}
