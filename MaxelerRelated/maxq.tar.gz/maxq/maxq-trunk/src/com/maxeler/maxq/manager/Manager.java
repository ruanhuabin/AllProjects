package com.maxeler.maxq.manager;

import java.io.IOException;
import java.util.logging.Level;

import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.controller.commands.CommandRouter;


public class Manager {
	
	private static String m_ManagerAddress = "localhost";
	private static String m_Syntax = "Syntax: MaxQManager <start|stop> [-v,-verbose]";
	private static MaxQLogger log = MaxQLogger.getLogger("Manager");
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		log.logf(Level.INFO, "MaxQ Manager");
		
		if (args.length < 1) {
			log.logf(Level.SEVERE, m_Syntax);
			return;
		}
		
		if (args.length > 1) {
			String s = args[1].replace('-', ' ');
			s = s.trim();
			if (s.equalsIgnoreCase("v") || s.equalsIgnoreCase("verbose")) {
				log.log(Level.INFO, "Verbose logging requested.");
				Globals.minLogLevel = Level.ALL;
			}
		}
		
		if (args[0].compareTo("start") == 0) {
			log.logf(Level.INFO, "Starting Up.");
			ManagerServer ms;
			try {
				ms = new ManagerServer(new ManagerConfiguration(Globals.ManagerConfigPath));
				ms.Start();
			} catch (IOException e) {
				log.log(Level.SEVERE, e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				log.log(Level.SEVERE, e.getMessage());
				e.printStackTrace();
			}
		} else if (args[0].compareTo("stop") == 0) {
			CommandRouter cr = new CommandRouter(m_ManagerAddress, Globals.ManagerPort, "Stop", null, null, null);
			try {
				cr.Execute();
			} catch (Exception e) {
				log.logf(Level.SEVERE, "Failed: %s", e.getMessage());
			}			
		} else {
			log.logf(Level.INFO, m_Syntax);
			return;
		}
		
		
	}	
}
