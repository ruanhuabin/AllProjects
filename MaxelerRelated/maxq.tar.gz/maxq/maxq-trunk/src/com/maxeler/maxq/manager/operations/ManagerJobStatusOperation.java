/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.nio.channels.SelectionKey;
import java.util.logging.Level;

import com.maxeler.maxq.BlockingCommand;
import com.maxeler.maxq.BlockingResponse;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobID;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

/**
 * @author itay
 *
 */
public class ManagerJobStatusOperation extends Operation<ManagerQueryRouter> {

	private boolean m_BlockToCompletion;
	private boolean m_BlockToStarted;
	
	private JobID m_JobID;
	private final transient MaxQLogger log = MaxQLogger.getLogger("ManagerJobStatusOperation");
	/**
	 * @param r
	 */
	public ManagerJobStatusOperation(ManagerQueryRouter r) {
		super("ManagerJobStatusOperation", r);

		State wfwSendBlockCommand = new State("wfwSendBlockCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
		});
		
		State SendBlockCommand = new State("SendBlockCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerJobStatusOperation mjso = (ManagerJobStatusOperation) m_Internal;
				ManagerQueryRouter r = mjso.getRouter();
				try {
					r.getObjectStreams().SendObject(BlockingCommand.SHOULD_BLOCK);
				} catch (Exception e) {
					try {
						return mjso.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}
		});
		
		State wfrBlockResponse = new State("wfrBlockResponse", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadBlockResponse = new State("ReadBlockResponse", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// Read new Job Request
				ManagerJobStatusOperation mjso = (ManagerJobStatusOperation) m_Internal;
				try {
					BlockingResponse br = (BlockingResponse) mjso.getRouter().getObjectStreams().ReceiveObject();
					if (br.equals(BlockingResponse.BLOCK_TO_COMPLETION)) {
						setBlockToCompletion(true);
						setBlockToStarted(false);
					} else if (br.equals(BlockingResponse.BLOCK_TO_STARTED)) {
						setBlockToCompletion(false);
						setBlockToStarted(true);
					} else if (br.equals(BlockingResponse.NON_BLOCKING)) {
						setBlockToCompletion(false);
						setBlockToStarted(false);
					} else {
						return mjso.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						return mjso.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State wfwSendBlockResponseAck = new State("wfwSendBlockResponseAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
		});
		
		State SendBlockResponseAck = new State("SendBlockResponseAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerJobStatusOperation mjso = (ManagerJobStatusOperation) m_Internal;
				ManagerQueryRouter r = mjso.getRouter();
				try {
					r.getObjectStreams().SendObject(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						return mjso.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State wfrReadJobID = new State("wfrReadJobID", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// TODO Auto-generated method stub
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadJobIDAndSetupBlocking = new State("ReadJobIDAndSetupBlocking", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				//ManagerJobStatusOperation mjso = (ManagerJobStatusOperation) m_Internal;
				try {
					JobID jid = (JobID) getRouter().getObjectStreams().ReceiveObject();
					setJobID(jid);
					
					if (shouldBlockToCompletion() || shouldBlockToStarted()) {
						// Set Keep-Alive
						try {
							getRouter().setKeepAlive(true);
						} catch (Exception e) {
							log.logf(Level.WARNING, "Exception while trying to setKeepAlive on socketChannel: %s", e.getMessage());
						}
						
						// Wait For Writable
						return SelectionKey.OP_WRITE;
					}
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State wfwSendJobDescriptorAndBlockIfNeeded = new State("wfwSendJobDescriptorAndBlockIfNeeded",
				new Delegate(this) {
					@Override
					public Integer Invoke(Object param) {
						ManagerJobStatusOperation mjso = (ManagerJobStatusOperation) m_Internal;
						
						log.logf(Level.FINEST, "Job %s: Getting job descriptor", getJobID().getJobIDString());
						WorkerJobDescriptor jd = getRouter().getManagerServer().getJobDescriptor(getJobID());
						log.logf(Level.FINEST, "Job %s: Got job descriptor, shouldBlockToStarted = %s, shouldBlockToCompletion = %s", jd.getJobID().getJobIDString(),
								shouldBlockToStarted(), shouldBlockToCompletion());
						if (shouldBlockToStarted()) {
							if (jd.getInQueue() && !jd.getStarted()) {
								log.logf(Level.FINE, "Queuing Started FSM...");
								getRouter().getManagerServer().QueueStartedFSM(getJobID(), mjso);
								
								return 0;
							}
						} else if (shouldBlockToCompletion()) {							
							if (jd.getRunning() || jd.getInQueue()) {
								log.logf(Level.FINE, "Queuing Completion FSM...");
								getRouter().getManagerServer().QueueCompletionFSM(getJobID(), mjso);

								// Wait For Nothing
								return 0;
							}
						}
						return SelectionKey.OP_WRITE;
					}
		});
		
		State SendJobDescriptor = new State("SendJobDescriptor", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerJobStatusOperation mjso = (ManagerJobStatusOperation) m_Internal;
				ManagerQueryRouter r = mjso.getRouter();
				try {
					WorkerJobDescriptor jd = mjso.getRouter().getManagerServer().getJobDescriptor(mjso.getJobID());
					r.getObjectStreams().SendObject(jd);
					mjso.getRouter().Terminate();
				} catch (Exception e) {
					try {
						return mjso.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					ManagerJobStatusOperation mjso = (ManagerJobStatusOperation) m_Internal;
					mjso.getRouter().Terminate();
				} catch (Exception e) {
				}
				return 0;
			}
		});
		
		AddState(wfwSendBlockCommand);
		AddState(SendBlockCommand);
		AddState(wfrBlockResponse);
		AddState(ReadBlockResponse);
		AddState(wfwSendBlockResponseAck);
		AddState(SendBlockResponseAck);
		AddState(wfrReadJobID);
		AddState(ReadJobIDAndSetupBlocking);
		AddState(wfwSendJobDescriptorAndBlockIfNeeded);
		AddState(SendJobDescriptor);
		AddState(EndState);
		
		setInitialState(wfwSendBlockCommand);
		setCurrentState(wfwSendBlockCommand);
		
		// Wait
		AddTransition(new Transition(wfwSendBlockCommand, SendBlockCommand, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendBlockCommand, wfwSendBlockCommand, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendBlockCommand, EndState, CommonEvents.eERROR_EVENT));

		// Write
		AddTransition(new Transition(SendBlockCommand, ReadBlockResponse, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendBlockCommand, wfrBlockResponse, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendBlockCommand, EndState, CommonEvents.eERROR_EVENT));
				
		// Wait
		AddTransition(new Transition(wfrBlockResponse, ReadBlockResponse, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrBlockResponse, wfrBlockResponse, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrBlockResponse, EndState, CommonEvents.eERROR_EVENT));

		// Read
		AddTransition(new Transition(ReadBlockResponse, SendBlockResponseAck, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(ReadBlockResponse, wfwSendBlockResponseAck, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadBlockResponse, EndState, CommonEvents.eERROR_EVENT));
		
		// Wait
		AddTransition(new Transition(wfwSendBlockResponseAck, SendBlockResponseAck, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendBlockResponseAck, wfwSendBlockResponseAck, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendBlockResponseAck, EndState, CommonEvents.eERROR_EVENT));

		// Write
		AddTransition(new Transition(SendBlockResponseAck, ReadJobIDAndSetupBlocking, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendBlockResponseAck, wfrReadJobID, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendBlockResponseAck, EndState, CommonEvents.eERROR_EVENT));
		
		// Wait
		AddTransition(new Transition(wfrReadJobID, ReadJobIDAndSetupBlocking, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrReadJobID, wfrReadJobID, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrReadJobID, EndState, CommonEvents.eERROR_EVENT));
		
		// Read - we might be waiting for completion of a job
		AddTransition(new Transition(ReadJobIDAndSetupBlocking, wfwSendJobDescriptorAndBlockIfNeeded, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadJobIDAndSetupBlocking, EndState, CommonEvents.eERROR_EVENT));

		// Wait
		AddTransition(new Transition(wfwSendJobDescriptorAndBlockIfNeeded, SendJobDescriptor, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendJobDescriptorAndBlockIfNeeded, wfwSendJobDescriptorAndBlockIfNeeded, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendJobDescriptorAndBlockIfNeeded, EndState, CommonEvents.eERROR_EVENT));
		
		// Write & Finish
		AddTransition(new Transition(SendJobDescriptor, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}
	
	public void setBlockToCompletion(boolean block) {
		m_BlockToCompletion = block;
	}
	
	public void setBlockToStarted(boolean block) {
		m_BlockToStarted = block;
	}
	
	public boolean shouldBlockToCompletion() {
		return m_BlockToCompletion;
	}
	
	public boolean shouldBlockToStarted() {
		return m_BlockToStarted;
	}
	
	public void setJobID(JobID jid) {
		m_JobID = jid;
	}
	
	public JobID getJobID() {
		return m_JobID;
	}
}
