/**
 * 
 */
package com.maxeler.maxq.worker;

import java.io.Serializable;

import com.maxeler.maxq.manager.KillJobStatus;

/**
 * @author itay
 *
 */
public class KillJobResult implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7729516699794682128L;

	private final WorkerJobDescriptor m_jobDescriptor;
	private final KillJobStatus m_killed;
	private final String m_message;

	public KillJobResult(WorkerJobDescriptor jd, KillJobStatus killed, String msg) {
		m_jobDescriptor = jd;
		m_killed = killed;
		m_message = msg;			
	}

	public WorkerJobDescriptor getJobDescriptor() {
		return m_jobDescriptor;
	}

	public KillJobStatus getStatus() {
		return m_killed;
	}

	public String getMessage() {
		return m_message;
	}
}
