/**
 * 
 */
package com.maxeler.maxq.worker.operations;

import java.nio.channels.SelectionKey;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.worker.WorkerConfiguration;
import com.maxeler.maxq.worker.WorkerDiscoverReply;

/**
 * @author itay
 *
 */
public class WorkerDiscoverOperation extends Operation<WorkerQueryRouter> {

	private final transient MaxQLogger log = MaxQLogger.getLogger("WorkerDiscoverOperation");
	
	/**
	 * 
	 * @param r
	 */
	public WorkerDiscoverOperation(WorkerQueryRouter r) {
		super("WorkerDiscoverOperation", r);

		State wfwSendWorkerDiscoverReply = new State("wfwSendWorkerDiscoverReply", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		
		State SendWorkerDiscoverReply = new State("SendWorkerDiscoverReply", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerDiscoverOperation wdo = (WorkerDiscoverOperation) m_Internal;
				try {
					// Update Manager Information
					try {
						log.logf(Level.INFO, "Updating manager information: %s:%d", wdo.getRouter().getRemoteAddress(), 
								Globals.ManagerPort);
						wdo.getRouter().getWorkerServer().getWorkerConfiguration().setManagerAddress(wdo.getRouter().getRemoteAddress());
					} catch (Exception ignore) {
						
					}
					
					WorkerConfiguration wc = wdo.getRouter().getWorkerServer().getWorkerConfiguration();
					//log.logf(Level.INFO, "Updating WorkerID with local address: %s", wdo.getRouter().getSocketChannel().socket().getLocalAddress().getHostName());
					//wdo.getRouter().getWorkerServer().getWorkerID().setAddress(wdo.getRouter().getSocketChannel().socket().getLocalAddress().getHostName());
					
					WorkerDiscoverReply wdr = new WorkerDiscoverReply(wdo.getRouter().getWorkerServer().getWorkerID(), wc,
							wdo.getRouter().getWorkerServer().getAvailableResources(), getRouter().getWorkerServer().getRunningJobs().values());
					wdo.getRouter().getObjectStreams().SendObject(wdr);
				} catch (Exception e) {
					try {
						wdo.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});

		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerDiscoverOperation wdo = (WorkerDiscoverOperation) m_Internal;
				wdo.getRouter().Terminate();
				return 0;
			}			
		});
		
		AddState(wfwSendWorkerDiscoverReply);
		AddState(SendWorkerDiscoverReply);
		AddState(EndState);
		setCurrentState(wfwSendWorkerDiscoverReply);
		setInitialState(wfwSendWorkerDiscoverReply);
		
		AddTransition(new Transition(wfwSendWorkerDiscoverReply,SendWorkerDiscoverReply, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendWorkerDiscoverReply,wfwSendWorkerDiscoverReply, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendWorkerDiscoverReply,EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(SendWorkerDiscoverReply,EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(EndState,EndState, CommonEvents.eANY_EVENT));
		CreateDotGraph();
	}
}
