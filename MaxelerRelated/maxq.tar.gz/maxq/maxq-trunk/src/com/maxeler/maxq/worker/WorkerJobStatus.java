package com.maxeler.maxq.worker;

public class WorkerJobStatus {

}
