package com.maxeler.maxq.worker;

public enum WorkerQueryCommands {
	DISCOVER,
	RUNNING
}
