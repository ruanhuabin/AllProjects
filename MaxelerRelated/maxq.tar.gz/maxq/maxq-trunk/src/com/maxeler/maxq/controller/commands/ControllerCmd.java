package com.maxeler.maxq.controller.commands;

import java.io.IOException;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.controller.ControllerClient;


public class ControllerCmd extends FSM {

	CommandRouter m_cr;
	ControllerClient m_cc;
	Delegate m_OnCommandCompletion;
	private final transient MaxQLogger log = MaxQLogger.getLogger("ControllerCmd");
	
	public ControllerCmd(String CommandName, CommandRouter cr, Delegate OnCommandCompletion) throws Exception {
		super(CommandName);
		m_cr = cr;
		m_OnCommandCompletion = OnCommandCompletion;
		try {
			log.logf(Level.FINEST, "Instantiating ControllerClient for %s:%d (cmd: %s)", cr.getServerName(), cr.getPortNumber(), CommandName);
			m_cc = new ControllerClient(cr.getServerName(), cr.getPortNumber());
		} catch (IOException ioe) {
			throw new Exception("Cannot connect to " + cr.getServerName() + ":" + cr.getPortNumber() + " -> " + ioe.getMessage());
		}
	}

	public CommandRouter getCommandRouter() {
		return m_cr;
	}

	public ControllerClient getControllerClient() {
		return m_cc;
	}
	
	public Delegate getOnCommandCompletion() {
		return m_OnCommandCompletion;
	}
}
