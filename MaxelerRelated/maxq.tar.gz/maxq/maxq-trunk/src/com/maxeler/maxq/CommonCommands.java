package com.maxeler.maxq;

/**
 * @description: Basic commands that can be given to the Manager
 * 				 These will usually be proceeded by a more specific command object. 
 */

public enum CommonCommands {
	// A general status query
	STATUS,
	// A query retrieves information
	QUERY,
	// A request submits work
	REQUEST,
	// A notification submits information
	NOTIFY,
	// Stop/Shutdown/Terminate/Die
	STOP
}




















