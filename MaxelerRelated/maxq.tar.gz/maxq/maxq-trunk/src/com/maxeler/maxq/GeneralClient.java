/**
 * 
 */
package com.maxeler.maxq;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.util.logging.Level;

/**
 * @author itay
 *
 */
public abstract class GeneralClient {
	
	private final transient MaxQLogger log = MaxQLogger.getLogger("GeneralClient");
//	private SocketChannel m_sChannel;
	private final GeneralClientByteChannel m_Channel;
	private Socket m_Socket;
	private final String m_ServerName;
	
	class GeneralClientByteChannel implements ByteChannel {
		
		private final Socket m_Socket;
	//	private final ReadableByteChannel rbc;
	//	private final WritableByteChannel wbc;

		public GeneralClientByteChannel(Socket socket) throws IOException {
			m_Socket = socket;
			//rbc = Channels.newChannel(m_Socket.getInputStream());
			//wbc = Channels.newChannel(m_Socket.getOutputStream());
		}		
	
		@Override
		public boolean isOpen() {
			return m_Socket.isConnected();
			//return wbc.isOpen() && rbc.isOpen();
		}
	
		@Override
		public void close() {
			/*try {
				rbc.close();
			} catch (IOException e) {
			}*/
			/*try {
				wbc.close();
			} catch (IOException e) {
				e.printStackTrace();
			}*/
			try {
				m_Socket.close();
			} catch (IOException e) {
			}
		}
	
		@Override
		public int read(ByteBuffer dst) throws IOException {
			int size = m_Socket.getInputStream().read(dst.array(), dst.position(), dst.remaining());
			if (size > -1)	dst.position(dst.position()+size);
			return size;
			//return rbc.read(dst);
		}
		
		@Override
		public int write(ByteBuffer src) throws IOException {
			m_Socket.getOutputStream().write(src.array(), src.position(), src.remaining());
			src.position(src.limit());
			return src.limit();
			//return wbc.write(src);
		}
		
		public void setKeepAlive(boolean keepAlive) throws SocketException {
			m_Socket.setKeepAlive(keepAlive);
		}
		
	}
	
	protected GeneralClient(String ServerName, int port) throws IOException {
		m_ServerName = ServerName;
		IOException lastException = null;
		/*m_sChannel = SocketChannel.open();
		m_sChannel.configureBlocking(true);
		m_sChannel.connect(new InetSocketAddress(ServerName, port));
		m_sChannel.finishConnect();*/
		SocketAddress sa = new InetSocketAddress(ServerName, port);
		for (int retry = 0; retry < Globals.ClientSocketConnectRetries; retry--) {
			try {
				m_Socket = new Socket();
				m_Socket.connect(sa, Globals.ClientSocketTimeout);
				lastException = null;
				break;
			} catch (SocketTimeoutException e) {
				log.logf(Level.FINE, "Attempt %d: Timed out while trying to connect: %s", retry, e.getMessage());
				m_Socket = null;
				lastException = e;
			}
		}
		
		if (m_Socket == null) throw lastException;
		m_Socket.setSoTimeout(Globals.ClientSocketTimeout);
		m_Socket.setSoLinger(true, Globals.ClientSocketLinger);
		m_Channel = new GeneralClientByteChannel(m_Socket);
		try {
			Ready(m_Channel, ServerName);
		} catch (Exception e) {
			throw new IOException(e.getMessage(), e); 
		}
	}
	
	public void Close()  {
		m_Channel.close();
		log.log(Level.FINEST, "Closed.");
	}
	
	protected abstract void Ready(ByteChannel bc, String remoteName) throws Exception;
	
	public void setKeepAlive(boolean keepAlive) {
		try {
			m_Channel.setKeepAlive(keepAlive);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public void setBlocking(boolean on) {
		try {
			m_Socket.setSoTimeout(on ? 0 : Globals.ClientSocketTimeout);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public String getRemoteName() {
		return m_ServerName;
	}
}
