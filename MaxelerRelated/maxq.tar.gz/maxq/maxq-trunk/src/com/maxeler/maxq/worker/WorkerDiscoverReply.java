/**
 * 
 */
package com.maxeler.maxq.worker;

import java.io.Serializable;
import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author itay
 *
 */
public class WorkerDiscoverReply implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9032975126185679141L;
	
	private WorkerConfiguration m_WorkerConfiguration;
	private WorkerResources m_WorkerResources;
	private WorkerID m_WorkerID;
	
	private TreeSet<WorkerJobDescriptor> m_RunningJobs;

	public WorkerDiscoverReply() {
		m_WorkerConfiguration = null;
		m_WorkerResources = null;
		m_RunningJobs = null;
	} 
	/**
	 * 
	 */
	public WorkerDiscoverReply(WorkerID wid, WorkerConfiguration wc, WorkerResources war, Collection<WorkerJobDescriptor> runningJobs) {
		m_WorkerConfiguration = wc;
		m_WorkerResources = war;
		m_WorkerID = wid;
		m_RunningJobs = new TreeSet<WorkerJobDescriptor>(runningJobs);
	}
	
	public WorkerConfiguration getWorkerConfiguration() {
		return m_WorkerConfiguration;		
	}
	
	public WorkerResources getWorkerResources() {
		return m_WorkerResources;		
	}
	
	public WorkerID getWorkerID() {
		return m_WorkerID;
	}
	
	public Set<WorkerJobDescriptor> getRunningJobs() {
		return m_RunningJobs;
	}
}
