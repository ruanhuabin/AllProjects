/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobSearchCriteria;
import com.maxeler.maxq.manager.KillJobResults;
import com.maxeler.maxq.manager.ManagerRequestCommands;

/**
 * @author itay
 *
 */
public class ManagerKillJobCmd extends ControllerCmd {

	private final JobSearchCriteria m_JobSearchCriteria;
	private KillJobResults m_KillJobResults; 
	
	/**
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public ManagerKillJobCmd(JobSearchCriteria jsc, CommandRouter cr,
			Delegate OnCommandCompletion) throws Exception {
		super("ManagerKillJobCmd", cr, OnCommandCompletion);
		
		m_JobSearchCriteria = jsc;
		
		State SendRequestCmd = new State("SendRequestCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerKillJobCmd mkjc = (ManagerKillJobCmd) m_Internal;
				try {
					mkjc.getControllerClient().getObjectStreams().SendObject(CommonCommands.REQUEST);
					mkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State ReadRequestElabCmd = new State("ReadRequestElabCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerKillJobCmd mkjc = (ManagerKillJobCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) mkjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.REQUEST_ELAB)) {
						mkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
 					try {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State SendKillJobCmd = new State("SendKillJobCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerKillJobCmd mkjc = (ManagerKillJobCmd) m_Internal;
				try {
					mkjc.getControllerClient().getObjectStreams().SendObject(ManagerRequestCommands.KILL_JOB);
					mkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State ReadKillJobACK = new State("ReadKillJobACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerKillJobCmd mkjc = (ManagerKillJobCmd) m_Internal;
				try {
					ProtocolControlCommands pcc = (ProtocolControlCommands) mkjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (pcc.equals(ProtocolControlCommands.ACK)) {
						mkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
 					try {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State SendJobSearchCriteria = new State("SendJobSearchCriteria", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerKillJobCmd mkjc = (ManagerKillJobCmd) m_Internal;
				try {
					mkjc.getControllerClient().getObjectStreams().SendObject(mkjc.getJobSearchCriteria());
					mkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State ReadKilledJobsResult = new State("ReadKillJobsResults", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerKillJobCmd mkjc = (ManagerKillJobCmd) m_Internal;
				try {
					m_KillJobResults = (KillJobResults) mkjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (mkjc.getOnCommandCompletion() != null) {
						getOnCommandCompletion().Invoke(m_KillJobResults);
					}
					mkjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
 					try {
						mkjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerKillJobCmd mkjc = (ManagerKillJobCmd) m_Internal;
				mkjc.getControllerClient().Close();	
				return 0;
			}			
		});
		
		AddState(SendRequestCmd);
		AddState(ReadRequestElabCmd);
		AddState(SendKillJobCmd);
		AddState(ReadKillJobACK);
		AddState(SendJobSearchCriteria);
		AddState(ReadKilledJobsResult);
		AddState(EndState);
		
		setCurrentState(SendRequestCmd);
		setInitialState(SendRequestCmd);
		
		AddTransition(new Transition(SendRequestCmd, ReadRequestElabCmd, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadRequestElabCmd, SendKillJobCmd, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendKillJobCmd, ReadKillJobACK, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadKillJobACK, SendJobSearchCriteria, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendJobSearchCriteria, ReadKilledJobsResult, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadKilledJobsResult, EndState, CommonEvents.eSTEP_EVENT));
		
		
		AddTransition(new Transition(SendRequestCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadRequestElabCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendKillJobCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadKillJobACK, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendJobSearchCriteria, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadKilledJobsResult, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}
	
	public JobSearchCriteria getJobSearchCriteria() {
		return m_JobSearchCriteria;
	}
	
	public KillJobResults getKillJobResults() {
		return m_KillJobResults;
	}
}
