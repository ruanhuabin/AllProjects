package com.maxeler.maxq.manager;

import java.util.List;
import java.util.Map;

import com.maxeler.maxq.FSM.FSM;

public class CompletionNotificationThread extends EventNotificationThread {
	
	private final ManagerServer m_Manager;

	public CompletionNotificationThread(ManagerServer ms) {
		super(ms, "completed");
		m_Manager = ms;
	}

	@Override
	public void doPostNotificationCleanup(JobID jid) {
	}

	@Override
	public Map<JobID, List<FSM>> getMap() {
		return m_Manager.getState().getCompletionKeys();
	}

}
