package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerNotifyCommands;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

public class NotifyManagerJobCompleteCmd extends ControllerCmd {

	private WorkerJobDescriptor m_CompletedJobDescriptor;
	private boolean m_Success = false;
	
	public NotifyManagerJobCompleteCmd(WorkerJobDescriptor completedJobDescriptor, 
			CommandRouter cr, Delegate OnCommandCompletion) throws Exception {
		super("NotifyManagerJobCompleteCmd_" + completedJobDescriptor.getJobID().getJobIDString(), cr, OnCommandCompletion);
		m_CompletedJobDescriptor = completedJobDescriptor;
		
		State SendNotifyCommand = new State("SendNotifyCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyManagerJobCompleteCmd njcc = (NotifyManagerJobCompleteCmd) m_Internal;
				try {
					njcc.getControllerClient().getObjectStreams().SendObject(CommonCommands.NOTIFY);
					njcc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return njcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0; // Controller commands are blocking commands, so it has no effect
			}			
		});
		
		State ReadNotifyElab = new State("ReadNotifyElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyManagerJobCompleteCmd njcc = (NotifyManagerJobCompleteCmd) m_Internal;
				try {
					CommonResponses cr =  (CommonResponses) njcc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.NOTIFY_ELAB)) {
						njcc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						njcc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						e.printStackTrace();
						njcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State SendNotifyJobCompleteCommand = new State("SendNotifyJobCompleted", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyManagerJobCompleteCmd njcc = (NotifyManagerJobCompleteCmd) m_Internal;
				try {
					njcc.getControllerClient().getObjectStreams().SendObject(ManagerNotifyCommands.JOB_COMPLETED);
					njcc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return njcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
			
		});
		
		State ReadNotifyJobCompleteCommandACK = new State("ReadNotifyJobCompleteCommandACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyManagerJobCompleteCmd njcc = (NotifyManagerJobCompleteCmd) m_Internal;
				try {
					ProtocolControlCommands pcc =  (ProtocolControlCommands) njcc.getControllerClient().getObjectStreams().ReceiveObject();
					if (pcc.equals(ProtocolControlCommands.ACK)) {
						njcc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						njcc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						njcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State SendJobDescriptor = new State("SendJobDescriptor", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyManagerJobCompleteCmd njcc = (NotifyManagerJobCompleteCmd) m_Internal;
				try {
					njcc.getControllerClient().getObjectStreams().SendObject(njcc.getCompletedJobDescriptor());
					m_Success = true;
					return njcc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return njcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyManagerJobCompleteCmd njcc = (NotifyManagerJobCompleteCmd) m_Internal;
				try {
					njcc.getControllerClient().Close();
				} catch (Exception e) {
				}
				return 0;
			}			
		});
		
		AddState(SendNotifyCommand);
		AddState(ReadNotifyElab);
		AddState(SendNotifyJobCompleteCommand);
		AddState(ReadNotifyJobCompleteCommandACK);
		AddState(SendJobDescriptor);
		AddState(EndState);
		setInitialState(SendNotifyCommand);
		setCurrentState(SendNotifyCommand);
		
		AddTransition(new Transition(SendNotifyCommand, ReadNotifyElab, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadNotifyElab, SendNotifyJobCompleteCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendNotifyJobCompleteCommand, ReadNotifyJobCompleteCommandACK, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadNotifyJobCompleteCommandACK, SendJobDescriptor, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendJobDescriptor, EndState, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(SendNotifyCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadNotifyElab, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendNotifyJobCompleteCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadNotifyJobCompleteCommandACK, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendJobDescriptor, EndState, CommonEvents.eERROR_EVENT));
		
		CreateDotGraph();
	}

	public WorkerJobDescriptor getCompletedJobDescriptor() {
		return m_CompletedJobDescriptor;
	}
	
	public boolean isSuccess() {
		return m_Success;
	}
}
