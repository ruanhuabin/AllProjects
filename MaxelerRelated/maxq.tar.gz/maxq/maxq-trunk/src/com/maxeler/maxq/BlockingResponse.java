package com.maxeler.maxq;

public enum BlockingResponse {
	BLOCK_TO_COMPLETION,
	BLOCK_TO_STARTED,	
	NON_BLOCKING
}
