package com.maxeler.maxq.worker;

import java.io.Serializable;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.logging.Level;

import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.MaxQProperties;
import com.maxeler.maxq.manager.JobID;

public class JobRequest implements Serializable, Comparable<JobRequest> {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6857565355454115035L;


	public static final String SpecialTags = "exclusive"; 
	
	
	String m_TempDirectory;
	
	Integer m_SubmitIndex = 0;
	String m_JobName;
	String m_WorkingDirectory;
	String m_Command;
	String m_Arguments;
	String m_GroupName;
	Integer m_Timeout = 0;
	Hashtable<String, String> m_Environment;
	Date m_Date;
	Integer m_Priority;
	String m_umaskCmd = "";
	
		Boolean m_NotifyControllerOnComplete;
	String m_ControllerAddress; 
	Integer m_ControllerPort;
	String m_Username;
	Hashtable<String, Integer> m_SpecialTags = new Hashtable<String, Integer>();
	
	WorkerResources m_RequiredResources;
	private String m_Message;
	
	public JobRequest() {
		// empty
	}
	
	public JobRequest(String JobName, String cmd, String args, 
			String workingDirectory, WorkerResources wr) {
		
		m_RequiredResources = wr;
		m_RequiredResources.setOwner(this);
		m_JobName = JobName;
		m_Command = cmd;
		m_Arguments = args;
		m_WorkingDirectory = workingDirectory;

		m_GroupName = "defaultGroupName_" + new Date().toString().replace(' ', '_').replace(':', '.');
		m_Date = new Date();
		m_Environment = new Hashtable<String, String>();
		m_Environment.putAll(System.getenv()); // Copy current environment
		m_Priority = 1;
		m_NotifyControllerOnComplete = true;
		m_ControllerAddress = System.getenv("HOSTNAME");
		m_ControllerPort = Globals.ControllerPort;
		m_Username = System.getenv("USER");
		m_umaskCmd = getUmask();

		if (m_Username == null) // 'USER' is not defined on windows systems
		{
			m_Username = System.getenv("USERNAME");
		}
		
	}
	
	public WorkerResources getRequiredResources() {
		return m_RequiredResources;
	}
	
	public static JobRequest BuildFromOptions(String option_str) {
		Map<String, String> params = new HashMap<String, String>();
		
		for(String kv_pair_str : option_str.split(",")) {			
			String[] kv_pair_array = kv_pair_str.split("=");
			params.put(kv_pair_array[0].trim(), kv_pair_array[1].trim());
		}
		
		return BuildFromMaxQProperties( new MaxQProperties(params) );
	}
		
	public static JobRequest BuildFromFile(String path) {
		MaxQProperties p;
		try {
			p = new MaxQProperties(path);
		} catch(Exception e) {
			MaxQLogger.getLogger("JobRequest").logf(Level.SEVERE, "JobRequest: failed: " + e.getMessage());
			return null;
		}
		
		return BuildFromMaxQProperties(p);
	}
	
	public static JobRequest BuildFromMaxQProperties(MaxQProperties p) {
		JobRequest jr = null;
		try {
			Hashtable<String, String> env = new Hashtable<String, String>();
			String prop = p.getProperty("env");
			if (prop != null) {
				String [] EnvArray = prop.split(",");
				for (String envItem : EnvArray) {
					String [] KeyValPair = envItem.split(":");
					if (KeyValPair.length > 1) {
						env.put(KeyValPair[0].trim(), KeyValPair[1].trim());
					}
				}
			}
			
			
			Boolean NotifyControllerOnComplete = true;
			String ControllerAddress = System.getenv("HOSTNAME");
			Integer ControllerPort = Globals.ControllerPort;
			prop = p.getProperty("notify_controller_on_complete");
			if (prop != null) {
				NotifyControllerOnComplete = Boolean.parseBoolean(prop);
			}
			prop = p.getProperty("controller_address");
			if (prop != null) {
				String [] AddrPort = prop.split(":");
				ControllerAddress = AddrPort[0];
				ControllerPort = AddrPort.length > 1 ? Integer.decode(AddrPort[1]) : Globals.ControllerPort;
			}
			
			String username = p.getProperty("user");
			if (username == null) {				
				username = System.getenv("USER");
				if (username == null) // 'USER' is not defined on windows systems
				{
					username = System.getenv("USERNAME");					
				}
			}
			
			String [] tags = p.getProperty("tags", "").split(" ");
			TreeSet<String> tag_tree = new TreeSet<String>();
			Hashtable<String, Integer> specialTags = new Hashtable<String, Integer>();
			for (String tag : tags) {
				tag = tag.toLowerCase();
				if (SpecialTags.contains(tag)) {
					if (specialTags.containsKey(tag)) {
						specialTags.put(tag, specialTags.get(tag) + 1);
					} else {
						specialTags.put(tag, 1);
					}
				} else {
					tag_tree.add(tag);
				}
			}
			
			
			String umaskCommand = getUmask();
			
			if (umaskCommand == null) {
				MaxQLogger.getLogger("JobRequest").logf(Level.SEVERE, "Could not find umask... running on windows?");
			}
			
			WorkerResources resources = new WorkerResources(Float.parseFloat(p.getProperty("cores", "1")), Integer.parseInt(p.getProperty("mem", "256")), 
					tag_tree);
			
			resources.requireWorker(p.getProperty("worker", null));
			
			jr = new JobRequest(p.getProperty("name", username + "_defaultName"), p.getProperty("command"), p.getProperty("args"),
					p.getProperty("wd", System.getenv("PWD")), resources);
			
			jr.setGroupName(p.getProperty("group", username + "_defaultGroupName"));
			jr.setEnvironment(env, true); 
			jr.setPriority(Integer.parseInt(p.getProperty("priority", "5")));
			jr.setTimeout(Integer.parseInt(p.getProperty("timeout", "0")));
			jr.setNotifyControllerOnComplete(NotifyControllerOnComplete);
			jr.setControllerAddress(ControllerAddress);
			jr.setControllerPort(ControllerPort);
			jr.setUsername(username);
			jr.setSpecialTags(specialTags);
			jr.setUmaskCmd(umaskCommand);
		} catch (Exception e) {
			MaxQLogger.getLogger("JobRequest").logf(Level.SEVERE, "JobRequest: failed: " + e.getMessage());
			return null;
		}
		return jr;
	}

	public static String getUmask() {
		// Find umask
		ProcessBuilder pb = new ProcessBuilder("/bin/sh", "-c", "umask -p");
		Process umaskProc;
		String umaskCommand = null;
		try {
			umaskProc = pb.start();
			umaskProc.waitFor();			
			if (umaskProc.exitValue() == 0) {
				List<String> umaskOut = WorkerJobDescriptor.readStdOut(umaskProc);
				if (umaskOut.size() == 1) {
					umaskCommand = umaskOut.get(0);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return umaskCommand;
	}

	
	public String getJobName() {
		return m_JobName;
	}

	public void setJobName(String jobName) {
		if (jobName != null)
			m_JobName = jobName;
	}

	public String getWorkingDirectory() {
		return m_WorkingDirectory;
	}

	public void setWorkingDirectory(String workingDirectory) {
		if (workingDirectory != null)
			m_WorkingDirectory = workingDirectory;
	}

	public String getCommand() {
		return m_Command;
	}

	public void setCommand(String command) {
		if (command != null)
			m_Command = command;
	}

	public String getArguments() {
		return m_Arguments;
	}

	public void setArguments(String arguments) {
		if (arguments != null)
			m_Arguments = arguments;
	}

	public String getGroupName() {
		return m_GroupName;
	}

	public void setGroupName(String groupName) {
		if (groupName != null)
			m_GroupName = groupName;
	}

	public Hashtable<String, String> getEnvironment() {
		return m_Environment;
	}

	public void setEnvironment(Hashtable<String, String> environment, boolean append) {
		if (environment != null) {
			if (append) {
				m_Environment.putAll(environment);
			} else {
				m_Environment = environment;
			}
			
		}
	}
	
	public void deleteEnvironmentVar(String key) {
		m_Environment.remove(key);
	}

	public Integer getPriority() {
		return m_Priority;
	}

	public void setPriority(Integer priority) {
		if (priority != null)
			m_Priority = priority;
	}

	public Boolean getNotifyControllerOnComplete() {
		return m_NotifyControllerOnComplete;
	}

	public void setNotifyControllerOnComplete(Boolean notifyControllerOnComplete) {
		if (notifyControllerOnComplete != null)
			m_NotifyControllerOnComplete = notifyControllerOnComplete;
	}

	public String getControllerAddress() {
		return m_ControllerAddress;
	}

	public void setControllerAddress(String controllerAddress) {
		if (controllerAddress != null)
			m_ControllerAddress = controllerAddress;
	}

	public Integer getControllerPort() {
		return m_ControllerPort;
	}

	public void setControllerPort(Integer controllerPort) {
		if (controllerPort != null)
			m_ControllerPort = controllerPort;
	}

	public String getEnvironmentString() {
		String ret = "\n\t";
		Enumeration<String> eKeys = m_Environment.keys();
		if (eKeys.hasMoreElements()) {
			while (eKeys.hasMoreElements()) {
				String key = eKeys.nextElement();
				ret += key + " -> " + m_Environment.get(key);
				if (eKeys.hasMoreElements()) {
					ret += ",\n\t";
				}
			}
		} else {
			ret += "(empty)";
		}
		return ret;
	}

	public JobID getJobID() {
	/*	Integer code = Math.abs(hashCode());
		Integer ix = m_SubmitIndex;
		
		Integer id = ix * 1000 + code % 1000;*/
		return new JobID(m_SubmitIndex);
	}
	
	public Integer getSubmitIndex() {
		return m_SubmitIndex;
	}
	
	public void setSubmitIndex(Integer index) {
		m_SubmitIndex = index;
	}
	
	public String getUsername()	{
		return m_Username;
	}
	
	public void setUsername(String username) {
		m_Username = username;
	}
	
	public void setTempDirectory(String tmp) {
		m_TempDirectory = tmp;
	}
	
	public String getTempDirectory() {
		return m_TempDirectory;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((m_Arguments == null) ? 0 : m_Arguments.hashCode());
		result = prime * result
				+ ((m_Command == null) ? 0 : m_Command.hashCode());
		result = prime
				* result
				+ ((m_ControllerAddress == null) ? 0 : m_ControllerAddress
						.hashCode());
		result = prime
				* result
				+ ((m_ControllerPort == null) ? 0 : m_ControllerPort.hashCode());
		result = prime * result + ((m_Date == null) ? 0 : m_Date.hashCode());
		result = prime * result
				+ ((m_Environment == null) ? 0 : m_Environment.hashCode());
		result = prime * result
				+ ((m_GroupName == null) ? 0 : m_GroupName.hashCode());
		result = prime * result
				+ ((m_JobName == null) ? 0 : m_JobName.hashCode());
		result = prime
				* result
				+ ((m_NotifyControllerOnComplete == null) ? 0
						: m_NotifyControllerOnComplete.hashCode());
		result = prime * result
				+ ((m_Priority == null) ? 0 : m_Priority.hashCode());
		result = prime
				* result
				+ ((m_WorkingDirectory == null) ? 0 : m_WorkingDirectory
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final JobRequest other = (JobRequest) obj;
		if (m_Arguments == null) {
			if (other.m_Arguments != null)
				return false;
		} else if (!m_Arguments.equals(other.m_Arguments))
			return false;
		if (m_Command == null) {
			if (other.m_Command != null)
				return false;
		} else if (!m_Command.equals(other.m_Command))
			return false;
		if (m_ControllerAddress == null) {
			if (other.m_ControllerAddress != null)
				return false;
		} else if (!m_ControllerAddress.equals(other.m_ControllerAddress))
			return false;
		if (m_ControllerPort == null) {
			if (other.m_ControllerPort != null)
				return false;
		} else if (!m_ControllerPort.equals(other.m_ControllerPort))
			return false;
		if (m_Date == null) {
			if (other.m_Date != null)
				return false;
		} else if (!m_Date.equals(other.m_Date))
			return false;
		if (m_Environment == null) {
			if (other.m_Environment != null)
				return false;
		} else if (!m_Environment.equals(other.m_Environment))
			return false;
		if (m_GroupName == null) {
			if (other.m_GroupName != null)
				return false;
		} else if (!m_GroupName.equals(other.m_GroupName))
			return false;
		if (m_JobName == null) {
			if (other.m_JobName != null)
				return false;
		} else if (!m_JobName.equals(other.m_JobName))
			return false;
		if (m_NotifyControllerOnComplete == null) {
			if (other.m_NotifyControllerOnComplete != null)
				return false;
		} else if (!m_NotifyControllerOnComplete
				.equals(other.m_NotifyControllerOnComplete))
			return false;
		if (m_Priority == null) {
			if (other.m_Priority != null)
				return false;
		} else if (!m_Priority.equals(other.m_Priority))
			return false;
		if (m_WorkingDirectory == null) {
			if (other.m_WorkingDirectory != null)
				return false;
		} else if (!m_WorkingDirectory.equals(other.m_WorkingDirectory))
			return false;
		
		if (m_Timeout == null) {
			if (other.m_Timeout != null)
				return false;
		} else if (!m_Timeout.equals(other.m_Timeout))
			return false;
		
		return true;
	}

	@Override
	public int compareTo(JobRequest o) {
		//System.out.print("Compare: --> ");
		if (o != null) {
			//System.out.printf("(1: p=%d i=%d, 2: p=%d i=%d) --> ", getPriority(), getSubmitIndex(), o.getPriority(), o.getSubmitIndex());
			if (getPriority().equals(o.getPriority())) {
				int ret = getSubmitIndex().compareTo(o.getSubmitIndex());
				//System.out.printf("ret: 1 %s 2\n", ret > 0 ? ">" : ret == 0 ? "=" : "<");
				return ret;
			}
			int ret = o.getPriority().compareTo(getPriority());
			//System.out.printf("ret: 1 %s 2\n", ret > 0 ? ">" : ret == 0 ? "=" : "<");
			return ret;
		}
		return 1;
	}
	
	private String getString(String s) {
		if (s== null) {
			return "null";
		}
		return s;
	}
	
	@Override
	public String toString() {
		String name = "(name=" + getString(m_JobName) + ", group=" + getString(m_GroupName) + ", command=" + getString(m_Command)+", user="+ getString(m_Username) +")";
		return name;
	}

	public Integer getTimeout() {
		return m_Timeout;
	}

	public void setTimeout(int seconds) {
		m_Timeout = seconds;
	}

	public Hashtable<String, Integer> getSpecialTags() {
		return m_SpecialTags;
	}

	public void setSpecialTags(Hashtable<String, Integer> specialTags) {
		m_SpecialTags = specialTags;
	}
	
	public String getUmaskCmd() {
		return m_umaskCmd;
	}

	public void setUmaskCmd(String cmd) {
		m_umaskCmd = cmd;
	}
	
	public void setMessage(String msg) {
		m_Message = msg;
	}

	public String getMessage() {
		return m_Message;
	}
}
