/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.nio.channels.SelectionKey;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobToken;
import com.maxeler.maxq.worker.JobRequest;


/**
 * @author itay
 *
 */
public class ManagerNewJobOperation extends Operation<ManagerRequestRouter> {

	private JobToken m_JobToken;
	private final transient MaxQLogger log = MaxQLogger.getLogger("ManagerNewJobOperation");
	/**
	 * @param FSMName
	 * @param r
	 */
	public ManagerNewJobOperation(ManagerRequestRouter r) {
		super("ManagerNewJobOperation", r);
		
		State wfwNewJobOperationAck = new State("wfwNewJobOperationAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
		});
		
		State SendNewJobOperationAck = new State("SendNewJobOperationAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobOperation mnjo = (ManagerNewJobOperation) m_Internal;
				ManagerRequestRouter r = mnjo.getRouter();
				try {
					r.getObjectStreams().SendObject(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						return r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}
		});
		
		State wfrNewJobRequest = new State("wfrNewJobRequest", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadNewJobRequest = new State("ReadNewJobRequest", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// Read new Job Request
				ManagerNewJobOperation mnjo = (ManagerNewJobOperation) m_Internal;
				try {
					JobRequest jr = (JobRequest) mnjo.getRouter().getObjectStreams().ReceiveObject();
					log.log(Level.INFO, "Trying to queue Job... ");
					log.logf(Level.FINE, "\n------------------------------------\n" +
							"\tUsername: %s\n" +
							"\tWorkingDirectory: %s\n" +
							"\tCommand: %s\n" +
							"\tArguments: %s\n" +
							"\tCores: %f\n" +
							"\tMemory: %d\n" +
							"\tTags: %s\n" +
							"\tGroup: %s\n" +
							"\tSpecific Worker: %s\n" +
							//"\tEnviorment: %s\n" +
							"------------------------------------", 
							jr.getUsername(),
							jr.getWorkingDirectory(), jr.getCommand(),
							jr.getArguments(), jr.getRequiredResources().getConfiguredCores(), jr.getRequiredResources().getConfiguredMemory(),
							jr.getRequiredResources().getTags(), jr.getGroupName(), 
							jr.getRequiredResources().getRequiredWorkerName() /*, jr.getEnviormentString()*/);
					
					// We have a job request, pass it on to the manager server
					JobToken jt = mnjo.getRouter().getManagerServer().QueueJob(jr);
					if (jt.isValid()) {
						log.logf(Level.INFO, "[%d] Job %s Queued.", jr.getSubmitIndex(), jr.getJobID().getJobIDString());
					} else {
						log.logf(Level.INFO, "Failed Queuing job %s: %s", jr.getJobID().getJobIDString(), jt.getMessage());
					}
					mnjo.setJobToken(jt);
					} catch (Exception e) {
						try {
							return mnjo.HandleEvent(CommonEvents.eERROR_EVENT);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State wfwSendNewJobToken = new State("wfwSendNewJobToken", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
		});
		
		State SendNewJobToken = new State("SendNewJobToken", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getRouter().getObjectStreams().SendObject(getJobToken());
					return HandleEvent(CommonEvents.eANY_EVENT);					
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getRouter().Terminate();
				} catch (Exception e) {
				}
				return 0;
			}
		});
		
		AddState(wfwNewJobOperationAck);
		AddState(SendNewJobOperationAck);
		AddState(wfrNewJobRequest);
		AddState(ReadNewJobRequest);
		AddState(wfwSendNewJobToken);
		AddState(SendNewJobToken);
		AddState(EndState);
		setInitialState(wfwNewJobOperationAck);
		setCurrentState(wfwNewJobOperationAck);
		
		// Wait
		AddTransition(new Transition(wfwNewJobOperationAck, SendNewJobOperationAck, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwNewJobOperationAck, wfwNewJobOperationAck, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwNewJobOperationAck, EndState, CommonEvents.eERROR_EVENT));

		// Write
		AddTransition(new Transition(SendNewJobOperationAck, ReadNewJobRequest, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendNewJobOperationAck, wfrNewJobRequest, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendNewJobOperationAck, EndState, CommonEvents.eERROR_EVENT));
				
		// Wait
		AddTransition(new Transition(wfrNewJobRequest, ReadNewJobRequest, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrNewJobRequest, wfrNewJobRequest, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrNewJobRequest, EndState, CommonEvents.eERROR_EVENT));

		// Read
		AddTransition(new Transition(ReadNewJobRequest, SendNewJobToken, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(ReadNewJobRequest, wfwSendNewJobToken, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadNewJobRequest, EndState, CommonEvents.eERROR_EVENT));
		
		// Wait
		AddTransition(new Transition(wfwSendNewJobToken, SendNewJobToken, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendNewJobToken, wfwSendNewJobToken, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendNewJobToken, EndState, CommonEvents.eERROR_EVENT));

		// Write & Finish
		AddTransition(new Transition(SendNewJobToken, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}
	
	public void setJobToken(JobToken jt) {
		m_JobToken = jt;
	}
	
	public JobToken getJobToken() {
		return m_JobToken;
	}

}
