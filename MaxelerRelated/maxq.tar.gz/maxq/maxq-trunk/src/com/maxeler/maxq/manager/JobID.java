/**
 * 
 */
package com.maxeler.maxq.manager;

import java.io.Serializable;

/**
 * @author itay
 *
 */
public class JobID implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3730061258711525683L;
	
	private Integer m_JobIDCode;
	
	public String toString() {
		return getJobIDString();
	}
	
	public JobID(Integer jidc) {
		m_JobIDCode = jidc;
	}
	
	public Integer getJobIDCode() {
		return m_JobIDCode;
	}
	
	public String getJobIDString() {
		return m_JobIDCode.toString();
	}

	@Override
	public int hashCode() {
		return m_JobIDCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		
		if (!obj.getClass().equals(getClass())) {
			return false;
		}

		final JobID other = (JobID) obj;

		return m_JobIDCode.equals(other.getJobIDCode());
	}
	
	
}
