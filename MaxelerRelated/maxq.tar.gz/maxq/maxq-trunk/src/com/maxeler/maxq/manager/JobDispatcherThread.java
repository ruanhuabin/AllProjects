/**
 * 
 */
package com.maxeler.maxq.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Stoppable;
import com.maxeler.maxq.controller.commands.CommandRouter;
import com.maxeler.maxq.controller.commands.WorkerNewJobCmd;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.WorkerID;
import com.maxeler.maxq.worker.WorkerJobDescriptor;
import com.maxeler.maxq.worker.WorkerResources;

/**
 * @author itay
 * 
 */
public class JobDispatcherThread implements Runnable, Stoppable, Comparable<Object> {

	private final ManagerServer m_ManagerServer;
	private Boolean m_Stopping;
	private Thread m_Thread;
	
	
	enum FindWorkersCriteria {
		FIND_BY_CAPABILITY,
		FIND_BY_AVAILABILITY
	}
	
	private final transient MaxQLogger log = MaxQLogger.getLogger("JobDispatcherThread");
	//private static WorkerID LastWorker = null;

	/**
	 * 
	 */
	public JobDispatcherThread(ManagerServer ms) {
		m_ManagerServer = ms;
		m_Stopping = false;
	}
	
	public void Start() {
		m_Thread = new Thread(this, "maxq_job_dispatcher");
		m_Thread.start();
	}

	@Override
	public void run() {		
			while (!m_Stopping) {
				try {
					log.logf(Level.FINE, "Going to sleep...");
					Thread.sleep(5000);
					log.logf(Level.FINE, "Woke up...");
					while (!m_Stopping && ProcessQueue());
				} catch (InterruptedException ie) {
					log.log(Level.INFO, "Thread Interrupted.");
					return;
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	}

	private boolean ProcessQueue() {
		synchronized (m_ManagerServer.getState()) {
			NavigableSet<JobRequest> jq = m_ManagerServer.getState().getJobQueue();
			if (jq.isEmpty() == true) {
				return false;
			}
			log.logf(Level.FINE, "Processing, queue size: %d...", jq.size());
			JobRequest jr = jq.first();
			
			Map<WorkerID, WorkerResources> all_workers = getManagerServer().getState().getWorkerResources();
			boolean succesfulyProcessed = ProcessRequest(jr, all_workers);
			if (!succesfulyProcessed) {
				if (jq.size() > 1) {
					log.log(Level.FINE, "Checking if some jobs can skip the queue...");
					// Collect all workers who can't run the job
					Map<WorkerID, WorkerResources> incapable = FindWorkers(all_workers, jr.getRequiredResources(), FindWorkersCriteria.FIND_BY_CAPABILITY, true); 
					
					if (incapable.size() > 0) {
						log.logf(Level.FINE, "%d workers can't process next job in queue, searching for jobs to preempt.", incapable.size());
						// Evaluate the entire queue, and search for jobs that can skip ahead				
						// Collect all workers that are available to run these jobs
						List<JobRequest> toRemove = new ArrayList<JobRequest>();
						for (JobRequest candidate : jq) {
							Map<WorkerID, WorkerResources> possibleWorkers = FindWorkers(incapable, candidate.getRequiredResources(), FindWorkersCriteria.FIND_BY_AVAILABILITY, false);
							if (possibleWorkers.size() > 0) {
								log.logf(Level.FINE, "Found %d workers that can handle job %s", possibleWorkers.size(), candidate.getJobID().getJobIDString());
								// Try to submit
								if (ProcessRequest(candidate, possibleWorkers) == true) {
									log.logf(Level.INFO, "Job %s skipped the queue.", candidate.getJobID().getJobIDString());
									toRemove.add(candidate);
								} else {
									break;
								}
							}
						}
						
						for (JobRequest remove : toRemove) {
							jq.remove(remove);
						}
					}
				}
			} else {
				// Processed successfully
				jq.remove(jr);
				return true;			
			}
		}
		return false;
	}
	
	private Boolean ProcessRequest(JobRequest jr, Map<WorkerID, WorkerResources> workerPool) {
		// create a capable worker list
        Map<WorkerID, WorkerResources> available = FindWorkers(workerPool, jr.getRequiredResources(), FindWorkersCriteria.FIND_BY_AVAILABILITY, false);
        log.logf(Level.FINE, "Found %d available workers:", available.size());
        
        for (WorkerID id : available.keySet()) {
        	log.logf(Level.FINEST, "Worker: %s @ %s", id.getName(), id.getAddress());
        }
        
		while (available.isEmpty() == false) {
			WorkerResources war = Collections.min(available.values());
			WorkerID selectedWorker = (WorkerID) war.getOwner();

			try {
				log.logf(Level.INFO, "[%d] Trying to submit Job %s to %s:%d", jr.getSubmitIndex(), jr.getJobID().getJobIDString(), selectedWorker.getAddress(),selectedWorker.getPort());
				// Issue Controller command:
				WorkerNewJobCmd wnjc = new WorkerNewJobCmd(jr, new CommandRouter(selectedWorker.getAddress(),selectedWorker.getPort()),
						new Delegate(this) {
					@Override
					public Integer Invoke(Object param) {
						WorkerJobDescriptor wjd = (WorkerJobDescriptor)param;
						if (wjd != null) {
							if (wjd.getStarted() == true || wjd.getExecutionErrorCode() == 0) {
								wjd.setInQueue(false); // Mark as removed from queue
								getManagerServer().OnJobSubmitted(wjd);
							}
						}
						return 0;
					}
				});
				wnjc.Reset(null); // Execute Sequence

				if (wnjc.getWorkerJobDescriptor() == null) {
					throw new Exception(selectedWorker.getName() +  " returned a NULL job descriptor (" + jr.getJobID().getJobIDString() + ")");
				}
				
				if (wnjc.getWorkerJobDescriptor().getStarted() == false || wnjc.getWorkerJobDescriptor().getExecutionErrorCode() != 0) {
					throw new Exception(selectedWorker.getName() +  " failed to start job " + jr.getJobID().getJobIDString() + ": (" + wnjc.getWorkerJobDescriptor().getExecutionErrorCode() + ") " + wnjc.getWorkerJobDescriptor().getExecutionErrorMessage());
				}
				
				return true; // Success				
			} catch (Exception e) {
				log.logf(Level.SEVERE, "Error: %s", e.getMessage());
				log.logf(Level.SEVERE, "Failed to assign job '%s - %s' to Worker '%s', putting job back in to the queue.", 
						jr.getJobName(), jr.getJobID().getJobIDString(), selectedWorker.getName() + " -> " + selectedWorker.getAddress());

				// Remove selected worker from pool
				available.remove(selectedWorker);
			}
		}

		return false; // Failed to reduce the queue
	}	
	
	private Map<WorkerID, WorkerResources> FindWorkers(Map<WorkerID, WorkerResources> workersPool, WorkerResources resources, 
			FindWorkersCriteria find_criteria, boolean inverse) {
		
		Map<WorkerID, WorkerResources> matching_workers = new Hashtable<WorkerID, WorkerResources>();
		
		for (WorkerID wid : workersPool.keySet()) {
			boolean match = false;
			
			if (find_criteria.equals(FindWorkersCriteria.FIND_BY_AVAILABILITY)) {
				match = workersPool.get(wid).isAvailable(resources);
			} else if (find_criteria.equals(FindWorkersCriteria.FIND_BY_CAPABILITY)) {
				match = workersPool.get(wid).isCapable(resources);
			}
			
			if (match != inverse) {
				matching_workers.put(wid, workersPool.get(wid));
			}			
		}
		return matching_workers;
	}

	@Override
	public void Stop() {
		m_Stopping = true;
		try {
			m_Thread.interrupt();
			m_Thread.join();
		} catch (InterruptedException e) {
		}
	}

	public ManagerServer getManagerServer() {
		return m_ManagerServer;
	}

	@Override
	public int compareTo(Object o) {
		return 1;
	}

}
