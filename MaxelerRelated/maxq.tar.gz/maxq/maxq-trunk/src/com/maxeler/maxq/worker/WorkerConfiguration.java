package com.maxeler.maxq.worker;

import java.io.FileReader;
import java.io.Serializable;
import java.util.Properties;
import java.util.TreeSet;
import java.util.logging.Level;
import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;



public class WorkerConfiguration implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1096160322562311359L;
	
	String m_Name = System.getenv("HOSTNAME");
	Float m_Cores = new Float(1);
	Integer m_Memory = 512;
	TreeSet<String> m_Tags = new TreeSet<String>();
	String m_StateFilePath = Globals.WorkerStateFile;
	Integer m_ListenPort = Globals.WorkerPort;
	String m_ManagerAddress = "127.0.0.1";
	Integer m_ManagerPort = Globals.ManagerPort;
	
	private final transient MaxQLogger log = MaxQLogger.getLogger("WorkerConfiguration");
	
	public WorkerConfiguration(String ConfigPath) throws Exception {
		FileReader fr = new FileReader(ConfigPath);
		Properties pr = new Properties();
		pr.load(fr);
		
		String prop = pr.getProperty("name");
		if (prop != null)
			m_Name = prop;
		
		prop = pr.getProperty("cores");
		if (prop != null) 	
			m_Cores = Float.parseFloat(prop);
		
		prop = pr.getProperty("memory");
		if (prop != null) 	
			m_Memory = Integer.parseInt(prop);
		
		prop = pr.getProperty("tags");
		m_Tags.add("linux");
		if (prop != null) {
			for (String tag : prop.split(" ")) {
				m_Tags.add(tag);
			}
		}
		
		prop = pr.getProperty("state_file");
		if (prop != null)
			m_StateFilePath = prop;
		
		prop = pr.getProperty("listen_port");
		if (prop != null) 	
			m_ListenPort = Integer.parseInt(prop);
		
		prop = pr.getProperty("manager");
		if (prop != null) {
			String [] mgrAddrPort = prop.split(":", 2);
			if (mgrAddrPort.length > 1) {
				m_ManagerPort = Integer.parseInt(mgrAddrPort[1]);
			}
			m_ManagerAddress = mgrAddrPort[0];
		}
		
		
		log.logf(Level.INFO, "Using Configuration:\n\tName: %s\n\tCores: %.2f\n\tMemory: %d\n\tTags: %s\nStateFile: %s\n" +
				"Listen Port: %d\nManager Address: %s\nManager Port: %d\n", 
				getName(), getCores(), getMemory(), getTags(), getStateFilePath(),
				getListenPort(), getManagerAddress(), getManagerPort());
		fr.close();
	}

	public String getName() {
		return m_Name;
	}

	public float getCores() {
		return m_Cores;
	}

	public Integer getMemory() {
		return m_Memory;
	}

	public TreeSet<String> getTags() {
		return m_Tags;
	}	
	
	public String getStateFilePath() {
		return m_StateFilePath;
	}

	public Integer getListenPort() {
		return m_ListenPort;
	}

	public String getManagerAddress() {
		return m_ManagerAddress;
	}

	public Integer getManagerPort() {
		return m_ManagerPort;
	}
	
	public void setManagerAddress(String address) {
		m_ManagerAddress = address;
	}

	public void setManagerPort(Integer port) {
		m_ManagerPort = port;
	}
	
	public WorkerResources getResources() {
		return new WorkerResources(getCores(), getMemory(), getTags());
	}
}
