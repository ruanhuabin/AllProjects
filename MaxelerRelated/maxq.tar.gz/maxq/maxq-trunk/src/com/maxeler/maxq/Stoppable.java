package com.maxeler.maxq;

public interface Stoppable {
	public void Stop();
}
