package com.maxeler.maxq.worker;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.manager.JobID;


/**
 * Contains all the information necessary to query about a process that has
 * been submitted successfully to a workerServer.
 * @author itay
 *
 */
public class WorkerJobDescriptor implements Serializable, Comparable<WorkerJobDescriptor> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6126852438463458271L;
	
	private boolean m_shouldNotifyOnCompletion = true;
	private final JobRequest m_jr;
	private final JobID m_JobID;
	private final WorkerID m_ExecutingWorkerID;
	private String m_LogPath = "Not yet assigned.";
	private String m_ScriptPath = "Not yet assigned.";
	private String m_exitCodePath = "Not yet assigned.";
	private String m_ExitScriptPath = "Not yet assigned.";
	private String m_SubscriptExitCodePath = "Not yet assigned.";
	private String m_SubScriptPath = "Not yet assigned.";
	private int m_ExitCode = 0;
	private int m_PPID = 0;
	private String m_PIDCodePath = "Not yet assigned.";
	private boolean m_Killed = false;
	private boolean m_Started = false;
	private boolean m_Running = false;
	private boolean m_InQueue = false;
	private boolean m_Lost = false;
	private int m_ExecutionErrorCode = 0;
	private String m_ExecutionErrorMessage  = "Not yet assigned.";
	
	private long m_TimeStarted;
	private long m_TimeFinished;
	
	
	public final static transient MaxQLogger log = MaxQLogger.getLogger("WorkerJobDescriptor");
	
	
	public WorkerJobDescriptor(JobRequest jr, JobID jobID, String LogPath, String ScriptPath, String exitCodePath,
			WorkerID ExecutingWorkerID) {
		m_jr = jr;
		m_JobID = jobID;
		m_LogPath = LogPath;
		m_ScriptPath = ScriptPath;
		m_exitCodePath = exitCodePath;
		m_ExecutingWorkerID = ExecutingWorkerID;
		setStarted(ExecutingWorkerID != null);
		setInQueue(ExecutingWorkerID == null);
		setRunning(false);
		setExitCode(0);		
	}

	public void setInQueue(boolean inQueue) {
		m_InQueue = inQueue;		
	}
	
	public boolean getInQueue() {
		return m_InQueue;		
	}

	public JobRequest getJobRequest() {
		return m_jr;
	}

	public JobID getJobID() {
		return m_JobID;
	}

	public String getLogPath() {
		return m_LogPath;
	}

	public String getScriptPath() {
		return m_ScriptPath;
	}

	public String getExitCodeFilePath() {
		return m_exitCodePath;
	}
	
	public WorkerID getExecutingWorkerID() {
		return m_ExecutingWorkerID;
	}

	public int getExitCode() {
		return m_ExitCode;
	}

	public void setExitCode(int exitCode) {
		m_ExitCode = exitCode;
	}

	public boolean getStarted() {
		return m_Started;
	}

	public void setStarted(boolean started) {
		m_Started = started;
	}

	public boolean getRunning() {
		return m_Running;
	}

	public void setRunning(boolean running) {
		m_Running = running;
	}

	public int getExecutionErrorCode() {
		return m_ExecutionErrorCode;
	}
	
	public String getExecutionErrorMessage() {
		return m_ExecutionErrorMessage;
	}

	public void setExecutionError(int executionErrorCode, String executionErrorMsg) {
		m_ExecutionErrorCode = executionErrorCode;
		m_ExecutionErrorMessage = executionErrorMsg;
	}

	public boolean hasBeenKilled() {
		return m_Killed;
	}
	
	public void setKilled(boolean killed) {
		m_Killed = killed;
	}
	
	public boolean isLost() {
		return m_Lost;
	}
	
	public void setLost(boolean lost) {
		m_Lost = lost;
	}

	/**
	 * This command will almost always fail when ran on any host other than the Worker Server
	 * It actively searches for the PID of the process using the PPID.
	 * If the process finished already or for some other reason cannot be found,
	 * the function would return 0. This however, cannot be relied upon to indicate
	 * if the process finished execution or not, for that we have the Query Status method
	 * on the JobToken.
	 * 
	 * @return a set of PIDs that are beneath PPID in the process list
	 */
	public Set<Integer> getPIDs() {
		WorkerJobDescriptor.log.log(Level.FINEST, "getPIDs() called...");
		Set<Integer> pids = findPIDs(getPPID());
		if (pids.size() == 0) {
			WorkerJobDescriptor.log.log(Level.WARNING, "No PIDs found.");
		} else {
			for (int pid : pids) {
				WorkerJobDescriptor.log.logf(Level.FINEST, "Found: %d", pid);
			}
		}
		return pids;
	}
	
	public static Set<Integer> findPIDs(int ppid) {
		String getPidCommand = "ps -Ao ppid,pid";
		Process getPID = null;
		List<String> pidStrings = null;
		Set<Integer> children = new TreeSet<Integer>();  
		Map<Integer, Integer> pairs = new Hashtable<Integer, Integer>();
		SortedSet<Integer> ppids = new TreeSet<Integer>();
		
		WorkerJobDescriptor.log.logf(Level.FINEST, "Searching for PIDs belonging to PPID %d...", ppid);
		try {
			getPID = Runtime.getRuntime().exec(getPidCommand);
			getPID.waitFor();
			pidStrings = readStdOut(getPID);
			for (String pid : pidStrings) {
				Pattern p = Pattern.compile("\\s*(\\d+)\\s+(\\d+)");
				Matcher m = p.matcher(pid);
				if (m.matches()) {
					WorkerJobDescriptor.log.logf(Level.FINEST, "Matched (%s)", pid);
					int ppid_g = Integer.decode(m.group(1)), pid_g = Integer.decode(m.group(2));
					WorkerJobDescriptor.log.logf(Level.FINEST, "Extracted ppid = %d, pid = %d", ppid_g, pid_g);
					pairs.put(ppid_g, pid_g);
					ppids.add(Integer.decode(m.group(1)));
				} else {
					WorkerJobDescriptor.log.logf(Level.FINEST, "NO Match (%s)", pid);
				}
			}
			
			/* 
			 * Since pids are assigned randomly,
			 * we loop over the ppid set and remove every entry that we match.
			 * We stop the loop when we cannot reduce the ppid set further (no pid was found)
			 */
			boolean pid_found = true;
			while (pid_found) {
				pid_found = false;
				SortedSet<Integer> copy = new TreeSet<Integer>(ppids);
				for (int p1 : ppids) {
					//System.out.printf("Checking %d\n", p1);
					if (p1 == ppid || children.contains(p1)) {
						int pid = pairs.get(p1);
						WorkerJobDescriptor.log.logf(Level.FINEST, "FOUND: pid %d", pid);
						children.add(pid);
						copy.remove(p1);
						pid_found = true;
					}
				}
				ppids = copy;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return children;
	}
	
	public static List<String> readStdError(Process p) {
		return readEntireStream(p.getErrorStream());
	}
	
	public static List<String> readStdOut(Process p) {
		return readEntireStream(p.getInputStream());
	}
	
	public static List<String> readEntireStream(InputStream stream) {
		List<String> strings = new ArrayList<String>();
		BufferedReader br = new BufferedReader(new InputStreamReader(stream));
		try {
			while (br.ready()) {
				strings.add(br.readLine());
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return strings;
	}

	public int getPPID() {
		return m_PPID;
	}

	public void setPPID(int m_ppid) {
		m_PPID = m_ppid;
	}

	public String getPIDCodePath() {
		return m_PIDCodePath;
	}

	public void setPIDCodePath(String codePath) {
		m_PIDCodePath = codePath;
	}

	public void setExitScriptPath(String exitScriptPath) {
		m_ExitScriptPath = exitScriptPath;		
	}	
	
	public String getExitScriptPath() {
		return m_ExitScriptPath;		
	}

	public void setSubscriptExitCodePath(String subscriptExitCodePath) {
		m_SubscriptExitCodePath = subscriptExitCodePath;		
	}
	
	public String getSubscriptExitCodePath() {
		return m_SubscriptExitCodePath;		
	}

	public void setSubScriptPath(String subScriptPath) {
		m_SubScriptPath = subScriptPath;		
	}
	
	public String getSubScriptPath() {
		return m_SubScriptPath;		
	}

	public long getTimeStarted() {
		return m_TimeStarted;
	}

	public void setTimeStarted(long timeStarted) {
		m_TimeStarted = timeStarted;
	}

	public long getTimeFinished() {
		return m_TimeFinished;
	}

	public void setTimeFinished(long timeFinished) {
		m_TimeFinished = timeFinished;
	}
	
	public void setShouldNotifyOnCompletion(boolean success) {
		m_shouldNotifyOnCompletion = success;
	}
	
	public boolean shouldNotifyOnCompletion() {
		return m_shouldNotifyOnCompletion;
	}

	@Override
	public int compareTo(WorkerJobDescriptor o) {
		if (o == null) return -1;
		return getJobID().equals(o.getJobID()) ? 0 : 1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (m_shouldNotifyOnCompletion ? 1231 : 1237);
		result = prime
				* result
				+ ((m_ExecutingWorkerID == null) ? 0 : m_ExecutingWorkerID
						.hashCode());
		result = prime * result + m_ExecutionErrorCode;
		result = prime
				* result
				+ ((m_ExecutionErrorMessage == null) ? 0
						: m_ExecutionErrorMessage.hashCode());
		result = prime * result + m_ExitCode;
		result = prime
				* result
				+ ((m_ExitScriptPath == null) ? 0 : m_ExitScriptPath.hashCode());
		result = prime * result + (m_InQueue ? 1231 : 1237);
		result = prime * result + ((m_JobID == null) ? 0 : m_JobID.hashCode());
		result = prime * result + (m_Killed ? 1231 : 1237);
		result = prime * result
				+ ((m_LogPath == null) ? 0 : m_LogPath.hashCode());
		result = prime * result + (m_Lost ? 1231 : 1237);
		result = prime * result
				+ ((m_PIDCodePath == null) ? 0 : m_PIDCodePath.hashCode());
		result = prime * result + m_PPID;
		result = prime * result + (m_Running ? 1231 : 1237);
		result = prime * result
				+ ((m_ScriptPath == null) ? 0 : m_ScriptPath.hashCode());
		result = prime * result + (m_Started ? 1231 : 1237);
		result = prime * result
				+ ((m_SubScriptPath == null) ? 0 : m_SubScriptPath.hashCode());
		result = prime
				* result
				+ ((m_SubscriptExitCodePath == null) ? 0
						: m_SubscriptExitCodePath.hashCode());
		result = prime * result
				+ (int) (m_TimeFinished ^ (m_TimeFinished >>> 32));
		result = prime * result
				+ (int) (m_TimeStarted ^ (m_TimeStarted >>> 32));
		result = prime * result
				+ ((m_exitCodePath == null) ? 0 : m_exitCodePath.hashCode());
		result = prime * result + ((m_jr == null) ? 0 : m_jr.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WorkerJobDescriptor other = (WorkerJobDescriptor) obj;
		if (m_shouldNotifyOnCompletion != other.m_shouldNotifyOnCompletion)
			return false;
		if (m_ExecutingWorkerID == null) {
			if (other.m_ExecutingWorkerID != null)
				return false;
		} else if (!m_ExecutingWorkerID.equals(other.m_ExecutingWorkerID))
			return false;
		if (m_ExecutionErrorCode != other.m_ExecutionErrorCode)
			return false;
		if (m_ExecutionErrorMessage == null) {
			if (other.m_ExecutionErrorMessage != null)
				return false;
		} else if (!m_ExecutionErrorMessage
				.equals(other.m_ExecutionErrorMessage))
			return false;
		if (m_ExitCode != other.m_ExitCode)
			return false;
		if (m_ExitScriptPath == null) {
			if (other.m_ExitScriptPath != null)
				return false;
		} else if (!m_ExitScriptPath.equals(other.m_ExitScriptPath))
			return false;
		if (m_InQueue != other.m_InQueue)
			return false;
		if (m_JobID == null) {
			if (other.m_JobID != null)
				return false;
		} else if (!m_JobID.equals(other.m_JobID))
			return false;
		if (m_Killed != other.m_Killed)
			return false;
		if (m_LogPath == null) {
			if (other.m_LogPath != null)
				return false;
		} else if (!m_LogPath.equals(other.m_LogPath))
			return false;
		if (m_Lost != other.m_Lost)
			return false;
		if (m_PIDCodePath == null) {
			if (other.m_PIDCodePath != null)
				return false;
		} else if (!m_PIDCodePath.equals(other.m_PIDCodePath))
			return false;
		if (m_PPID != other.m_PPID)
			return false;
		if (m_Running != other.m_Running)
			return false;
		if (m_ScriptPath == null) {
			if (other.m_ScriptPath != null)
				return false;
		} else if (!m_ScriptPath.equals(other.m_ScriptPath))
			return false;
		if (m_Started != other.m_Started)
			return false;
		if (m_SubScriptPath == null) {
			if (other.m_SubScriptPath != null)
				return false;
		} else if (!m_SubScriptPath.equals(other.m_SubScriptPath))
			return false;
		if (m_SubscriptExitCodePath == null) {
			if (other.m_SubscriptExitCodePath != null)
				return false;
		} else if (!m_SubscriptExitCodePath
				.equals(other.m_SubscriptExitCodePath))
			return false;
		if (m_TimeFinished != other.m_TimeFinished)
			return false;
		if (m_TimeStarted != other.m_TimeStarted)
			return false;
		if (m_exitCodePath == null) {
			if (other.m_exitCodePath != null)
				return false;
		} else if (!m_exitCodePath.equals(other.m_exitCodePath))
			return false;
		if (m_jr == null) {
			if (other.m_jr != null)
				return false;
		} else if (!m_jr.equals(other.m_jr))
			return false;
		return true;
	}	
}
