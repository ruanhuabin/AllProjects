package com.maxeler.maxq.FSM;

import com.maxeler.maxq.ChannelEvent;
import com.maxeler.maxq.ChannelEvents;

public class CommonEvents {
	public static final Event eANY_EVENT = new Event(Event.ANY_EVENT);
	public static final Event eERROR_EVENT = new Event(Event.ERROR_EVENT);
	public static final Event eSTEP_EVENT = new Event(Event.STEP_EVENT);
	public static final Event eCHANNEL_WRITABLE = new ChannelEvent(ChannelEvents.WRITABLE);
	public static final Event eCHANNEL_READABLE = new ChannelEvent(ChannelEvents.READABLE);
}
