/**
 * 
 */
package com.maxeler.maxq.worker;

import java.io.Serializable;
import java.util.Arrays;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.maxeler.maxq.MaxQLogger;


/**
 * @author itay
 *
 */
public class WorkerResources  implements Serializable, Comparable<WorkerResources> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 162394942303272038L;
	final transient MaxQLogger log = MaxQLogger.getLogger("WorkerResources");
	
	private final float m_ConfiguredCores;
	private final int m_ConfiguredMemory;
	
	private TreeSet<Tag> m_Tags;
	private float m_AvailableCores;
	private int m_AvailableMemory;
	private String m_SpecificWorker;
	
	private Object m_Owner = null;
	
	@Deprecated
	public WorkerResources(float configuredCores, int configuredMemory, String [] tags) {
		this(configuredCores, configuredMemory, new TreeSet<String>(Arrays.asList(tags)));
	}
	
	public WorkerResources(Object owner, float configuredCores, int configuredMemory, TreeSet<String> configuredTags) {
		this(configuredCores, configuredMemory, configuredTags);
		m_Owner = owner;
	}

	public WorkerResources(float configuredCores, int configuredMemory, TreeSet<String> configuredTags) {
		m_ConfiguredCores = configuredCores;
		m_ConfiguredMemory = configuredMemory;
		
		m_Tags = new TreeSet<Tag>();
		Pattern p = Pattern.compile("(\\d+)(\\*)(.+)\\Z");
		for (String tag_raw : configuredTags) {
			int count = 0;
			String actual_tag = tag_raw;
			Matcher m = p.matcher(tag_raw);
			if (m.matches()) {
				count = Integer.parseInt(m.group(1));
				actual_tag = m.group(3);
			}
			m_Tags.add(new Tag(actual_tag, count));
		}
		
		m_AvailableCores = m_ConfiguredCores;
		m_AvailableMemory = m_ConfiguredMemory;
	}
	
	public Boolean isCapable(WorkerResources wrr) {
		Boolean PhysicallyCapable =  (wrr.getConfiguredCores() <= getConfiguredCores() && 
				wrr.getConfiguredMemory() <= getConfiguredMemory());
		
		Boolean FeatureCapable = true;
		for (Tag tag : wrr.getTags()) {
			boolean specific = false;
			for (Tag my_tag : getTags()) {
				if (my_tag.getTag().equals(tag.getTag())) {
					if (my_tag.getTotal() >= tag.getTotal()) {
						specific = true;
						break;
					}
				}
			}
			if (specific == false) {
				FeatureCapable = false;
				break;
			}
		}
		
		boolean capable = PhysicallyCapable && FeatureCapable;
		
		if (capable && wrr.isSpecificWorkerRequired()) {
			if (getOwner() != null && (getOwner() instanceof WorkerID)) {
				WorkerID worker = (WorkerID) getOwner();
				boolean match = wrr.getRequiredWorkerName().equalsIgnoreCase(worker.getName());
				return match;
			} else 
				return false;
		}
		
		return capable;
	}
	
	public Boolean isAvailable(WorkerResources wrr) {
		Boolean PhysicallyCapable =  (wrr.getConfiguredCores() <= getAvailableCores() && 
				wrr.getConfiguredMemory() <= getAvailableMemory());
		
		Boolean FeatureCapable = true;
		for (Tag tag : wrr.getTags()) {
			boolean specific = false;
			for (Tag my_tag : getTags()) {
				if (my_tag.getTag().equals(tag.getTag())) {
					if (my_tag.CanAllocate(tag.getTotal())) {
						specific = true;
					}
				}
			}
			if (specific == false) {
				FeatureCapable = false;
				break;
			}
		}
		
		boolean available = PhysicallyCapable && FeatureCapable;
		
		if (available && wrr.isSpecificWorkerRequired()) {
			if (getOwner() != null && (getOwner() instanceof WorkerID)) {
				WorkerID worker = (WorkerID) getOwner();
				boolean match = wrr.getRequiredWorkerName().equalsIgnoreCase(worker.getName());
				return match;
			} else
				return false;
		}
		
		return available;		
	}
	
	public float getAvailableCores() {
		return m_AvailableCores;
	}

	public int getAvailableMemory() {
		return m_AvailableMemory;
	}

	public float getConfiguredCores() {
		return m_ConfiguredCores;
	}

	public int getConfiguredMemory() {
		return m_ConfiguredMemory;
	}
	
	public TreeSet<Tag> getTags() {
		return m_Tags;
	}

//	protected void setCores(float cores) {
//		m_AvailableCores = cores;
//	}
//
//	protected void setMemory(int memory) {
//		m_AvailableMemory = memory;
//	}

	public synchronized Boolean Allocate(WorkerResources wr) {
		if (isAvailable(wr)) {
			m_AvailableMemory -= wr.getConfiguredMemory();
			m_AvailableCores -= wr.getConfiguredCores();
			
			for (Tag t : wr.getTags()) {
				for (Tag myTags : getTags()) {
					if (myTags.getTag().equals(t.getTag())) {
						
						try {
							myTags.Allocate(t.getTotal());
						} catch (Exception e) {
							log.logf(Level.WARNING, "Exception: Could not allocate: %s", e.getMessage());
							e.printStackTrace();
						}
					}
				}
			}
			return true;
		}
		return false;
	}

	public synchronized void Free(WorkerResources wrr) throws Exception {
		if (getAvailableCores() + wrr.getConfiguredCores() > getConfiguredCores() || 
				getAvailableMemory() + wrr.getConfiguredMemory() > getConfiguredMemory()) {
			log.logf(Level.WARNING, "Error: Attempted to free more resources than the worker has been configured with");
			throw new Exception("Error: Attempted to free more resources than the worker has been configured with");
		}
		
		for (Tag t : wrr.getTags()) {
			for (Tag myTags : getTags()) {
				if (myTags.getTag().equals(t.getTag())) {
					myTags.Free(t.getTotal());
				}
			}
		}
		
		m_AvailableCores += wrr.getConfiguredCores();
		m_AvailableMemory += wrr.getConfiguredMemory();
	}
	
	public void requireWorker(String hostname) {
		m_SpecificWorker = hostname;
	}
	
	public String getRequiredWorkerName() {
		return m_SpecificWorker;
	}
	
	public Boolean isSpecificWorkerRequired() {
		return m_SpecificWorker == null ? false : true;
	}

	@Override
	public int compareTo(WorkerResources o) {
		if (Float.compare(m_AvailableCores, o.getAvailableCores()) == 0) {
			return Integer.valueOf(m_AvailableMemory).compareTo(o.getAvailableMemory());
		}
		return Float.compare(m_AvailableCores, o.getAvailableCores());
	}

	public Object getOwner() {
		return m_Owner;
	}

	public void setOwner(Object owner) {
		m_Owner = owner;
	}

	@Override
	public String toString() {		
		return "(" + (isSpecificWorkerRequired() ? "w: " + getRequiredWorkerName() + ", " : "")  + "c: " + getConfiguredCores() + ", m: " + getConfiguredMemory() + ", t: " + getTags() + ")";
	}
}
