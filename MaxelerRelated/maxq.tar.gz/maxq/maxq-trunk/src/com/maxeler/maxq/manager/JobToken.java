/**
 * 
 */
package com.maxeler.maxq.manager;

import java.io.Serializable;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.controller.commands.CommandRouter;
import com.maxeler.maxq.controller.commands.ManagerQueryJobStatusCmd;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

/**
 * A token that would be associated with a JobRequest
 * This token would be used to query the status of a JobRequest
 * @author itay
 *
 */
public class JobToken implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7413774467258808639L;
	private static final transient MaxQLogger log = MaxQLogger.getLogger("JobToken");
	
	Boolean m_isValid;
	JobID m_JobID;
	String m_Message;
	Boolean m_Complete;
	private WorkerJobDescriptor m_CompletedJobDescriptor;
	private String m_ManagerAddress;
	private Integer m_ManagerPort;
	private transient CommandRouter m_cr = null;
	
	public JobToken(JobRequest jr, String ManagerAddress, Integer ManagerPort) {
		m_JobID = jr.getJobID();
		m_isValid = false;
		m_Message = "";
		m_Complete = false;
		m_ManagerPort = ManagerPort;
		m_ManagerAddress = ManagerAddress;
	}
	
	public JobToken(JobID jid, String ManagerAddress, Integer ManagerPort) {
		m_JobID = jid;
		m_isValid = false;
		m_Message = "";
		m_Complete = false;
		m_ManagerPort = ManagerPort;
		m_ManagerAddress = ManagerAddress;
	}
	
	
	public JobID getJobID() {
		return m_JobID;
	}
	
	public void setValid(Boolean isValid) {
		m_isValid = isValid;
	}
	
	public Boolean isValid() {
		return m_isValid;
	}
	
	public String getMessage() {
		return m_Message;
	}
	
	public void setMessage(String msg) {
		m_Message = msg;
	}
	
	public void setCompletedJobDescriptor(WorkerJobDescriptor jd) {
		m_CompletedJobDescriptor = jd;
	}
	
	public WorkerJobDescriptor WaitForCompletion() {
		int attempt = 1;
		while (true) {
			if (attempt > 1) {
				JobToken.log.logf(Level.WARNING, "Job %s: Trying to query status (attempt #%d)....", getJobID().getJobIDString(), attempt);
			}
			attempt++;
			try {			
				ManagerQueryJobStatusCmd mqjs = new ManagerQueryJobStatusCmd(getJobID(), getCommandRouter(), new Delegate(this) {
					@Override
					public Integer Invoke(Object param) {
						return 0;
					}			
				});
				mqjs.setShouldBlockToCompletion(true);
				mqjs.Reset(null);
				if (mqjs.isSuccess()) {
					setCompletedJobDescriptor(mqjs.getJobDescriptor());
					break;
				} 
				
				JobToken.log.logf(Level.WARNING, "Job %s: Query command returned with an error...", getJobID().getJobIDString());
			} catch (Exception e) {
				JobToken.log.logf(Level.WARNING, "Job %s: Exception: %s", getJobID().getJobIDString(), e.getMessage());
				JobToken.log.logf(Level.WARNING, "Job %s: Exception while waiting for completion...", getJobID().getJobIDString());
			}
			try {
				JobToken.log.logf(Level.WARNING, "Job %s: Sleeping for 5 seconds and retrying (attempt #%d)...", getJobID().getJobIDString(), attempt);
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			}			
		}
		
		return m_CompletedJobDescriptor;		
	}
	
	public WorkerJobDescriptor WaitForStarted() {
		int attempt = 1;
		while (true) {
			if (attempt > 1) {
				JobToken.log.logf(Level.WARNING, "Job %s: Trying to query status (attempt #%d)....", getJobID().getJobIDString(), attempt);
			}
			attempt++;
			try {			
				ManagerQueryJobStatusCmd mqjs = new ManagerQueryJobStatusCmd(getJobID(), getCommandRouter(), new Delegate(this) {
					@Override
					public Integer Invoke(Object param) {
						return 0;
					}			
				});
				mqjs.setShouldBlockToStarted(true);
				mqjs.Reset(null);
				if (mqjs.isSuccess()) {
					setCompletedJobDescriptor(mqjs.getJobDescriptor());
					break;
				} 
				
				JobToken.log.logf(Level.WARNING, "Job %s: Query command returned with an error...", getJobID().getJobIDString());
			} catch (Exception e) {
				JobToken.log.logf(Level.WARNING, "Job %s: Exception: %s", getJobID().getJobIDString(), e.getMessage());
				JobToken.log.logf(Level.WARNING, "Job %s: Exception while waiting for completion...", getJobID().getJobIDString());
			}
			try {
				JobToken.log.logf(Level.WARNING, "Job %s: Sleeping for 5 seconds and retrying (attempt #%d)...", getJobID().getJobIDString(), attempt);
				Thread.sleep(5000);
			} catch (InterruptedException e) {
			}			
		}
		
		return m_CompletedJobDescriptor;		
	}
	
	public WorkerJobDescriptor QueryStatus() {
		try {
			ManagerQueryJobStatusCmd mqjs = new ManagerQueryJobStatusCmd(getJobID(), getCommandRouter(), new Delegate(this) {
				@Override
				public Integer Invoke(Object param) {
					return 0;
				}			
			});
			mqjs.Reset(null);
			setCompletedJobDescriptor(mqjs.getJobDescriptor());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return m_CompletedJobDescriptor;		
	}
	
	public Boolean getComplete() {
		return m_Complete;
	}


	public void setComplete(Boolean complete) {
		m_Complete = complete;
	}
	
	public CommandRouter getCommandRouter() {
		if (m_cr == null) {
			m_cr = new CommandRouter(m_ManagerAddress, m_ManagerPort); 
		}
		return m_cr;
	}
	


	@Override
	public int hashCode() {
		return getJobID().hashCode();
	}
}
