/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import java.util.logging.Level;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerRequestCommands;

/**
 * @author itay
 *
 */
public class DiscoverManagerCmd extends ControllerCmd {

	private final transient MaxQLogger log = MaxQLogger.getLogger("DiscoverManagerCmd");
	/**
	 * This command tells a manager server to start a discovery process.
	 * 
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public DiscoverManagerCmd(CommandRouter cr,
			Delegate OnCommandCompletion) throws Exception {
		super("DiscoverManagerCmd", cr, OnCommandCompletion);
		
		State SendRequestCmd = new State("SendRequestCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverManagerCmd dmc = (DiscoverManagerCmd) m_Internal;
				try {
					dmc.getControllerClient().getObjectStreams().SendObject(CommonCommands.REQUEST);
					dmc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						dmc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e.printStackTrace();
					}					
				}
				return 0;
			}			
		});
		
		State ReadRequestElabCmd = new State("ReadRequestElabCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverManagerCmd dmc = (DiscoverManagerCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) dmc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.REQUEST_ELAB)) {
						dmc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						dmc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						dmc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e.printStackTrace();
					}
				}
				return 0;
			}			
		});
	
		State SendDiscoverCmd = new State("SendDiscoverCmd", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverManagerCmd dmc = (DiscoverManagerCmd) m_Internal;
				try {
					log.log(Level.INFO, "Sending command...");
					dmc.getControllerClient().getObjectStreams().SendObject(ManagerRequestCommands.DISCOVER);
					dmc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						dmc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e.printStackTrace();
					}					
				}
				return 0;
			}			
		});
		
		State ReadDiscoverACK = new State("ReadDiscoverACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverManagerCmd dmc = (DiscoverManagerCmd) m_Internal;
				try {
					log.log(Level.INFO, "Waiting for command completion...");
					ProtocolControlCommands pcc = (ProtocolControlCommands) dmc.getControllerClient().getObjectStreams().ReceiveObject();
					if (pcc.equals(ProtocolControlCommands.ACK)) {
						log.log(Level.INFO, "Command successful.");
						dmc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else if (pcc.equals(ProtocolControlCommands.NACK)) {
						log.log(Level.INFO, "Command failed: Manager side failure.");
						dmc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						dmc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						dmc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverManagerCmd dmc = (DiscoverManagerCmd) m_Internal;
				dmc.getControllerClient().Close();
				dmc.getOnCommandCompletion().Invoke(null);
				return 0;
			}			
		});
		
		AddState(SendRequestCmd);
		AddState(ReadRequestElabCmd);
		AddState(SendDiscoverCmd);
		AddState(ReadDiscoverACK);
		AddState(EndState);
		
		setInitialState(SendRequestCmd);
		setCurrentState(SendRequestCmd);
		
		AddTransition(new Transition(SendRequestCmd, ReadRequestElabCmd, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadRequestElabCmd, SendDiscoverCmd, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendDiscoverCmd, ReadDiscoverACK, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadDiscoverACK, EndState, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(SendRequestCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadRequestElabCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendDiscoverCmd, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadDiscoverACK, EndState, CommonEvents.eERROR_EVENT));
		
		CreateDotGraph();
	}
}
