/**
 * 
 */
package com.maxeler.maxq.manager;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.OperationsServer;
import com.maxeler.maxq.SaveableState;
import com.maxeler.maxq.StateSaverThread;
import com.maxeler.maxq.Stoppable;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.controller.commands.CommandRouter;
import com.maxeler.maxq.controller.commands.DiscoverWorkerCmd;
import com.maxeler.maxq.controller.commands.WorkerKillJobCmd;
import com.maxeler.maxq.manager.operations.ManagerOperationsRouter;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.KillJobResult;
import com.maxeler.maxq.worker.WorkerConfiguration;
import com.maxeler.maxq.worker.WorkerDiscoverReply;
import com.maxeler.maxq.worker.WorkerID;
import com.maxeler.maxq.worker.WorkerJobDescriptor;
import com.maxeler.maxq.worker.WorkerResources;


/**
 * @author itay
 *
 */
public class ManagerServer extends OperationsServer implements SaveableState {
	private final ManagerStatus m_Status;
	
	private final ManagerConfiguration m_ManagerConfiguration;
	private final JobDispatcherThread m_JobDispatcherThread;
	private final CompletionNotificationThread m_CompletionNotificationThread;
	private final StartedNotificationThread m_StartedNotificationThread;
	
	private final StateSaverThread m_StateSaver;	
	private final Set<Stoppable> m_Threads;
	private final transient MaxQLogger log = MaxQLogger.getLogger("ManagerServer");
	
	ManagerState m_State;

	
	
	ManagerServer(ManagerConfiguration mc) throws Exception {
		super(mc.getListenPort(), new ManagerOperationsRouter(null, null));
		
		m_Status = new ManagerStatus();
		m_ManagerConfiguration = mc;
		m_State = new ManagerState();
		m_Threads = new ConcurrentSkipListSet<Stoppable>();

		if (rebuildState() == false) {		
			Discover();
		}
		
		// Start Thread
		m_JobDispatcherThread = new JobDispatcherThread(this);
		registerThread(m_JobDispatcherThread);
		m_JobDispatcherThread.Start();
		
		m_StateSaver = new StateSaverThread(this);
		registerThread(m_StateSaver);
		m_StateSaver.Start();
		
		m_CompletionNotificationThread = new CompletionNotificationThread(this);
		registerThread(m_CompletionNotificationThread);
		m_CompletionNotificationThread.Start();
		
		m_StartedNotificationThread = new StartedNotificationThread(this);
		registerThread(m_StartedNotificationThread);
		m_StartedNotificationThread.Start();
	}

    public ManagerStatus getManagerStatus() {
		return m_Status;
	}
    
	public ManagerState getState() {
		m_State.m_ManagerNow = new Date().getTime(); 
		return m_State;
	}
    
    public void OnJobCompleted(WorkerJobDescriptor jd) {
    	// Free Cluster Resources
    	synchronized (m_State) {
    		// Update the processed Jobs map
    		WorkerJobDescriptor wjd = m_State.getProcessedJobs().get(jd.getJobID());
    		wjd.setTimeFinished(new Date().getTime());
    		wjd.setRunning(false);
    		wjd.setExecutionError(jd.getExecutionErrorCode(), jd.getExecutionErrorMessage());
    		wjd.setExitCode(jd.getExitCode());
    		wjd.setKilled(jd.hasBeenKilled());

    		WorkerID wid = wjd.getExecutingWorkerID();
        	String index = "?";
        	if (wjd.getJobRequest() != null) {
        		index = wjd.getJobRequest().getSubmitIndex().toString();
        	}
        	log.logf(Level.INFO, "[%s] %s notified: job %d completed.", index, wid.getName(), wjd.getJobID().getJobIDCode());
        	
			try {				
				WorkerResources wr = m_State.getWorkerResources().get(wid);
				wr.Free(wjd.getJobRequest().getRequiredResources());
			} catch (Exception e) {
				log.logf(Level.WARNING, "Couldn't free resources: %s", e.getMessage());
				//e.printStackTrace();
			}
			
			NotifyJobCompleted(wjd.getJobID());
	    	
			CleanupProcessedJobs();
			
    		// Wake up dispatcher thread, to process queued jobs
	    	//m_State.getJobQueue().notify();
		}  	
    }
    
    private void CleanupProcessedJobs() {
    	synchronized (m_State) {
    		try {
	    		if (m_State.getProcessedJobs().size() >= ManagerState.CleanupThreshold) {
	    			log.log(Level.INFO, "Starting processed jobs cleanup...");
	    			log.logf(Level.INFO, "Examining %d jobs...", m_State.getProcessedJobs().size());
	    			ArrayList<WorkerJobDescriptor> descriptors = new ArrayList<WorkerJobDescriptor>();
	    			for (WorkerJobDescriptor wjd : m_State.getProcessedJobs().values()) {
	    				if (wjd != null && !wjd.getRunning() && ! wjd.getInQueue()) {
	    					descriptors.add(wjd);
	    				}
	    			}
	    			
	    			ArrayList<JobID> null_ids = new ArrayList<JobID>();
	    			for (JobID jid : m_State.getProcessedJobs().keySet()) {
	    				if (m_State.getProcessedJobs().get(jid) == null) {
	    					null_ids.add(jid);
	    				}
	    			}
	    			
	    			for (JobID jid : null_ids) {
	    				m_State.getProcessedJobs().remove(jid);
	    			}
	    			
	    			log.logf(Level.INFO, "%d null job-ids removed...", null_ids.size());
	    			log.logf(Level.INFO, "%d jobs completed...", descriptors.size());
	    			
	    			Collections.sort(descriptors, new Comparator<WorkerJobDescriptor>() {
						@Override
						public int compare(WorkerJobDescriptor o1,
								WorkerJobDescriptor o2) {
							if (o1 == null)
								return 1;
							if (o2 == null)
								return -1;
							long l1 = o1.getTimeFinished(), l2 = o2.getTimeFinished();
							return l2 < l1 ? -1 : l2 > l1 ? 1 : 0;
						}    				
	    			});
	    			
	    			int target = (ManagerState.CleanupTarget > descriptors.size() ?  descriptors.size() - 1: ManagerState.CleanupTarget);
	    			if (target >= 0) {
		    			for (WorkerJobDescriptor wjd : descriptors.subList(0, target)) {
		    				m_State.getProcessedJobs().put(wjd.getJobID(), wjd);
		    				m_State.getTokenToJobMap().put(wjd.getJobID(), wjd.getJobRequest());
		    			}
		    			
	    			}
	    			if (target < descriptors.size() -1) {
	    				int the_rest = target;
		    			for (WorkerJobDescriptor wjd : descriptors.subList(the_rest, descriptors.size()-1)) {
		    				m_State.getProcessedJobs().remove(wjd.getJobID());
		    				m_State.getTokenToJobMap().remove(wjd.getJobID());
		    			}
	    			}
	    			log.logf(Level.INFO, "New processed jobs list size: %d", m_State.getProcessedJobs().size());    			
	    		}    		
			} catch (Exception e) {
	    		log.logf(Level.INFO, "Exception in cleanup:", e.getMessage());
	    		e.printStackTrace();
	    	}
    	} 
    	
	}

	public void NotifyJobCompleted(JobID jid) {
		m_CompletionNotificationThread.Notify(jid);
    }
	
	public void NotifyJobStarted(JobID jid) {
		m_StartedNotificationThread.Notify(jid);
    }

    /**
     * <p>Called by the job dispatcher thread after it has successfully submitted a job
     *  to a worker, this means that it should already be synchronised on the JobQueue object 
     * @param jd - The worker's job descriptor 
     */
    public void OnJobSubmitted(WorkerJobDescriptor jd) {
    	synchronized (m_State) {
	    	// Mark Resources as used
	    	if (jd != null && jd.getJobRequest() != null && jd.getJobID() != null && jd.getExecutingWorkerID() != null) {
	    		log.logf(Level.INFO,"[%d] Job %d submitted to %s.", jd.getJobRequest().getSubmitIndex(), jd.getJobID().getJobIDCode(), jd.getExecutingWorkerID().getName());
		    	WorkerID wid = jd.getExecutingWorkerID();
		    	WorkerResources war = m_State.getWorkerResources().get(wid);
		    	war.Allocate(jd.getJobRequest().getRequiredResources());
		    	jd.setInQueue(false);
		    	jd.setTimeStarted(new Date().getTime());
		    	jd.setTimeFinished(new Date().getTime());
		    	m_State.getProcessedJobs().put(jd.getJobID(), jd);
		    	m_State.incrementProcessedCount();
		    	NotifyJobStarted(jd.getJobID());
	    	} else {
	    		log.logf(Level.WARNING, "OnJobSubmitted: Invalid Job descriptor received (null fields), not allocating.");
	    	}
    	}
    }
    
    public JobToken QueueJob(JobRequest jr) {
    	String Address;
    	try {
    		Address = InetAddress.getLocalHost().getHostAddress();
    	} catch (Exception e) {
    		Address = System.getenv("HOSTNAME");
    	}
    	
    	jr.setSubmitIndex(m_State.NextSubmission());
    	jr.setTempDirectory(m_ManagerConfiguration.getTempDirectory());
		JobToken jt = new JobToken(jr, Address, m_ManagerConfiguration.getListenPort());
		
		if (isClusterCapable(jr)) {
			synchronized (m_State) {
				log.logf(Level.FINE, "Adding to queue: priority = %d, submit index = %d", jr.getPriority(), jr.getSubmitIndex());
				m_State.getJobQueue().add(jr);
				jt.setValid(true);
				jt.setMessage("Queued OK");
				m_State.getTokenToJobMap().put(jt.getJobID(), jr);
				
				log.logf(Level.INFO, "[%d] Job %d Queued.", m_State.getSubmitIndex(), jt.getJobID().getJobIDCode());
				log.logf(Level.FINE, "Queue size: %d", m_State.getJobQueue().size());
				// Notify the job dispatcher thread...
				//m_State.getJobQueue().notify();
			}
		} else {
			jt.setMessage(jr.getMessage());
		}
		return jt;
	}
    
    public void Discover() {
    	log.logf(Level.INFO, "%s: Starting worker discovery...", m_ManagerConfiguration.getName());
    	log.log(Level.FINEST, "Clearing cluster's configured workers list...");
    	synchronized (m_State) {
    		m_State.getWorkerResources().clear();
        	
	    	for (String worker : m_ManagerConfiguration.getWorkerNames()) {
	    		// DiscoverCommand
	    		String [] workerAddrPort = worker.split(":",2);
	    		
	    		String WorkerAddress = workerAddrPort[0];
	    		Integer WorkerPort = Globals.WorkerPort;
	    		if (workerAddrPort.length > 1) {
	    			WorkerPort = Integer.parseInt(workerAddrPort[1]);
	    		}
	    		
	    		CommandRouter cr = new CommandRouter(WorkerAddress, WorkerPort);
	    		
	    		try {
					DiscoverWorkerCmd dwc = new DiscoverWorkerCmd(cr, null);
					dwc.Reset(null); // start
					WorkerDiscoverReply wdr = dwc.getWorkerDiscoverReply();
					WorkerResources wr = wdr.getWorkerResources();
					WorkerConfiguration wc = wdr.getWorkerConfiguration();
					WorkerID wid = wdr.getWorkerID();
					Set<WorkerJobDescriptor> runningJobs = wdr.getRunningJobs();
					int count = 0;
					
					// remove jobs that are on the manager's list, but not on the worker's
					List<JobID> zombies = new ArrayList<JobID>(); 
					for (WorkerJobDescriptor jd : getState().getProcessedJobs().values()) {
						if (jd.getRunning() == true && wid.equals(jd.getExecutingWorkerID())) {
							if (!runningJobs.contains(jd)) {
								zombies.add(jd.getJobID());
							}
						}
					}
					
					for (JobID jid : zombies) {
						getState().getProcessedJobs().remove(jid);
					}
						
					for (WorkerJobDescriptor jd : runningJobs) {
						if (!getState().getProcessedJobs().containsKey(jd.getJobID())) {
							getState().getProcessedJobs().put(jd.getJobID(), jd);
							count++;					
						}
					}
					
					
					log.logf(Level.INFO, "Discovered: Worker %s: running %d jobs of which %d are previously unknown.", wc.getName(), runningJobs.size(), count);
					log.logf(Level.INFO, "Available: %s : %.2f/%.2f Cores, %d/%d RAM, %s Tags", wc.getName(),
							wr.getAvailableCores(),wr.getConfiguredCores(), wr.getAvailableMemory(),wr.getConfiguredMemory(), wr.getTags());
					m_State.getWorkerResources().put(wid, wr);					
				} catch (Exception e) {
					log.logf(Level.WARNING, "Discovery Error: %s", e.getMessage());
				}
	    	}
	    	
	    	// Dispatch queued jobs to newly available workers
	    	//m_State.getJobQueue().notify();
    	}
    }

	@Override
	public void Exit() {
		log.log(Level.SEVERE, "Shutting down...");
		Stop(); // notify server to stop the listen loop
		log.log(Level.SEVERE, "Waiting for threads...");
		synchronized (m_Threads) {
			for (Stoppable s : m_Threads) {
				s.Stop();
			}
		}		
		log.log(Level.FINE, "Threads finished.");		
	}
	
	/**
	 * <p>Determines if the cluster can theoretically execute this job
	 * assuming all resources are free.
	 * @param jr
	 * @return true or false
	 */
	public boolean isClusterCapable(JobRequest jr) {
		synchronized (m_State) {
			for (WorkerID worker : m_State.getWorkerResources().keySet()) {
				if (m_State.getWorkerResources().get(worker).isCapable(jr.getRequiredResources())) {
					return true;
				}
			}
		}

		jr.setMessage("Cluster cannot handle the specified job request: " + jr.getRequiredResources().toString());
		return false;
	}

	public ManagerConfiguration getManagerConfiguration() {
		return m_ManagerConfiguration;
	}

	public WorkerJobDescriptor getJobDescriptor(JobID jid) {
		WorkerJobDescriptor jd = null;
		synchronized (m_State) {
			jd = m_State.getProcessedJobs().get(jid);
			if (jd == null) {
				JobRequest jr = m_State.getTokenToJobMap().get(jid);
				jd = new WorkerJobDescriptor(jr, jid, null, null, null, null);
				if (jr != null) { // Job still in Queue 
					jd.setInQueue(true);
					jd.setStarted(false);
				} else {
					jd.setInQueue(false);
					jd.setRunning(false);
				}
			}
		}

		return jd;
	}
	
	public void QueueCompletionFSM(JobID jid, FSM Key) {
		synchronized (m_State) {
			List<FSM> keys;
			if (m_State.getCompletionKeys().containsKey(jid)) {
				keys = m_State.getCompletionKeys().get(jid);
			} else {
				keys = new LinkedList<FSM>();
				m_State.getCompletionKeys().put(jid, keys);
			}
			keys.add(Key);
		} 
	}
	
	public void QueueStartedFSM(JobID jid, FSM Key) {
		synchronized (m_State) {
			List<FSM> keys;
			if (m_State.getStartedKeys().containsKey(jid)) {
				keys = m_State.getStartedKeys().get(jid);
			} else {
				keys = new LinkedList<FSM>();
				m_State.getStartedKeys().put(jid, keys);
			}
			keys.add(Key);
		} 
	}
	
	public KillJobResults KillJobs(JobSearchCriteria jsc) {
		JobSearchResult jsr = FindJobs(jsc);
		KillJobResults kjrs = new KillJobResults();
		
		List<KillJobResult> results = kjrs.getResults();
		
		synchronized (m_State) {
			for (WorkerJobDescriptor jd : jsr.getJobList()) {
				results.add(KillJob(jd));
			}
			// Re-evaluate queue
	    	//m_State.getJobQueue().notify();
		}
		
		return kjrs;
	}
	
	public KillJobResult KillJob(WorkerJobDescriptor jd) {
		KillJobResult kjr = null;
		synchronized (m_State) {
			jd.setTimeFinished(new Date().getTime());
			if (jd.getRunning()) {
				WorkerID wid = jd.getExecutingWorkerID();
				if (wid != null) {
					CommandRouter cr = new CommandRouter(wid.getAddress(), wid.getPort());
					try {
						WorkerKillJobCmd wkjc = new WorkerKillJobCmd(jd.getJobID(), cr, new Delegate(jd) {
							@Override
							public Integer Invoke(Object param) {
								KillJobResult kjr = (KillJobResult) param;
								WorkerJobDescriptor wjd = (WorkerJobDescriptor) m_Internal;
								wjd.setTimeFinished(new Date().getTime());
								log.logf(Level.INFO, "[%5s] Job %d: %s", kjr.getStatus().equals(KillJobStatus.SIGNAL_SENT) ? "OKAY" : "ERROR", wjd.getJobID().getJobIDCode(),
										kjr.getMessage());
								return 0;
							}							
						});
						wkjc.Reset(null);
						// Grab result
						kjr = wkjc.geResult();
						
						KillJobStatus kjs = kjr.getStatus();
						if (kjs.equals(KillJobStatus.JOB_NOT_FOUND)) {
							log.logf(Level.INFO, "Phantom job, manually removing from running list...");
							jd.setKilled(true);
							jd.setExitCode(-1);
							OnJobCompleted(jd);
						}
					} catch (Exception e) {
						kjr = new KillJobResult(jd, KillJobStatus.FAIL, "ManagerServer: Caught exception: " + e.getMessage() + "\nIf this is a 'zombie' job, make sure worker '" + wid.getName()+ "' is accessible by manager and try again.");
						//e.printStackTrace();
					}
				}
			} else if (jd.getInQueue()){
				// we only need to manually notify about jobs inside the queue,
				// since if the job is executing (i.e not in the queue) 
				// then the job monitoring thread will
				// notice when it gets killed and notify the manager by itself.
				NotifyJobCompleted(jd.getJobID());
				
				log.logf(Level.INFO, "[%d] Kill requested for queued job %d, removing from queue.", jd.getJobRequest().getSubmitIndex(), jd.getJobID().getJobIDCode());
				
				m_State.getJobQueue().remove(jd.getJobRequest());
				m_State.getTokenToJobMap().remove(jd.getJobID());
				kjr = new KillJobResult(jd, KillJobStatus.DEQUEUED, getManagerConfiguration().getName() + ": Job dequeud");
			} else {
				kjr = new KillJobResult(jd, KillJobStatus.JOB_NOT_RUNNING_NOR_QUEUED, getManagerConfiguration().getName() + ": Job not running nor queued - nothing to do.");
			}
		}
		return kjr;		
	}
	
	public JobSearchResult FindJobs(JobSearchCriteria jsc) {
		JobSearchResult jsr = new JobSearchResult();
		log.log(Level.FINE, "Searching for jobs...");
		synchronized (m_State) { 
			for (JobID jid : m_State.getTokenToJobMap().keySet()) {
				WorkerJobDescriptor jd = getJobDescriptor(jid);
				log.logf(Level.FINER, "Testing job: %s", jid.getJobIDString());
				if (jsc.Match(jd)) {
					log.logf(Level.FINE, "Found matching job: %s", jid.getJobIDString());
					jsr.getJobList().add(jd);
				}
			}
		}
		return jsr;	
	}
	
	private boolean rebuildState() {
		FileInputStream fis = null;
		synchronized (m_State) {
			try {
				log.logf(Level.INFO, "Rebuilding state from file: %s", getConfiguration().getStateFilePath());
				fis = new FileInputStream(getConfiguration().getStateFilePath());
				ObjectInputStream ois = new ObjectInputStream(fis);
				ManagerState ms = (ManagerState) ois.readObject();
				
				if (ms != null) {
					m_State = ms;
					m_State.validate();
					Discover();
					return true;
				}				
			} catch (Exception e) {
				log.logf(Level.WARNING, "Could not rebuild state from file: %s", e.getMessage());
			}
			finally {
				try {
					if (fis != null) fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}	
		return false;
	}

	@Override
	public void saveState() {
		synchronized (m_State) {
			try {
				log.logf(Level.FINER, "Saving state to file: %s", getConfiguration().getStateFilePath());
				FileOutputStream faos = new FileOutputStream(getConfiguration().getStateFilePath());
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(baos);
				
				oos.writeObject(getState());
				oos.flush();
				baos.flush();
				faos.write(baos.toByteArray());
				faos.flush();
				faos.close();
				oos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}			
		}				
	}

	public ManagerConfiguration getConfiguration() {
		return m_ManagerConfiguration;
	}
	
	public void deregisterThread(Stoppable thread) {
		m_Threads.remove(thread);			
	}
	
	public void registerThread(Stoppable thread) {
		m_Threads.add(thread);			
	}
}
