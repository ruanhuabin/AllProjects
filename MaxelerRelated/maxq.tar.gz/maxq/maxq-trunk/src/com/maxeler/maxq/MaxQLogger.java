package com.maxeler.maxq;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.LogManager;


public class MaxQLogger {
	
	//private Logger m_Logger;
	private final String m_Name;
	private static final SimpleDateFormat date_format = new SimpleDateFormat("MMM dd kk:mm:ss.SSS");
	
	protected MaxQLogger(String name/*Logger logger*/) {
		//m_Logger = null;
		m_Name = name;
	}
	
	
	public static MaxQLogger getLogger(String name) {
	/*	Logger logger = LogManager.getLogManager().getLogger(name);
		if (logger == null) {
			logger = Logger.getLogger(name);
			LogManager.getLogManager().addLogger(logger);
		}*/
		return new MaxQLogger(name);
	}
	
	public void logf(Level level, String format, Object ... args) {
		try {
			ByteArrayOutputStream  baos = new ByteArrayOutputStream();
			PrintStream ps = new PrintStream(baos);
			if (args.length > 0) {
				ps.printf(format, args);
			} else {
				ps.print(format);
			}
			ps.close();
			
			if (Globals.minLogLevel.intValue() <= level.intValue()) {
				synchronized (LogManager.getLogManager()) {
					StringBuffer buffer = new StringBuffer();
					
					if (level.intValue() < Level.INFO.intValue())
						buffer.append(date_format.format(new Date()) + " ");
					
					buffer.append(getName() + ": " + baos.toString());
					System.out.println(buffer);
					System.out.flush();
				}			
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		//m_Logger.log(level, baos.toString());
	}
	
	public void log(Level level, String msg) {
		try {
			if (Globals.minLogLevel.intValue() <= level.intValue()) {
				synchronized (LogManager.getLogManager()) {
					StringBuffer buffer = new StringBuffer();
					if (level.intValue() < Level.INFO.intValue())
						buffer.append(date_format.format(new Date()) + " ");
					
					buffer.append(getName() + ": " + msg);
					System.out.println(buffer);
					System.out.flush();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		//m_Logger.log(level, msg);
	}
	
	public String getName() {
		return m_Name;
	}	
}
