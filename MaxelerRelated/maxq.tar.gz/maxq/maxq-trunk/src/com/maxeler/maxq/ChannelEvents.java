package com.maxeler.maxq;

public enum ChannelEvents {
	ACCEPTABLE,
	CONNECTABLE,
	READABLE,
	WRITABLE,
	ERROR
}
