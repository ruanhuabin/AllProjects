/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerQueryCommands;
import com.maxeler.maxq.manager.ManagerState;

/**
 * @author itay
 *
 */
public class ManagerGetStateCmd extends ControllerCmd {

	private ManagerState m_ManagerState = null;
	
	/**
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public ManagerGetStateCmd(CommandRouter cr,
			Delegate OnCommandCompletion) throws Exception {
		super("ManagerGetStateCmd", cr, OnCommandCompletion);
		
		State SendQueryCommand = new State("SendQueryCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getControllerClient().getObjectStreams().SendObject(CommonCommands.QUERY);
					return HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadQueryElab = new State("ReadQueryElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					CommonResponses cr = (CommonResponses) getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.QUERY_ELAB)) {
						return HandleEvent(CommonEvents.eSTEP_EVENT);
					}
					
					return HandleEvent(CommonEvents.eERROR_EVENT);
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}
		});
		
		State SendQueryManagerStateCommand = new State("SendQueryManagerStateCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getControllerClient().getObjectStreams().SendObject(ManagerQueryCommands.CLUSTER_STATUS);
					HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadManagerState = new State("ReadClusterStatus", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					m_ManagerState = (ManagerState) getControllerClient().getObjectStreams().ReceiveObject();
					if (getOnCommandCompletion() != null) {
						getOnCommandCompletion().Invoke(m_ManagerState);
					}
					return HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				getControllerClient().Close();
				return 0;
			}			
		});
		
		AddState(SendQueryCommand);
		AddState(ReadQueryElab);
		AddState(SendQueryManagerStateCommand);
		AddState(ReadManagerState);
		AddState(EndState);
		
		setInitialState(SendQueryCommand);
		setCurrentState(SendQueryCommand);
		
		AddTransition(new Transition(SendQueryCommand, ReadQueryElab, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadQueryElab, SendQueryManagerStateCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendQueryManagerStateCommand, ReadManagerState, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadManagerState, EndState, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(SendQueryCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadQueryElab, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendQueryManagerStateCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadManagerState, EndState, CommonEvents.eERROR_EVENT));
		
		CreateDotGraph();		
	}
	
	public ManagerState getManagerState() {
		return m_ManagerState;
	}
}
