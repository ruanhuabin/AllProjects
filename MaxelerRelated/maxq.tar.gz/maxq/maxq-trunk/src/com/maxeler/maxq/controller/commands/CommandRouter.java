/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.controller.Controller;
import com.maxeler.maxq.manager.JobID;
import com.maxeler.maxq.manager.JobSearchCriteria;
import com.maxeler.maxq.manager.JobToken;
import com.maxeler.maxq.manager.KillJobResults;
import com.maxeler.maxq.manager.KillJobStatus;
import com.maxeler.maxq.manager.ManagerState;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.KillJobResult;
import com.maxeler.maxq.worker.WorkerID;
import com.maxeler.maxq.worker.WorkerJobDescriptor;
import com.maxeler.maxq.worker.WorkerResources;

/**
 * Will parse commands and options and instantiate a suitable Command FSM
 * 
 * @author itay
 * 
 */
public class CommandRouter {

	String m_ServerName;
	String m_Command;
	String m_Option;
	String m_FileName;
	String[] m_OtherArgs;
	Integer m_Port;
	Integer m_VerbosityLevel = 0;
	private final transient MaxQLogger log = MaxQLogger.getLogger("CR");

	public CommandRouter(String ServerName, Integer port, String Command,
			String Option, String FileName, String[] OtherArgs) {
		m_ServerName = ServerName;
		m_Command = Command;
		m_Option = Option;
		m_FileName = FileName;
		m_OtherArgs = OtherArgs;
		m_Port = port;
	}

	public CommandRouter(String ServerName, Integer port) {
		m_ServerName = ServerName;
		m_Port = port;

		m_Command = null;
		m_Option = null;
		m_FileName = null;
		m_OtherArgs = null;
	}

	public String getUpTime(Long Started, Long Finished) {
		if (Finished == null || Started == null) {
			return "-cannot calculate-";
		}
		float elapsedMilli = (Finished - Started);
		boolean negative = false;
		if (elapsedMilli < 0) {
			negative = true;
			elapsedMilli = Math.abs(elapsedMilli);
		}
		int days = (int) (elapsedMilli / 1000 / 60 / 60 / 24);
		elapsedMilli -= days * 1000 * 60 * 60 * 24;
		int hours = (int) (elapsedMilli / 1000 / 60 / 60);
		elapsedMilli -= hours * 1000 * 60 * 60;
		int minutes = (int) (elapsedMilli / 1000 / 60);
		elapsedMilli -= minutes * 1000 * 60;
		int seconds = (int) (elapsedMilli / 1000);
		elapsedMilli -= seconds * 1000;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);
		ps.printf("%d days %02d:%02d:%02d.%03d%s", days, hours, minutes,
				seconds, (int) elapsedMilli, negative ? " ago" : "");
		ps.close();
		return baos.toString();
	}

	public void PrintClusterStatus(ManagerState ms) {
		log.logf(Level.INFO,
				"Manager State: %d Jobs Queued, %d Jobs proccessed", ms
						.getJobQueue().size(), ms.getProcessedCount());

		int workers_count = 0;
		int core_count = 0;
		int ram_count = 0;
		int cores_available = 0;
		int ram_available = 0;
		for (WorkerResources wr : ms.getWorkerResources().values()) {
			if (wr != null) {
				workers_count++;
				core_count += wr.getConfiguredCores();
				ram_count += wr.getConfiguredMemory();
				cores_available += wr.getAvailableCores();
				ram_available += wr.getAvailableMemory();
			}
		}
		log.logf(Level.INFO,
				"Workers: %d Configured, %d/%d cores available, %d/%dMB ram available",
				workers_count, cores_available, core_count,
				ram_available, ram_count);
		log.log(Level.INFO, "---------------------------------------------");
		log.log(Level.INFO, "Workers:");
		int count = 0;
		for (WorkerID wid : ms.getWorkerResources().keySet()) {
			if (wid == null)
				continue;
			count++;
			log.logf(Level.INFO, "[%02d] %-8s @ %s", count, wid.getName(), wid
					.getAddress());
			WorkerResources wr = ms.getWorkerResources().get(wid);
			log.logf(Level.INFO,
					"\t Resources: cores: %.2f/%.2f, ram %d/%d, tags: %s", wr.getAvailableCores(), wr.getConfiguredCores(), 
					wr.getAvailableMemory(), wr.getConfiguredMemory(), wr.getTags().toString());
		}
		log.log(Level.INFO, "---------------------------------------------");
		log.log(Level.INFO, "Running Jobs: ");
		int i = 1;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);

		Set<Map.Entry<JobID, WorkerJobDescriptor>> sorted_set = new TreeSet<Map.Entry<JobID,WorkerJobDescriptor>>(
				new Comparator<Map.Entry<JobID,WorkerJobDescriptor>>() {
					@Override
					public int compare(Entry<JobID, WorkerJobDescriptor> o1,
							Entry<JobID, WorkerJobDescriptor> o2) {
						WorkerJobDescriptor wjd1 = o1.getValue();
						WorkerJobDescriptor wjd2 = o2.getValue();
						
						int name_compare = wjd1.getExecutingWorkerID().getName().compareTo(wjd2.getExecutingWorkerID().getName());
						return name_compare != 0 ? name_compare : o1.getKey().getJobIDCode().compareTo(o2.getKey().getJobIDCode());
					}
		});
		
		for (Map.Entry<JobID,WorkerJobDescriptor> entry : ms.getProcessedJobs().entrySet()) {
			sorted_set.add(entry);
		}
		
		for (Map.Entry<JobID, WorkerJobDescriptor> entry : sorted_set) {
			WorkerJobDescriptor wjd = entry.getValue();
			if (wjd.getRunning()) {
				log.logf(Level.INFO,
						"  [%4d] %-11s@ %-10s: [c %.1f, m %4.1fg] id=%-8s " + (m_VerbosityLevel > 1 ? "%s" : "%.40s"), i++,
						wjd.getJobRequest().getUsername(),
						wjd.getExecutingWorkerID().getName(),
						wjd.getJobRequest().getRequiredResources().getConfiguredCores(), 
						wjd.getJobRequest().getRequiredResources().getConfiguredMemory()/1024.0, 
						wjd.getJobID().getJobIDString(),
						wjd.getJobRequest().getJobName());
				if (m_VerbosityLevel > 1) {
					log.logf(Level.INFO, "  \t\tcmd: %s", wjd.getJobRequest().getCommand().trim());
					log.logf(Level.INFO, "  \t\tgroup: '%s'", wjd.getJobRequest()
							.getGroupName());
					log.logf(Level.INFO, "  \t\tup: %s", getUpTime(wjd.getTimeStarted(), ms.getManagerTime()));
					if (wjd.getJobRequest().getTimeout() != null && wjd.getJobRequest().getTimeout() > 0) {
						log.logf(Level.INFO, "  \t\ttimeout: %d seconds", wjd.getJobRequest().getTimeout());
					}
					if (wjd.getJobRequest() != null) {
						log.logf(Level.INFO,
								"  \t\tResources: cores: %.2f, ram: %d, tags: %s",
								wjd.getJobRequest().getRequiredResources().getConfiguredCores(), 
								wjd.getJobRequest().getRequiredResources().getConfiguredMemory(), 
								wjd.getJobRequest().getRequiredResources().getTags().toString());
						log.logf(Level.INFO, "  \t\twd: %s", wjd.getJobRequest()
								.getWorkingDirectory());
					}
					log.logf(Level.INFO, "  \t\tLog File: %s", wjd.getLogPath());
	
					log.logf(Level.INFO, "  \t\tscreen: ssh -t %s@%s screen -r %s",
							wjd.getJobRequest().getUsername(), wjd
									.getExecutingWorkerID().getName(), "maxq"
									+ wjd.getJobID().getJobIDString());
					log.log(Level.INFO,
									"  ___________________________________________________________");
				}
			}
		}
		ps.close();
		log.log(Level.INFO, "---------------------------------------------");
		log.logf(Level.INFO, "Queued Jobs (%d): ", ms.getJobQueue().size());
		i = 0;
		for (JobRequest jr : ms.getJobQueue()) {
			if (m_VerbosityLevel > 1) {
				log.logf(Level.INFO, "  [%4s] Job %-18s (id=%-12s, group=%-18s, cpu: %4.2f, ram: %-5d, tags: %-8s, cmd=%.15s)",
									++i == 1 ? "next" : i, "'" + jr.getJobName() + "'",
									jr.getJobID().getJobIDString(), jr.getGroupName(),
									jr.getRequiredResources().getConfiguredCores(), 
									jr.getRequiredResources().getConfiguredMemory(), jr.getRequiredResources().getTags().toString(), 
									jr.getCommand().trim());
			} else {
				log.logf(Level.INFO, "  [%4s] %-11s: id=%-8s [c %.1f, m %4.1fg] name=%.45s",
						++i == 1 ? "next" : i, jr.getUsername(),
						jr.getJobID().getJobIDString(),
						jr.getRequiredResources().getConfiguredCores(), 
						jr.getRequiredResources().getConfiguredMemory() / 1024.0,
						jr.getJobName());
			}
		}		
		log.log(Level.INFO, "---------------------------------------------");
	}

	public void PrintJobDescriptor(WorkerJobDescriptor jd, ManagerState ms) {
		if (jd != null) { // Shouldn't ever be null...
			if (jd.getJobRequest() == null) {
				log.logf(Level.INFO, "----- Job %s Was not found.", jd.getJobID().getJobIDString());
			} else {
				JobRequest jr = jd.getJobRequest();
				log
						.logf(
								Level.INFO,
								"\n---------------------------------------------\n"
										+ "Job:                %d\n"
										+ "Worker:             %s (%s)\n"
										+ "Command:            %s\n"
										+ "Arguments:          %s\n"
										+ "User:               %s\n" 
										+ "Priority:           %d\n"
										+ "Working Dir:        %s\n"
										+ "Job Group:          '%s'\n"
										+ "Resources:          %.02f cores, %dMB of memory, tags: %s\n"
										+ "Screen access:      %s\n"
										+ "Started?            %s\n"
										+ "Running?            %s\n"
										+ "Worker Message:     '%d' (%s)\n"										
										+ "Uptime:             %s\n"
										+ "Exit code:          %s\n"
										+ "Timeout:            %s\n"
										+ "Execution script:   %s\n"
										+ "Log file:           %s\n"
										+ "FIFO path:          %s\n"
										+ "---------------------------------------------",
								jd.getJobID().getJobIDCode(),
								jd.getInQueue() ? "not yet assigned" : jd.getExecutingWorkerID().getName(),
								jd.getInQueue() ? "-" : jd.getExecutingWorkerID().getAddress(),
								jr.getCommand(),
								jr.getArguments(),
								jr.getUsername(),
								jr.getPriority(),
								jr.getWorkingDirectory(),
								jr.getGroupName(),
								jr.getRequiredResources().getConfiguredCores(),
								jr.getRequiredResources().getConfiguredMemory(),
								jr.getRequiredResources().getTags().toString(),
								"maxq" + jr.getJobID().getJobIDString(),
								jd.getStarted() ? "Yes" : "No",
								jd.getRunning() ? "Yes" : "No",
								jd.getExecutionErrorCode(),
								jd.getExecutionErrorMessage(),								
								jd.getRunning() ? getUpTime(jd.getTimeStarted(), ms == null ? null : ms.getManagerTime()) : getUpTime(jd.getTimeStarted(), jd.getTimeFinished()),
								(jd.getInQueue() || jd.getRunning()) ? "-still running-" : jd.getExitCode(),
								jd.getJobRequest().getTimeout() != null ? jd.getJobRequest().getTimeout() > 0 ? jd.getJobRequest().getTimeout().toString() + " seconds" : "no timeout" : "no timeout", 
								jd.getInQueue() ? "not yet assigned" : jd.getScriptPath(),
								jd.getInQueue() ? "not yet assigned" : jd.getLogPath(),
								jd.getInQueue() ? "not yet assigned" : jd.getExitCodeFilePath(),
								jd.getInQueue() ? "not yet assigned" : "maxq"
										+ jd.getJobID().getJobIDString());
			}
		}
	}
	
	public void PrintQueuedJobRequest(JobRequest jr, ManagerState ms) {
		log.logf(Level.INFO,
				"\n---------------------------------------------\n"
				+ "Queued Job Request: %s\n"
				+ "Name: '%s'\n"
				+ "Group: '%s'\n"
				+ "User: %s\n" 
				+ "Priority: %d\n"
				+ "Submit index: %d\n"
				+ "Command: %s\n"
				+ "Arguments: %s\n"
				+ "Working directory: %s\n"
				+ "Requested resources: cores = %.02f, ram = %dMB, tags = %s\n"
				+ "---------------------------------------------",
				jr.getJobID().getJobIDString(),
				jr.getJobName(),
				jr.getGroupName(),
				jr.getUsername(),
				jr.getPriority(),
				jr.getSubmitIndex(),
				jr.getCommand(),
				jr.getArguments(),				
				jr.getWorkingDirectory(),				
				jr.getRequiredResources().getConfiguredCores(),
				jr.getRequiredResources().getConfiguredMemory(),
				jr.getRequiredResources().getTags().toString());

	}

	public Integer Execute() throws Exception {
		FSM fsm = null;
		
		if (m_VerbosityLevel > 10) {
			Controller.setVerboseLogging();
		}

		if (m_Command == null) {
			throw new Exception(
					"CommandRouter is not fully configured: Command = null");
		}

		Delegate OnCommandComplete = null;
		if (m_Command.equalsIgnoreCase("Status")) {
			OnCommandComplete = new Delegate(this) {

				@Override
				public Integer Invoke(Object param) {
					ManagerState ms = (ManagerState) param;
					if (ms == null) {
						log.log(Level.WARNING,
								"Failed getting a proper Manager Status reply");
					} else {
						if (m_Option != null && m_Option.length() > 1) {
							String[] PairList = m_Option.split(",");
							for (String pair : PairList) {
								String[] OptVal = pair.split("=", 2);
								String filter = OptVal[0];
								if (filter.equalsIgnoreCase("id")
										&& OptVal.length > 1) {
									String val = OptVal[1];
									for (JobID jid : ms.getProcessedJobs()
											.keySet()) {
										WorkerJobDescriptor wjd = ms
												.getProcessedJobs().get(jid);
										if (wjd.getJobID().getJobIDString()
												.equalsIgnoreCase(val)) {
											PrintJobDescriptor(wjd, ms);
										}
									}
									
									for (JobRequest jr : ms.getJobQueue()) {
										if (jr.getJobID().getJobIDString().equalsIgnoreCase(val)) {
											PrintQueuedJobRequest(jr, ms);
										}
									}
									
								} else if (OptVal[0].equalsIgnoreCase("abnormalexit") || 
										   OptVal[0].equalsIgnoreCase("normalexit")) {
									Integer threshold = 50;
									try {
										int temp = Integer.decode(OptVal[1]);
										if (temp > 0) {
											threshold = temp;
										}
									} catch (Exception e) {

									}
									log.logf(Level.INFO,
											"Searching for last %d finished jobs...", threshold);
									Integer index = 1;
									ArrayList<WorkerJobDescriptor> descriptors = new ArrayList<WorkerJobDescriptor>();
									for (JobID jid : ms.getProcessedJobs()
											.keySet()) {
										WorkerJobDescriptor wjd = ms
												.getProcessedJobs().get(jid);
										if (wjd.getRunning() == false
												&& wjd.getInQueue() == false
												&& wjd.getStarted() == true
												&& wjd.getJobRequest() != null
												&& OptVal[0]
														.equalsIgnoreCase("normalexit") ? wjd
												.getExitCode() == 0
												: wjd.getExitCode() != 0) {
											descriptors.add(wjd);
										}
									}
									Collections.sort(descriptors,
													new Comparator<WorkerJobDescriptor>() {
														@Override
														public int compare(WorkerJobDescriptor o1,
																	       WorkerJobDescriptor o2) {
															if (o1 == null)
																return 1;
															if (o2 == null)
																return -1;
															long l1 = o1.getTimeFinished(), l2 = o2.getTimeFinished();
															return l2 < l1 ? -1 : l2 > l1 ? 1 : 0;
														}
													});

									for (WorkerJobDescriptor wjd : descriptors) {
										if (threshold-- <= 0)
											break;
										log.logf(Level.INFO,
												"[%3d:%03d] %s, Job %10s, user: %s, name: %.20s..., cmd: %.35s%s",
												index++,
												wjd.getJobRequest().getSubmitIndex(),
												getUpTime(new Date().getTime(), wjd.getTimeFinished()),
												  		  wjd.getJobID().getJobIDString(),
														  wjd.getJobRequest().getUsername(),
														  wjd.getJobRequest().getJobName(),
														  wjd.getJobRequest().getCommand(),
														  wjd.getJobRequest().getCommand().length() > 30 ? "..." : "");
									}
									descriptors.clear();
								}
							}
						} else {
							PrintClusterStatus(ms);
						}

					}
					log.log(Level.INFO, "Status command completed.");
					return 0;
				}
			};
			fsm = new ManagerGetStateCmd(this, OnCommandComplete);
		} else if (m_Command.equalsIgnoreCase("Job")) {
			boolean block_to_completion = m_Option.contains("block_to_completion=true");
			boolean block_to_started = m_Option.contains("block_to_started=true");
			
			JobRequest jr;
			if (m_FileName == null || m_FileName.length() == 0)
				jr = JobRequest.BuildFromOptions(m_Option);
			else
				jr = JobRequest.BuildFromFile(m_FileName);
			
			return submitJob(jr, block_to_completion, block_to_started);
			
		} else if (m_Command.equalsIgnoreCase("Wait")) {
			if (m_Option != null && m_Option.length() > 1) {
				String[] pair = m_Option.trim().split("=");
				if (pair.length > 1) {
					String OP = pair[0];
					Integer ID = Integer.decode(pair[1]);
					if (OP.equalsIgnoreCase("id")) {
						JobID jid = new JobID(ID);
						JobToken jt = new JobToken(jid, m_ServerName, m_Port);
						log.logf(Level.INFO, "Waiting for job %d on %s:%d ...",
								ID, m_ServerName, m_Port);
						jt.WaitForCompletion();
					} else {
						throw new Exception("Unknown option: '" + OP + "'");
					}
				} else {
					throw new Exception("Option must be: id=<ID_NUMBER>");
				}
			} else {
				throw new Exception("Option must be: id=<ID_NUMBER>");
			}
		} else if (m_Command.equalsIgnoreCase("Stop")) {
			OnCommandComplete = new Delegate(this) {
				@Override
				public Integer Invoke(Object param) {
					log.log(Level.INFO, "Stop Command Completed.");
					return (Integer) param;
				}
			};
			fsm = new StopCmd(this, OnCommandComplete);
		} else if (m_Command.equalsIgnoreCase("Discover")) {
			if (m_Option != null && m_Option.length() > 1) {
				if (m_Option.equalsIgnoreCase("Worker")) {
					throw new Exception(
							"Individual worker discovery is not yet implented");
				} else if (m_Option.equalsIgnoreCase("manager")) {
					OnCommandComplete = new Delegate(this) {
						@Override
						public Integer Invoke(Object param) {
							log.log(Level.INFO, "Command issued.");
							return null;
						}
					};
					fsm = new DiscoverManagerCmd(this, OnCommandComplete);
				} else {
					throw new Exception(
							"Unknown option: "
									+ m_Option
									+ ", acceptable options are either worker or manager");
				}
			} else {
				throw new Exception("Must sepcify an option: worker or manager");
			}
		} else if (m_Command.equalsIgnoreCase("Kill")) {
			HashSet<JobID> jids = new HashSet<JobID>(1);
			HashSet<JobRequest> jrs = new HashSet<JobRequest>(1);

			String[] split = m_Option.split(",");
			for (String subSplit : split) {
				String[] pair = subSplit.split("=", 2);
				if (pair[0].equalsIgnoreCase("id")) {
					jids.add(new JobID(Integer.decode(pair[1])));
				}

				if (pair[0].equalsIgnoreCase("group")) {
					JobRequest jr = new JobRequest();
					jr.setGroupName(pair[1]);
					jrs.add(jr);
				}
				
				if (pair[0].equalsIgnoreCase("name")) {
					JobRequest jr = new JobRequest();
					jr.setJobName(pair[1]);
					jrs.add(jr);
				}
				
				if (pair[0].equalsIgnoreCase("user")) {
					JobRequest jr = new JobRequest();
					jr.setUsername(pair[1]);
					jrs.add(jr);
				}
			}

			boolean bCriteriaSet = (jids.size() > 0) || (jrs.size() > 0);
			if (bCriteriaSet) {
				log.log(Level.INFO, "Killing by:");
				if (jids.size() > 0) {
					log.logf(Level.INFO, "IDs: %s", jids);
				}
				if (jrs.size() > 0) {
					log.logf(Level.INFO, "JRs: %s", jrs);
				}
			} else {
				log.log(Level.SEVERE,
						"You must specify search criteria by using the -o modifier:\n"
						+ "\ti.e. -o id=JOBID,group=GROUPNAME,user=USERNAME...\n"
						+ "\tPlease note, that all parameters specified must match simultaneously: id=JOBID AND group=GROUPNAME\n");
				return -1;
			}

			JobSearchCriteria jsc = new JobSearchCriteria(false,
					jids.size() > 0, jids, jrs.size() > 0, jrs);

			fsm = new ManagerKillJobCmd(jsc, this, new Delegate(this) {
				@Override
				public Integer Invoke(Object param) {
					KillJobResults kjrs = (KillJobResults) param;
					log.logf(Level.FINEST, "Invoked with: %s", kjrs.toString());
					int count = 0;
					int killed_or_dequeued = 0;
					for (KillJobResult kjr : kjrs) {
						if (kjr != null) {
							WorkerJobDescriptor jd = kjr.getJobDescriptor();
							boolean killedOrDequeued = (kjr.getStatus().equals(KillJobStatus.SIGNAL_SENT) ||  kjr.getStatus().equals(KillJobStatus.DEQUEUED));
							if (!kjr.getStatus().equals(KillJobStatus.JOB_NOT_RUNNING_NOR_QUEUED)) {
								count++;
								killed_or_dequeued += killedOrDequeued ? 1 : 0;
								log.logf(Level.INFO, "[%3d] (%7s) Job %12s: %s", count,
										killedOrDequeued ?	"OKAY  " : "WARNING",
										jd != null ? jd.getJobID().getJobIDString() : "'unknown'",
										kjr.getMessage());
								
							}
						}
					}
					if (count == 0) {
						log.log(Level.INFO, "Nothing to do.");						
					}
					log.logf(Level.INFO, "Done, killed/dequeued %d jobs.", killed_or_dequeued);
					return 0;
				}
			});
		}

		return execFSM(fsm);
	}
	
	public int submitJob(final JobRequest jr, final boolean block_to_completion, final boolean block_to_started) {
		Delegate OnCommandComplete = new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				JobToken jt = (JobToken) param;
				if (jt != null) {
					log.logf(Level.INFO,
							"Got Job Token: ID = %s, Valid = %s, Msg = %s",
							jt.getJobID().getJobIDString(), jt.isValid().toString(), jt.getMessage());
					if (block_to_completion) {
						log.log(Level.INFO, "Blocking to completion... ");
						WorkerJobDescriptor jd = jt.WaitForCompletion();
						PrintJobDescriptor(jd, null);
					} else if (block_to_started) {
						log.log(Level.INFO, "Blocking to started... ");
						WorkerJobDescriptor jd = jt.WaitForStarted();
						PrintJobDescriptor(jd, null);
					} else {
						log.log(Level.INFO, "Non-Blocking mode, exiting.");
					}
				} else {
					log.logf(Level.INFO, "Failed: JobToken is null");
				}
				return 0;
			}
		};
		ManagerNewJobCmd mnjc;
		try {
			mnjc = new ManagerNewJobCmd(jr, this, OnCommandComplete);
		} catch (Exception e) {
			log.log(Level.INFO, "Failed: Exception when creating ManagerNewJobCmd FSM, trace:");
			e.printStackTrace();
			return -1;
		}
		return execFSM(mnjc);
	}
	
	private int execFSM(FSM fsm) {
		if (fsm != null)
			return fsm.Reset(null);
		return 0;
	}

	public int getPortNumber() {
		return m_Port;
	}

	public String getServerName() {
		return m_ServerName;
	}

	public String getCommand() {
		return m_Command;
	}

	public String getOption() {
		return m_Option;
	}

	public String[] getOtherArgs() {
		return m_OtherArgs;
	}

	public void setVerbosityLevel(Integer verbosityLevel) {
		m_VerbosityLevel = verbosityLevel;
	}
}
