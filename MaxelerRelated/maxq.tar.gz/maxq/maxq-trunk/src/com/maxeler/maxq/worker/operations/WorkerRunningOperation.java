package com.maxeler.maxq.worker.operations;

import java.nio.channels.SelectionKey;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;

public class WorkerRunningOperation extends Operation<WorkerQueryRouter> {

	public WorkerRunningOperation(WorkerQueryRouter r) {
		super("WorkerRunningOperation", r);
		
		State wfwSendRunningJobs = new State("wfwSendRunningJobs", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendRunningJobs = new State("SendRunningJobs", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerRunningOperation wro = (WorkerRunningOperation) m_Internal;
				try {
					wro.getRouter().getObjectStreams().SendObject(wro.getRouter().getWorkerServer().getRunningJobs());
				} catch (Exception e) {
					wro.getRouter().Terminate();
				}
						
				return 0; // This is an end state
			}			
		});
		
		State ErrorState = new State("ErrorState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				getRouter().Terminate();
				return 0;
			}			
		});
		
		AddState(wfwSendRunningJobs);
		AddState(SendRunningJobs);
		AddState(ErrorState);
		setInitialState(wfwSendRunningJobs);
		setCurrentState(wfwSendRunningJobs);
		
		AddTransition(new Transition(wfwSendRunningJobs, SendRunningJobs, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(SendRunningJobs, ErrorState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendRunningJobs, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfwSendRunningJobs, wfwSendRunningJobs, CommonEvents.eANY_EVENT));
		CreateDotGraph();
	}

}
