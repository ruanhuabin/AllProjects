package com.maxeler.maxq.manager.operations;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Map;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.GeneralServer;
import com.maxeler.maxq.ObjectStreamChannel;
import com.maxeler.maxq.OperationsRouter;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerServer;

/**
 * Contains the default FSM router
 * This FSM exists for the sole purpose of selecting the correct FSM that a new connection needs to use.
 * @author itay
 * 
 */
public class ManagerOperationsRouter extends OperationsRouter  {

	private ManagerServer m_ms;
	private SocketChannel m_sc;
	private ObjectStreamChannel m_os;
	
	/**
	 * @author itay
	 * @throws Exception 
	 */
	public ManagerOperationsRouter(ManagerServer ms, SocketChannel sc) {
		super("ManagerOperationsRouter");
		m_ms = ms;
		m_sc = sc;
		m_os = null;
	}
	
	@Override
	public void Init() {
		m_os = new ObjectStreamChannel(m_sc, m_sc.socket().getInetAddress().getHostName());
		
		State WaitForCommand = new State("WaitForCommand", new Delegate(this) {
				@Override
				public Integer Invoke(Object param) {
					// Do Nothing...
					// The next state is interested only in the Readable event,
					// so we set that as our interest set
					return SelectionKey.OP_READ;
				}
			});
		
		State ReadCommand = new State("ReadCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerOperationsRouter r = (ManagerOperationsRouter)m_Internal;
				try {					
					CommonCommands mc = (CommonCommands)r.getObjectStreams().ReceiveObject();
					// Got Command, Now select appropriate FSM
					Map<SocketChannel, FSM> FSMSelector = r.getManagerServer().getMapChannelFSM();
					FSM newFSM = null;
					if (mc.equals(CommonCommands.STATUS)) {
						newFSM = new StatusOperation(r);
					} else if (mc.equals(CommonCommands.STOP)) {
						newFSM = new StopOperation(r.getManagerServer());
					} else if (mc.equals(CommonCommands.REQUEST)) {
						ManagerRequestRouter mrr = new ManagerRequestRouter(r.getManagerServer(), r.getSocketChannel());
						mrr.Init();
						newFSM = mrr;
					} else if (mc.equals(CommonCommands.QUERY)) {
						ManagerQueryRouter mqr = new ManagerQueryRouter(r.getManagerServer(), r.getSocketChannel());
						mqr.Init();
						newFSM = mqr;
					} else if (mc.equals(CommonCommands.NOTIFY)) {
						ManagerNotifyRouter mnr = new ManagerNotifyRouter(r.getManagerServer(), r.getSocketChannel());
						mnr.Init();
						newFSM = mnr;
					}
					
					FSMSelector.put(r.getSocketChannel(), newFSM);
				} catch (Exception e) {
					try {
						r.getSocketChannel().close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					return 0;
				} 
				return SelectionKey.OP_WRITE;
			} });
		
		AddState(WaitForCommand);
		AddState(ReadCommand);
		AddTransition(new Transition(WaitForCommand, ReadCommand, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(WaitForCommand, WaitForCommand, CommonEvents.eANY_EVENT));
		setInitialState(WaitForCommand);
		setCurrentState(WaitForCommand);
		CreateDotGraph();
	}

	public ManagerServer getManagerServer() {
		return m_ms;
	}

	private SocketChannel getSocketChannel() {
		return m_sc;
	}

	public ObjectStreamChannel getObjectStreams() {
		return m_os;
	}
	
	public void Terminate() {
		Map<SocketChannel, FSM> selector = getManagerServer().getMapChannelFSM();
		selector.remove(getSocketChannel());
		try {
			getSocketChannel().close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		m_sc = null;
		m_os = null;
		m_ms = null;
	}

	@Override
	public OperationsRouter CreateNew(GeneralServer gs, SocketChannel sc) {
		return new ManagerOperationsRouter((ManagerServer)gs, sc);
	}
	
}