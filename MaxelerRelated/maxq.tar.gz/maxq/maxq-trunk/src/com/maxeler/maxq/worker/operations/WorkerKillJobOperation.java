/**
 * 
 */
package com.maxeler.maxq.worker.operations;

import java.nio.channels.SelectionKey;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobID;
import com.maxeler.maxq.worker.KillJobResult;

/**
 * @author itay
 *
 */
public class WorkerKillJobOperation extends Operation<WorkerRequestRouter> {

	JobID m_JobToKill = null;
	/**
	 * @param FSMName
	 * @param r
	 */
	public WorkerKillJobOperation(WorkerRequestRouter r) {
		super("WorkerKillJobOperation", r);
		
		State wfwSendAck = new State("wfwSendAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
		});
		
		State SendAck = new State("SendAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getRouter().getObjectStreams().SendObject(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		
		State wfrReadJobID = new State("wfrReadJobID", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}
			
		});
		
		State ReadJobID = new State("ReadJobID", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					m_JobToKill = (JobID) getRouter().getObjectStreams().ReceiveObject();
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}					
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State wfwSendKillResult = new State("wfwSendAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendKillResult = new State("SendKillResult", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				KillJobResult kjr = getRouter().getWorkerServer().KillJob(m_JobToKill);
				try {
					getRouter().getObjectStreams().SendObject(kjr);
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				getRouter().Terminate();
				return 0;
			}			
		});
		
		AddState(wfwSendAck);
		AddState(SendAck);
		AddState(wfrReadJobID);
		AddState(ReadJobID);
		AddState(wfwSendKillResult);
		AddState(SendKillResult);
		AddState(EndState);
		
		setInitialState(wfwSendAck);
		setCurrentState(wfwSendAck);
		
		AddTransition(new Transition(wfwSendAck, SendAck, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendAck, wfwSendAck, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendAck, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(SendAck, ReadJobID, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendAck, wfrReadJobID, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendAck, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(wfrReadJobID, ReadJobID, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrReadJobID, wfrReadJobID, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrReadJobID, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(ReadJobID, SendKillResult, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(ReadJobID, wfwSendKillResult, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadJobID, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(SendKillResult, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendKillResult, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();		
	}

}
