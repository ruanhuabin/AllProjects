package com.maxeler.maxq;

public abstract class Delegate {
	public Object m_Internal = null;
	
	public Delegate(Object Internal) {
		m_Internal = Internal;
	}
	
	public abstract Integer Invoke(Object param);
}
