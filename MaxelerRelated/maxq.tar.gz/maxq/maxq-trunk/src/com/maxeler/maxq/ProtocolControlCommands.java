package com.maxeler.maxq;

public enum ProtocolControlCommands {
	ACK,
	NACK
}
