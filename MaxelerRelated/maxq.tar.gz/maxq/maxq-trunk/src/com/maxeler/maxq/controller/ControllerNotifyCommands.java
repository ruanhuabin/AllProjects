package com.maxeler.maxq.controller;

public enum ControllerNotifyCommands {
	JOB_COMPLETED
}
