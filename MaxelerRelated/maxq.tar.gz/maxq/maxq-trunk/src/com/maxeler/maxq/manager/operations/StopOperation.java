package com.maxeler.maxq.manager.operations;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.OperationsServer;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;

public class StopOperation extends Operation<OperationsServer> {

	public StopOperation(OperationsServer r) {
		super("StopOperation", r);
		
		State Terminate = new State("Terminate", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StopOperation s = (StopOperation)m_Internal;
				s.getRouter().Exit();
				return 0;
			}			
		});
		
		AddState(Terminate);
		setInitialState(Terminate);
		setCurrentState(Terminate);
		AddTransition(new Transition(Terminate, Terminate, CommonEvents.eANY_EVENT));
		CreateDotGraph();
	}
}
