package com.maxeler.maxq.worker;

import java.io.Serializable;
import java.util.Map;

import com.maxeler.maxq.manager.JobID;

public class WorkerState implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3356856022771174219L;

	
	
	private WorkerID m_ID;
	private WorkerConfiguration m_wc;
	private WorkerResources m_wr;
	private Map<JobID, WorkerJobDescriptor> m_Running;
	private transient Map<JobID, JobMonitoringThread> m_Monitors;
	
	
	public WorkerID getID() {
		return m_ID;
	}
	
	public void setID(WorkerID id) {
		m_ID = id;
	}
	
	public WorkerConfiguration getConfiguration() {
		return m_wc;
	}
	
	public void setConfiguration(WorkerConfiguration wc) {
		m_wc = wc;
	}
	
	public WorkerResources getAvailableResources() {
		return m_wr;
	}
	
	public void setAvailableResources(WorkerResources wr) {
		m_wr = wr;
	}
	
	public Map<JobID, WorkerJobDescriptor> getRunningJobs() {
		return m_Running;
	}
	
	public void setRunningJobs(Map<JobID, WorkerJobDescriptor> running) {
		m_Running = running;
	}
	
	public Map<JobID, JobMonitoringThread> getJobMonitors() {
		return m_Monitors;
	}
	
	public void setJobMonitors(Map<JobID, JobMonitoringThread> monitors) {
		m_Monitors = monitors;
	}
}
