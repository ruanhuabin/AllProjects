package com.maxeler.maxq;

import java.io.IOException;
import java.nio.channels.SocketChannel;
import java.util.Hashtable;
import java.util.Map;
import java.util.logging.Level;

import com.maxeler.maxq.FSM.FSM;


public abstract class OperationsServer extends GeneralServer {
	
	private Map<SocketChannel, FSM> m_MapChannelFSM;
	
	private OperationsRouter m_RouterFactory;
	private final transient MaxQLogger log = MaxQLogger.getLogger("OperationsServer");
	
	public OperationsServer(int port, OperationsRouter routerFactory) throws IOException {
		super(port);
		m_RouterFactory = routerFactory;
		m_MapChannelFSM = new Hashtable<SocketChannel, FSM>();
	}

	/**
	 * Main Loop, Waits for new connections and dispatches events
	 * @throws Exception
	 */
	public void Start() throws Exception {
		m_Running = true;
		while (m_Running) {
			try {
				log.log(Level.FINEST, "Waiting for Connections...");
				WaitForEvents();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	@Override
	protected Integer OnEvent(SocketChannel channel, ChannelEvents eventID) throws Exception {
		if (getMapChannelFSM().containsKey(channel)) {
			FSM fsm = getMapChannelFSM().get(channel);
			return fsm.HandleEvent(new ChannelEvent(eventID), null);
		} 
		
		OperationsRouter router = m_RouterFactory.CreateNew(this, channel);
		router.Init();
		return router.HandleEvent(new ChannelEvent(eventID));			
	}

	public Map<SocketChannel, FSM> getMapChannelFSM() {
		return m_MapChannelFSM;
	}
	
	public void Stop() {
		m_Running = false;
		WakeUp();
		log.log(Level.FINE, "Stopping.");
	}
	
	public abstract void Exit();
}
