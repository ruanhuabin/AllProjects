/**
 * 
 */
package com.maxeler.maxq.manager;

import com.maxeler.maxq.CommonResponses;

/**
 * @author itay
 *
 */
public class ManagerReply {
	private CommonResponses m_mr; 
	private Object m_er;
	
	public ManagerReply(CommonResponses mr, Object ExtendedResponse) {
		m_mr = mr;
		m_er = ExtendedResponse;
	}

	public CommonResponses getManagerResponse() {
		return m_mr;
	}


	public Object getExtendedResponse() {
		return m_er;
	}
}
