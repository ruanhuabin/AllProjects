/**
 * 
 */
package com.maxeler.maxq.manager;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Properties;

import com.maxeler.maxq.Globals;


/**
 * @author itay
 *
 */
public class ManagerConfiguration {
	
	private String m_Name;
	private Integer m_ListenPort;
	private String m_WorkersPoolFilePath = null;
	private String m_ManagerStateFilePath = null;
	private String m_TempDirectory = null;
	private ArrayList<String> m_WorkerNames;

	public ManagerConfiguration(String ConfigFilePath) throws Exception {
		m_WorkerNames = new ArrayList<String>();
		FileReader fr = new FileReader(ConfigFilePath);
		Properties p = new Properties();
		p.load(fr);
		fr.close();
		
		m_Name = p.getProperty("name", System.getenv("HOSTNAME"));
		m_ListenPort = Integer.parseInt(p.getProperty("listen_port", Integer.toString(Globals.ManagerPort)));
		m_WorkersPoolFilePath = p.getProperty("workers_file");
		m_ManagerStateFilePath = p.getProperty("state_file");
		m_TempDirectory = p.getProperty("temp_dir", Globals.DefaultTempDirectory);
		
		if (m_WorkersPoolFilePath != null) {
			FileReader frWorkersPool = new FileReader(m_WorkersPoolFilePath);
			BufferedReader br = new BufferedReader(frWorkersPool);
			String worker;
			while ((worker = br.readLine()) != null) {
				m_WorkerNames.add(worker);
			}
			br.close();
			frWorkersPool.close();
		}
		
	}

	public String getName() {
		return m_Name;
	}

	public Integer getListenPort() {
		return m_ListenPort;
	}

	public String getWorkersPoolFilePath() {
		return m_WorkersPoolFilePath;
	}
	
	public String getStateFilePath() {
		return m_ManagerStateFilePath;
	}
	
	public String getTempDirectory() {
		return m_TempDirectory;
	}

	public ArrayList<String> getWorkerNames() {
		try {
			if (m_WorkersPoolFilePath != null) {
				FileReader frWorkersPool = new FileReader(m_WorkersPoolFilePath);
				BufferedReader br = new BufferedReader(frWorkersPool);
				String worker;
				m_WorkerNames.clear();
				while ((worker = br.readLine()) != null) {
					m_WorkerNames.add(worker);
				}
				br.close();
				frWorkersPool.close();
			}
		} catch (Exception e) {
			
		}
		
		return m_WorkerNames;
	}
	
}
