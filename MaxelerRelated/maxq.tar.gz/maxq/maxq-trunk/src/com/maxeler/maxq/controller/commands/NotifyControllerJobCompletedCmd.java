/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

/**
 * @author itay
 *
 */
public class NotifyControllerJobCompletedCmd extends ControllerCmd {

	private WorkerJobDescriptor m_CompletedJobDescriptor;
	
	/**
	 * 
	 * This is command is used by the Manager Server to notify a blocking controller
	 * that a job has completed 
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public NotifyControllerJobCompletedCmd(WorkerJobDescriptor completedJobDescriptor, CommandRouter cr, Delegate OnCommandCompletion) throws Exception {
		super("NotifyControllerJobCompletedCmd", cr, OnCommandCompletion);
		
		m_CompletedJobDescriptor = completedJobDescriptor;
		
		State SendNotifyCommand = new State("SendNotifyCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyControllerJobCompletedCmd ncjcc = (NotifyControllerJobCompletedCmd) m_Internal;
				try {
					ncjcc.getControllerClient().getObjectStreams().SendObject(CommonCommands.NOTIFY);
					ncjcc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						ncjcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State ReadNotifyElabCommand = new State("ReadNotifyElabCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyControllerJobCompletedCmd ncjcc = (NotifyControllerJobCompletedCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) ncjcc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.NOTIFY_ELAB)) {
						ncjcc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						ncjcc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						ncjcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
//		State SendNotifyJobCompletedCommand = new State("SendNotifyJobCompletedCommand", new Delegate(this) {
//			@Override
//			public Integer Invoke(Object param) {
//				NotifyControllerJobCompletedCmd ncjcc = (NotifyControllerJobCompletedCmd) m_Internal;
//				try {
//					ncjcc.getControllerClient().getObjectStreams().SendObject(ControllerNotifyCommands.JOB_COMPLETED);
//					ncjcc.HandleEvent(CommonEvents.eSTEP_EVENT);
//				} catch (Exception e) {
//					try {
//						ncjcc.HandleEvent(CommonEvents.eERROR_EVENT);
//					} catch (Exception e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//				return 0;
//			}			
//		});
//		
//		State ReadNotifyJobCompletedCommandACK = new State("ReadNotifyJobCompletedCommandACK", new Delegate(this) {
//			@Override
//			public Integer Invoke(Object param) {
//				NotifyControllerJobCompletedCmd ncjcc = (NotifyControllerJobCompletedCmd) m_Internal;
//				try {
//					ProtocolControlCommands pcc = (ProtocolControlCommands) ncjcc.getControllerClient().getObjectStreams().ReceiveObject();
//					if (pcc.equals(ProtocolControlCommands.ACK)) {
//						ncjcc.HandleEvent(CommonEvents.eSTEP_EVENT);
//					} else {
//						ncjcc.HandleEvent(CommonEvents.eERROR_EVENT);
//					}
//				} catch (Exception e) {
//					try {
//						ncjcc.HandleEvent(CommonEvents.eERROR_EVENT);
//					} catch (Exception e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//				return 0;
//			}			
//		});
		
		State SendCompletedJobDescriptor = new State("SendCompletedJobDescriptor", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyControllerJobCompletedCmd ncjcc = (NotifyControllerJobCompletedCmd) m_Internal;
				try {
					ncjcc.getControllerClient().getObjectStreams().SendObject(ncjcc.getCompletedJobDescriptor());
					ncjcc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						ncjcc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				NotifyControllerJobCompletedCmd ncjcc = (NotifyControllerJobCompletedCmd) m_Internal;
				ncjcc.getControllerClient().Close();
				return 0;
			}
		});
		
		AddState(SendNotifyCommand);
		AddState(ReadNotifyElabCommand);
		//AddState(SendNotifyJobCompletedCommand);
		//AddState(ReadNotifyJobCompletedCommandACK);
		AddState(SendCompletedJobDescriptor);
		AddState(EndState);
		
		setInitialState(SendNotifyCommand);
		setCurrentState(SendNotifyCommand);
		
		AddTransition(new Transition(SendNotifyCommand, ReadNotifyElabCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadNotifyElabCommand, SendCompletedJobDescriptor, CommonEvents.eSTEP_EVENT));
		//AddTransition(new Transition(SendNotifyJobCompletedCommand, ReadNotifyJobCompletedCommandACK, CommonEvents.eSTEP_EVENT));
		//AddTransition(new Transition(ReadNotifyJobCompletedCommandACK, SendCompletedJobDescriptor, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendCompletedJobDescriptor, EndState, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(SendNotifyCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadNotifyElabCommand, EndState, CommonEvents.eERROR_EVENT));
//		AddTransition(new Transition(SendNotifyJobCompletedCommand, EndState, CommonEvents.eERROR_EVENT));
//		AddTransition(new Transition(ReadNotifyJobCompletedCommandACK, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendCompletedJobDescriptor, EndState, CommonEvents.eERROR_EVENT));
		
		CreateDotGraph();
	}

	public WorkerJobDescriptor getCompletedJobDescriptor() {
		return m_CompletedJobDescriptor;
	}

}
