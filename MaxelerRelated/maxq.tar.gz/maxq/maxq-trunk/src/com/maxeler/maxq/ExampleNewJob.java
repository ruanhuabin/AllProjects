/**
 * 
 */
package com.maxeler.maxq;

import java.util.TreeSet;

import com.maxeler.maxq.controller.commands.CommandRouter;
import com.maxeler.maxq.controller.commands.ManagerNewJobCmd;
import com.maxeler.maxq.manager.JobToken;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.WorkerJobDescriptor;
import com.maxeler.maxq.worker.WorkerResources;

/**
 * @author itay
 *
 */
public class ExampleNewJob {

	public static WorkerJobDescriptor CompletedJobDescriptor;
	public static JobToken SubmittedJobToken;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/**
		 * The Command Router is used to specify the a server's address and port
		 * The address can either be a Manager's address or a Worker's address, depending 
		 * on the type of command you intend to issue.
		 * 
		 * In general, it is used to select the proper FSM when issuing a command line
		 * Job, but since we use it manually, we only need to supply an address and a port. 
		 */
		CommandRouter cr = new CommandRouter("drought", Globals.ManagerPort);
		
		/**
		 * Create a job request object
		 */
		String JobName = "My Job's Name";
		String command = "/usr/bin/perl"; // Our favourite scripting language
		String arg = "-e '$| = 1; for (1..2) { print \"$_. hello world\\n\"; sleep 1;}'";
		String workingDir = System.getenv("HOME"); // working directory
		
		// Worker Resources object
		Float neededCores = Float.parseFloat("1"); 
		Integer neededMemory = 1024; // MBytes
		TreeSet<String> neededTags = new TreeSet<String>();
		neededTags.add("linux");		
		WorkerResources wr = new WorkerResources(neededCores, neededMemory, neededTags);
		
		// Instantiate the job request object
		JobRequest jr = new JobRequest(JobName, command, arg, workingDir, wr);
		
		Object someObject = null;
		
		
		/**
		 * Create a completion Event Delegate
		 * The delegat's 'Invoke' method would be called with the job token passed
		 * as the parameter.
		 * The job token is used to monitor the submitted job
		 */
		Delegate OnCompletionRoutine = new Delegate(someObject) { // argument will be saved as m_Internal 
			
			@Override
			public Integer Invoke(Object param) {
				Object sameObject = m_Internal;
				if (sameObject == null) {
					// do nothing
				}
				// Save the token aside
				ExampleNewJob.SubmittedJobToken = (JobToken)param;
				return null;
			}
			
		};
		
		/**
		 * Now, we instantiate the command object.
		 * Notice that this is specific for a manager.
		 * The worker equivalent is: WorkerNewJobCmd
		 */
		ManagerNewJobCmd mnjc = null;
		try {
			mnjc = new ManagerNewJobCmd(jr, cr, OnCompletionRoutine);
		} catch (Exception e) {
			System.out.printf("Oh oh: %s\n", e.getMessage());
			System.exit(-1);
		}		
		
		
		// Start it up
		// This basically changes the FSM's state to the initial state and "Enters" it.
		mnjc.Reset(null);
		
		// Since this is a Controller command, it is blocking by nature,
		// meaning, that each state of the FSM immediately invokes a transition to a different
		// state according to the outcome of the commands issued in the given state.
		
		// You can see the FSM visually by checking out its dot graph:
		// ManagerNewJobCmd.dot
		// in the current working directory.
		
		// The FSM has completed by this point so the Job token is in SubmittedJobToken.
		System.out.printf("Job submitted: %s\n", SubmittedJobToken.isValid() ? "Successfuly" : "ERROR!");
		
		
		if (!SubmittedJobToken.isValid()) {
			System.out.printf("Job submission failed because: %s\n", SubmittedJobToken.getMessage());
		} else {
			System.out.printf("Job ID: %d\n", SubmittedJobToken.getJobID().getJobIDCode());
		
			System.out.printf("\nWaiting for job completion...\n\n");
			// We can now wait for completion of the Job:
			WorkerJobDescriptor jd = SubmittedJobToken.WaitForCompletion(); 
			
			// There is also a non-blocking version
			//WorkerJobDescriptor jd = SubmittedJobToken.QueryStatus();
			// You can use that to receive a WorkerJobDescriptor for a currently executing job.
			// The function blocked until a notification event was received.
			// The Job descriptor will provide all information about the executed job:
			if (jd != null) { // Shouldn't ever be null...
				if (jd.getJobRequest() == null) {
					System.out.printf("----- Job %d Was not found.", jd.getJobID().getJobIDString());
				} else {
					System.out.printf("Job %d was submitted to worker %s\n" +
							"The job %s start.\n" +
							"The worker's execution code was: '%d' with a message of: '%s'\n" +
							"The Job is %s currently running.\n" +
							"The return code was: %d\n" +
							"The execution script was: %s\n" +
							"The Log file was: %s\n" +
							"The Fifo path: %s\n" +
							"The Screen ID was: %s\n", jd.getJobID().getJobIDCode(), jd.getInQueue() ? "NOT YET ASSIGNED" : jd.getExecutingWorkerID().getAddress(), 
							jd.getStarted() ? "did" : "did not", 
							jd.getExecutionErrorCode(),	jd.getExecutionErrorMessage(), jd.getRunning() ? "STILL" : "not", 
						    jd.getExitCode(), jd.getInQueue() ? "NOT YET ASSIGNED" : jd.getScriptPath(), jd.getInQueue() ? "NOT YET ASSIGNED" : jd.getLogPath(), jd.getInQueue() ? "NOT YET ASSIGNED" : jd.getExitCodeFilePath(),
						    jd.getInQueue() ? "NOT YET ASSIGNED" : "maxq" + jd.getJobID().getJobIDString());
				}
			} else {
				System.out.println("Oh no! The job descriptor came out as null!!\n");			
			}
		}
	}

}
