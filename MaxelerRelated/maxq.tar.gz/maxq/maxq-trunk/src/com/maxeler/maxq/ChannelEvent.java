package com.maxeler.maxq;

import com.maxeler.maxq.FSM.Event;

public class ChannelEvent extends Event {
	public ChannelEvent(ChannelEvents Event) {
		super(Event.ordinal(), Event.toString());
	}
	
	public ChannelEvents getServerEvent() {
		return ChannelEvents.values()[getEventID()];		
	}
}
