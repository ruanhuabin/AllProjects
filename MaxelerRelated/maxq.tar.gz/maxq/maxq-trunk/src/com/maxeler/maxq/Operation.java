package com.maxeler.maxq;

import com.maxeler.maxq.FSM.FSM;

public class Operation<T_Router> extends FSM {

	T_Router m_Router;
	
	public Operation(String FSMName, T_Router r) {
		super(FSMName);
		m_Router = r;
	}
	
	public T_Router getRouter() {
		return m_Router;
	}
}
