/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.Event;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobToken;
import com.maxeler.maxq.manager.ManagerRequestCommands;
import com.maxeler.maxq.worker.JobRequest;

/**
 * This commands submits a new job to the manager's Queue
 * @author itay
 *
 */
public class ManagerNewJobCmd extends ControllerCmd {

	private JobRequest m_JobRequest;
	private JobToken m_JobToken;
	
	public final Integer QUEUE_FAILED = 5;
	public final Integer QUEUE_OK = 10;
	
	/**
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public ManagerNewJobCmd(JobRequest jr, CommandRouter cr,
			Delegate OnCommandCompletion) throws Exception {
		super("ManagerNewJobCmd", cr, OnCommandCompletion);
		
		m_JobRequest = jr;
		m_JobToken = null;
		
		State SendManagerRequestCommand = new State("SendManagerRequestCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobCmd mnjc = (ManagerNewJobCmd) m_Internal;
				try {
					mnjc.getControllerClient().getObjectStreams().SendObject(CommonCommands.REQUEST);
					mnjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadManagerRequestElab = new State("ReadManagerRequestElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobCmd mnjc = (ManagerNewJobCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) mnjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.REQUEST_ELAB)) {
						mnjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});	

		State SendManagerNewJobRequestCommand = new State("SendManagerNewJobRequestCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobCmd mnjc = (ManagerNewJobCmd) m_Internal;
				try {
					mnjc.getControllerClient().getObjectStreams().SendObject(ManagerRequestCommands.NEWJOB);
					mnjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});

		State ReadManagerNewJobRequestCommandACK = new State("ReadManagerNewJobRequestCommandACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobCmd mnjc = (ManagerNewJobCmd) m_Internal;
				try {
					ProtocolControlCommands pcc = (ProtocolControlCommands) mnjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (pcc.equals(ProtocolControlCommands.ACK)) {
						mnjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
	
		State SendNewJobRequestObject = new State("SendNewJobRequestObject", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobCmd mnjc = (ManagerNewJobCmd) m_Internal;
				try {
					mnjc.getControllerClient().getObjectStreams().SendObject(mnjc.getJobRequest());
					mnjc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
	
		State ReadNewJobToken = new State("ReadNewJobToken", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobCmd mnjc = (ManagerNewJobCmd) m_Internal;
				try {
					JobToken jt = (JobToken) mnjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (jt != null) {
						mnjc.setJobToken(jt);
						if (jt.isValid()) {
							mnjc.HandleEvent(new Event(mnjc.QUEUE_OK, "Queue OK"));
						} else {
							mnjc.HandleEvent(new Event(mnjc.QUEUE_FAILED, "Queue FAILED"));
						}
					} else {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						mnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
	
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNewJobCmd mnjc = (ManagerNewJobCmd) m_Internal;
				mnjc.getControllerClient().Close();
				if (mnjc.getOnCommandCompletion() != null) {
					mnjc.getOnCommandCompletion().Invoke(mnjc.getJobToken());
				}
				return 0;
			}			
		});
		
		AddState(SendManagerRequestCommand);
		AddState(ReadManagerRequestElab);
		AddState(SendManagerNewJobRequestCommand);
		AddState(ReadManagerNewJobRequestCommandACK);
		AddState(SendNewJobRequestObject);
		AddState(ReadNewJobToken);
		AddState(EndState);
		
		setCurrentState(SendManagerRequestCommand);
		setInitialState(SendManagerRequestCommand);
		
		AddTransition(new Transition(SendManagerRequestCommand, ReadManagerRequestElab, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadManagerRequestElab, SendManagerNewJobRequestCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendManagerNewJobRequestCommand, ReadManagerNewJobRequestCommandACK, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadManagerNewJobRequestCommandACK, SendNewJobRequestObject, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendNewJobRequestObject, ReadNewJobToken, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadNewJobToken, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(SendManagerRequestCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadManagerRequestElab, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendManagerNewJobRequestCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadManagerNewJobRequestCommandACK, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendNewJobRequestObject, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eERROR_EVENT));
		
		CreateDotGraph();
	}

	public JobRequest getJobRequest() {
		return m_JobRequest;
	}

	public void setJobRequest(JobRequest jobRequest) {
		m_JobRequest = jobRequest;
	}

	public JobToken getJobToken() {
		return m_JobToken;
	}

	public void setJobToken(JobToken jobToken) {
		m_JobToken = jobToken;
	}

}
