package com.maxeler.maxq.manager;

public enum ManagerNotifyCommands {
	JOB_COMPLETED
}
