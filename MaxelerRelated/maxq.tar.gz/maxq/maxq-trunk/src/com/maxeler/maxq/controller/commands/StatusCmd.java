package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.Status;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.Event;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;

public class StatusCmd extends ControllerCmd {

	Status m_s;
	
	public StatusCmd(CommandRouter cr, Delegate OnCommandCompletion) throws Exception {
		super("StatusCommand",cr, OnCommandCompletion);
		m_s = null;
		
		State SendCommand = new State("SendCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusCmd s = (StatusCmd)m_Internal;
				try {
					s.getControllerClient().getObjectStreams().SendObject(CommonCommands.STATUS);
					s.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						s.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State ReadCommandReply = new State("ReadCommandReply", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusCmd s = (StatusCmd)m_Internal;
				try {
					CommonResponses mr = (CommonResponses)s.getControllerClient().getObjectStreams().ReceiveObject();
					if (mr.compareTo(CommonResponses.STATUS_REPLY) == 0) {
						s.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						s.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						s.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}					
				}
				return 0;
			}
		});
		
		State SendReplyAck = new State("SendReplyAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusCmd s = (StatusCmd)m_Internal;
				try {
					s.getControllerClient().getObjectStreams().SendObject(ProtocolControlCommands.ACK);
					s.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						s.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State ReadExtendedReply = new State("ReadExtendedReply", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusCmd s = (StatusCmd)m_Internal;
				try {
					Status st = (Status)s.getControllerClient().getObjectStreams().ReceiveObject();
					s.setStatus(st);
					s.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						s.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}					
				}
				return 0;
			}
		}); 
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				StatusCmd s = (StatusCmd)m_Internal;
				s.getControllerClient().Close();
				// Provide Result
				s.getOnCommandCompletion().Invoke(s.getStatus());
				return 0;
			}
		}); 
		
		/*SendCommand
		ReadCommandReply
		SendReplyAck
		ReadExtendedReply
		EndState*/
		AddState(SendCommand);
		AddState(ReadCommandReply);
		AddState(SendReplyAck);
		AddState(ReadExtendedReply);
		AddState(EndState);
		
		AddTransition(new Transition(SendCommand, ReadCommandReply, new Event(Event.STEP_EVENT, "OK")));
		AddTransition(new Transition(ReadCommandReply, SendReplyAck, new Event(Event.STEP_EVENT, "OK")));
		AddTransition(new Transition(SendReplyAck, ReadExtendedReply, new Event(Event.STEP_EVENT, "OK")));
		AddTransition(new Transition(ReadExtendedReply, EndState, new Event(Event.STEP_EVENT, "OK")));
		AddTransition(new Transition(EndState, EndState, new Event(Event.ANY_EVENT, "Any")));
		
		AddTransition(new Transition(SendCommand, EndState, new Event(Event.ERROR_EVENT, "ERROR")));
		AddTransition(new Transition(ReadCommandReply, EndState, new Event(Event.ERROR_EVENT, "ERROR")));
		AddTransition(new Transition(SendReplyAck, EndState, new Event(Event.ERROR_EVENT, "ERROR")));
		AddTransition(new Transition(ReadExtendedReply, EndState, new Event(Event.ERROR_EVENT, "ERROR")));
		
		setCurrentState(SendCommand);
		setInitialState(SendCommand);		
		CreateDotGraph();
	}

	public Status getStatus() {
		return m_s;
	}

	public void setStatus(Status s) {
		m_s = s;
	}

	
}
