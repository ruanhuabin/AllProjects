/**
 * 
 */
package com.maxeler.maxq.manager;

import java.io.Serializable;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.TreeSet;

import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.WorkerID;
import com.maxeler.maxq.worker.WorkerJobDescriptor;
import com.maxeler.maxq.worker.WorkerResources;

/**
 * @author itay
 *
 */
public class ManagerState implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6536986457227528949L;

	private int m_ProcessedCount = 0;

	/**
	 * Workers' resources
	 */
	Map<WorkerID, WorkerResources> m_WorkerResources;
	
	NavigableSet<JobRequest> m_JobQueue;
	Map<JobID, WorkerJobDescriptor> m_ProcessedJobs;
	Map<JobID, JobRequest> m_TokenToJobMap;
	
	transient Map<JobID, List<FSM>> m_CompletionKeys;
	transient Map<JobID, List<FSM>> m_StartedKeys;
	
	int submitIndex = 0;
	public long m_ManagerNow;
	
	
	/**
	 * Processed job history limits
	 */
	public static int CleanupThreshold = 550;
	public static int CleanupTarget = 300;
	
	/**
	 * 
	 */
	public ManagerState() {
		m_TokenToJobMap = new Hashtable<JobID, JobRequest>(2);
		m_ProcessedJobs = new Hashtable<JobID, WorkerJobDescriptor>(2);
		m_JobQueue = new TreeSet<JobRequest>();
		m_WorkerResources = new Hashtable<WorkerID, WorkerResources>();
		m_CompletionKeys = new Hashtable<JobID, List<FSM>>();
		m_StartedKeys = new Hashtable<JobID, List<FSM>>();
		m_ManagerNow = new Date().getTime();
	}
	
	public void validate() {
		if (m_WorkerResources == null)
			m_WorkerResources = new Hashtable<WorkerID, WorkerResources>();
		if (m_JobQueue == null) 
			m_JobQueue = new TreeSet<JobRequest>();
		if (m_ProcessedJobs == null)
			m_ProcessedJobs = new Hashtable<JobID, WorkerJobDescriptor>();
		if (m_TokenToJobMap == null)
			m_TokenToJobMap = new Hashtable<JobID, JobRequest>();
		if (m_CompletionKeys == null)
			m_CompletionKeys = new Hashtable<JobID, List<FSM>>();
		if (m_StartedKeys == null)
			m_StartedKeys = new Hashtable<JobID, List<FSM>>();
		m_ManagerNow = new Date().getTime();
	}
	
	public String GetStatsString() {
		String stats = "State: ";
	
		stats += " res: " + m_WorkerResources.size();
		stats += ", q: " + m_JobQueue.size();
		stats += ", pro: " + m_ProcessedJobs.size();
		stats += ", tok: " + m_TokenToJobMap.size();
		stats += ", com: " + m_CompletionKeys.size();
		stats += ", sta: " + m_StartedKeys.size();
		
		stats += "\n";
		return stats;
	}

	public Map<WorkerID, WorkerResources> getWorkerResources() {
		return m_WorkerResources;
	}

	public NavigableSet<JobRequest> getJobQueue() {
		return m_JobQueue;
	}

	public Map<JobID, WorkerJobDescriptor> getProcessedJobs() {
		return m_ProcessedJobs;
	}

	public Map<JobID, JobRequest> getTokenToJobMap() {
		return m_TokenToJobMap;
	}

	public Map<JobID, List<FSM>> getCompletionKeys() {
		return m_CompletionKeys;
	}
	
	public Map<JobID, List<FSM>> getStartedKeys() {
		return m_StartedKeys;
	}

	public int getSubmitIndex() {
		return submitIndex;
	}
	
	public int NextSubmission() {
		return ++submitIndex;
	}
	
	public long getManagerTime() {
		return new Date().getTime();
	}
	
	public int getProcessedCount()	{
		return m_ProcessedCount;
	}
	
	public void incrementProcessedCount() {
		m_ProcessedCount++;
	}
}
