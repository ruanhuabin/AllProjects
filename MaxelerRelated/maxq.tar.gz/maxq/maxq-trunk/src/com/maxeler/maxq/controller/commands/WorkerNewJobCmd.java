/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.WorkerJobDescriptor;
import com.maxeler.maxq.worker.WorkerRequestCommands;

/**
 * @author itay
 *
 */
public class WorkerNewJobCmd extends ControllerCmd {

	private JobRequest m_JobRequest;
	private WorkerJobDescriptor m_WorkerJobDescriptor = null;
	private WorkerJobDescriptor m_TempWorkerJobDescriptor = null;
	
	/**
	 * 
	 * @param jr
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public WorkerNewJobCmd(JobRequest jr, CommandRouter cr,
			Delegate OnCommandCompletion) throws Exception {
		super("WorkerNewJobCmd", cr, OnCommandCompletion);
		
		m_JobRequest = jr;
		m_WorkerJobDescriptor = null;
		
		
		State SendWorkerRequestCommand = new State("SendWorkerRequestCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				try {
					wnjc.getControllerClient().getObjectStreams().SendObject(CommonCommands.REQUEST);
					wnjc.HandleEvent(CommonEvents.eSTEP_EVENT);										
				} catch (Exception e) {
					try {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}			
				return 0;
			}
		});
		
		State ReadRequestElab = new State("ReadRequestElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) wnjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.REQUEST_ELAB)) {
						wnjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State SendNewJobRequestCommand = new State("SendNewJobRequestCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				try {
					wnjc.getControllerClient().getObjectStreams().SendObject(WorkerRequestCommands.NEWJOB);
					wnjc.HandleEvent(CommonEvents.eSTEP_EVENT);										
				} catch (Exception e) {
					try {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}			
				return 0;
			}			
		});
		
		State ReadNewJobRequestCommandACK = new State("ReadNewJobRequestCommandACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				try {
					ProtocolControlCommands pcc = (ProtocolControlCommands) wnjc.getControllerClient().getObjectStreams().ReceiveObject();
					if (pcc.equals(ProtocolControlCommands.ACK)) {
						wnjc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}		
		});
		
		State SendNewJobRequestObject = new State("SendNewJobRequestObject", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				try {
					wnjc.getControllerClient().getObjectStreams().SendObject(wnjc.getJobRequest());
					wnjc.HandleEvent(CommonEvents.eSTEP_EVENT);										
				} catch (Exception e) {
					try {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadNewJobDescriptorObject = new State("ReadNewJobDescriptorObject", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				try {
					WorkerJobDescriptor wjd =  (WorkerJobDescriptor) wnjc.getControllerClient().getObjectStreams().ReceiveObject();
					wnjc.setTempWorkerJobDescriptor(wjd);
					wnjc.HandleEvent(CommonEvents.eSTEP_EVENT);					
				} catch (Exception e) {
					try {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State SendNewJobDescriptorACK = new State("SendNewJobDescriptorACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				try {
					wnjc.getControllerClient().getObjectStreams().SendObject(ProtocolControlCommands.ACK);
					wnjc.markFinalWorkerJobDescriptor();
					wnjc.HandleEvent(CommonEvents.eSTEP_EVENT);					
				} catch (Exception e) {
					try {
						wnjc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobCmd wnjc = (WorkerNewJobCmd) m_Internal;
				if (wnjc.getOnCommandCompletion() != null) {
					wnjc.getOnCommandCompletion().Invoke(wnjc.getWorkerJobDescriptor());
				}
				wnjc.getControllerClient().Close();
				return 0;
			}
		});
		
		AddState(SendWorkerRequestCommand);
		AddState(ReadRequestElab);
		AddState(SendNewJobRequestCommand);
		AddState(ReadNewJobRequestCommandACK);
		AddState(SendNewJobRequestObject);
		AddState(ReadNewJobDescriptorObject);
		AddState(SendNewJobDescriptorACK);
		AddState(EndState);
		setCurrentState(SendWorkerRequestCommand);
		setInitialState(SendWorkerRequestCommand);
		
		AddTransition(new Transition(SendWorkerRequestCommand, ReadRequestElab, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadRequestElab, SendNewJobRequestCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendNewJobRequestCommand, ReadNewJobRequestCommandACK, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadNewJobRequestCommandACK, SendNewJobRequestObject, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendNewJobRequestObject, ReadNewJobDescriptorObject, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadNewJobDescriptorObject, SendNewJobDescriptorACK, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendNewJobDescriptorACK, EndState, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(SendWorkerRequestCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadRequestElab, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendNewJobRequestCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadNewJobRequestCommandACK, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendNewJobRequestObject, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadNewJobDescriptorObject, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendNewJobDescriptorACK, EndState, CommonEvents.eERROR_EVENT));
		
		CreateDotGraph();
	}
	
	public void setJobRequest(JobRequest jr) {
		m_JobRequest = jr;
	}
	
	public JobRequest getJobRequest() {
		return m_JobRequest;
	}
	
	public void setTempWorkerJobDescriptor(WorkerJobDescriptor wjd) {
		m_TempWorkerJobDescriptor = wjd;
	}
	
	public void markFinalWorkerJobDescriptor() {
		m_WorkerJobDescriptor = m_TempWorkerJobDescriptor;
	}
	
	public WorkerJobDescriptor getWorkerJobDescriptor() {
		return m_WorkerJobDescriptor;
	}
}
