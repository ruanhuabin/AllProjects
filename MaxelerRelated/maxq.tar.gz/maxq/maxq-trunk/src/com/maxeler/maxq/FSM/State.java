package com.maxeler.maxq.FSM;

import com.maxeler.maxq.Delegate;

public class State {
	String m_StateName;
	Delegate m_OnEnter;
	
	public State(String Name, Delegate EntryFunction) {
		m_StateName = Name;
		m_OnEnter = EntryFunction;
	}
	
	public String getName() {
		return m_StateName;
	}
	
	public Boolean isEqualState(State state) {
		return (state.getName() == getName());
	}
	
	/**
	 * 
	 * @param param
	 * @return The Interest set of the next state (from channel.validOps())
	 */
	public Integer OnEnter(Object param) {
		return m_OnEnter.Invoke(param);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((m_StateName == null) ? 0 : m_StateName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final State other = (State) obj;
		if (m_StateName == null) {
			if (other.m_StateName != null)
				return false;
		} else if (!m_StateName.equals(other.m_StateName))
			return false;
		return true;
	}
}
