package com.maxeler.maxq.controller;

import java.util.logging.Level;

import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.controller.commands.CommandRouter;

import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;


public class Controller {

	public static final String version = "0.2";
	private static final MaxQLogger log = MaxQLogger.getLogger("Controller");
	
	public static void Syntax() {
		log.log(Level.INFO, "Syntax: maxqctl [option1] [arg1] [option2] [arg2] ... ");
		log.log(Level.INFO, "\t--help, -h : This help message");
		log.log(Level.INFO, "\t--command, -c <command> : A command to execute");
		log.log(Level.INFO, "\t--file,-f <file name> : A file containing extended command information");
		log.log(Level.INFO, "\t--option,-o <command option> : An option associated with a command");
		log.log(Level.INFO, "\t--server,-s <server address[:port]> : The address[:port] to connect to");
		log.log(Level.INFO, "\t--verbose,-v : Enable verbose output");
		log.log(Level.INFO, "\tTry --<option> help, eg. --command help");
	}
	
	public static void setVerboseLogging() {
		Globals.minLogLevel = Level.ALL;
		log.log(Level.FINEST, "Verbose logging requested.");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		//Logger.ShowLog(false);
		log.log(Level.INFO, "maxqctl v"+ version);
		
		if (args.length == 0) {
			Syntax();
			return;
		}
		
		StringBuffer CommandBuffer = new StringBuffer();
		StringBuffer FileBuffer = new StringBuffer();
		StringBuffer OptionBuffer = new StringBuffer();
		StringBuffer ServerBuffer = new StringBuffer();
		StringBuffer VerbosityBuffer = new StringBuffer();
		LongOpt[] longopts = new LongOpt[6];
		longopts[0] = new LongOpt("help", LongOpt.NO_ARGUMENT, null, 'h');
		longopts[1] = new LongOpt("command", LongOpt.REQUIRED_ARGUMENT, CommandBuffer, 'c');
		longopts[2] = new LongOpt("file", LongOpt.REQUIRED_ARGUMENT, FileBuffer, 'f');
		longopts[3] = new LongOpt("option", LongOpt.REQUIRED_ARGUMENT, OptionBuffer, 'o');
		longopts[4] = new LongOpt("server", LongOpt.REQUIRED_ARGUMENT, ServerBuffer, 's');
		longopts[5] = new LongOpt("verbose", LongOpt.OPTIONAL_ARGUMENT, VerbosityBuffer, 'v');
		
		Getopt g = new Getopt("maxqctl", args, "-:c:f:s:o:hv::", longopts);
		
		Integer c;
		String arg = "";
		String Command = null;
		String FileName = "";
		String Option = "";
		String Server = System.getenv("MAXQ_MANAGER") != null ? System.getenv("MAXQ_MANAGER") : "primary-maxq-manager";
		String verbose = "2";
		Boolean bVerbose = false;
		Integer verbosityLevel = 2;
		
		while ((c = g.getopt()) != -1) {
			switch (c) {
			case 0:
				arg = g.getOptarg();
				switch (g.getLongind()) {
				case 1:
					Command = arg;
					break;
				case 2: 
					FileName = arg;
					break;
				case 3:
					Option = arg;
					break;
				case 4:
					Server = arg;
					break;
				case 5:
					bVerbose = true;
					verbose = arg;
					break;
				}
				break;
			case 'c':
				Command = g.getOptarg();
				break;
			case 'f':
				FileName = g.getOptarg();
				break;
			case 'o':
				Option = g.getOptarg();
				break;
			case 's':
				Server = g.getOptarg();
				break;
			case 'v':
				bVerbose = true;
				verbose = g.getOptarg();
				break;
			default:
				Syntax();
				return;
			}
		}

		try {
			if (bVerbose) {
				verbosityLevel = Integer.decode(verbose);
			} 
		} catch (Exception e) {			
		}
		
		// Command and File are now set
		if (Command != null && Command.compareToIgnoreCase("help") == 0) {
			log.log(Level.INFO, "Valid commands are:");
			log.log(Level.INFO, "\tStatus");
			log.log(Level.INFO, "\tJob");
			log.log(Level.INFO, "\tWait");
			log.log(Level.INFO, "\tStop");
			log.log(Level.INFO, "\tDiscover");
			log.log(Level.INFO, "\tKill");
			return;
		}
		
		
		String [] OtherArgs = new String[args.length - g.getOptind()];
		for (int i = g.getOptind(); i < args.length; i++)
			OtherArgs[i] = args[i];
		
		// split server
		String [] split = Server.split(":", 2);
		Server = split[0];
		Integer port = Globals.ManagerPort;
		if (split.length == 2) {
			port = Integer.parseInt(split[1]);
		}
		
		CommandRouter cr = new CommandRouter(Server, port, Command, Option, FileName, OtherArgs);
		cr.setVerbosityLevel(verbosityLevel);
		
		try {
			System.exit(cr.Execute());
		} catch (Exception e) {
			log.logf(Level.INFO, "maxqctl Failed: %s", e.getMessage());
		}
	}
}
