package com.maxeler.maxq.controller;

import gnu.getopt.Getopt;
import gnu.getopt.LongOpt;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Globals;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.MaxQProperties;
import com.maxeler.maxq.controller.commands.CommandRouter;
import com.maxeler.maxq.controller.commands.ManagerNewJobCmd;
import com.maxeler.maxq.manager.JobToken;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

public class Submit {

	private static final MaxQLogger log = MaxQLogger.getLogger("maxqsubmit");

	public static JobToken token = null;
	
	public static void Syntax() {
		log.log(Level.INFO, "Syntax: maxqsubmit [option1] [arg1] [option2] [arg2] -- <command> <args>");
		log.log(Level.INFO, "\t--help, -h : This help message");
		log.log(Level.INFO, "\t--priority, -p <integer>");
		log.log(Level.INFO, "\t--mem, -m <memory>");
		log.log(Level.INFO, "\t--cores,-c <num cores>");
		log.log(Level.INFO, "\t--tags,-t <space seperated tags> : \"linux quadcore\"");
		log.log(Level.INFO, "\t--name,-n <job name>");
		log.log(Level.INFO, "\t--wd,-w <working directory path>");
		log.log(Level.INFO, "\t--group,-g <group name>");
		log.log(Level.INFO, "\t--worker,-k <worker name> : submit the job only to this worker");
		log.log(Level.INFO, "\t--block-to-completion,-b : wait for completion");
		log.log(Level.INFO, "\t--block-to-started,-r : wait for job to start");
		log.log(Level.INFO, "\t--attach,-a : Attaches a terminal to the running job using over ssh");
		log.log(Level.INFO, "\t--terminal,-l <terminal> : Uses the specified terminal program when attaching to a job [gnome-terminal, xterm, ...]");
		log.log(Level.INFO, "\t--server,-s <server address[:port]> : The address[:port] to connect to");
		log.log(Level.INFO, "\t--verbose,-v : Enable verbose output");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		log.log(Level.INFO, "maxqsubmit v0.2");
		
		Map<String, String> options = new Hashtable<String, String>();
		
		if (args.length == 0) {
			Syntax();
			return;
		}
		
		
		List<LongOpt> long_options = new ArrayList<LongOpt>();
		
		long_options.add(new LongOpt("help", LongOpt.NO_ARGUMENT, null, 'h')); 
		long_options.add(new LongOpt("verbose", LongOpt.OPTIONAL_ARGUMENT, new StringBuffer(), 'v'));
		long_options.add(new LongOpt("priority", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'p'));
		long_options.add(new LongOpt("mem", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'm'));
		long_options.add(new LongOpt("cores", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'c'));
		long_options.add(new LongOpt("tags", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 't'));
		long_options.add(new LongOpt("name", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'n'));
		long_options.add(new LongOpt("worker", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'k'));
		long_options.add(new LongOpt("wd", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'w'));
		long_options.add(new LongOpt("group", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'g'));
		long_options.add(new LongOpt("block-to-completion", LongOpt.NO_ARGUMENT, new StringBuffer(), 'b'));
		long_options.add(new LongOpt("block-to-started", LongOpt.NO_ARGUMENT, new StringBuffer(), 'r'));
		long_options.add(new LongOpt("attach", LongOpt.NO_ARGUMENT, new StringBuffer(), 'a'));
		long_options.add(new LongOpt("terminal", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 'l'));
		long_options.add(new LongOpt("server", LongOpt.REQUIRED_ARGUMENT, new StringBuffer(), 's'));		
		
		Getopt g = new Getopt("maxqctl", args, "-:hv::p:m:c:t:n:k:w:g:bral:s:", long_options.toArray(new LongOpt[0]));
		
		Integer c;
		String arg = "";
		String Server = System.getenv("MAXQ_MANAGER") != null ? System.getenv("MAXQ_MANAGER") : "primary-maxq-manager";
		//String verbose = "2";
		Boolean bVerbose = false;
		boolean block_to_completion = false;
		boolean block_to_started = false;
		
		String Terminal = "gnome-terminal";
		boolean connect = false;
		
		while ((c = g.getopt()) != -1) {
			switch (c) {
			case 0:
				arg = g.getOptarg();
				switch (g.getLongind()) {
				case 1:
					bVerbose = true;
					break;
				case 2: 
				case 3: 
				case 4: 
				case 5: 
				case 6:
				case 7:
				case 8:
					options.put(long_options.get(g.getLongind()).getName(), arg);
					break;
				case 9:
					block_to_completion = true;
					break;
				case 10:
					block_to_started = true;
					break;
				case 11:
					connect = true;
					break;
				case 12:
					Terminal = arg != null ? arg : Terminal;					
					break;
				case 13:
					Server = arg;
					break;
				default:
					Syntax();
					return;					
				}
				break;
			case 'a':
				connect = true;
				break;
			case 'l':
				Terminal = g.getOptarg() != null ? g.getOptarg() : Terminal;
				break;
			case 'n':
			case 'm':
			case 'p':
			case 'c':
			case 't':			
			case 'w':
			case 'g':
			case 'k':
				for (LongOpt lo : long_options) {
					if (lo.getVal() == c) {
						options.put(lo.getName(), g.getOptarg());
						break;
					}
				}
				break;
			case 's':
				Server = g.getOptarg();
				break;
			case 'b':
				block_to_completion = true;
				break;
			case 'r':
				block_to_started = true;
				break;
			case 'v':
				bVerbose = true;
				//verbose = g.getOptarg();
				break;
			default:
				Syntax();
				return;
			}
		}

		try {
			if (bVerbose) {
				//verbosityLevel = Integer.decode(verbose);
				Globals.minLogLevel = Level.ALL;
				log.log(Level.FINEST, "Verbose logging requested.");
			} 
		} catch (Exception e) {			
		}
		
		
		//String [] OtherArgs = new String[args.length - g.getOptind()];
		String command = args[g.getOptind()];
		options.put("command", command);
		String arguments = "";
		for (int i = g.getOptind()+1; i < args.length; i++) {
			arguments += args[i] + " ";
		}
		options.put("args", arguments);
		
		
		log.logf(Level.INFO, "Executing: %s %s", command, arguments);
		
		int port = 7001;
		String [] address = Server.split(":");
		try {
			if (address.length > 1) {
				port = Integer.decode(address[1]);
			}
		} catch (Exception e) {
			log.logf(Level.WARNING, "Exception while trying to decode port '%s' as an Integer.", address[1]);
		}
		
		
		MaxQProperties props = new MaxQProperties(options);
		JobRequest jr = JobRequest.BuildFromMaxQProperties(props);
		CommandRouter cr = new CommandRouter(Server, port);
		
		Delegate OnCommandComplete = new Delegate(null) {
			@Override
			public Integer Invoke(Object param) {
				token = (JobToken) param;
				return 0;
			}
		};
		
		ManagerNewJobCmd mnjc;
		try {
			mnjc = new ManagerNewJobCmd(jr, cr, OnCommandComplete);
			mnjc.Reset(null);
		} catch (Exception e) {
			log.log(Level.INFO, "Failed: Exception during ManagerNewJobCmd FSM, trace:");
			e.printStackTrace();
		}
		
		if (connect && !block_to_started) {
			log.log(Level.INFO, "Attach option implies block to start...");
			block_to_started = true;
		}
		
		if (token != null) {
			WorkerJobDescriptor jd = null;
			log.logf(Level.INFO, "Submitted: valid=%s,id=%s,msg=%s", token.isValid(), token.getJobID().getJobIDString(), token.getMessage());
			
			if (token.isValid()) {
				if (block_to_completion) { 
					jd = token.WaitForCompletion();
					cr.PrintJobDescriptor(jd, null);
				} else if (block_to_started) {
					log.log(Level.INFO, "Waiting for job to start...");
					jd = token.WaitForStarted();
					log.logf(Level.INFO, "Job %s started.", jd.getJobID().getJobIDString());
					if (connect) {
						log.log(Level.INFO, "Connecting to screen...");
						ProcessBuilder pb = new ProcessBuilder(Terminal, "-e", "ssh -t " + jd.getJobRequest().getUsername() + "@" + jd.getExecutingWorkerID().getAddress() + " screen -r maxq" + jd.getJobID().getJobIDString());
						try {
							pb.start();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		} else {
			log.log(Level.SEVERE, "Error: got null job-token.");
		}
		log.log(Level.INFO, "done.");
	}
	
}
