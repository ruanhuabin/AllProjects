/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.nio.channels.SelectionKey;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

/**
 * @author itay
 *
 */
public class ManagerJobCompletedOperation extends Operation<ManagerNotifyRouter> {
	
	/**
	 * 
	 * @param r
	 */
	public ManagerJobCompletedOperation(ManagerNotifyRouter r) {
		super("ManagerJobCompletedOperation", r);
		
		// Wait
		State wfwSendAck = new State("wfwSendAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		// Write
		State SendAck = new State("SendAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerJobCompletedOperation jco = (ManagerJobCompletedOperation) m_Internal;
				try {
					jco.getRouter().getObjectStreams().SendObject(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						return jco.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
						return 0;
					}					
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		// Wait
		State wfrReadCompletedJobDescriptor = new State("wfrReadCompletedJobDescriptor", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		// Read
		State ReadCompletedJobDescriptor = new State("ReadCompletedJobDescriptor", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerJobCompletedOperation jco = (ManagerJobCompletedOperation) m_Internal;
				try {
					WorkerJobDescriptor jd = (WorkerJobDescriptor)jco.getRouter().getObjectStreams().ReceiveObject();
					jco.getRouter().getManagerServer().OnJobCompleted(jd);
				} catch (Exception e) {
					try {
						return jco.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
						return 0;
					}
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		// Finish		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerJobCompletedOperation jco = (ManagerJobCompletedOperation) m_Internal;
				jco.getRouter().Terminate();
				return 0;
			}			
		});
		
		AddState(wfwSendAck);
		AddState(SendAck);
		AddState(wfrReadCompletedJobDescriptor);
		AddState(ReadCompletedJobDescriptor);
		AddState(EndState);
		setCurrentState(wfwSendAck);
		setInitialState(wfwSendAck);
		
		AddTransition(new Transition(wfwSendAck, SendAck, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendAck, wfwSendAck, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendAck, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(SendAck, ReadCompletedJobDescriptor, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendAck, wfrReadCompletedJobDescriptor, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendAck, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(wfrReadCompletedJobDescriptor, ReadCompletedJobDescriptor, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrReadCompletedJobDescriptor, wfrReadCompletedJobDescriptor, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrReadCompletedJobDescriptor, EndState, CommonEvents.eERROR_EVENT));
		
		AddTransition(new Transition(ReadCompletedJobDescriptor, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}
}
