package com.maxeler.maxq.manager.operations;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Map;

import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.GeneralServer;
import com.maxeler.maxq.ObjectStreamChannel;
import com.maxeler.maxq.OperationsRouter;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerNotifyCommands;
import com.maxeler.maxq.manager.ManagerServer;

public class ManagerNotifyRouter extends OperationsRouter {

	private ManagerServer m_ms;
	private SocketChannel m_sc;
	private ObjectStreamChannel m_os;
	
	public ManagerNotifyRouter(ManagerServer ms, SocketChannel sc) {
		super("ManagerNotifyRouter");		
		m_ms = ms;
		m_sc = sc;
		m_os = null;
	}

	@Override
	public OperationsRouter CreateNew(GeneralServer gs, SocketChannel sc) {
		return new ManagerNotifyRouter((ManagerServer)gs, sc);
	}

	@Override
	public void Init() {
		m_os = new ObjectStreamChannel(m_sc, m_sc.socket().getInetAddress().getHostName());
		
		State wfwSendNotifyElab = new State("wfwSendNotifyElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// TODO Auto-generated method stub
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendNotifyElab = new State("SendNotifyElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNotifyRouter r = (ManagerNotifyRouter) m_Internal;
				try {
					r.getObjectStreams().SendObject(CommonResponses.NOTIFY_ELAB);
				} catch (Exception e) {
					try {
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State wfrReadNotifyCommand = new State("wfrReadNotifyCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadNotifyCommand = new State("ReadNotifyCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerNotifyRouter r = (ManagerNotifyRouter)m_Internal;
				try {
					ManagerNotifyCommands wqc =  (ManagerNotifyCommands) r.getObjectStreams().ReceiveObject();
					
					Map<SocketChannel, FSM> FSMSelector = r.getManagerServer().getMapChannelFSM();
					FSM newFSM = r;
					// Routing
					if (wqc.equals(ManagerNotifyCommands.JOB_COMPLETED)) {
						newFSM = new ManagerJobCompletedOperation(r);
					}
					FSMSelector.put(r.getSocketChannel(), newFSM);
				} catch (Exception e) {
					try {
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}
		});
		
		State ErrorState = new State("ErrorState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					Terminate();
				} catch (Exception e) {
				
				}
				return 0;
			}
		});
		
		AddState(wfwSendNotifyElab);
		AddState(SendNotifyElab);
		AddState(wfrReadNotifyCommand);
		AddState(ReadNotifyCommand);
		AddState(ErrorState);
		setInitialState(wfwSendNotifyElab);
		setCurrentState(wfwSendNotifyElab);
		
		AddTransition(new Transition(wfwSendNotifyElab, SendNotifyElab, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendNotifyElab, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfwSendNotifyElab, wfwSendNotifyElab, CommonEvents.eANY_EVENT));
		
		
		AddTransition(new Transition(SendNotifyElab, wfrReadNotifyCommand, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendNotifyElab, ReadNotifyCommand, CommonEvents.eCHANNEL_READABLE));
		
		AddTransition(new Transition(wfrReadNotifyCommand, ReadNotifyCommand, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrReadNotifyCommand, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfrReadNotifyCommand, wfrReadNotifyCommand, CommonEvents.eANY_EVENT));

		
		AddTransition(new Transition(ReadNotifyCommand, ErrorState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ErrorState, ErrorState, CommonEvents.eANY_EVENT));
	}
	
	public ManagerServer getManagerServer() {
		return m_ms;
	}

	private SocketChannel getSocketChannel() {
		return m_sc;
	}

	public ObjectStreamChannel getObjectStreams() {
		return m_os;
	}
	
	public void Terminate() {
		Map<SocketChannel, FSM> selector = getManagerServer().getMapChannelFSM();
		selector.remove(getSocketChannel());
		try {
			getSocketChannel().close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		m_sc = null;
		m_os = null;
		m_ms = null;
	}
	
	public static void main(String [] args) {
		ManagerNotifyRouter mnr = new ManagerNotifyRouter(null, null);
		mnr.Init();
		mnr.CreateDotGraph();		
	}

}
