package com.maxeler.maxq.worker;

import java.io.Serializable;

public class Tag implements Limited, Comparable<Tag>, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6440989113314605969L;
	public String m_tag;
	private int m_free;
	private final int m_total; 
	
	public Tag(String tag, int total_amount) {
		m_tag = tag;
		m_free = m_total = total_amount;
	}

	@Override
	public void Allocate(int amount) throws Exception {
		if (m_total == 0) return;
		amount = amount >= 1 ? amount : 1;
		if (m_free < amount) throw new Exception(m_tag + ": Insufficent free tags: " + m_free + " < " + amount);
		m_free -= amount;
	}

	@Override
	public void Free(int amount) throws Exception {
		if (m_total == 0) return;
		amount = amount >= 1 ? amount : 1;
		if (m_free+amount > m_total) throw new Exception(m_tag + ": Cannot free more tags than the total_amount: " + m_free + " + "+amount + " > " + m_total);
		m_free += amount;
	}

	@Override
	public boolean CanAllocate(int amount) {
		if (m_total == 0) return true;
		amount = amount >= 1 ? amount : 1;
		return amount <= m_free;
	}

	@Override
	public int getTotal() {
		return m_total;
	}
	
	public String getTag() {
		return m_tag;
	}

	@Override
	public String toString() {
		return (m_total == 0 ? "":m_total + "*") + m_tag; 
	}

	@Override
	public int compareTo(Tag o) {
		return getTag().compareTo(o.getTag());
	}
}
