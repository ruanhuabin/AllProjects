package com.maxeler.maxq;

import java.util.logging.Level;


public class StateSaverThread implements Runnable, Stoppable, Comparable<Object> {
	
	private final transient MaxQLogger log = MaxQLogger.getLogger("WorkerStateSaverThread");
	private SaveableState m_Saveable;
	private boolean m_Stop = false;
	private Thread m_Thread;
	
	
	public StateSaverThread(SaveableState saveable) {
		m_Saveable = saveable;
	}
	
	public void Start() {
		m_Thread = new Thread(this, "maxq_state_saver_thread");
		m_Thread.start();
	}
	
	@Override
	public void run() {
		while (!m_Stop) {
			try {
				Thread.sleep(10000);
				m_Saveable.saveState();
			} catch (InterruptedException e) {
				log.log(Level.FINE, "Thread interrupted.");
				break;
			}
		}
	}

	@Override
	public void Stop() {
		m_Stop = true;
		try {
			m_Thread.interrupt();
			m_Thread.join();				
		} catch (InterruptedException e) {
		}		
	}

	@Override
	public int compareTo(Object o) {
		return 1;
	}
}
