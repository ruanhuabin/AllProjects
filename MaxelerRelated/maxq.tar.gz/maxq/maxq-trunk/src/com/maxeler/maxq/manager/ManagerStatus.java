package com.maxeler.maxq.manager;

import java.io.Serializable;

import com.maxeler.maxq.Status;
import com.maxeler.maxq.StatusCodes;

public class ManagerStatus implements Status, Serializable {

	/**
	 * Auto Generated
	 */
	private static final long serialVersionUID = -6418821663827476058L;

	@Override
	public StatusCodes GetStatusCode() {
		return StatusCodes.OK;
	}
}
