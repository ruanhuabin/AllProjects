package com.maxeler.maxq;

public enum BlockingCommand {
	SHOULD_BLOCK
}
