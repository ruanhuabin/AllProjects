/**
 * 
 */
package com.maxeler.maxq.manager.operations;

import java.io.IOException;
import java.net.SocketException;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Map;

import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.GeneralServer;
import com.maxeler.maxq.ObjectStreamChannel;
import com.maxeler.maxq.OperationsRouter;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.ManagerQueryCommands;
import com.maxeler.maxq.manager.ManagerServer;

/**
 * @author itay
 *
 */
public class ManagerQueryRouter extends OperationsRouter {

	private ManagerServer m_ms;
	private SocketChannel m_sc;
	private ObjectStreamChannel m_os;	
	/**
	 * @param FSMName
	 */
	public ManagerQueryRouter(ManagerServer ms, SocketChannel sc) {
		super("ManagerQueryRouter");
		m_ms = ms;
		m_sc = sc;
		m_os = null;
	}

	@Override
	public OperationsRouter CreateNew(GeneralServer gs, SocketChannel sc) {
		return new ManagerQueryRouter((ManagerServer)gs, sc);
	}

	@Override
	public void Init() {
		m_os = new ObjectStreamChannel(m_sc, m_sc.socket().getInetAddress().getHostName());
		
		State wfwSendQueryElab = new State("wfwSendQueryElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State SendQueryElab = new State("SendQueryElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryRouter r = (ManagerQueryRouter) m_Internal;
				try {
					r.getObjectStreams().SendObject(CommonResponses.QUERY_ELAB);
				} catch (Exception e) {
					try {
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State wfrReadQueryCommand = new State("wfrReadQueryCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadQueryCommand = new State("ReadQueryCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryRouter r = (ManagerQueryRouter)m_Internal;
				try {
					ManagerQueryCommands mqc =  (ManagerQueryCommands) r.getObjectStreams().ReceiveObject();
					
					Map<SocketChannel, FSM> FSMSelector = r.getManagerServer().getMapChannelFSM();
					FSM newFSM = r;
					// Routing
					if (mqc.equals(ManagerQueryCommands.JOB_STATUS)) {
						newFSM = new ManagerJobStatusOperation(r);
					} else if (mqc.equals(ManagerQueryCommands.CLUSTER_STATUS)) {
						newFSM = new ManagerGetStateOperation(r);
					}
					FSMSelector.put(r.getSocketChannel(), newFSM);
				} catch (Exception e) {
					try {
						r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}
		});
		
		State ErrorState = new State("ErrorState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				try {
					getSocketChannel().close();
				} catch (Exception e) {
				
				}
				return 0;
			}
		});
		
		AddState(wfwSendQueryElab);
		AddState(SendQueryElab);
		AddState(wfrReadQueryCommand);
		AddState(ReadQueryCommand);
		AddState(ErrorState);
		setInitialState(wfwSendQueryElab);
		setCurrentState(wfwSendQueryElab);
		
		AddTransition(new Transition(wfwSendQueryElab, SendQueryElab, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendQueryElab, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfwSendQueryElab, wfwSendQueryElab, CommonEvents.eANY_EVENT));
		
		
		AddTransition(new Transition(SendQueryElab, wfrReadQueryCommand, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendQueryElab, ReadQueryCommand, CommonEvents.eCHANNEL_READABLE));
		
		AddTransition(new Transition(wfrReadQueryCommand, ReadQueryCommand, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrReadQueryCommand, ErrorState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(wfrReadQueryCommand, wfrReadQueryCommand, CommonEvents.eANY_EVENT));

		
		AddTransition(new Transition(ReadQueryCommand, ErrorState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ErrorState, ErrorState, CommonEvents.eANY_EVENT));
		
	}

	public ManagerServer getManagerServer() {
		return m_ms;
	}

	private SocketChannel getSocketChannel() {
		return m_sc;
	}
	
	public void Terminate() {
		Map<SocketChannel, FSM> selector = getManagerServer().getMapChannelFSM();
		selector.remove(getSocketChannel());
		try {
			getSocketChannel().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		m_sc = null;
		m_os = null;
		m_ms = null;
	}
	
	public void setKeepAlive(boolean keep) {
		try {
			getSocketChannel().socket().setKeepAlive(keep);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	public ObjectStreamChannel getObjectStreams() {
		return m_os;
	}
}
