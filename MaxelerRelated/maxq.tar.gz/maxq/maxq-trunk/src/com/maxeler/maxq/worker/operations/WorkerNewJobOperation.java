package com.maxeler.maxq.worker.operations;

import java.nio.channels.SelectionKey;
import java.util.logging.Level;

import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Operation;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.worker.JobRequest;
import com.maxeler.maxq.worker.KillJobResult;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

public class WorkerNewJobOperation extends Operation<WorkerRequestRouter> {

	WorkerJobDescriptor m_NewJobDescriptor = null;
	private boolean m_SendJobDescriptorSucceeded = false;
	private final transient MaxQLogger log = MaxQLogger.getLogger("WorkerNewJobOperation");
	
	public WorkerNewJobOperation(WorkerRequestRouter r) {
		super("WorkerNewJobOperation", r);
		m_NewJobDescriptor = null;
		
		State wfwNewJobOperationAck = new State("wfwNewJobOperationAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
		});
		
		State SendNewJobOperationAck = new State("SendNewJobOperationAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobOperation wnjo = (WorkerNewJobOperation) m_Internal;
				WorkerRequestRouter r = wnjo.getRouter();
				try {
					r.getObjectStreams().SendObject(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						return r.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}
		});
		
		State wfrNewJobRequest = new State("wfrNewJobRequest", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadNewJobRequest = new State("ReadNewJobRequest", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// Read new Job Request
				WorkerNewJobOperation wnjo = (WorkerNewJobOperation) m_Internal;
				try {
					JobRequest jr = (JobRequest) wnjo.getRouter().getObjectStreams().ReceiveObject();
					log.logf(Level.FINE, "Got Job Request:\n" +
							"WorkingDirectory: %s\n" +
							"Command: %s\n" +
							"Arguments: %s\n" +
							"Cores: %f\n" +
							"Memory: %d\n" +
							"Tags: %s\n" +
							"Group: %s\n",
							jr.getWorkingDirectory(), jr.getCommand(),
							jr.getArguments(), jr.getRequiredResources().getConfiguredCores(), jr.getRequiredResources().getConfiguredMemory(),
							jr.getRequiredResources().getTags(), jr.getGroupName());
					// Submit the job to the Worker Server
					WorkerJobDescriptor jd = wnjo.getRouter().getWorkerServer().SubmitJob(jr);
					if (jd.getStarted() == true)
						log.logf(Level.INFO, "Job %d submitted.", jd.getJobID().getJobIDCode());
					else
						log.logf(Level.INFO, "Job %d rejected.", jd.getJobID().getJobIDCode());
					wnjo.setNewJobDescriptor(jd);
				} catch (Exception e) {
					try {
						return wnjo.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State wfwSendNewJobDescriptor = new State("wfwSendNewJobDescriptor", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_WRITE;
			}
		});
		
		State SendNewJobDescriptor = new State("SendNewJobDescriptor", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobOperation wnjo = (WorkerNewJobOperation) m_Internal;
				WorkerRequestRouter r = wnjo.getRouter();
				try {					
					r.getObjectStreams().SendObject(wnjo.getNewJobDescriptor());
				} catch (Exception e) {
					try {
						return HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_READ;
			}			
		});
		
		State wfrNewJobDescriptorACK = new State("wfrNewJobDescriptorACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				return SelectionKey.OP_READ;
			}			
		});
		
		State ReadNewJobDescriptorACK = new State("ReadNewJobDescriptorACK", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// Read new Job Request
				WorkerNewJobOperation wnjo = (WorkerNewJobOperation) m_Internal;
				try {
					ProtocolControlCommands cmd = (ProtocolControlCommands) wnjo.getRouter().getObjectStreams().ReceiveObject();
					m_SendJobDescriptorSucceeded = cmd.equals(ProtocolControlCommands.ACK);
				} catch (Exception e) {
					try {
						return wnjo.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return SelectionKey.OP_WRITE;
			}			
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerNewJobOperation wnjo = (WorkerNewJobOperation) m_Internal;
				
				if (!m_SendJobDescriptorSucceeded && getNewJobDescriptor() != null && getNewJobDescriptor().getStarted() == true) {
					log.logf(Level.WARNING, "Job (%s) submission protocol failed after job has been executed, killing.", getNewJobDescriptor().getJobID().getJobIDString());
					getNewJobDescriptor().setShouldNotifyOnCompletion(false);
					KillJobResult result = wnjo.getRouter().getWorkerServer().KillJob(getNewJobDescriptor().getJobID());
					log.logf(Level.WARNING, "Kill Job: %s: %s",result.getStatus().toString(), result.getMessage());
				} 

				wnjo.getRouter().Terminate();
				
				return 0;
			}
		});
		
		AddState(wfwNewJobOperationAck);
		AddState(SendNewJobOperationAck);
		AddState(wfrNewJobRequest);
		AddState(ReadNewJobRequest);
		AddState(wfwSendNewJobDescriptor);
		AddState(SendNewJobDescriptor);
		AddState(wfrNewJobDescriptorACK);
		AddState(ReadNewJobDescriptorACK);
		AddState(EndState);
		setInitialState(wfwNewJobOperationAck);
		setCurrentState(wfwNewJobOperationAck);
		
		// Wait
		AddTransition(new Transition(wfwNewJobOperationAck, SendNewJobOperationAck, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwNewJobOperationAck, wfwNewJobOperationAck, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwNewJobOperationAck, EndState, CommonEvents.eERROR_EVENT));

		// Write
		AddTransition(new Transition(SendNewJobOperationAck, ReadNewJobRequest, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendNewJobOperationAck, wfrNewJobRequest, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendNewJobOperationAck, EndState, CommonEvents.eERROR_EVENT));
				
		// Wait
		AddTransition(new Transition(wfrNewJobRequest, ReadNewJobRequest, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrNewJobRequest, wfrNewJobRequest, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrNewJobRequest, EndState, CommonEvents.eERROR_EVENT));

		// Read
		AddTransition(new Transition(ReadNewJobRequest, SendNewJobDescriptor, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(ReadNewJobRequest, wfwSendNewJobDescriptor, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadNewJobRequest, EndState, CommonEvents.eERROR_EVENT));
		
		// Wait
		AddTransition(new Transition(wfwSendNewJobDescriptor, SendNewJobDescriptor, CommonEvents.eCHANNEL_WRITABLE));
		AddTransition(new Transition(wfwSendNewJobDescriptor, wfwSendNewJobDescriptor, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfwSendNewJobDescriptor, EndState, CommonEvents.eERROR_EVENT));
		
		// Write
		AddTransition(new Transition(SendNewJobDescriptor, ReadNewJobDescriptorACK, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(SendNewJobDescriptor, wfrNewJobDescriptorACK, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendNewJobDescriptor, EndState, CommonEvents.eERROR_EVENT));
		
		// Wait
		AddTransition(new Transition(wfrNewJobDescriptorACK, ReadNewJobDescriptorACK, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(wfrNewJobDescriptorACK, wfrNewJobDescriptorACK, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(wfrNewJobDescriptorACK, EndState, CommonEvents.eERROR_EVENT));
		
		// Read & Finish
		AddTransition(new Transition(ReadNewJobDescriptorACK, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();		
	}
	
	public static void main(String [] args) {
		new WorkerNewJobOperation(null);
	}
	
	public void setNewJobDescriptor(WorkerJobDescriptor jd) {
		m_NewJobDescriptor = jd;
	}
	
	public WorkerJobDescriptor getNewJobDescriptor() {
		return m_NewJobDescriptor;
	}

}
