/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.worker.WorkerDiscoverReply;
import com.maxeler.maxq.worker.WorkerQueryCommands;

/**
 * @author itay
 *
 */
public class DiscoverWorkerCmd extends ControllerCmd {

	private WorkerDiscoverReply m_DiscoverReply;
	
	private Exception m_error = null;
	
	/**
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public DiscoverWorkerCmd(CommandRouter cr,
			Delegate OnCommandCompletion) throws Exception {
		super("DiscoverWorkerCmd", cr, OnCommandCompletion);
		m_DiscoverReply = null;
		
		State SendQueryCommand = new State("SendQueryCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverWorkerCmd dwc = (DiscoverWorkerCmd) m_Internal;
				try {
					dwc.getControllerClient().getObjectStreams().SendObject(CommonCommands.QUERY);
					dwc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					m_error = e;
					try {
						dwc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}					
				}
				return 0;
			}			
		});
		
		State ReadQueryElabCommand = new State("ReadQueryElabCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverWorkerCmd dwc = (DiscoverWorkerCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) dwc.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.QUERY_ELAB)) {
						dwc.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						dwc.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					m_error = e;
					try {
						dwc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}
		});
		
		State SendDiscoverCommand = new State("SendDiscoverCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverWorkerCmd dwc = (DiscoverWorkerCmd) m_Internal;
				try {
					dwc.getControllerClient().getObjectStreams().SendObject(WorkerQueryCommands.DISCOVER);
					dwc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					m_error = e;
					try {
						dwc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}					
				}
				return 0;
			}			
		});
		
		State ReadWorkerDiscoverReply = new State("ReadWorkerDiscoverReply", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverWorkerCmd dwc = (DiscoverWorkerCmd) m_Internal;
				try {
					WorkerDiscoverReply wdr = (WorkerDiscoverReply) dwc.getControllerClient().getObjectStreams().ReceiveObject();
					dwc.setWorkerDiscoverReply(wdr);
					dwc.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					m_error = e;
					try {
						dwc.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				return 0;
			}						
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				DiscoverWorkerCmd dwc = (DiscoverWorkerCmd) m_Internal;
				dwc.getControllerClient().Close();
				return 0;
			}
		});
		
		AddState(SendQueryCommand);
		AddState(ReadQueryElabCommand);
		AddState(SendDiscoverCommand);
		AddState(ReadWorkerDiscoverReply);
		AddState(EndState);
		
		setInitialState(SendQueryCommand);
		setCurrentState(SendQueryCommand);
		
		AddTransition(new Transition(SendQueryCommand, ReadQueryElabCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadQueryElabCommand, SendDiscoverCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendDiscoverCommand, ReadWorkerDiscoverReply, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadWorkerDiscoverReply, EndState, CommonEvents.eSTEP_EVENT));
		
		AddTransition(new Transition(SendQueryCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadQueryElabCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(SendDiscoverCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(ReadWorkerDiscoverReply, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}
	
	public WorkerDiscoverReply getWorkerDiscoverReply() throws Exception {
		if (m_error != null) throw new Exception(m_error);
		return m_DiscoverReply;
	}
	
	public void setWorkerDiscoverReply(WorkerDiscoverReply wdr) {
		m_DiscoverReply = wdr;
	}

}
