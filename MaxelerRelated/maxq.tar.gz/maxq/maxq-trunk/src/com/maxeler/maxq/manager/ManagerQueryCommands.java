package com.maxeler.maxq.manager;

public enum ManagerQueryCommands {
	JOB_STATUS,
	CLUSTER_STATUS
}
