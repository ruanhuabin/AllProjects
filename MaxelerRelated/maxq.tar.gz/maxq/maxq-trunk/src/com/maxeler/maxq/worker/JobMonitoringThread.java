/**
 * 
 */
package com.maxeler.maxq.worker;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.Stoppable;

/**
 * @author itay
 *
 */
public class JobMonitoringThread implements Runnable, Stoppable, Comparable<Object> {

	private Thread m_Thread;
	private WorkerJobDescriptor m_JobDescriptor;
	private Delegate m_OnFinish;
	private final MaxQLogger log = MaxQLogger.getLogger("JobMonitoringThread");
	private boolean m_Stop = false;
	private boolean m_JobMissing = false;
	

	public JobMonitoringThread(WorkerJobDescriptor jd, Delegate OnFinish) {
		m_Thread = null;
		m_JobDescriptor = jd;
		m_OnFinish = OnFinish;
		m_OnFinish.m_Internal = this;
	}

	public void Start() {
		m_Thread = new Thread(this, "maxq_thread_" + m_JobDescriptor.getJobID().toString());
		m_Thread.start();
	}

	@Override
	public void run() {
		BufferedReader exitCodeReader = null;
		try {
			log.logf(Level.FINER, "Opening exitCode file: %s", m_JobDescriptor.getExitCodeFilePath());
			exitCodeReader = new BufferedReader(new FileReader(m_JobDescriptor.getExitCodeFilePath()));
			
			while (!m_Stop && !m_JobMissing && !exitCodeReader.ready()) {
				Thread.sleep(1000);
			}
			
			int exitCode = -1;
			

			String line = exitCodeReader.readLine();
			log.logf(Level.FINER, "Read '%s'", line);
			if (line.contains(JobExecutor.ExitCodeCreationString)) {
				log.log(Level.FINER, "exit-code file exists, waiting for code...");
			} else {
				throw new Exception("Unexpected value: " + line);
			}
			
			while (!m_Stop && !m_JobMissing && !exitCodeReader.ready()) {
				Thread.sleep(1000);
			}
			
			if (m_Stop == true) {
				return;
			}
			
			
			if (m_JobMissing == false) {				
				line = exitCodeReader.readLine();
				log.logf(Level.FINER, "Read '%s' from exit-code File: %s",line, m_JobDescriptor.getExitCodeFilePath());
				
				try {
					exitCode = Integer.decode(line);
				} catch (Exception e) {
					log.logf(Level.WARNING, "Error while getting exit code from ('%s'): %s", line, e.getMessage());				
				}
				
				// This isn't entirely accurate...
				if (exitCode == -1) {
					m_JobDescriptor.setKilled(true);
				}
			} else {
				exitCode = -2;
				m_JobDescriptor.setLost(true);
				log.logf(Level.INFO, "Job %d Lost, marking as completed.", m_JobDescriptor.getJobID().getJobIDCode());
			}
			
			m_JobDescriptor.setRunning(false);			
			log.logf(Level.INFO, "Job %d completed, exit code: %d.", m_JobDescriptor.getJobID().getJobIDCode(), exitCode);
			m_JobDescriptor.setExitCode(exitCode);
		} catch (IOException ioe) {
			log.logf(Level.INFO, "Error: while trying to read exit-code file %s: %s.", m_JobDescriptor.getExitCodeFilePath(), ioe.getMessage());
			m_JobDescriptor.setExecutionError(-1, ioe.getMessage());
		} catch (InterruptedException e) {
			return;
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if (exitCodeReader != null) {
				try {
					exitCodeReader.close();
				} catch (Exception e) {
				}
			}
		}
		
		m_OnFinish.Invoke(m_JobDescriptor);

		// Cleanup  - remove temporary files
		
		WorkerServer.DeleteFile(m_JobDescriptor.getScriptPath());
		WorkerServer.DeleteFile(m_JobDescriptor.getExitScriptPath());
		WorkerServer.DeleteFile(m_JobDescriptor.getSubScriptPath());
		WorkerServer.DeleteFile(m_JobDescriptor.getExitCodeFilePath());
	}

	@Override
	public void Stop() {
		try {
			m_Stop  = true;
			m_Thread.interrupt();
			m_Thread.join();
		} catch (Exception e) {
		}		
	}
	
	public void setJobMissing() {
		m_JobMissing = true;
	}

	@Override
	public int compareTo(Object o) {
		return 1;
	}
}

