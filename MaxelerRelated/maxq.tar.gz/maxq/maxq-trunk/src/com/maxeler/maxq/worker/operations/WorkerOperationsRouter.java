package com.maxeler.maxq.worker.operations;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.Map;
import java.util.logging.Level;

import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.GeneralServer;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.ObjectStreamChannel;
import com.maxeler.maxq.OperationsRouter;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.FSM;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.operations.StopOperation;
import com.maxeler.maxq.worker.WorkerServer;

public class WorkerOperationsRouter extends OperationsRouter {

	WorkerServer m_ws;
	SocketChannel m_sc;
	ObjectStreamChannel m_os;
	private final transient MaxQLogger log = MaxQLogger.getLogger("WorkerOperationsRouter");

	public WorkerOperationsRouter(WorkerServer ws, SocketChannel sc) {
		super("WorkerOperationsRouter");
		m_ws = ws;
		m_sc = sc;
		m_os = null;
	}

	@Override
	public OperationsRouter CreateNew(GeneralServer gs, SocketChannel sc) {
		return new WorkerOperationsRouter((WorkerServer) gs, sc);
	}

	@Override
	public void Init() {
		m_os = new ObjectStreamChannel(m_sc, m_sc.socket().getInetAddress().getHostName());

		State WaitForCommand = new State("WaitForCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				// Do Nothing...
				// The next state is interested only in the Readable event,
				// so we set that as our interest set
				return SelectionKey.OP_READ;
			}
		});

		State ReadCommonCommand = new State("ReadCommonCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerOperationsRouter r = (WorkerOperationsRouter)m_Internal;
				try {

					CommonCommands cc = (CommonCommands)r.getObjectStreams().ReceiveObject();
					// Got Command, Now select appropriate FSM
					Map<SocketChannel, FSM> FSMSelector = r.getWorkerServer().getMapChannelFSM();
					FSM newFSM = r;

					if (cc.equals(CommonCommands.STATUS)) {
						//newFSM = new WorkerStatusOperation(r);
					} else if (cc.equals(CommonCommands.STOP)) {
						newFSM = new StopOperation(r.getWorkerServer());
					} else if (cc.equals(CommonCommands.QUERY)) {
						WorkerQueryRouter wqr = new WorkerQueryRouter(r.getWorkerServer(), r.getSocketChannel());
						wqr.Init();
						newFSM = wqr;
					} else if (cc.equals(CommonCommands.REQUEST)) {
						WorkerRequestRouter wrr = new WorkerRequestRouter(r.getWorkerServer(), r.getSocketChannel());
						wrr.Init();
						newFSM = wrr;						
					}
					FSMSelector.put(r.getSocketChannel(), newFSM);
				} catch (Exception e) {
					r.getLogger().logf(Level.WARNING, "%s: Error: %s, closing channel.", r.getName() ,e.getMessage());
					try {
						r.getSocketChannel().close();
					} catch (Exception e1) {
						r.getLogger().logf(Level.WARNING, "%s: Failed closing channel: %s, ignoring.", r.getName() ,e1.getMessage());
					}
					return 0; // A closed channel doesn't find anything to be interesting.
				} 
				return SelectionKey.OP_WRITE;
			} });
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				WorkerOperationsRouter r = (WorkerOperationsRouter)m_Internal;
				r.getLogger().log(Level.INFO, "Command not understood, failing.");
				try {
					r.getSocketChannel().close();
				} catch (Exception e) {
					
				}
				return 0;
			}		
		});
		

		AddState(WaitForCommand);
		AddState(ReadCommonCommand);
		AddState(EndState);
		AddTransition(new Transition(WaitForCommand, ReadCommonCommand, CommonEvents.eCHANNEL_READABLE));
		AddTransition(new Transition(WaitForCommand, WaitForCommand, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(ReadCommonCommand, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(WaitForCommand, EndState, CommonEvents.eERROR_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		setInitialState(WaitForCommand);
		setCurrentState(WaitForCommand);
		CreateDotGraph();
	}
	
	private SocketChannel getSocketChannel() {
		return m_sc;
	}

	public ObjectStreamChannel getObjectStreams() {
		return m_os;
	}
	
	public WorkerServer getWorkerServer() {
		return m_ws;
	}
	
	public MaxQLogger getLogger() {
		return log;
	}
	
	public void Terminate() {
		Map<SocketChannel, FSM> selector = getWorkerServer().getMapChannelFSM();
		selector.remove(getSocketChannel());
		
		try {
			getSocketChannel().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		m_sc = null;
		m_os = null;
		m_ws = null;
	}
}
