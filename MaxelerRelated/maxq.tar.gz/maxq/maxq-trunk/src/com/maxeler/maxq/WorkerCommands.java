package com.maxeler.maxq;

public enum WorkerCommands {

}
