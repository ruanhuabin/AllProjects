package com.maxeler.maxq;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.util.logging.Level;


public class ObjectStreamChannel {
	private final ByteChannel m_bc;
	private final transient MaxQLogger log = MaxQLogger.getLogger("ObjectStreamChannel");

	private final int ACK_DWORD = 0x5555AAAA;
	private final int SIZE_BYTE_COUNT = 4;
	private final int MAX_READ_RETRY = 30;
	private final int MAX_SIZE_BYTE_COUNT = 100*1024*1024; // 100MB
	private final String m_remoteName;
	
	
	public ObjectStreamChannel(ByteChannel bc, String remoteName) {
		m_bc = bc;
		m_remoteName = remoteName;
		log.logf(Level.FINEST, "Remote: %s", remoteName);
		
	//	try { 
//			m_baos = new ByteArrayOutputStream();
//			m_os = new ObjectOutputStream(m_baos);
//		} catch (Exception e) {
//			log.logf(Level.WARNING, "Exception when creating an ObjectOutputStream: %s\n", e.getMessage());
//			e.printStackTrace();
//		}
		
	}
	
	public void Close()	{
		try {
			m_bc.close();
		} catch (IOException e) {
		}
	}
	
	private void transmitBuffer(ByteBuffer b) throws Exception {
		if (b == null) throw new Exception("transmitBuffer to " + m_remoteName + ": null ByteBuffer passed.");
		
		log.logf(Level.FINEST, "transmitBuffer to %s: Sending %d bytes", m_remoteName, b.limit());
		b.rewind();
		int count = 0;
		while (b.hasRemaining()) {
			int wroteNow = m_bc.write(b);
			if (wroteNow < 0) {
				 throw new Exception("transmitBuffer to " + m_remoteName + ": Error while trying to transmit "+b.limit()+" bytes.\n");
			 } else if (wroteNow > 0){
				 count += wroteNow;
				 log.logf(Level.FINEST, "transmitBuffer to %s: Sent %d of %d", m_remoteName, count, b.limit());
			 } else {
				 Thread.sleep(50); // Sleep 50 ms
			 }
		}
	}
	
	private ByteBuffer receiveBuffer(int size) throws Exception {
		int retries = 0;
		ByteBuffer b = ByteBuffer.allocate(size);
		while (b.hasRemaining()) {
			int readNow = m_bc.read(b);
			if (readNow < 0) {
				log.logf(Level.FINEST, "receiveBuffer from %s: Error while reading.", m_remoteName);
				throw new Exception(m_remoteName + ": Error while reading.\n");
			} else if (readNow == 0) {
				retries++;
				if (retries > MAX_READ_RETRY) throw new Exception(m_remoteName+ ": Error while reading size: max retries reached.");
				Thread.sleep(50); // Sleep 50 ms
			} else {
				log.logf(Level.FINEST, "receiveBuffer from %s: Read %d of %d", m_remoteName, readNow, b.limit());
			}
		}
		
		b.rewind();
		return b;
	}
	
	public Integer SendObject(Object o) throws Exception {
		int count = 0;
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream os = new ObjectOutputStream(baos);
			 
			log.logf(Level.FINEST, "SendObject to %s: Object is a %s", m_remoteName, o.getClass().getName());
			os.writeObject(o);
			os.flush();
			int Size = baos.size();
		    
			log.logf(Level.FINEST, "%s: Serialized... %d bytes", m_remoteName, Size);
			// Write the size
			ByteBuffer SizeBuffer = ByteBuffer.allocate(SIZE_BYTE_COUNT);
			SizeBuffer.putInt(Size);
			log.logf(Level.FINEST, "%s: Sending size: %d --> 4 bytes (int32)", m_remoteName, Size);
			transmitBuffer(SizeBuffer);
			
			ByteBuffer ack = receiveBuffer(SIZE_BYTE_COUNT);
			if (ack.getInt() != ACK_DWORD) {
				log.logf(Level.WARNING, "SendObject to %s: ACK dword mismatch, bailing.", m_remoteName);
				throw new Exception("SendObject to "+m_remoteName+": ACK dword mismatch, bailing.");
			}

			// Write the data
			log.logf(Level.FINEST, "%s: Sending object data...", m_remoteName);
			ByteBuffer data = ByteBuffer.wrap(baos.toByteArray());
			transmitBuffer(data);
			log.logf(Level.FINEST, "Sent a %s to %s [%d bytes]", o.getClass().getName(), m_remoteName, count);
		} catch (Exception e) {
			log.logf(Level.WARNING, "%s: Failed on SendObject: %s", m_remoteName, e.getMessage());
			throw e;
		}
		return count;
	}
	
	public Object ReceiveObject() throws Exception {
		Object o = null;
		try {
			ByteBuffer SizeBuffer = receiveBuffer(SIZE_BYTE_COUNT);			
			Integer Size = SizeBuffer.getInt();
			
			if (Size > MAX_SIZE_BYTE_COUNT || Size <= 0) {
				log.logf(Level.INFO, "%s: Unreasonable size read: %d bytes", m_remoteName, Size);
				throw new Exception(m_remoteName+": Error while reading object: size unreasonable: " + Size + " [bytes]"); 
			}
			
			ByteBuffer ack = ByteBuffer.allocate(SIZE_BYTE_COUNT);
			ack.putInt(ACK_DWORD);
			transmitBuffer(ack);
			
			log.logf(Level.FINEST, "ReceiveObject from %s: Expecting Size: %d", m_remoteName, Size);
			
			ByteBuffer rxBuffer = receiveBuffer(Size);
			ByteArrayInputStream bais = new ByteArrayInputStream(rxBuffer.array());
			ObjectInputStream ois = new ObjectInputStream(bais);
			o = ois.readObject();
			
			log.logf(Level.FINEST, "Received from %s a \"%s\" object [%d bytes]", m_remoteName, o != null ? o.getClass().getName() : "NULL Object", Size);
		} catch (Exception e) {
			log.logf(Level.WARNING, "ReceiveObject from %s: Failed: %s", m_remoteName, e.getMessage());
			//e.printStackTrace();
			throw e;
		}
		return o;
	}	
}
