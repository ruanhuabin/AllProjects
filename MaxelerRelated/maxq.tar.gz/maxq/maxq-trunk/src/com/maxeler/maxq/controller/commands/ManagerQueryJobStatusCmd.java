/**
 * 
 */
package com.maxeler.maxq.controller.commands;

import java.util.logging.Level;

import com.maxeler.maxq.BlockingCommand;
import com.maxeler.maxq.BlockingResponse;
import com.maxeler.maxq.CommonCommands;
import com.maxeler.maxq.CommonResponses;
import com.maxeler.maxq.Delegate;
import com.maxeler.maxq.MaxQLogger;
import com.maxeler.maxq.ProtocolControlCommands;
import com.maxeler.maxq.FSM.CommonEvents;
import com.maxeler.maxq.FSM.State;
import com.maxeler.maxq.FSM.Transition;
import com.maxeler.maxq.manager.JobID;
import com.maxeler.maxq.manager.ManagerQueryCommands;
import com.maxeler.maxq.worker.WorkerJobDescriptor;

/**
 * @author itay
 *
 */
public class ManagerQueryJobStatusCmd extends ControllerCmd {

	private JobID m_JobID;
	
	private WorkerJobDescriptor m_jd;
	private boolean m_shouldBlockToCompletion;
	private boolean m_shouldBlockToStarted;
	
	private boolean m_Success = false;
	
	private final transient MaxQLogger log = MaxQLogger.getLogger("ManagerQueryJobStatusCmd");
	
	/**
	 * @param CommandName
	 * @param cr
	 * @param OnCommandCompletion
	 * @throws Exception
	 */
	public ManagerQueryJobStatusCmd(JobID jid, CommandRouter cr, Delegate OnCommandCompletion) throws Exception {
		super("ManagerQueryJobStatusCmd", cr, OnCommandCompletion);
		m_JobID = jid;
		m_shouldBlockToCompletion = false;
		m_shouldBlockToStarted = false;
		
		State SendQueryCommand = new State("SendQueryCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					mqjs.getControllerClient().getObjectStreams().SendObject(CommonCommands.QUERY);
					mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadQueryElab = new State("ReadQueryElab", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					CommonResponses cr = (CommonResponses) mqjs.getControllerClient().getObjectStreams().ReceiveObject();
					if (cr.equals(CommonResponses.QUERY_ELAB)) {
						mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}				
				return 0;
			}
		});
		
		State SendQueryJobStatusCommand = new State("SendQueryJobStatusCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					mqjs.getControllerClient().getObjectStreams().SendObject(ManagerQueryCommands.JOB_STATUS);
					mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadBlockingCommand = new State("ReadBlockingCommand", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					BlockingCommand bc = (BlockingCommand) mqjs.getControllerClient().getObjectStreams().ReceiveObject();
					if (bc.equals(BlockingCommand.SHOULD_BLOCK)) {
						mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}				
				return 0;
			}
		});
		
		State SendShouldBlockReply = new State("SendShouldBlockReply", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					BlockingResponse br = shouldBlockToCompletion() ? BlockingResponse.BLOCK_TO_COMPLETION : 
						shouldBlockToStarted() ? BlockingResponse.BLOCK_TO_STARTED : BlockingResponse.NON_BLOCKING;
					
					mqjs.getControllerClient().getObjectStreams().SendObject(br);
					mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadBlockingCommandReplyAck = new State("ReadBlockingCommandReplyAck", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					ProtocolControlCommands pcc = (ProtocolControlCommands) mqjs.getControllerClient().getObjectStreams().ReceiveObject();
					if (pcc.equals(ProtocolControlCommands.ACK)) {
						mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
					} else {
						mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					}
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}				
				return 0;
			}
		});
		
		State SendJobID = new State("SendJobID", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					mqjs.getControllerClient().getObjectStreams().SendObject(mqjs.getJobID());
					mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return 0;
			}			
		});
		
		State ReadJobDescriptorAndBlockIfNeeded = new State("ReadJobDescriptorAndBlockIfNeeded", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				ManagerQueryJobStatusCmd mqjs = (ManagerQueryJobStatusCmd) m_Internal;
				try {
					try {
						mqjs.getControllerClient().setKeepAlive(true);
						mqjs.getControllerClient().setBlocking(true);
					} catch (Exception e) {
						log.logf(Level.WARNING, "Could not set socket to keep alive: %s", e.getMessage());
					}
					WorkerJobDescriptor wjd = (WorkerJobDescriptor) mqjs.getControllerClient().getObjectStreams().ReceiveObject();
					mqjs.setJobDescriptor(wjd);
					m_Success = true; // mark as success
					mqjs.HandleEvent(CommonEvents.eSTEP_EVENT);
				} catch (Exception e) {
					try {
						return mqjs.HandleEvent(CommonEvents.eERROR_EVENT);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}				
				return 0;
			}
		});
		
		State EndState = new State("EndState", new Delegate(this) {
			@Override
			public Integer Invoke(Object param) {
				getControllerClient().Close();
				return 0;
			}
		});
		
		AddState(SendQueryCommand);
		AddState(ReadQueryElab);
		AddState(SendQueryJobStatusCommand);
		AddState(ReadBlockingCommand);
		AddState(SendShouldBlockReply);
		AddState(ReadBlockingCommandReplyAck);
		AddState(SendJobID);
		AddState(ReadJobDescriptorAndBlockIfNeeded);
		AddState(EndState);
		
		setInitialState(SendQueryCommand);
		setCurrentState(SendQueryCommand);
		
		AddTransition(new Transition(SendQueryCommand, ReadQueryElab, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadQueryElab, SendQueryJobStatusCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendQueryJobStatusCommand, ReadBlockingCommand, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadBlockingCommand, SendShouldBlockReply, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendShouldBlockReply, ReadBlockingCommandReplyAck, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(ReadBlockingCommandReplyAck, SendJobID, CommonEvents.eSTEP_EVENT));
		AddTransition(new Transition(SendJobID, ReadJobDescriptorAndBlockIfNeeded, CommonEvents.eSTEP_EVENT));
		
		AddTransition(new Transition(ReadJobDescriptorAndBlockIfNeeded, EndState, CommonEvents.eANY_EVENT));
		
		AddTransition(new Transition(SendQueryCommand, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadQueryElab, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendQueryJobStatusCommand, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadBlockingCommand, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendShouldBlockReply, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(ReadBlockingCommandReplyAck, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(SendJobID, EndState, CommonEvents.eANY_EVENT));
		AddTransition(new Transition(EndState, EndState, CommonEvents.eANY_EVENT));
		
		CreateDotGraph();
	}
	
	public WorkerJobDescriptor getJobDescriptor() {
		return m_jd;
	}
	
	public void setJobDescriptor(WorkerJobDescriptor jd) {
		m_jd = jd;
	}
	
	public JobID getJobID() {
		return m_JobID;
	}
	
	public void setJobID(JobID jid) {
		m_JobID = jid;
	}
	
	public Boolean shouldBlockToCompletion() {
		return m_shouldBlockToCompletion;
	}
	
	public void setShouldBlockToCompletion(Boolean shouldBlock) {
		m_shouldBlockToCompletion = shouldBlock;
	}
	
	public Boolean shouldBlockToStarted() {
		return m_shouldBlockToStarted;
	}
	
	public void setShouldBlockToStarted(Boolean shouldBlock) {
		m_shouldBlockToStarted = shouldBlock;
	}
	
	
	public boolean isSuccess() {
		return m_Success;
	}
}
