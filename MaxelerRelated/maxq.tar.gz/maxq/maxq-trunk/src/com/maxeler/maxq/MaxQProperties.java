package com.maxeler.maxq;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Map;

/**
 * An alternative for java's properties, that does not interpret strings:<br>
 * KEY1=VALUE1<br>
 * KEY2=VALUE\nVALUE<br>
 * <br>
 * would produce a mapping:<br>
 * KEY1 -> VALUE1<br>
 * and:<br>
 * KEY2 -> VALUE\nVALUE<br>
 * Unlike java properties, which produces:<br>
 * KEY2 -> VALUE<br>
 * VALUE<br>
 * 
 * @author itay
 *
 */
public class MaxQProperties {
	Hashtable<String, String> m_Map;
	public MaxQProperties(String fileName) throws Exception {
		BufferedReader br;
		if(fileName.equals("-")) {
			br = new BufferedReader(new InputStreamReader(System.in));
		} else {
			FileReader fr = new FileReader(fileName);
			br = new BufferedReader(fr);
		}
		m_Map = new Hashtable<String, String>(8);
		String line = null;
		while ((line = br.readLine()) != null) {
			if (line.matches("^\\s*#")) continue;
			String [] KeyVal = line.split("=", 2);
			if (KeyVal.length == 2) {
				m_Map.put(KeyVal[0].trim(), KeyVal[1].trim());
			}
		}		
	}
	
	public MaxQProperties(Map<String, String> values) {
		m_Map = new Hashtable<String, String>(values);
	}
	
	public String getProperty(String key) {
		return m_Map.get(key);
	}
	
	public String getProperty(String key, String defaultVal) {
		return m_Map.containsKey(key) ? m_Map.get(key) : defaultVal;
	}
	
	public Hashtable<String,String> getMap() {
		return m_Map;
	}
}
