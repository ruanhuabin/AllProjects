#!/usr/bin/perl

my $maxq_root;
if ($#ARGV == -1) {
	$maxq_root = "/network-raid/opt/maxq/maxq-trunk";
	system("svn up $maxq_root");
	system("cd $maxq_root && ant clean && ant");
} else {
	$maxq_root = $ARGV[0];
}


if (! -e $maxq_root) {
	die "ERROR: $maxq_root does not exist, please pass the correct path to the maxq svn root as an argument.\n";
}

print "Updating distribution from local workspace... $maxq_root\n";

my @svn_info = `svn st -v $maxq_root | sort -nr | head  -1`;
my $revision = "unknown";

for (@svn_info) {
	if (/^\s*(\d+)/) {
		$revision = $1;
		last;
	}
}

print "Using revision: $revision\n";

my @entry_point = ("com.maxeler.maxq.manager.Manager", "com.maxeler.maxq.worker.Worker", "com.maxeler.maxq.controller.Controller", "com.maxeler.maxq.controller.Submit");
my @jars = ("maxq-mgr-$revision.jar", "maxq-worker-$revision.jar", "maxq-ctl-$revision.jar", "maxq-submit-$revision.jar");
my @links = ("maxq-mgr.jar", "maxq-worker.jar", "maxq-ctl.jar", "maxq-submit.jar");


for my $index (0..3) {
	print "Creating jar file: $jars[$index]\n";
	system("rm -f ./$jars[$index]");
	system("jar cfe ./$jars[$index] $entry_point[$index] -C $maxq_root/bin .");
        system("chmod 0664 ./$jars[$index]");
	system("rm -f $links[$index]");
	system("ln -s $jars[$index] $links[$index]");
}

print "done.\n";

