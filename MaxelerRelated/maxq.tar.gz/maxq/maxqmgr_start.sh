. /etc/rc.d/init.d/functions

[ -r /etc/sysconfig/maxq ] && . /etc/sysconfig/maxq
[ -z "$MAXQ_MANAGER" ] && exit 0
$MAXQ_MANAGER $MAXQ_MANAGER_ARGS  > /var/log/maxq/maxqmgr-$$.log 2>&1 &
PID=$!
sleep 2
PROCESS=`ps | grep $PID | grep -v grep`
echo -n " /var/log/maxq/maxqmgr-$$.log"
if [ "$PROCESS" = "" ]
then
	failure
else
	success	
fi

