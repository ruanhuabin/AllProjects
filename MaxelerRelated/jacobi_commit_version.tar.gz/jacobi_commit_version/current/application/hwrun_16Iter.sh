#!/bin/bash - 
#===============================================================================
#
#          FILE:  run.sh
# 
#         USAGE:  ./run.sh 
# 
#   DESCRIPTION:  
# 
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR: YOUR NAME (), 
#       COMPANY: 
#       CREATED: 05/18/2012 11:20:47 AM BST
#      REVISION:  ---
#===============================================================================

set -o nounset                              # Treat unset variables as an error
max_dim=200
dims=(0 0);
index=0;
for((i = 2; i <= ${max_dim}; i += 2))
do
		dims[${index}]=$i
		index=$((${index} +1))
done
echo "dims=${dims[*]}"
len=${#dims[*]}
run_times=0
MAX_ITER=$1
for((i = 0; i < ${len}; i += 1)) 
do
	current_dim=${dims[${i}]}
	#dim_index=$(($RANDOM%${len}))
	#dimLen=${dims[$dim_index]}
	run_times=$((${run_times}+1))
	#SLIC_CONF="max_socket=sim" ./JacobiRun ${current_dim} 20
	./JacobiRun ${current_dim} ${MAX_ITER}
	if [ $? -eq 1 ]
	then
			break
	fi

	#echo "==========>Run Times: ${run_times}, Dim Len: ${dimLen}, Process Status:$?"
	#echo "==========>Run Times: ${run_times}, Process Status:$?"

done


