Usage:

	./JacobiRun [-d <number>] [-b <number >] [-i <number>]
where:
	-d	Demension Length, should between[2,200] and should be multipy of 2, default length is 2.
	-b	Blocks to be caculated, each block contains 62 equations,should be
		an integer which is bigger than zero, default block number is 1.
	-i	Iteration times for Kernel, default iteration times is 20.
	-h	Print this help message.

