#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

void max_print_matrix(double *m, int rows, int cols, char *hint_msg)
{
	fprintf(stderr, "====>%s\n", hint_msg);
	for(int i = 0; i < rows; i ++)
	{
		for(int j = 0; j < cols; j ++)
		{
			fprintf(stderr, "%g ", m[i * cols + j]);
		}
		fprintf(stderr, "\n");
	}
}
int main(int argc, const char** argv) {
	int RUN = 10;
	int dim = atoi(argv[1]);   // this should be a scalar input in the bitstream

	double* A = malloc(dim*dim*sizeof(double));  // probably 'dim' mapped rom
    double* x_base = malloc(RUN*dim*sizeof(double)); // output of the bitstream
	double* x = NULL;
	double* z = malloc(dim*sizeof(double));
	double* b_base = malloc(RUN*dim*sizeof(double)); // this will be streamed into the bitstream
	double* b = b_base;

	double diff[RUN];
	memset(diff, 0, sizeof(double)*RUN);
	int i, j, run;

	srand(time(NULL));

	for(i = 0; i < dim; ++i) {
		double sum = 0;
		for(j = 0; j < dim; ++j) {
			if(i != j) {
//				A[i*dim+j] = 2.0*rand()/(double)RAND_MAX - 1;  // random number between -1 and 1
//				sum += fabs(A[i*dim+j]);
				A[i*dim+j] = 1; 
				sum += fabs(A[i*dim+j]);

			}
		}
		A[i*dim+i] = 1 + sum;
	}
	for(i = 0; i < dim*RUN; ++i) {
//		b[i] = 2.0*rand()/(double)RAND_MAX - 1;  // random number between -1 and 1
		b[i] = 20;  // random number between -1 and 1
	}


	/**
	* Start solving. This will go into HW.
	*
	* 	JACOBI(dim, A, b_base, x_base);
	**/
	int stage = 0;
	int MAX_ITER = 100; 
	for(run = 0; run < RUN; ++run) {
		x  = x_base + run*dim;
		double error = 1000;
		for(i = 0; i < dim; ++i) {
			x[i] = 0;
		}
		for(int e = 0; e < MAX_ITER; e ++)
		{	// update x
			for(i = 0; i < dim; ++i) 
			{
				double sigma = 0;
				for(j = 0; j < dim; ++j) 
				{
					if(j != i) 
					{
						sigma += A[i*dim+j]*x[j];
					}
				}
				z[i] = (b[i]-sigma)/A[i*dim+i];
				++stage;
			}
			double *tmp = x;
			x = z;
			z = tmp;

			error = 0;
			for(i = 0; i < dim; ++i) 
			{
				double y = 0;
				for(j = 0; j < dim; ++j) 
				{
					y += A[i*dim+j]*x[j];
				}
				error += fabs(y-b[i]);
			}
		}
		diff[run] = error;
	
		// move to next problem to solve
		b += dim;
	}


	max_print_matrix(A, dim, dim, "A");
	max_print_matrix(b_base, 1, dim, "b");
	max_print_matrix(x_base, RUN, dim, "X");
//	max_print_matrix(z-dim*RUN + dim, RUN, dim, "Z");
	max_print_matrix(diff, 1, RUN, "diff");
	free(A);
	free(b_base);
	free(x_base);
}
