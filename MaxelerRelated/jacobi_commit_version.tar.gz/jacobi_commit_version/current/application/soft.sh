#!/bin/bash
rm -rf JACOBI.max
TIME=25-05-12
DIR_NAME=JACOBI_24D_6C_Sim_125MHz
NAME=JACOBI
ln -s /network-scratch/hruan/maxdc_builds/${TIME}/${DIR_NAME}/scratch/${NAME}.max JACOBI.max
ls -l ${NAME}.max

