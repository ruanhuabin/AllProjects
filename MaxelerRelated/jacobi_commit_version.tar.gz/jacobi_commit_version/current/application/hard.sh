#!/bin/bash
rm -rf JACOBI.max
TIME=26-05-12
DIR_NAME=JACOBI_200D_62C_HW_170MHz
NAME=JACOBI
ln -s /network-scratch/hruan/maxdc_builds/${TIME}/${DIR_NAME}/scratch/${NAME}.max JACOBI.max
ls -l ${NAME}.max

