#!/bin/bash - 
#===============================================================================
#
#          FILE:  run.sh
# 
#         USAGE:  ./run.sh 
# 
#   DESCRIPTION:  
# 
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR: YOUR NAME (), 
#       COMPANY: 
#       CREATED: 05/18/2012 11:20:47 AM BST
#      REVISION:  ---
#===============================================================================

set -o nounset                              # Treat unset variables as an error
max_dim=200;
dim_val=(0 0 0 0 0 0);
index=0;
for((i = 2; i <= ${max_dim}; i += 2))
do
		dim_val[${index}]=$i
		index=$((${index} +1))
done
echo "${dim_val[*]}"
exit
#dims=(2 4 6 8 10 12)
#dims=(2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40)
dims=(2 4 6 8 10)
len=${#dims[*]}
run_times=0
max_run_times=$1
while [ 1 ]
do
	index=$(($RANDOM%${len}))
	dimLen=${dims[$index]}
	run_times=$((${run_times}+1))
	#SLIC_CONF="max_socket=sim" ./JacobiRun ${dimLen}
	SLIC_CONF="max_socket=sim" ./JacobiRun ${dimLen}
	if [ $? -eq 1 ]
	then
			break
	fi
	if [ ${run_times} -gt ${max_run_times} ]
	then
			break
	fi

	echo "==========>Run Times: ${run_times}, Dim Len: ${dimLen}, Process Status:$?"

done


