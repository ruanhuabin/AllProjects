#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#define DEBUG 1

/**
 *  Each solution's max iteration times
 */
int MAX_ITER = 6;
void max_print_matrix_by_row(double *m, int rows, int cols, char *hint_msg)
{
	fprintf(stdout, "====>%s\n", hint_msg);
	for(int i = 0; i < rows; i ++)
	{
		for(int j = 0; j < cols; j ++)
		{
			fprintf(stdout, "%g ", m[i * cols + j]);
		}
		fprintf(stdout, "\n");
	}
}

void standard_jacobi(double *A, double *x_base, double *b_base, int dim, int C, int total_equations,  double* init_value) 
{

	double x[total_equations][dim];
	memcpy(x, init_value, sizeof(double) * total_equations* dim);	
	double z[total_equations][dim];
	memset(z, 0, sizeof(double) * C * dim);
	double b[total_equations][dim];
	memset(b, 0, sizeof(double) * total_equations * dim);

	memcpy(b, b_base, sizeof(double) * total_equations * dim);
	int blks = total_equations/C;
	printf("blks = %d\n", blks);
	//分成几块
	for(int yy = 0; yy < blks; yy++)
   	{
		//对每一块迭代多少次
		for(int e = 0; e < MAX_ITER; e ++)
		{	// update x
			//当该循环结束，就产生了C个方程的解。
			for(int i = 0; i < dim; i ++)
			{
				//当该循环结束，就产生了C个方程的部分解，每个解得长度为j。
				for(int k = 0; k < C; k ++) 
				{
					double sigma = 0;
					//当该循环结束，就产生了第K个方程第i个分量的sigma，而计算这第i个分量的sigma，需要用到
					//矩阵A第i行的所有元素和第K个方程当前解的所有元素，这就是这个循环的本质含义。
					for(int j = 0; j < dim; j ++)
					{						
						sigma += (i != j) ? (A[i * dim + j]*x[k+yy*C][j]):0;
					}
				
					z[k+yy*C][i] = (b[k+yy*C][i] - sigma)/A[i * dim + i];				
				}
			
			}

			/**
			 *  Swap x and z
			 */
			double tmp[total_equations][dim];
			memcpy(tmp, x, sizeof(double) * total_equations * dim);
			memcpy(x, z, sizeof(double) * total_equations * dim);
			memcpy(z, tmp, sizeof(double) * total_equations * dim);

		}//loop e

	}
	
	/**
	 *  Copy the final result x to output parameter x_base
	 */
	memcpy(x_base, x, sizeof(double) * total_equations * dim);
}	


int main(int argc, const char** argv) {

	int dim = (argv != NULL) ?  atoi(argv[1]):4;   // this should be a scalar input in the bitstream
	int total_equations = (argv[2] != NULL) ? atoi(argv[2]):2;
	int C = 2;
	int blks = total_equations / C;

	double A[dim * dim];
	double b[total_equations *dim];
	double x_init[C * dim];
	for ( int i = 0; i < C ; i ++ ) 
	{
			for ( int j = 0; j < dim; j ++ ) 
			{
					x_init[i * dim + j] = i * dim + j + 1;
			}
	}
	max_print_matrix_by_row(x_init, C, dim, "X_init");
	/**
	 *  Generating random value for b and A
	 */
	srand(time(NULL));
	for(int i = 0; i < C*blks; i ++)
	{
			for(int j = 0; j < dim; j ++)
			{
//				b[i * dim + j] = 2;
				b[i * dim + j] = 2.0*rand()/(double)RAND_MAX - 1;
			}
	}

	for(int i = 0; i < dim; ++i) {
		double sum = 0;
		for(int j = 0; j < dim; ++j) {
			if(i != j) {
				A[i*dim+j] = 2.0*rand()/(double)RAND_MAX - 1;  // random number between -1 and 1
				sum += fabs(A[i*dim+j]);
//				A[i * dim + j] = 1; 
//				sum += fabs(A[i * dim + j]);

			}
		}
		A[i * dim + i] = 1 + sum;
	}

	double x_base[total_equations * dim];	
	double x_all_init[total_equations];
	for(int i = 0; i < blks; i ++)
	{
		memcpy(x_all_init + i * C * dim, x_init, sizeof(double)*C*dim); 
	}
	standard_jacobi(A,x_base, b, dim, C, total_equations, x_all_init); 

	max_print_matrix_by_row(A, dim, dim, "A");
	max_print_matrix_by_row(b, total_equations, dim, "B");
	max_print_matrix_by_row(x_base, total_equations, dim, "Standard result");
	return 0;
}
