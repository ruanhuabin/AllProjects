#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include "Copula.max"
#define RESULT_EPS 1.0e-7L
#define NR_END 1
#define TINY 1.0e-20;
#define ZERO_EPS 1.0e-8
int PROBABILITY_NUM = 8;
long double mu = 0.0L;
long double sig = 1.0L;
static int MATRIX_DIM_LEN = 8;
static int MATRIX_MAX_DIM_LEN = 10;
static int TOTAL_COPULA_NUM = 16 * 1024 * 1024;

void max_print_matrix(double **m, int rows, int cols, char *hint_msg)
{
	fprintf(stdout, "====>%s\n", hint_msg);
	for(int i = 1; i <= rows; i ++)
	{
		for(int j = 1; j <= cols; j ++)
		{
			fprintf(stdout, "%.16f ", m[i][j]);
		}
		fprintf(stdout, "\n");
	}
}
void max_print_int_vector(int *m, int cols, char *hint_msg)
{
	fprintf(stdout, "====>%s\n", hint_msg);
	for(int i = 0; i < 1; i ++)
	{
		for(int j = 0; j < cols; j ++)
		{
			fprintf(stdout, "%d ", m[i * cols + j]);
		}
		fprintf(stdout, "\n");
	}
}
void max_print_double_vector(double *m, int cols, char *hint_msg)
{
	fprintf(stdout, "====>%s\n", hint_msg);
	for(int i = 0; i < 1; i ++)
	{
		for(int j = 0; j <= cols; j ++)
		{
			fprintf(stdout, "%.16f ", m[i * cols + j]);
		}
		fprintf(stdout, "\n");
	}
}

void load_data(double *buffer, int total_number, const char *file_name)
{
                FILE *fp = fopen(file_name, "r");
                if(NULL == fp)
                {
                        fprintf(stderr, "Read file [%s] failed\n", file_name);
                        exit(0);
                }

                for(int i = 0; i < total_number; i ++)
                {
                        fscanf(fp, "%lf ", &buffer[i]);
                }

                fclose(fp);
}

void max_init_mu_sig(long double new_mu, long double new_sig)
{
	mu = new_mu;
	sig = new_sig;
}

long double  max_get_mu()
{
	return mu;
}

long double max_get_sig()
{
	return sig;
}

long double max_acklam_inverse_cdf(long double p)
{
   long double a[7];
   long double b[6];
   long double c[7];
   long double d[5];

   long double p_low  = 0.02425L;
   long double p_high = 1.0L - p_low;
   long double q = 0.0L;
   long double x = 0.0L;
   long double r= 0.0L;


   a[1] = -3.969683028665376e+01L;
   a[2] =  2.209460984245205e+02L;
   a[3] = -2.759285104469687e+02L;
   a[4] =  1.383577518672690e+02L;
   a[5] = -3.066479806614716e+01L;
   a[6] =  2.506628277459239e+00L;

   b[1] = -5.447609879822406e+01L;
   b[2] =  1.615858368580409e+02L;
   b[3] = -1.556989798598866e+02L;
   b[4] =  6.680131188771972e+01L;
   b[5] = -1.328068155288572e+01L;

   c[1] = -7.784894002430293e-03L;
   c[2] = -3.223964580411365e-01L;
   c[3] = -2.400758277161838e+00L;
   c[4] = -2.549732539343734e+00L;
   c[5] =  4.374664141464968e+00L;
   c[6] =  2.938163982698783e+00L;

   d[1] =  7.784695709041462e-03L;
   d[2] =  3.224671290700398e-01L;
   d[3] =  2.445134137142996e+00L;
   d[4] =  3.754408661907416e+00L;
      
  // if 0 < p < p_low
  if(p > ZERO_EPS && (p - p_low) < ZERO_EPS)
  {     
	  q = sqrtl(-2*logl(p));
      x = (((((c[1]*q+c[2])*q+c[3])*q+c[4])*q+c[5])*q+c[6]) / ((((d[1]*q+d[2])*q+d[3])*q+d[4])*q+1);
  }
 
   //if p_low <= p <= p_high
   if((p_low - p) <= ZERO_EPS && (p - p_high) <= ZERO_EPS)
   {
	  q = p - 0.5L;
      r = q*q;
      x = (((((a[1]*r+a[2])*r+a[3])*r+a[4])*r+a[5])*r+a[6])*q / (((((b[1]*r+b[2])*r+b[3])*r+b[4])*r+b[5])*r+1);
   }
  
   //if p_high < p < 1
   if( (p_high - p) < ZERO_EPS && (p - 1.0L) < ZERO_EPS)
   {
      q = sqrt(-2*log(1-p));
      x = -(((((c[1]*q+c[2])*q+c[3])*q+c[4])*q+c[5])*q+c[6]) / ((((d[1]*q+d[2])*q+d[3])*q+d[4])*q+1);
   }
  	
	return ( p > ZERO_EPS && (p - 1.0L) < ZERO_EPS) ? sig *x + mu : INFINITY;
	
}


void max_error(char error_text[])
/* Numerical Recipes standard error handler */
{
	fprintf(stderr,"Run-time error...\n");
	fprintf(stderr,"%s\n",error_text);
	fprintf(stderr,"...now exiting to system...\n");
	exit(1);
}

double *max_vector(long nl, long nh)
/* allocate a double vector with subscript range v[nl..nh] */
{
	double *v;

	v=(double *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(double)));
	if (!v) max_error("allocation failure in vector()");
	return v-nl+NR_END;
}

void max_free_vector(double *v, long nl, long nh)
/* free a double vector allocated with vector() */
{
	free((v+nl-NR_END));
}


void max_ludcmp(double **input_m, double **dcmp_m, int n, int *indx, double *d)
{
	for(int i = 1; i <=n; i ++)
	{
		memcpy(dcmp_m[i], input_m[i], (n+1)*sizeof(double) );
	}
	int i,imax=0,j,k;
	double big,dum,sum,temp;
	double *vv;

	vv=max_vector(1,n);
	*d=1.0;
	for (i=1;i<=n;i++)
   	{
		big=0.0;
		for (j=1;j<=n;j++)
		{	if ((temp=fabs(dcmp_m[i][j])) > big) 
			{
					big=temp;
			}
		}
		if (fabs(big) < ZERO_EPS) 
		{	
				max_error("Singular matrix in routine max_ludcmp");
		}
		vv[i]=1.0/big;
	}
	for (j=1;j<=n;j++)
   	{
		for (i=1;i<j;i++) 
		{
			sum=dcmp_m[i][j];
			for (k=1;k<i;k++) 
			{	
				sum -= dcmp_m[i][k]*dcmp_m[k][j];
			}

			dcmp_m[i][j]=sum;
		}
		big=0.0;
		for (i=j;i<=n;i++)
	   	{
			sum=dcmp_m[i][j];
			for (k=1;k<j;k++)
			{
					sum -= dcmp_m[i][k]*dcmp_m[k][j];
			}
			dcmp_m[i][j]=sum;
			if ( (dum=vv[i]*fabs(sum)) >= big) 
			{
				big=dum;
				imax=i;
			}
		}
		if (j != imax)
	   	{
			for (k=1;k<=n;k++) 
			{
				dum=dcmp_m[imax][k];
				dcmp_m[imax][k]=dcmp_m[j][k];
				dcmp_m[j][k]=dum;
			}
			*d = -(*d);
			vv[imax]=vv[j];
		}
		indx[j]=imax;
		if (fabs(dcmp_m[j][j]) < ZERO_EPS) 
		{
				dcmp_m[j][j]=TINY;
		}
		if (j != n)
	   	{
			dum=1.0/(dcmp_m[j][j]);
			for (i=j+1;i<=n;i++)
			{	
					dcmp_m[i][j] *= dum;
			}
		}
	}
	max_free_vector(vv,1,n);
}


void max_lubksb(double **a, int n, int *indx, double b[])
{
	int i,ii=0,ip,j;
	double sum;

	for (i=1;i<=n;i++)
   	{
		ip=indx[i];
		sum=b[ip];
		b[ip]=b[i];
		if (ii)
		{
			for (j=ii;j<=i-1;j++)
				   	sum -= a[i][j]*b[j];
		}
		else if (sum) 
		{
				ii=i;
		}
		b[i]=sum;
	}
	for (i=n;i>=1;i--)
   	{
		sum=b[i];
		for (j=i+1;j<=n;j++) 
		{
				sum -= a[i][j]*b[j];
		}
		b[i]=sum/a[i][i];
	}
}

void max_inverse_matrix(double **dcmp_input_m, double **inverse_m, int *indx, int N)
{
	int i,j;
	double *col = (double *)malloc((N + 1) * sizeof(double));
	for(j=1;j<=N;j++)
	{ 
		for(i=1;i<=N;i++)
		{
			col[i]=0.0;
		}
		col[j]=1.0;
		max_lubksb(dcmp_input_m,N,indx,col);
		for(i=1;i<=N;i++)
		{	
			inverse_m[i][j]=col[i];
		}
	}
	free(col);
}


/**
 *  Caculate the matrix det value.
 *  Note: the input matrix should be LU Decomposition
 *  Hint: call max_ludcmp first
 */
double max_det_matrix(double **dcmp_input_m, double d, int N)
{
	int j;
	int *indx = (int *)malloc((N + 1) * sizeof(int));
	for(j=1;j<=N;j++) 
	{
		d *= dcmp_input_m[j][j];
	}
	free(indx);
	return d;

}

void max_matrix_mul_vec(double **m, double *vec, double *result, int n)   
{
	double sum = 0.0;
	 for(int i = 1; i <= n; i ++)
	 {
		sum = 0.0;
	 	for(int j = 1; j <=n; j ++)
		{
			sum += m[i][j] * vec[j];
		}
		result[i] = sum;
	 }	 
}   

double max_vec_mul_vec(double *vec_a, double* vec_b, int n)   
{  
		double sum = 0.0;
	   for(int i = 1; i <= n; i ++)	
	   {
			   sum += vec_a[i] * vec_b[i];
	   }
	   return sum;
}   


void max_minus_identity_matrix(double **input_m, int N)
{
	for(int i = 1; i <= N; i ++)
	{
		input_m[i][i] -= 1;
	}
}
void init_correlation_matrix(double **corr_matrix )
{
	srand(time(NULL));
	for( int i = 1; i <= MATRIX_DIM_LEN; i ++)
	{
		corr_matrix[i][i] = 1.0;
		for(int j = 1; j < i; j ++)
		{
			corr_matrix[i][j] = corr_matrix[j][i] =\
								(double)(1 + rand() % 5) / (double)20.0;
		}
	}

}	
void gen_rand_probability_ex(double *buffer, double min, double max, int N)
{
	if( NULL == buffer )
	{
		fprintf(stderr, "[%s:%d]: gen_rand_probability: buffer is NULL\n", __FILE__, __LINE__);
		exit(1);
	}

	int i = 0;
	int rand_num;
	int max_rand_value = 1000000;
	double tmp = 0.0;

	for( i = 0 ; i <= N; i ++)
	{
		rand_num = 1 + rand() % max_rand_value;
		tmp = (((double)rand_num) / (double)(max_rand_value + 1));
		buffer[i] = tmp < min ? min : tmp;
		buffer[i] = buffer[i] < max ? buffer[i] :max;
	}
}

int max_alloc_double_matrix(double ***p, unsigned int rows, unsigned int cols)
{
	unsigned int i = 0;
	*p = (double **)malloc((rows+1) * sizeof(double *));
	if(*p == NULL)
	{
		fprintf(stderr, "[%s:%d]: Memory allocation failed.\n",\
				__FILE__, __LINE__);
		return 1;
	}
	for( i = 0; i <= rows; i ++)
	{
		(*p)[i] = (double *)malloc((cols + 1) * sizeof(double));
		if((*p)[i] == NULL)
		{
			fprintf(stderr, "[%s:%d]: Memory allocation failed.\n",\
				__FILE__, __LINE__);
			return 1;
		}
		/*Setting maxtrix's init value to 0*/
		memset((*p)[i], 0, (cols + 1) * sizeof(double));
	}
	return 0;
}

void max_free_double_matrix(double ***p, unsigned int rows)
{
	unsigned int i = 0;
	for(; i <= rows; i ++)
	{
		free((*p)[i]);
		(*p)[i] = NULL;
	}
	free(*p);
	*p = NULL;
}

double max_gauss_copula_ex(double **inverse_corr_matrix, double root_reverse_value, double *u, int corr_dim_len, int u_len)
{

	/**
	 *  Caculate u[i]'s inverse cdf value
	 */
	double inverse_cdf_value[u_len + 1];
	double c[u_len + 1];
	memset(inverse_cdf_value, 0, sizeof(inverse_cdf_value));
	memset(c, 0, sizeof(c));
	for(int i = 1; i <= u_len; i ++)
	{
		inverse_cdf_value[i] = max_acklam_inverse_cdf((long double)u[i]);
	}
	/**
	 *  Mul [inverse_corr matrix - E] with inverse cdf of u,
	 *  Saving the result in vector c
	 */
	max_matrix_mul_vec(inverse_corr_matrix, inverse_cdf_value, c, u_len); 
	double matrix_mul_result = max_vec_mul_vec(inverse_cdf_value, c, u_len);
	double exp_power = (-0.5) *matrix_mul_result;
	double	gauss_copula_value = root_reverse_value * exp(exp_power);
	
	return gauss_copula_value;
}

void usage()
{
      printf("\nUsage:\n\n");
	  printf("\t./CopulaRun [-l <number>] [-n <number >]");
	  printf("\nwhere:\n");
	  printf("\t");
	  printf("-l\tnumber of probablity values to generate, default is 8\n");
	  printf("\t");
	  printf("-n\tnumber of copula values to caculate, default 16*1024*1024\n\n");
}
int main(int argc, char* argv[])
{
	if(argc == 1)
	{
		usage();
		return -1;
	}
	char *opt_str = "hd:l:n:";
	int opt = 0;
	while( (opt = getopt(argc, argv, opt_str)) != -1)
	{
		switch(opt)
		{
				case 'l':
						PROBABILITY_NUM = atoi(optarg);
						MATRIX_DIM_LEN = PROBABILITY_NUM;
						break;
				case 'n':
						TOTAL_COPULA_NUM = atoi(optarg);
						break;
				case 'h':
					usage();
					break;
				default:
					printf("Your command line paramters is not right!\n");
					usage();
					return -1;
		}
	}	
	/**
	 *  Processing the invaild data size, for the total byte to stream to/from
	 *  kernel should be multipy of 16 Bytes
	 */
	if( PROBABILITY_NUM * sizeof(double) % 16 != 0 || PROBABILITY_NUM > MATRIX_MAX_DIM_LEN)
	{
		fprintf(stderr, "===>Error:Invalid data size, data size should be 16 bytes align, using only one of following values:[2,4,6,8,10]\n");

		return 1;
	}


	/**
	 *  Setting initial value gaussian copula parameter mu and sig
	 *  their default value is 0.0 and 1.0 respectly.
	 */
    double mu = 0.0;
	double sig = 2.0;
	max_init_mu_sig(mu, sig);

	/**
	 *  Preparing input data for the gauss copula: probablity values and
	 *  inverse matrix of correlation matrix
	 */
	double *prob_val             = NULL;
	double **corr_matrix         = NULL;
    double **dcmp_corr_matrix    = NULL;/* Saving the LU decomposition result */
	double **inverse_corr_matrix = NULL; /* Saving the inverse matrix of original*/
	int    *index                = NULL; /* Output param of max_ludcmp used for caculating inverse matrix */
	double d                     = 0;/* Output parameter of max_ludcmp using for caculating matrix determinant value */

	prob_val = malloc((PROBABILITY_NUM * TOTAL_COPULA_NUM + 1) * sizeof(double));
	index    = malloc((PROBABILITY_NUM + 1) * sizeof(int));
	max_alloc_double_matrix(&corr_matrix         , MATRIX_DIM_LEN     , MATRIX_DIM_LEN);
	max_alloc_double_matrix(&dcmp_corr_matrix    , MATRIX_DIM_LEN     , MATRIX_DIM_LEN);
	max_alloc_double_matrix(&inverse_corr_matrix , MATRIX_MAX_DIM_LEN , MATRIX_MAX_DIM_LEN);

	/**
	 *  Using for saving the copula result.
	 *  The result value is saving in data_out[PROBABILITY_NUM - 1];
	 */
	double *data_out = NULL;
	data_out = malloc((TOTAL_COPULA_NUM + 1) * sizeof(double));

	/**
	 *  Initital probablity values and correlation matrix values
	 */
    clock_t fpga_start       = 0;
	clock_t fpga_end         = 0;
	clock_t total_fpga_ticks = 0;
   gen_rand_probability_ex(prob_val,0.0,1.0, PROBABILITY_NUM * TOTAL_COPULA_NUM);
	init_correlation_matrix(corr_matrix);


	/**
	 *  Using LU Decomposition method to processing correlation matrix
	 *  Saving result decomposition result in dcmp_corr_matrix
	 */
	max_ludcmp(corr_matrix,  dcmp_corr_matrix, PROBABILITY_NUM, index, &d);

	/**
	 *  Using decomposition result matrix to caculate the inverse matrix of
	 *  original correlation matrix
	 */
	max_inverse_matrix(dcmp_corr_matrix, inverse_corr_matrix, index, MATRIX_DIM_LEN);

	/**
	 *  Minus inverse matrix with indentity matrix, for kernel only needs 
	 *  this result
	 */
	max_minus_identity_matrix(inverse_corr_matrix, MATRIX_DIM_LEN);
	/**
	 *  Using decomposition result matrix to Caculate the determinant value of
	 *  correlation matrix
	 */
    double corr_matrix_det = max_det_matrix(dcmp_corr_matrix, d, MATRIX_DIM_LEN);
	double sqrt_matrix_det = sqrt(corr_matrix_det);
	double exp_coef        = 1.0/sqrt_matrix_det;

	/**
	 *  Starting to strean the required data to the kernel, include:
	 *  1. result of [inverse_corr_matrix] - [E]
	 *  2. probablity values
	 *  3. result of 1.0/sqrt(det(|inverse_corr_matrix - E|))
	 *  4. sig
	 *  5. mu
	 *  6. number of probablity values
	 */

	fpga_start = clock();
    Copula(
				PROBABILITY_NUM*TOTAL_COPULA_NUM,
				inverse_corr_matrix[1][1],
				inverse_corr_matrix[2][1],
				inverse_corr_matrix[2][2],
				inverse_corr_matrix[3][1],	
				inverse_corr_matrix[3][2],	
				inverse_corr_matrix[3][3],	
				inverse_corr_matrix[4][1],
				inverse_corr_matrix[4][2],
				inverse_corr_matrix[4][3],
				inverse_corr_matrix[4][4],
				inverse_corr_matrix[5][1],
				inverse_corr_matrix[5][2],
				inverse_corr_matrix[5][3],
				inverse_corr_matrix[5][4],
				inverse_corr_matrix[5][5],
				inverse_corr_matrix[6][1],
				inverse_corr_matrix[6][2],
				inverse_corr_matrix[6][3],
				inverse_corr_matrix[6][4],
				inverse_corr_matrix[6][5],
				inverse_corr_matrix[6][6],
				inverse_corr_matrix[7][1],
				inverse_corr_matrix[7][2],
				inverse_corr_matrix[7][3],
				inverse_corr_matrix[7][4],
				inverse_corr_matrix[7][5],
				inverse_corr_matrix[7][6],
				inverse_corr_matrix[7][7],
				inverse_corr_matrix[8][1],
				inverse_corr_matrix[8][2],
				inverse_corr_matrix[8][3],
				inverse_corr_matrix[8][4],
				inverse_corr_matrix[8][5],
				inverse_corr_matrix[8][6],
				inverse_corr_matrix[8][7],
				inverse_corr_matrix[8][8],
				inverse_corr_matrix[9][1],
				inverse_corr_matrix[9][2],
				inverse_corr_matrix[9][3],
				inverse_corr_matrix[9][4],
				inverse_corr_matrix[9][5],
				inverse_corr_matrix[9][6],
				inverse_corr_matrix[9][7],
				inverse_corr_matrix[9][8],
				inverse_corr_matrix[9][9],
				inverse_corr_matrix[10][1],
				inverse_corr_matrix[10][2],
				inverse_corr_matrix[10][3],
				inverse_corr_matrix[10][4],
				inverse_corr_matrix[10][5],
				inverse_corr_matrix[10][6],
				inverse_corr_matrix[10][7],
				inverse_corr_matrix[10][8],
				inverse_corr_matrix[10][9],
				inverse_corr_matrix[10][10],
				MATRIX_DIM_LEN,
				exp_coef,
				mu,
				sig,
				PROBABILITY_NUM, /* Actual count of probability values*/
				prob_val,
				PROBABILITY_NUM * TOTAL_COPULA_NUM * sizeof(double),
				data_out,
				TOTAL_COPULA_NUM *sizeof(double)
					);

	fpga_end = clock();
	total_fpga_ticks = (fpga_end - fpga_start);	
	/**
	 *  Using C implentmation of of gaussian copula to check
	 *  whether the FPGA output value is correct 
	 */
	double *u = NULL;
	u = malloc((PROBABILITY_NUM * TOTAL_COPULA_NUM + 1) * sizeof(double));
	memcpy(u + 1, prob_val, PROBABILITY_NUM * TOTAL_COPULA_NUM *sizeof(double));

	clock_t cpu_start = 0;
	clock_t cpu_end = 0;
	clock_t total_cpu_ticks = 0;
	int pass_count = 0;
	double max_precision = 0.0;
	int mp_actual_copula_index = 0;

	/**
	 *  Testing the CPU Running Time
	 *  Caculating Total_CopuLa_NUM copula numbers
	 */
	double mp_expected_copula = 0.0;
	for(int k = 0; k < TOTAL_COPULA_NUM; k ++)
	{
			cpu_start = clock();
			double expected_copula_value = max_gauss_copula_ex(inverse_corr_matrix, exp_coef, u + k * PROBABILITY_NUM, MATRIX_DIM_LEN, PROBABILITY_NUM); 
			cpu_end = clock();
			total_cpu_ticks += (cpu_end - cpu_start);

			double precision = fabs(expected_copula_value - data_out[k]);
			/**
			 *  We caculte the related error
			 */
			precision = precision / expected_copula_value;
			if(max_precision < precision) {
				max_precision          = precision;
				mp_actual_copula_index = k;
				mp_expected_copula = expected_copula_value;
			}
			
			if(precision<= RESULT_EPS)
			{
					pass_count ++;
			}
	}
    
	/**
	 *  Caculating consuming time by engine and cpu
	 */
	double total_cpu_time = (double)total_cpu_ticks / CLOCKS_PER_SEC;
	double total_fpga_time = (double)total_fpga_ticks / CLOCKS_PER_SEC;
	double speedup = total_cpu_time/total_fpga_time;
	fprintf(stdout, "\nDimension\tCopula Number\tEngine Time\tCPU Time\tSpeedup\t\tMax Difference\n");
	fprintf(stdout, "%d\t\t%d\t\t%.3f\t\t%.3f\t\t%.2f\t\t%.3e\n", PROBABILITY_NUM, TOTAL_COPULA_NUM, total_fpga_time, total_cpu_time, speedup, max_precision);


	if(pass_count == TOTAL_COPULA_NUM)
	{
		fprintf(stderr, "All Test Passed\n");
	}
	else
	{
		fprintf(stderr, "Test Failed, Fail Count: %d\n", (TOTAL_COPULA_NUM - pass_count));
	}
	/**
	 *  Output the max err different probabability values
	 */
#if 0 
	fprintf(stderr, "Max Precision Probability values:\n");
	for(int j = 1; j <= PROBABILITY_NUM; j ++)
	{
			fprintf(stdout, "%.10f ", u[mp_actual_copula_index * PROBABILITY_NUM + j]);
	}

	fprintf(stdout, "\n");
	fprintf(stdout, "expected = %.10f, actual = %.10f, index=%d\n", mp_expected_copula, data_out[mp_actual_copula_index], mp_actual_copula_index);
#endif

	/**
	 *  Free all unused memory
	 */
    max_free_double_matrix(&corr_matrix, MATRIX_DIM_LEN);
	max_free_double_matrix(&dcmp_corr_matrix, MATRIX_DIM_LEN);
	max_free_double_matrix(&inverse_corr_matrix, MATRIX_MAX_DIM_LEN);

	free(prob_val);
	free(data_out);
	free(index);
	free(u);
	return 0;
}
