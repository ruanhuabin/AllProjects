#!/bin/bash
rm -rf JACOBI.max
TIME=01-06-12
DIR_NAME=Copula
NAME=Copula
ln -s /network-scratch/hruan/maxdc_builds/${TIME}/${DIR_NAME}/scratch/${NAME}.max Copula.max
ls -l ${NAME}.max

