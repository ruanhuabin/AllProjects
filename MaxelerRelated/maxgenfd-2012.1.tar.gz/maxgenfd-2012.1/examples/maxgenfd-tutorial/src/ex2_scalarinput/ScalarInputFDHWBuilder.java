package ex2_scalarinput;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;
import common.BoardModel;

public class ScalarInputFDHWBuilder {

	public static void main(String[] args) {

		FDConfig config = ScalarInputFDConfig.config();
		config.setBoardModel(BoardModel.BOARDMODEL);

		FDManager m = new FDManager("ScalarInputFD", config);
		ScalarInputFDKernel k = new ScalarInputFDKernel(m.makeKernelParameters());

		m.setKernel(k);
		m.build();
	}
}
