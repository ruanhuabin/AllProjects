#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "maxlib.h"
#include "../common/file_utils.h"
#include "../common/data_gen.h"

int main(int argc, char** argv) {
#ifndef SIM
	const int nx = 676, ny = 676, nz = 240; // Dimensions of the domain (z is vertical)
#else
	const int nx = 66, ny = 66, nz = 66;	// Dimensions of the domain for simulation
#endif
	int n = nx * ny * nz;
	const int source_x = nx/2, source_y = ny/2, source_z = 7; // Source coordinates

	const int sponge_width = 50;			// Width of the sponge in points
#ifndef SIM
	const int sponge_active_width = 50;		// Width of the sponge in use in hardware
#else
	const int sponge_active_width = 10;		// Width of the sponge to use in simulation
#endif
	const int sponge_mask = MAXLIB_BOUNDARY_ALL^MAXLIB_BOUNDARY_Z0; // Bit mask for the sides of the domain to sponge (all sides except z=0)

#ifndef SIM
	const int num_iterations = 2000;
#else
	const int num_iterations = 128;
#endif

#ifndef SIM
	const int iterations_per_frame = 50;
#else
	const int iterations_per_frame = 1;
#endif
	const float delta_distance = 20.0f;	// Delta distance in metres
	const float delta_time = 0.002f;	// Delta time in seconds
	const float fpeak = 5;				// Peak frequency of source wavelet


	float *vel_sq;						// Velocity earth model
	float *zero_wavefield;				// Empty wavefield to initialize simulation
	float *receiver;					// Receiver
	float source[3*3*3];				// Source stimulus
	float *sponge;						// Sponge

	const char *output_filename = "output";

	maxlib_context maxlib = maxlib_open(nx, ny, nz); // Initialise maxlib with dimensions of domain
	maxlib_print_status(maxlib);

	vel_sq = create_2layer_earth_model_vel(nx, ny, nz); // Set up earth model
	// Calculate the square of the earth model
	for(size_t i = 0; i < n; i++) {
		vel_sq[i] = vel_sq[i]*vel_sq[i];
	}

	maxlib_earthmodel em = maxlib_earthmodel_create_in_memory(nx, ny, nz);

	printf("Compressing earth model\n");
	maxlib_earthmodel_set_data(em, "vel_sq", vel_sq);
	free(vel_sq); // We don't need the original earth model any more

	// Allocate memory on the MaxCard for the wavefields and earth model
	maxlib_dram_array card_curr_array = maxlib_dram_alloc_wavefield(maxlib);
	maxlib_dram_array card_prev_array = maxlib_dram_alloc_wavefield(maxlib);
	maxlib_dram_array card_earthmodels = maxlib_dram_alloc_earthmodel(maxlib);

	zero_wavefield = malloc(n * sizeof(float));
	for(int i = 0; i < nz * nx * ny; i++) // Init empty wavefield
		zero_wavefield[i] = 0.0f;

	printf("Loading curr wavefield to card\n");
	maxlib_dram_load_wavefield(maxlib, card_curr_array, zero_wavefield);
	printf("Loading prev wavefield to card\n");
	maxlib_dram_load_wavefield(maxlib, card_prev_array, zero_wavefield);
	printf("Loading earth model to card\n");
	maxlib_dram_load_earthmodel(maxlib, card_earthmodels, em);
	maxlib_earthmodel_release(em);

	maxlib_set_scalar_flag(maxlib, "absorb", sponge_mask);	// Set bit mask
	sponge = create_simple_sponge(sponge_width, sponge_active_width); // Create sponge
	for(int i = 0; i < sponge_width; i++)				// Set the sponge on the MaxCard
		maxlib_set_mapped_memory_f(maxlib, "sponge", i, sponge[i]);

	receiver = malloc(ny*nz * sizeof(float));			// Allocate memory for receiver plane
	FILE* output = fopen(output_filename, "w");			// Output file for the receiver
	// Create a header file for the output file
	if (create_header_file(output_filename, nz, ny, 1, "Y", "Z", "Time"))
		exit(1);

	// Execute timesteps
	for(int iteration = 0; iteration < num_iterations; iteration++) {

		printf("Iteration %d / %d\n", iteration, num_iterations);

		float time = iteration * delta_time;

		maxlib_set_scalar(maxlib, "dttd", delta_time*delta_time / (delta_distance*delta_distance));

		if(time <= 2.0f/fpeak)
			gen_source(source, time, fpeak); // Generate source wavelet

		float* data = (time <= 2.0f/fpeak)? source : NULL;
		maxlib_stream_region_from_host(maxlib, "source",
				data,
				source_x-1, source_y-1, source_z-1,
				source_x+2, source_y+2, source_z+2);

		// Set up inputs and output arrays for this timestep
		maxlib_stream_from_dram(maxlib, "curr_w", card_curr_array);
		maxlib_stream_from_dram(maxlib, "prev_w", card_prev_array);
		maxlib_stream_earthmodel_from_dram(maxlib, card_earthmodels);
		maxlib_stream_to_dram(maxlib, "next_w", card_prev_array);

		// Read back the receiver every iterations_per_frame iterations
		data = (iteration % iterations_per_frame == 0)? receiver : NULL;
		maxlib_stream_region_to_host(maxlib, "receiver",
				data,
				source_x, 0, 0,
				source_x+1, ny, nz);

		// Run timestep
		maxlib_run(maxlib);

		// Write out the receiver data to the output file
		if (iteration % iterations_per_frame == 0) {
			fwrite(receiver, sizeof(float), ny * nz, output);
			fflush(output);
		}

		// Swap wavefield buffers
		maxlib_dram_array tmp_array = card_curr_array;
		card_curr_array = card_prev_array;
		card_prev_array = tmp_array;
	}

	// Clean up
	fclose(output);
	maxlib_close(maxlib);
	return 0;
}
