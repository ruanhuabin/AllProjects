package ex2_scalarinput;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;

public class ScalarInputFDHostSimBuilder {

	public static void main(String[] args) {

		FDConfig config = ScalarInputFDConfig.config();
		config.setSimulationEnabled(true);

		FDManager m = new FDManager("ScalarInputFDHostSim", config);
		ScalarInputFDKernel k = new ScalarInputFDKernel(m.makeKernelParameters());

		m.setKernel(k);
		m.build();
	}
}
