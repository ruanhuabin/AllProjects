/*
 * Create a header file for the output data with the output filename and ".H" extension.
 *
 * This can be loaded by Axion to view the output and set the dimensions correctly for display.
 */
int create_header_file(const char *file_name, int xDim, int yDim, int zDim, const char *xDimName, const char *yDimName, const char *zDimName);
