package common;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.channels.FileChannel;

public class OutputFile {

	File outputFile;

	/**
	 * Opens an output file and creates a header file for it.
	 * @param fileName Name for the output file. fileName.H will be used for the header file.
	 * @param xDim Width of the image.
	 * @param yDim Height of the image.
	 * @throws IOException
	 */
	public OutputFile(String fileName, int xDim, int yDim, int zDim, String xDimName, String yDimName, String zDimName) throws IOException
	{
		outputFile = new File(fileName);

		File parentDir = outputFile.getParentFile();
		if (parentDir != null)
			parentDir.mkdirs();
		if (outputFile.exists())
			outputFile.delete();
		outputFile.createNewFile();

		//Write out the metafile with the name of the output file and the dimensions of the 2D slice
		PrintWriter metaFile = null;
		try {
			int sep = fileName.lastIndexOf('/');
			String _fileName = fileName;
			if (sep > -1)
				_fileName = fileName.substring(sep + 1);

			metaFile = new PrintWriter(fileName+".H");
			metaFile.println("in="+_fileName);
			metaFile.println("n1="+xDim);
			metaFile.println("n2="+yDim);
			metaFile.println("label1="+xDimName);
			metaFile.println("label2="+yDimName);

			if (zDim!=1)
			{
				metaFile.println("label3="+zDimName);
				metaFile.println("n3="+zDim);
				metaFile.println("label4=Time");
			}
			else
				metaFile.println("label3=Time");
			metaFile.println("esize=1");
		}
		finally {
			metaFile.close();
		}
	}

	/**
	 * Append floating point data to the end of the file. The data is written
	 * out in IEEE 754 single-precision (32 bits) format using little-endian
	 * byte ordering.
	 * @param data The data to write out.
	 * @throws IOException
	 */
	public void appendData(double[] data) throws IOException {
		ByteBuffer b = ByteBuffer.allocate(data.length * 4);
		b.order(ByteOrder.LITTLE_ENDIAN);
		FloatBuffer fb = b.asFloatBuffer();

		for (double x : data)
			fb.put((float) x);

		FileOutputStream ff = new FileOutputStream(outputFile, true);
		FileChannel c = ff.getChannel();
		try {
			c.write(b);
		}
		finally {
			c.close();
		}
	}
}
