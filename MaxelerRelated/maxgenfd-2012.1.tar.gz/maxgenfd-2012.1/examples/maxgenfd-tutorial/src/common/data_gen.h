/*
 * Create two-layer velocity earth model
 */
float *create_2layer_earth_model_vel(int nx, int ny, int nz);

/*
 * Preprocess the earth model to create scaled velocity squared
 */
void preprocess_earth_model_dvv(float *em, int nx, int ny, int nz, float d, float dt);

/*
 * Preprocess the earth model to create scaled velocity
 */
void preprocess_earth_model_dv(float *em, int nx, int ny, int nz, float d, float dt);

/*
 * Create coefficients for simple sponge
 */
float *create_simple_sponge(int width, int active_width);

/*
 * Generate source Ricker wavelet
 */
void gen_source(float *source, float time, float fpeak);
