package common;

public class DataGen {

	/**
	 * Create two-layer velocity earth model
	 */
	public static double[] create2LayerEarthModel_vel(int nx, int ny, int nz) {
		double[] vel = new double[nx * ny * nz];
		int z;

		for(z = 0; z < nz/3; z++)
			for(int y = 0; y < ny; y++)
				for(int x = 0; x < nx; x++)
					vel[z + y*nz + x*nz*ny] = 1500; // water

		for(; z < nz; z++)
			for(int y = 0; y < ny; y++)
				for(int x = 0; x < nx; x++)
					vel[z + y*nz + x*nz*ny] = 4482; // salt

		return vel;
	}

	/**
	 * Preprocess the earth model to create scaled velocity squared
	 */
	static public void preprocessEarthModel_dvv(double[] em, int nx, int ny, int nz, double d, double dt)
	{
		int n = nx * ny * nz;
		double dttd = dt*dt / (d*d);

		double velmax = 0.0f;
		double velmin = 1.0e20f;
		double dvvmax = 0.0f;
		double dvvmin = 1.0e20f;

		for(int i = 0; i < n; i++) {
			if(em[i] > velmax) velmax = em[i];
			if(em[i] < velmin) velmin = em[i];

			em[i] = em[i]*em[i] * dttd;

			if(em[i] > dvvmax) dvvmax = em[i];
			if(em[i] < dvvmin) dvvmin = em[i];
		}

		System.out.println("  velmax = "+velmax);
		System.out.println("  velmin = "+velmin);
		System.out.println("  dvvmax = "+dvvmax);
		System.out.println("  dvvmin = "+dvvmin);
	}

	/**
	 * Preprocess the earth model to create scaled velocity
	 */
	static public void preprocessEarthModel_dv(double[] em, int nx, int ny, int nz, double d, double dt)
	{
		int n = nx * ny * nz;

		double velmax = 0.0f;
		double velmin = 1.0e20f;
		double dvmax = 0.0f;
		double dvmin = 1.0e20f;

		for(int i = 0; i < n; i++) {
			if(em[i] > velmax) velmax = em[i];
			if(em[i] < velmin) velmin = em[i];

			em[i] = em[i] * dt / d;

			if(em[i] > dvmax) dvmax = em[i];
			if(em[i] < dvmin) dvmin = em[i];
		}

		System.out.println("  velmax = "+velmax);
		System.out.println("  velmin = "+velmin);
		System.out.println("  dvmax = "+dvmax);
		System.out.println("  dvmin = "+dvmin);
	}

	/**
	 * Create sponge coefficients
	 */
	static public double[] createSponge(int width)
	{
		double[] s = new double[width];
		for(int i = 0; i < width; i++)
			s[i] = Math.exp(-0.0009 * (width-i));

		return s;
	}

	/**
	 * Generate Source Ricker Wavelet
	 */
	static public double[] genSource(int sourceSize, double time, double fpeak)
	{
		double[] source = new double[sourceSize*sourceSize*sourceSize];
		double x = Math.PI * fpeak * (time - 1.0f/fpeak);
		double val = Math.exp(-x * x) * (1.0f - 2.0f * x * x);

		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
				for (int k = 0; k < 3; k++)
					source[i * 9 + j * 3 + k] = -val * Math.exp(-(1-i)*(1-i)-(1-j)*(1-j)-(1-k)*(1-k));
		return source;
	}

}
