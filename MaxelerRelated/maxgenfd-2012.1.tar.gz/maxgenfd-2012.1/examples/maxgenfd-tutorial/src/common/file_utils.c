#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int create_header_file(const char *file_name, int xDim, int yDim, int zDim, const char *xDimName, const char *yDimName, const char *zDimName)
{
	char *header_file_name = (char*)malloc((strlen(file_name)+3)*sizeof(char));

	strcpy(header_file_name, file_name);
	strcat(header_file_name, ".H");
	FILE* header_file = fopen(header_file_name, "w");

	if (header_file == NULL)
	{
		printf("Error creating file: %s.", header_file_name);
		return 1;
	}

	char *file_name_stripped = strrchr(file_name,'/');
	if (file_name_stripped == NULL)
		fprintf(header_file, "in=%s\n", file_name);
	else
		fprintf(header_file, "in=%s\n", file_name_stripped);
	fprintf(header_file, "n1=%d\n", xDim);
	fprintf(header_file, "n2=%d\n", yDim);
	fprintf(header_file, "label1=%s\n", xDimName);
	fprintf(header_file, "label2=%s\n", yDimName);

	if (zDim!=1)
	{
		fprintf(header_file, "n3=%d\n", zDim);
		fprintf(header_file, "label3=%s\n", zDimName);
		fprintf(header_file, "label4=Time\n");
	}
	else
		fprintf(header_file, "label3=Time\n");

	fprintf(header_file, "esize=1\n");

	fclose(header_file);
	free(header_file_name);
	return 0;
}
