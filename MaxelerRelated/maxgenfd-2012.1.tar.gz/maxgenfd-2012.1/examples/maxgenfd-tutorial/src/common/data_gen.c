#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "maxlib.h"

#include "data_gen.h"

#define M_PI 3.14159265358979323846

float *create_2layer_earth_model_vel(int nx, int ny, int nz)
{
	const size_t n = nx * ny * nz;

	float *vel = malloc(n * sizeof(float));

	int z;

	for(z = 0; z < nz/6; z++)
		for(int y = 0; y < ny; y++)
			for(int x = 0; x < nx; x++)
				vel[z + y*nz + x*nz*ny] = 1500; // water


	for(; z < nz; z++)
		for(int y = 0; y < ny; y++)
			for(int x = 0; x < nx; x++)
				vel[z + y*nz + x*nz*ny] = 4482; // salt

	return vel;
}

void preprocess_earth_model_dv(float *em, int nx, int ny, int nz, float d, float dt)
{
	const size_t n = nx * ny * nz;

	float velmax = 0.0f;
	float velmin = 1.0e20f;
	float dvmax = 0.0f;
	float dvmin = 1.0e20f;

	for(size_t i = 0; i < n; i++) {
		if(em[i] > velmax) velmax = em[i];
		if(em[i] < velmin) velmin = em[i];

		em[i] = em[i] * dt / d;

		if(em[i] > dvmax) dvmax = em[i];
		if(em[i] < dvmin) dvmin = em[i];
	}

	printf("  velmax = %g\n", velmax);
	printf("  velmin = %g\n", velmin);
	printf("  dvmax = %g\n", dvmax);
	printf("  dvmin = %g\n", dvmin);
}

void preprocess_earth_model_dvv(float *em, int nx, int ny, int nz, float d, float dt)
{
	const size_t n = nx * ny * nz;
	const float dttd = dt*dt / (d*d);

	float velmax = 0.0f;
	float velmin = 1.0e20f;
	float dvvmax = 0.0f;
	float dvvmin = 1.0e20f;

	for(size_t i = 0; i < n; i++) {
		if(em[i] > velmax) velmax = em[i];
		if(em[i] < velmin) velmin = em[i];

		em[i] = em[i]*em[i] * dttd;

		if(em[i] > dvvmax) dvvmax = em[i];
		if(em[i] < dvvmin) dvvmin = em[i];
	}

	printf("  velmax = %g\n", velmax);
	printf("  velmin = %g\n", velmin);
	printf("  dvvmax = %g\n", dvvmax);
	printf("  dvvmin = %g\n", dvvmin);
}

float *create_simple_sponge(int width, int active_width)
{
	if (active_width > width)
		active_width = width;
	float *s = malloc(width * sizeof(float));
	int i = 0;
	for(; i < active_width; i++)
	{
		s[i] = exp(-0.0005 * (active_width-i));
	}
	for(; i < width; i++)
	{
		s[i] = 1.0;
	}
	return s;
}

void gen_source(float *source, float time, float fpeak)
{
	float x = M_PI * fpeak * (time - 1.0f/fpeak);
	float val = expf(-x * x) * (1.0f - 2.0f * x * x);

	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			for (int k = 0; k < 3; k++)
				source[i * 9 + j * 3 + k] = -val * expf(-(1-i)*(1-i)-(1-j)*(1-j)-(1-k)*(1-k));
}
