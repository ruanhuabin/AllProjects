package ex3_fixedpoint;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.StorageType;
import com.maxeler.maxgen.fd.FDConfig.DefaultType;

public class FixedPointFDConfig {
	public static FDConfig config() {
		// Use fixed point
		FDConfig config = new FDConfig(DefaultType.FIXED);

		config.setMaxBlockSize(192, 144);

		config.setClockFrequency(100);	// This can go up to 150Mhz but requires a long build time

		config.setParallelPipelines(8);

		// Enable compression for wavefields and earth model
		config.setWavefieldStorageType(StorageType.compressed16);
		config.setEarthModelStorageType("dvv", StorageType.compressedTable(10));

		// Set our fixed point type for all calculations
		config.setWavefieldComputeType(24);
		config.setCoefficientType(18);
		config.setEarthModelComputeType("dvv", 18);
		config.setConvolveTypes(25, 48);

		return config;
	}
}