package ex3_fixedpoint;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;

public class FixedPointFDHostSimBuilder {

	public static void main(String[] args) {

		FDConfig config = FixedPointFDConfig.config();
		config.setSimulationEnabled(true);

		FDManager m = new FDManager("FixedPointFDHostSim", config);
		FixedPointFDKernel k = new FixedPointFDKernel(m.makeKernelParameters());

		m.setKernel(k);
		m.build();
	}
}
