package ex3_fixedpoint;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;
import common.BoardModel;

public class FixedPointFDHWBuilder {

	public static void main(String[] args) {

		FDConfig config = FixedPointFDConfig.config();
		config.setBoardModel(BoardModel.BOARDMODEL);

		FDManager m = new FDManager("FixedPointFD", config);
		FixedPointFDKernel k = new FixedPointFDKernel(m.makeKernelParameters());

		m.setKernel(k);
		m.build();
	}
}
