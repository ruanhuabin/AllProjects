package ex1_simple;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;
import common.BoardModel;
public class SimpleFDHWBuilder {

	public static void main(String[] args) {

		FDConfig config = SimpleFDConfig.config();
		config.setBoardModel(BoardModel.BOARDMODEL);

		FDManager m = new FDManager("SimpleFD", config);
		SimpleFDKernel k = new SimpleFDKernel(m.makeKernelParameters());

		m.setKernel(k);

		m.build();
	}
}