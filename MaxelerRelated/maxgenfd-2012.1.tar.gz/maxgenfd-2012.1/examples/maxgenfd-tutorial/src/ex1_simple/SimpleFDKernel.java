package ex1_simple;

import com.maxeler.maxgen.fd.ConvolveAxes;
import com.maxeler.maxgen.fd.FDKernel;
import com.maxeler.maxgen.fd.FDKernelParameters;
import com.maxeler.maxgen.fd.FDVar;
import com.maxeler.maxgen.fd.stencils.Stencil;

public class SimpleFDKernel extends FDKernel {

	private final int stencilSize = 13;
	private final Stencil stencil = fixedStencil(-stencilSize/2, stencilSize/2, new double[] {
			-0.00003006253006249946f, 0.0005194805194800871f, -0.004464285714282842f, 0.02645502645501459f, -0.133928571428538f, 0.857142857142776f, -1.49138888888878f, 0.857142857142776f, -0.133928571428538f, 0.02645502645501459f, -0.004464285714282842f, 0.0005194805194800871f, -0.00003006253006249946f
	}, 8.0);

	public SimpleFDKernel(FDKernelParameters parameters) {
		super(parameters);
		FDVar curr = io.waveFieldInput("curr_w", 1.0, stencilSize/2);	// Current wavefield
		FDVar prev = io.waveFieldInput("prev_w", 1.0, 0); 				// Previous wavefield
		FDVar dvv = io.earthModelInput("dvv", 1/4.0, 0);				// Earth model
		FDVar source = io.hostInput("source", 1.0, 0);					// Stimulus data
		FDVar sponge = boundaries.sponge(50);							// Sponge

		prev = prev*sponge;												// Sponge previous wavefield

		FDVar laplacian = convolve(curr, ConvolveAxes.XYZ, stencil);
		FDVar result = curr * 2 - prev + dvv * laplacian + source;

		result = result*sponge;											// Sponge result

		io.hostOutput("receiver", result);								// Receiver output to host
		io.waveFieldOutput("next_w", result);							// Wavefield output
	}
}
