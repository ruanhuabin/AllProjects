package ex1_simple;

import com.maxeler.maxcompiler.v1.kernelcompiler.types.base.HWFloat;
import com.maxeler.maxcompiler.v1.kernelcompiler.types.base.HWTypeFactory;
import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.StorageType;
import com.maxeler.maxgen.fd.FDConfig.DefaultType;

public class SimpleFDConfig {
	public static FDConfig config() {
		// Use floating point
		FDConfig config = new FDConfig(DefaultType.FLOAT);

		config.setParallelPipelines(1);

		// Enable compression for wavefields and earth model
		config.setWavefieldStorageType(StorageType.compressed16);
		config.setEarthModelStorageType("dvv", StorageType.compressedTable(10));

		// IEEE single-precision floating point
		HWFloat t = HWTypeFactory.hwFloat(8, 24);
		// Set our floating point type for all calculations
		config.setWavefieldComputeType(t);
		config.setCoefficientType(t);
		config.setEarthModelComputeType("dvv", t);

		return config;
	}
}