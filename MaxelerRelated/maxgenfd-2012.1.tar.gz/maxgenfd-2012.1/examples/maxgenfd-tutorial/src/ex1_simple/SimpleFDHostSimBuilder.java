package ex1_simple;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;

public class SimpleFDHostSimBuilder {

	public static void main(String[] args) {

		FDConfig config = SimpleFDConfig.config();
		config.setSimulationEnabled(true);

		FDManager m = new FDManager("SimpleFDHostSim", config);
		SimpleFDKernel k = new SimpleFDKernel(m.makeKernelParameters());

		m.setKernel(k);
		m.build();
	}
}
