package ex1_simple;

import java.io.IOException;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDSimManager;
import com.maxeler.maxgen.fd.StorageType;
import common.DataGen;
import common.OutputFile;

public class SimpleFDSimRunner {

	/** Size of wave field and data in the X axis. */
	private static final int nx = 66;
	/** Size of wave field and data in the Y axis. */
	private static final int ny = 66;
	/** Size of wave field and data in the Z axis. */
	private static final int nz = 66;

	/** Delta time in seconds. */
	private static final double deltaTime = 0.002f;
	/** Delta distance in metres. */
	private static final double deltaDistance = 20.0f;
	/** Peak frequency of source wavelet. */
	private static final double fPeak = 5;

	/** Size of the source (in cells). */
	private static final int sourceSize = 3;
	/** Source location on X axis. */
	private static final int isx = nx / 2;
	/** Source location on Y axis. */
	private static final int isy = ny / 2;
	/** Source location on Z axis. */
	private static final int isz = 7;

	/** Sponge width. */
	private static final int spongeWidth = 50;

	/** Total number of timesteps to simulate. */
	private static final int numTimeSteps = 128;
	/** Number of timesteps between writing out receiver plane. */
	private static final int timestepsPerFrame = 4;

	/** File in which to save receiver data*/
	private static String outputFileName = "output";

	public static void main(String[] args) {
		FDConfig config = SimpleFDConfig.config();

		// Compressed storage types are not supported in simulatiin
		config.setWavefieldStorageType(StorageType.float8_24);

		FDSimManager sim = new FDSimManager("SimpleFDSim", config);
		sim.setKernel(new SimpleFDKernel(sim.makeKernelParameters()));

		sim.build();

		/** Earth model data. */
		double[] earthModel = DataGen.create2LayerEarthModel_vel(nx, ny, nz);
		DataGen.preprocessEarthModel_dvv(earthModel, nx, ny, nz, deltaDistance, deltaTime);

		double[] sponge = DataGen.createSponge(spongeWidth);
		sim.setMappedRom("sponge", sponge);
		// Disable the sponge for simulation
		sim.setScalarInput("absorb", 0);

		OutputFile outputfile = null;

		// Wavefield for current time step.
		double[] curr = new double[nx * ny * nz];
		// Wavefield for previous time step.
		double[] prev  = curr;

		try {
			if (System.getenv("MAXGENFD_TUTORIAL_COMMANDLINE")==null)
				outputFileName = "src/ex1_simple/"+outputFileName;
			outputfile = new OutputFile(outputFileName, nx, ny, 1, "X", "Y", "Z");
		} catch (IOException e) {
			sim.logError("Error creating header file: %s ("+outputFileName+")", e);
			System.exit(1);
		}

		sim.setProblemSize(nx, ny, nz);

		/** The time step that we are currently simulating. */
		int timestep = 0;

		while (timestep < numTimeSteps) {
			// set the earth model data
			sim.setEarthModelInputData("dvv", earthModel);

			// set the source data
			double[] source = DataGen.genSource(sourceSize, timestep*deltaTime, fPeak);
			sim.setHostInputData("source", source,
					isx, isx + sourceSize,
					isy, isy + sourceSize,
					isz, isz + sourceSize
			);
			sim.setHostOutputRegion("receiver",
					0, nx,
					isy, isy + 1,
					0, nz
			);

			// set the wave fields
			sim.setWaveFieldInputData("prev_w", prev);
			sim.setWaveFieldInputData("curr_w", curr);

			// run the simulation
			sim.run("timestep_" + timestep);

			// dump output data to file
			if (timestep % timestepsPerFrame == 0) {
				double[] dataOut = sim.getHostOutputData("receiver");
				try {
					outputfile.appendData(dataOut);

					sim.logMsg("Wrote data to '%s'.", outputFileName);
				} catch (IOException e) {
					sim.logError("Error writing out data: %s "+"("+outputFileName+")", e);
					System.exit(1);
				}
			}

			// update wave fields
			prev = curr;
			curr = sim.getWaveFieldOutputData("next_w");
			++timestep;
		}
	}
}
