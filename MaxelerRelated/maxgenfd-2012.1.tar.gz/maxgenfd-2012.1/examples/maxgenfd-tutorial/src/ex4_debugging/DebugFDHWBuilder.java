package ex4_debugging;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;
import common.BoardModel;

public class DebugFDHWBuilder {

	public static void main(String[] args) {

		FDConfig config = DebugFDConfig.config();
		config.setBoardModel(BoardModel.BOARDMODEL);

		FDManager m = new FDManager("DebugFD", config);
		DebugFDKernel k = new DebugFDKernel(m.makeKernelParameters());

		m.setKernel(k);
		m.build();
	}
}
