package ex4_debugging;

import com.maxeler.maxgen.fd.FDConfig;
import com.maxeler.maxgen.fd.FDManager;

public class DebugFDHostSimBuilder {

	public static void main(String[] args) {

		FDConfig config = DebugFDConfig.config();
		config.setSimulationEnabled(true);

		FDManager m = new FDManager("DebugFDHostSim", config);
		DebugFDKernel k = new DebugFDKernel(m.makeKernelParameters());

		m.setKernel(k);
		m.build();
	}
}
