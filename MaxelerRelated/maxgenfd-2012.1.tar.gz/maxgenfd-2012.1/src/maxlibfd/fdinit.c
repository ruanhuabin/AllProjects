/*********************************************************************
 * MaxGen FD Runtime Interface                                       *
 * Copyright (C) 2012 Maxeler Technologies                           *
 *                                                                   *
 * Version: 2012.1                                                   *
 * Date:    8th June 2012                                            *
 *                                                                   *
 *********************************************************************/

#include <math.h>
#include <stdlib.h>
#include <MaxCompilerRT.h>
#include <stdio.h>
#include <string.h>
#include "fdinit.h"

// This is required to get rid of spurious slic declarations in the maxfiles as of Feb 2012.
#define SLIC_NO_DECLARATIONS

#define EVAL_CONCAT(a, b) a ## b
#define CONCAT(a, b) EVAL_CONCAT(a, b)

#define EVAL_STRING(a) # a
#define STRING(a) EVAL_STRING(a)

#ifndef MAXFILE
#error MAXFILE macro has not been defined
#endif

#ifndef DESIGN_NAME
#error DESIGN_NAME macro has not been defined
#endif

#define FDCOMPILER_VERSION
#include STRING(MAXFILE)
#ifndef FDCOMPILER_VERSION_2012_1
#error "This maxfile was compiled using a different version of MaxGen FD (the current version is 2012.1). Please check that your MAXGENFDDIR environment variable is set correctly and that your build path includes the correct version of MaxGenFD.jar (the version number will be printed near the top of the _build.log file in your build directory)."
#endif

struct port_padding {
	const char *name;
	unsigned padding;	// number of bits of padding
};

struct packed_wavefield {
	const char *stream_name;
	const char *substream_name;
};

struct packed_to_derivable_resource {
	const unsigned num_packed;
	const struct maxlib_derivable_resource resource;
};

struct string_to_derivable_resource {
	const char* name;
	const struct maxlib_derivable_resource resource;
};


max_maxfile_t* maxlib_init_get_maxfile(void) {
    return CONCAT(max_maxfile_init_, DESIGN_NAME)();
}

#define FDCOMPILER_EARTH_MODEL_TABLE(name, size, param, expr)
#define FDCOMPILER_WAVE_FIELD_PACKING(input, sub_input)
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTH_MODEL_TABLE
#undef FDCOMPILER_WAVE_FIELD_PACKING



static const struct maxlib_config design_config = {
#define	FDCOMPILER_CONFIG(pipes, tile_w, tile_h, axis_x, axis_y, axis_z, block_min_width, block_min_height, block_max_width, block_max_height) \
	.num_pipes = pipes, \
	.tile_width = tile_w, \
	.tile_height = tile_h, \
	.axes_xyz = { axis_x, axis_y, axis_z }, \
	.block_size_min = { block_min_width, block_min_height }, \
	.block_size_max = { block_max_width, block_max_height }
#include STRING(MAXFILE)
#undef FDCOMPILER_CONFIG
};





const struct maxlib_config *
maxlib_init_get_config(void) { return &design_config; }



size_t maxlib_init_get_num_host_scaled_constants(void) {
	return 0
			#define FDCOMPILER_CONSTANTS(x, y, z, sg) + 1
			#include STRING(MAXFILE)
			#undef FDCOMPILER_CONSTANTS
	;
}

const char* maxlib_init_get_host_scaled_constant_name (size_t index) {
	const char* constant_names[] = {
			#define FDCOMPILER_CONSTANTS(register_name, x, y, sg) #register_name,
			#include STRING(MAXFILE)
			#undef FDCOMPILER_CONSTANTS
	};
	return constant_names[index];
}

float maxlib_init_get_host_scaled_constant_value (size_t index) {
	const float float_values[] = {
			#define FDCOMPILER_CONSTANTS(x, double_value, y, sg) double_value,
			#include STRING(MAXFILE)
			#undef FDCOMPILER_CONSTANTS
	};
	return float_values[index];
}

HWType maxlib_init_get_host_scaled_constant_type (size_t index) {
	size_t i = 0;
	#define FDCOMPILER_CONSTANTS(x, y, type, sg) if (index == i++) return type;
	#include STRING(MAXFILE)
	#undef FDCOMPILER_CONSTANTS
	abort();
}

unsigned maxlib_init_get_host_scaled_constant_group (size_t index) {
	size_t i = 0;
	#define FDCOMPILER_CONSTANTS(x, y, z, sg) if (index == i++) return sg;
	#include STRING(MAXFILE)
	#undef FDCOMPILER_CONSTANTS
	abort();
}

static const char **em_param_names;

struct maxlib_earthmodel_field* maxlib_init_get_earthmodel_dram_fields(void) {
	struct maxlib_earthmodel_field *fields = malloc(maxlib_init_get_n_earthmodel_dram_fields() * sizeof *fields);
	size_t i = 0;

#define FDCOMPILER_EARTH_MODEL_RAM(field_name, field_compute_type, field_store_type, field_block_size, field_param, field_expr) \
	fields[i].name = #field_name; \
	fields[i].param_name = #field_param; \
	fields[i].compute_type = field_compute_type; \
	fields[i].store_type = field_store_type; \
	fields[i].block_size = field_block_size; \
	++i;
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTH_MODEL_RAM

	return fields;
}



const char **maxlib_init_get_earthmodel_params(void) {
	em_param_names = malloc(maxlib_init_get_n_earthmodel_dram_fields() * sizeof(char*));
	size_t i = 0;

#define FDCOMPILER_EARTH_MODEL_RAM(field_name, field_compute_type, field_store_type, field_block_size, field_param, field_expr) \
	em_param_names[i] = #field_name; \
	++i;
#undef FDCOMPILER_EARTH_MODEL_RAM
	return em_param_names;

}
size_t maxlib_init_get_n_earthmodel_dram_fields(void) {
	size_t num_fields = 0;
#define FDCOMPILER_EARTH_MODEL_RAM(name, compute_type, store_type, block_size, param, expr) ++num_fields;
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTH_MODEL_RAM
	return num_fields;
}



static const struct maxlib_earthmodel_table em_tables[] = {
#define FDCOMPILER_EARTH_MODEL_TABLE(table_name, table_size, table_param, table_expr) \
    { #table_name, #table_param, table_size },
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTH_MODEL_TABLE
};

size_t maxlib_init_get_n_earthmodel_tables(void) { return sizeof em_tables / sizeof em_tables[0]; }

const struct maxlib_earthmodel_table *maxlib_init_get_earthmodel_tables(void) { return em_tables; }

HWType
maxlib_init_get_wavefield_type(void)
{
#define FDCOMPILER_WAVE_FIELD_TYPE(type) return type;
#include STRING(MAXFILE)
#undef FDCOMPILER_WAVE_FIELD_TYPE
	fprintf(stderr, "Error: No wavefield type in MaxFile\n");
	fflush(stderr);
	abort();
}



static const char *enable_names[] = {
#define FDCOMPILER_ENABLE_NAMES(name)	#name,
#include STRING(MAXFILE)
#undef FDCOMPILER_ENABLE_NAMES
};

size_t maxlib_init_get_n_enable_names(void) { return sizeof enable_names / sizeof enable_names[0]; }

const char **maxlib_init_get_enable_names(void) { return enable_names; }



int
maxlib_init_get_dram_region(const char *name)
{
#define FDCOMPILER_DRAM_REGIONS(region_name, halo) if (strcmp(name, #region_name) == 0) return halo;
#include STRING(MAXFILE)
#undef FDCOMPILER_DRAM_REGIONS
	return -1;
}


static const struct packed_wavefield packed_wavefields[] = {
#define FDCOMPILER_WAVE_FIELD_PACKING(stream, substream) { .stream_name = #stream, .substream_name = #substream },
#include STRING(MAXFILE)
#undef FDCOMPILER_WAVE_FIELD_PACKING
};




size_t
maxlib_init_get_n_packed_wavefields(void)
{
	const size_t n = sizeof packed_wavefields / sizeof packed_wavefields[0];
	const char *last_stream_name = NULL;

	size_t num_wavefields = 0;
	for (size_t i = 0; i < n; ++i) {
		if (packed_wavefields[i].stream_name != last_stream_name)
			++num_wavefields;
		last_stream_name = packed_wavefields[i].stream_name;
	}

	return num_wavefields;
}



const char ***
maxlib_init_get_packed_wavefields(void)
{
	const size_t n_packed_wavefields = sizeof packed_wavefields / sizeof packed_wavefields[0];

	if (n_packed_wavefields == 0)
		return NULL;

	const char*** wavefields = malloc(n_packed_wavefields * sizeof(char**));

	// allocate arrays
	const char *last_stream_name = packed_wavefields[0].stream_name;
	size_t curr_input = 0;
	size_t num_substreams = 0;
	for (size_t i = 0; i < n_packed_wavefields; ++i) {
		const char *input = packed_wavefields[i].stream_name;

		// yes, we can do pointer equality in this case
		if (input == last_stream_name) {
			++num_substreams;
			continue;
		}

		// +2 because the array looks like this:
		// [input, subinput1, subinput2, NULL]
		wavefields[curr_input] = malloc((num_substreams + 2) * sizeof(char **));
		wavefields[curr_input][0] = last_stream_name;
		wavefields[curr_input][num_substreams + 1] = NULL;
		last_stream_name = input;
		num_substreams = 1;
		++curr_input;
	}

	// handle last input
	wavefields[curr_input] = malloc((num_substreams + 2) * sizeof(char **));
	wavefields[curr_input][0] = last_stream_name;
	wavefields[curr_input][num_substreams + 1] = NULL;

	// fill in the arrays
	last_stream_name = packed_wavefields[0].stream_name;
	curr_input = 0;
	num_substreams = 0;
	for (size_t i = 0; i < n_packed_wavefields; ++i) {
		// yes, we can do pointer equality in this case
		const char *input = packed_wavefields[i].stream_name;
		if (input != last_stream_name) {
			num_substreams = 0;
			last_stream_name = input;
			++curr_input;
		}

		// +1 because the array starts with the 'packed' input name
		wavefields[curr_input][num_substreams + 1] = packed_wavefields[i].substream_name;
		++num_substreams;
	}

	return wavefields;
}

HWType maxlib_init_get_output_type(const char* name) {
    #define FDCOMPILER_WAVE_FIELD_OUTPUT_TYPES(output_name, type) if(strcmp(name, #output_name) == 0) return type;
    #include STRING(MAXFILE)
    #undef FDCOMPILER_WAVE_FIELD_OUTPUT_TYPES
    fprintf(stderr, "Error: No such output '%s'\n", name);
    abort();
}

HWType maxlib_init_get_input_type(const char* name) {
    #define FDCOMPILER_WAVE_FIELD_INPUT_TYPES(input_name, type) if(strcmp(name, #input_name) == 0) return type;
    #define FDCOMPILER_HOST_INPUT_TYPES(input_name, type) if(strcmp(name, #input_name) == 0) return type;
    #include STRING(MAXFILE)
    #undef FDCOMPILER_WAVE_FIELD_INPUT_TYPES
    #undef FDCOMPILER_HOST_INPUT_TYPES
    fprintf(stderr, "Error: No such input '%s'\n", name);
    abort();
}



static const char *inputs[] = {
#define FDCOMPILER_INPUTS(name, padding)	#name,
#include STRING(MAXFILE)
#undef FDCOMPILER_INPUTS
};

static const unsigned input_padding[] = {
#define FDCOMPILER_INPUTS(name, padding)	padding,
#include STRING(MAXFILE)
#undef FDCOMPILER_INPUTS
};



size_t
maxlib_init_get_num_inputs(void) { return sizeof inputs / sizeof inputs[0]; }



const char **
maxlib_init_get_inputs(void) { return inputs; }



int
maxlib_init_get_input_padding(const char *name)
{
	const size_t num_inputs = maxlib_init_get_num_inputs();
	for (size_t i = 0; i < num_inputs; ++i) {
		if (strcmp(name, inputs[i]) == 0)
			return input_padding[i];
	}

	return -1;
}



bool
maxlib_init_is_input(const char *name)
{
	size_t num_inputs = maxlib_init_get_num_inputs();
	for (size_t i = 0; i < num_inputs; ++i) {
		if (strcmp(name, inputs[i]) == 0)
			return true;
	}

	return false;
}



unsigned maxlib_init_num_scalar_inputs () {
#define FDCOMPILER_NUM_SCALAR_INPUTS(num) return num;
#include STRING(MAXFILE)
#undef FDCOMPILER_NUM_SCALAR_INPUTS
	fprintf(stderr, "Error: Number of scalar inputs not found.\n");
	abort();
}



static HWType get_scalar_input_dynamic_type (const char* base_name) {
#define FDCOMPILER_SCALAR_INPUT_DYNAMIC_TYPES(base, type) if (strcmp(#base, base_name) == 0) return type;
#include STRING(MAXFILE)
#undef FDCOMPILER_SCALAR_INPUT_DYNAMIC_TYPES

	fprintf(stderr, "Internal Error: Attempted to retrieve non-existent scalar input type.\n");
	abort();
}



void maxlib_init_scalar_inputs (struct maxlib_scalar_input* scalar_inputs) {
	int i = 0;

#define FDCOMPILER_FIXED_POINT_SCALAR_INPUTS(base, fixed, dynamic, maximum, sg) \
	scalar_inputs[i].base_name = #base; \
	scalar_inputs[i].fixed_name = fixed; \
	scalar_inputs[i].dynamic_name = dynamic; \
	scalar_inputs[i].set = false; \
	scalar_inputs[i].internal = true; \
	if (dynamic != NULL) \
		scalar_inputs[i].dynamic_type = get_scalar_input_dynamic_type(#base); \
	scalar_inputs[i].max = maximum; \
	scalar_inputs[i].scale_group = sg; \
	i++;
#include STRING(MAXFILE)
#undef FDCOMPILER_FIXED_POINT_SCALAR_INPUTS

#define FDCOMPILER_FLOATING_POINT_SCALAR_INPUTS(base) \
	scalar_inputs[i].base_name = #base; \
	scalar_inputs[i].fixed_name = #base; \
	scalar_inputs[i].dynamic_name = NULL; \
	scalar_inputs[i].set = false; \
	scalar_inputs[i].internal = false; \
	scalar_inputs[i].max = NAN; \
	scalar_inputs[i].scale_group = 0; \
	i++;
#include STRING(MAXFILE)
#undef FDCOMPILER_FLOATING_POINT_SCALAR_INPUTS

	if (i != maxlib_init_num_scalar_inputs()) {
		fprintf(stderr, "Internal Error: The number of scalar inputs found does not match the number expected.\n");
		abort();
	}
}



int
maxlib_init_mapped_rom_max(const char* name, float* max, int* is_unsigned) {
#define FDCOMPILER_MAPPED_ROM_MAXES(rom_name, rom_max, rom_unsigned) \
	if (strcmp(name, #rom_name) == 0) { \
		*max = rom_max; \
		*is_unsigned = rom_unsigned; \
		return 0; \
	}
#include STRING(MAXFILE)
#undef FDCOMPILER_MAPPED_ROM_MAXES
	return 1;
}



HWType maxlib_init_get_default_type() {
#define FDCOMPILER_DEFAULT_TYPE(type) return type;
#include STRING(MAXFILE)
#undef FDCOMPILER_DEFAULT_TYPE
	fprintf(stderr, "Internal error: default type not found.\n");
	abort();
}



static const char *outputs[] = {
#define FDCOMPILER_OUTPUTS(name, padding)	#name,
#include STRING(MAXFILE)
#undef FDCOMPILER_OUTPUTS
};

static const unsigned output_padding[] = {
#define FDCOMPILER_OUTPUTS(name, padding)	padding,
#include STRING(MAXFILE)
#undef FDCOMPILER_OUTPUTS
};





size_t
maxlib_init_get_num_outputs(void) { return sizeof outputs / sizeof outputs[0]; }



const char **
maxlib_init_get_outputs(void) { return outputs; }


int
maxlib_init_get_output_padding(const char *name)
{
	const size_t num_outputs = maxlib_init_get_num_outputs();
	for (size_t i = 0; i < num_outputs; ++i) {
		if (strcmp(name, outputs[i]) == 0)
			return output_padding[i];
	}

	return -1;
}



bool
maxlib_init_is_output(const char *name)
{
	const size_t num_outputs = maxlib_init_get_num_outputs();
	for (size_t i = 0; i < num_outputs; ++i) {
		if (strcmp(name, outputs[i]) == 0)
			return true;
	}

	return false;
}


static const char *user_inputs[] = {
#define FDCOMPILER_USER_INPUTS(name)	#name,
#include STRING(MAXFILE)
#undef FDCOMPILER_USER_INPUTS
};

size_t maxlib_init_get_n_user_inputs(void) { return sizeof user_inputs / sizeof user_inputs[0]; }

const char **maxlib_init_get_user_inputs(void) { return user_inputs; }


static const char *user_outputs[] = {
#define FDCOMPILER_USER_OUTPUTS(name)	#name,
#include STRING(MAXFILE)
#undef FDCOMPILER_USER_OUTPUTS
};

size_t maxlib_init_get_n_user_outputs(void) { return sizeof user_outputs / sizeof user_outputs[0]; }

const char **maxlib_init_get_user_outputs(void) { return user_outputs; }

float
maxlib_init_earthmodel_evaluate_field_by_index(unsigned field_index, float param_value)
{
	unsigned index = 0;
#define MAXLIB_DERIVED(expr) return expr
#define MAXLIB_COMPRESSED abort()
#define MAXLIB_GET(param_name)	(param_value)
#define FDCOMPILER_EARTH_MODEL_RAM(field_name, field_compute_type, field_store_type, field_block_size, field_param_name, field_expr) \
	if (field_index == index++) field_expr;
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTH_MODEL_RAM
#undef MAXLIB_GET
#undef MAXLIB_COMPRESSED
#undef MAXLIB_DERIVED

	abort();
}


float
maxlib_init_earthmodel_evaluate_table(const char *name, float param_value)
{
#define MAXLIB_GET(param_name)	(param_value)
#define FDCOMPILER_EARTH_MODEL_TABLE(table_name, table_size, table_param, table_expr) \
	if (strcmp(name, #table_name) == 0) return table_expr;
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTH_MODEL_TABLE
#undef MAXLIB_GET

	abort();
}



struct wavefield_loader_saver {
	unsigned group_size;
	const char *stream_name;
};

static const struct wavefield_loader_saver wavefield_loader_outputs[] = {
#define FDCOMPILER_WAVEFIELD_LOADER_OUTPUTS(size, name) { .group_size = size, .stream_name = #name },
#include STRING(MAXFILE)
#undef FDCOMPILER_WAVEFIELD_LOADER_OUTPUTS
};



size_t
maxlib_init_num_wavefield_loader_outputs(void)
{
	return sizeof wavefield_loader_outputs / sizeof wavefield_loader_outputs[0];
}



const char *
maxlib_init_get_wavefield_loader_output(unsigned group_size)
{
	const size_t n = maxlib_init_num_wavefield_loader_outputs();
	
	for (size_t i = 0; i < n; ++i) {
		if (wavefield_loader_outputs[i].group_size == group_size)
			return wavefield_loader_outputs[i].stream_name;
	}

	return NULL;
}



const char *
maxlib_init_get_wavefield_loader_output_at_index(size_t index)
{
	return wavefield_loader_outputs[index].stream_name;
}



static const struct wavefield_loader_saver wavefield_saver_inputs[] = {
#define FDCOMPILER_WAVEFIELD_SAVER_INPUTS(size, name) { .group_size = size, .stream_name = #name },
#include STRING(MAXFILE)
#undef FDCOMPILER_WAVEFIELD_SAVER_INPUTS
};



size_t
maxlib_init_num_wavefield_saver_inputs(void)
{
	return sizeof wavefield_saver_inputs / sizeof wavefield_saver_inputs[0];
}



const char *
maxlib_init_get_wavefield_saver_input(unsigned group_size)
{
	const size_t n = maxlib_init_num_wavefield_saver_inputs();

	for (size_t i = 0; i < n; ++i) {
		if (wavefield_saver_inputs[i].group_size == group_size)
			return wavefield_saver_inputs[i].stream_name;
	}

	return NULL;
}



const char *
maxlib_init_get_wavefield_saver_input_at_index(size_t index)
{
	return wavefield_saver_inputs[index].stream_name;
}



unsigned
maxlib_init_get_earthmodel_loader_width(void)
{
#define FDCOMPILER_EARTHMODEL_LOADER_WIDTH(width) return width;
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTHMODEL_LOADER_WIDTH

	return 0;
}



static const struct maxlib_board_info board_info = {
#define FDCOMPILER_BOARD_INFO(has_compute_ifpga, has_maxring_ab, pcie_width, mem_size) \
	has_compute_ifpga, has_maxring_ab, pcie_width, mem_size,
#include STRING(MAXFILE)
#undef FDCOMPILER_BOARD_INFO

#define MANAGER_MEMCTL(mem_type, something, burst_size) \
	#mem_type, burst_size * 8
#include STRING(MAXFILE)
#undef MANAGER_MEMCTL
};

const struct maxlib_board_info *
maxlib_init_get_board_info(void)
{
	return &board_info;
}



static const struct maxlib_parity_check parity_checks[] = {
#define FDCOMPILER_PARITY_CHECK(id, interfpga_a, interfpga_b, pcie) {.name = #id, {1, (interfpga_a), (interfpga_b), (pcie)}},
#include STRING(MAXFILE)
#undef FDCOMPILER_PARITY_CHECK
};

size_t maxlib_init_get_num_parity_checks(void) { return sizeof parity_checks / sizeof parity_checks[0]; }

const struct maxlib_parity_check *maxlib_init_get_parity_check_names(void) { return parity_checks; }

bool maxlib_init_port_uses_implicit_type_conversion(const char* name) {
#define FDCOMPILER_INTERNAL_FORMAT_IO(port_name) \
	if (strcmp(#port_name, name) == 0) \
		return false;
#include STRING(MAXFILE)
#undef FDCOMPILER_INTERNAL_FORMAT_IO
	return true;
}


int maxlib_init_get_user_param (const char* name, int* value) {
#define FDCOMPILER_USER_PARAM(key, contents) if (strcmp(#key, name) == 0) { *value = contents; return 0; }
#include STRING(MAXFILE)
#undef FDCOMPILER_USER_PARAM
	return 1;
}


int maxlib_init_is_simulation() {
#define FDCOMPILER_IS_SIMULATION(is_simulation) return is_simulation;
#include STRING(MAXFILE)
#undef FDCOMPILER_IS_SIMULATION
	abort();
}


float maxlib_init_earthmodel_param_max (const char* param_name) {
#define FDCOMPILER_EARTHMODEL_MAXES(name, max) if (strcmp((#name), param_name) == 0) return (max) < 0 ? -(max) : (max);
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTHMODEL_MAXES
	return 0;
}


unsigned maxlib_init_get_halo (const char* name) {
#define FDCOMPILER_HALOS(field_name, halo) if (strcmp(name, #field_name) == 0) return halo;
#include STRING(MAXFILE)
#undef FDCOMPILER_HALOS
	fprintf(stderr, "Error: the field '%s' does not exist", name);
	abort();
}


unsigned maxlib_init_max_halo (void) {
	unsigned max_halo = 0;
#define FDCOMPILER_HALOS(field_name, halo) if (halo > max_halo) max_halo = halo;
#include STRING(MAXFILE)
#undef FDCOMPILER_HALOS
	return max_halo;
}

static const char *controlled_output_names[] = {
#define FDCOMPILER_CONTROLLED_OUTPUTS(output_name) #output_name,
#include STRING(MAXFILE)
#undef FDCOMPILER_CONTROLLED_OUTPUTS
};

size_t maxlib_init_num_controlled_outputs (void) {
	return sizeof controlled_output_names / sizeof controlled_output_names[0];
}

const char** maxlib_init_get_controlled_output_names (void) {
	return controlled_output_names;
}

int maxlib_init_get_pcie_swap_padding(int num_packed_wavefields) {
#define FDCOMPILER_PCIE_SWAP_PADDING(n, padding) if ((n) == num_packed_wavefields) return (padding);
#include STRING(MAXFILE)
#undef FDCOMPILER_PCIE_SWAP_PADDING
	return 0;
}

int maxlib_init_swap_port_shift(const char* name, enum maxlib_swap_port port, bool is_input) {
#define MAXRING_MAX2_IN      0
#define MAXRING_A_IN         1
#define MAXRING_B_IN         2
#define IFPGA_IN             3
#define PCIE_IN              4
#define MAXRING_MAX2_OUT     5
#define MAXRING_A_OUT        6
#define MAXRING_B_OUT        7
#define IFPGA_OUT            8
#define PCIE_OUT             9

	int a = -1;
	switch (port) {
	case SWAP_PORT_MAXRING_MAX2:
		a = is_input ? MAXRING_MAX2_IN : MAXRING_MAX2_OUT;
		break;
	case SWAP_PORT_MAXRING_A:
		a = is_input ? MAXRING_A_IN : MAXRING_A_OUT;
		break;
	case SWAP_PORT_MAXRING_B:
		a = is_input ? MAXRING_B_IN : MAXRING_B_OUT;
		break;
	case SWAP_PORT_IFPGA:
		a = is_input ? IFPGA_IN : IFPGA_OUT;
		break;
	case SWAP_PORT_PCIE:
		a = is_input ? PCIE_IN : PCIE_OUT;
		break;
	case SWAP_PORT_EXTERNAL:
	case SWAP_PORT_NONE:
	default:
		abort();
	}

#define FDCOMPILER_SWAP_ENABLES(fdname, fdport, fdindex) \
	if ((fdport) == a && strcmp(#fdname, name) == 0) \
		return (fdindex);
#include STRING(MAXFILE)
#undef FDCOMPILER_SWAP_ENABLES

	abort();

#undef MAXRING_MAX2_IN
#undef MAXRING_A_IN
#undef MAXRING_B_IN
#undef IFPGA_IN
#undef PCIE_IN
#undef MAXRING_MAX2_OUT
#undef MAXRING_A_OUT
#undef MAXRING_B_OUT
#undef IFPGA_OUT
#undef PCIE_OUT
}


static const char *memory_streams[] = {
#define MEMCTRLPRO_STREAM(name, id, direction)	#name,
#include STRING(MAXFILE)
#undef MEMCTRLPRO_STREAM
};

unsigned maxlib_init_compressed_block_width (void) {
#define FDCOMPILER_COMPRESSED_BLOCK(width) \
	return width;
#include STRING(MAXFILE)
#undef FDCOMPILER_COMPRESSED_BLOCK
	return 0;
};

size_t maxlib_init_num_memory_streams(void) { return sizeof memory_streams / sizeof memory_streams[0]; }

const char **maxlib_init_get_memory_streams(void) { return memory_streams; }



static const unsigned dram_region_halos[] = {
#define FDCOMPILER_DRAM_REGIONS(region_name, halo) halo,
#include STRING(MAXFILE)
#undef FDCOMPILER_DRAM_REGIONS
};

size_t maxlib_init_num_dram_regions(void) { return sizeof dram_region_halos / sizeof dram_region_halos[0]; }

const unsigned *maxlib_init_get_dram_regions(void) { return dram_region_halos; }



static const unsigned swap_region_halos[] = {
#define FDCOMPILER_HALOS(name, halo) halo,
#include STRING(MAXFILE)
#undef FDCOMPILER_HALOS
};

static const char *swap_region_names[] = {
#define FDCOMPILER_HALOS(name, halo) #name,
#include STRING(MAXFILE)
#undef FDCOMPILER_HALOS
};

const char* maxlib_init_get_scale_shift_name() {
#define FDCOMPILER_SCALE_SHIFT_REGISTER(name) return #name;
#include STRING(MAXFILE)
#undef FDCOMPILER_SCALE_SHIFT_REGISTER
	return NULL;
}

size_t maxlib_init_num_swap_regions(void) { return sizeof swap_region_halos / sizeof swap_region_halos[0]; }

const unsigned *maxlib_init_get_swap_regions(void) { return swap_region_halos; }

const char *maxlib_init_get_swap_name(size_t index) { return swap_region_names[index]; }

//TODO optimise
unsigned maxlib_init_get_scale_group(const char* name) {
#define FDCOMPILER_SCALE_GROUP(n, id) if (strcmp(#n, name) == 0) return id;
#include STRING(MAXFILE)
#undef FDCOMPILER_SCALE_GROUP
	return 0;
}



int maxlib_init_get_custom_storage_type(const char* name, HWType* type, unsigned* padding) {
#define FDCOMPILER_CUSTOM_STORAGE_TYPE(n, t, p) if (strcmp(#n, name) == 0) { *type = t; *padding = p; return 0; }
#include STRING(MAXFILE)
#undef FDCOMPILER_CUSTOM_STORAGE_TYPE
	return 1;
}


unsigned maxlib_init_get_num_scale_groups() {
#define FDCOMPILER_NUM_SCALE_GROUPS(num) return num;
#include STRING(MAXFILE)
#undef FDCOMPILER_NUM_SCALE_GROUPS
}



unsigned maxlib_init_get_num_derived_scale_shifts() {
	unsigned num = 0;
#define FDCOMPILER_DERIVED_SCALE_SHIFT(id_to_check, expression) ++num;
#include STRING(MAXFILE)
#undef FDCOMPILER_DERIVED_SCALE_SHIFT
	return num;
}



int maxlib_init_get_derived_scale_shift(int* scale_shifts, int id, int* result) {
	switch (id) {
#define FDCOMPILER_DERIVED_SCALE_SHIFT(id_to_check, expression) case (id_to_check): *result = (expression); return 0;
#include STRING(MAXFILE)
#undef FDCOMPILER_DERIVED_SCALE_SHIFT
	// Error
	default: return 1;
	}
}



int maxlib_init_get_host_output_scale_group(const char* name) {
#define FDCOMPILER_HOST_OUTPUT_SCALE_GROUP(host_name, id) \
	if (strcmp(#host_name, name) == 0) \
		return id;
#include STRING(MAXFILE)
#undef FDCOMPILER_HOST_OUTPUT_SCALE_GROUP
	return -1;
}



const struct packed_to_derivable_resource wavefield_loader_inputs[] = {
#define FDCOMPILER_WAVEFIELD_LOADER_INPUTS(n, x_enable, x_name, x_reg_name, x_host_type) \
		{ n, { .enable = #x_enable, .name = #x_name, .reg_name = #x_reg_name, .host_type = x_host_type }},
#include STRING(MAXFILE)
#undef FDCOMPILER_WAVEFIELD_LOADER_INPUTS
};

const struct maxlib_derivable_resource* maxlib_init_get_wavefield_loader_input(int num_packed) {
	for (int i = 0; i < sizeof wavefield_loader_inputs / sizeof wavefield_loader_inputs[0]; ++i)
		if (wavefield_loader_inputs[i].num_packed == num_packed)
			return &wavefield_loader_inputs[i].resource;

	fprintf(stderr, "Internal error: unable to find loader input for %d packed wavefields.\n", num_packed);
	abort();
}



const struct packed_to_derivable_resource wavefield_saver_outputs[] = {
#define FDCOMPILER_WAVEFIELD_SAVER_OUTPUTS(n, x_enable, x_name, x_reg_name, x_host_type) \
		{ n, { .enable = #x_enable, .name = #x_name, .reg_name = #x_reg_name, .host_type = x_host_type }},
#include STRING(MAXFILE)
#undef FDCOMPILER_WAVEFIELD_SAVER_OUTPUTS
};

const struct maxlib_derivable_resource* maxlib_init_get_wavefield_saver_output(int num_packed) {
	for (int i = 0; i < sizeof wavefield_saver_outputs / sizeof wavefield_saver_outputs[0]; ++i)
		if (wavefield_saver_outputs[i].num_packed == num_packed)
			return &wavefield_saver_outputs[i].resource;

	fprintf(stderr, "Internal error: unable to find saver output for %d packed wavefields.\n", num_packed);
	abort();
}


const struct maxlib_derivable_resource earthmodel_loader_input[] = {
#define FDCOMPILER_EARTHMODEL_LOADER_INPUTS(x_enable, x_name, x_reg_name, x_host_type) \
	{ \
		.enable        = #x_enable, \
		.name          = #x_name, \
		.reg_name      = #x_reg_name, \
		.host_type = x_host_type \
	},
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTHMODEL_LOADER_INPUTS
};

const struct maxlib_derivable_resource* maxlib_init_get_earthmodel_loader_input() {
	if (sizeof earthmodel_loader_input == 0)
		return NULL;

	return &earthmodel_loader_input[0];
}

int maxlib_init_get_earthmodel_loader_output(const char** result) {
#define FDCOMPILER_EARTH_MODEL_LOADER_OUTPUT(name) *result = #name; return 0;
#include STRING(MAXFILE)
#undef FDCOMPILER_EARTH_MODEL_LOADER_OUTPUT
	return 1;
}

const struct string_to_derivable_resource custom_loader_inputs[] = {
#define FDCOMPILER_CUSTOM_LOADER_INPUT(x_array_name, x_enable, x_name, x_reg_name, x_host_type) \
	{ #x_array_name, { .enable = #x_enable, .name = #x_name, .reg_name = #x_reg_name, .host_type = x_host_type }},
#include STRING(MAXFILE)
#undef FDCOMPILER_CUSTOM_LOADER_INPUT
};

const struct string_to_derivable_resource custom_loader_outputs[] = {
#define FDCOMPILER_CUSTOM_LOADER_OUTPUT(x_array_name, x_enable, x_name, x_reg_name, x_host_type) \
	{ #x_array_name, { .enable = #x_enable, .name = #x_name, .reg_name = #x_reg_name, .host_type = x_host_type }},
#include STRING(MAXFILE)
#undef FDCOMPILER_CUSTOM_LOADER_OUTPUT
};

const struct string_to_derivable_resource custom_saver_inputs[] = {
#define FDCOMPILER_CUSTOM_SAVER_INPUT(x_array_name, x_enable, x_name, x_reg_name, x_host_type) \
	{ #x_array_name, { .enable = #x_enable, .name = #x_name, .reg_name = #x_reg_name, .host_type = x_host_type }},
#include STRING(MAXFILE)
#undef FDCOMPILER_CUSTOM_SAVER_INPUT
};

const struct string_to_derivable_resource const custom_saver_outputs[] = {
#define FDCOMPILER_CUSTOM_SAVER_OUTPUT(x_array_name, x_enable, x_name, x_reg_name, x_host_type) \
	{ #x_array_name, { .enable = #x_enable, .name = #x_name, .reg_name = #x_reg_name, .host_type = x_host_type }},
#include STRING(MAXFILE)
#undef FDCOMPILER_CUSTOM_SAVER_OUTPUT
};

#define NUMBEROF(x) const unsigned num_ ## x = sizeof x / sizeof (struct string_to_derivable_resource);
NUMBEROF(custom_loader_inputs)
NUMBEROF(custom_loader_outputs)
NUMBEROF(custom_saver_inputs)
NUMBEROF(custom_saver_outputs)
#undef NUMBEROF

const struct maxlib_derivable_resource* maxlib_init_get_custom_loader_input(const char* array_name) {
	for (unsigned i = 0; i < num_custom_loader_inputs; ++i)
		if (strcmp(array_name, custom_loader_inputs[i].name) == 0)
			return &custom_loader_inputs[i].resource;

	return NULL;
}

const struct maxlib_derivable_resource* maxlib_init_get_custom_loader_output(const char* array_name) {
	for (unsigned i = 0; i < num_custom_loader_outputs; ++i)
		if (strcmp(array_name, custom_loader_outputs[i].name) == 0)
			return &custom_loader_outputs[i].resource;

	return NULL;
}

const struct maxlib_derivable_resource* maxlib_init_get_custom_saver_input(const char* array_name) {
	for (unsigned i = 0; i < num_custom_saver_inputs; ++i)
		if (strcmp(array_name, custom_saver_inputs[i].name) == 0)
			return &custom_saver_inputs[i].resource;

	return NULL;
}

const struct maxlib_derivable_resource* maxlib_init_get_custom_saver_output(const char* array_name) {
	for (unsigned i = 0; i < num_custom_saver_outputs; ++i)
		if (strcmp(array_name, custom_saver_outputs[i].name) == 0)
			return &custom_saver_outputs[i].resource;

	return NULL;
}



int maxlib_init_get_wavefield_saver_shift(int num_packed) {
	switch (num_packed) {
#define FDCOMPILER_WAVEFIELD_SAVER_EXTRA_SHIFT(n, s) case (n): return (s);
#include STRING(MAXFILE)
#undef FDCOMPILER_WAVEFIELD_SAVER_EXTRA_SHIFT
	default: return 0;
	}
}


int
maxlib_init_cast(const char* name) {
	int i = -1;
#define FDCOMPILER_CASTS(n, t, s) ++i; if (strcmp(name, #n) == 0) return i;
#include STRING(MAXFILE)
#undef FDCOMPILER_CASTS
	return -1;
}



HWType maxlib_init_cast_type(int index) {
	HWType types[] = {
#define FDCOMPILER_CASTS(n, t, s) t,
#include STRING(MAXFILE)
#undef FDCOMPILER_CASTS
	};

	return types[index];
}



int maxlib_init_cast_scale_shift(int* scale_shifts, int id, int* result) {
	int i = 0;
#define FDCOMPILER_CASTS(n, t, expression) if (id == i++) { *result = (expression); return 0; }
#include STRING(MAXFILE)
#undef FDCOMPILER_CASTS
	// Error
	return 1;
}



int maxlib_init_get_num_scalar_outputs(void) {
	return 0
#define FDCOMPILER_SCALAR_OUTPUT(name, type) +1
#include STRING(MAXFILE)
#undef FDCOMPILER_SCALAR_OUTPUT
	;
}



int maxlib_init_get_scalar_output_index(const char* name) {
	int index = 0;
#define FDCOMPILER_SCALAR_OUTPUT(oname, otype) \
	if (strcmp(#oname, name) == 0) return index; ++index;
#include STRING(MAXFILE)
#undef FDCOMPILER_SCALAR_OUTPUT
	fprintf(stderr, "Error: Unable to find the scalar output '%s'", name);
	abort();
}



HWType maxlib_init_get_scalar_output_type(int index) {
	HWType array[] = {
#define FDCOMPILER_SCALAR_OUTPUT(oname, otype) \
	otype,
#include STRING(MAXFILE)
#undef FDCOMPILER_SCALAR_OUTPUT
	};

	return array[index];
}



const char* maxlib_init_get_scalar_output_name(int index) {
	const char* array[] = {
#define FDCOMPILER_SCALAR_OUTPUT(oname, otype) \
	#oname,
#include STRING(MAXFILE)
#undef FDCOMPILER_SCALAR_OUTPUT
	};

	return array[index];
}

bool maxlib_init_is_wavefield_tracking_supported(void) {
	bool s = false;
#define FDCOMPILER_SUPPORTS_WAVEFIELD_TRACKING(supported) s = (supported != 0);
#include STRING(MAXFILE)
#undef FDCOMPILER_SUPPORTS_WAVEFIELD_TRACKING
	return s;
}


