export MAXGENFDDIR="/network-raid/opt/maxgenfd-2012.1"
export PATH="$MAXGENFDDIR/bin:$PATH"
