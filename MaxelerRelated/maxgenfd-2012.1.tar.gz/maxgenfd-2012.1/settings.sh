install_dir="/network-raid/opt/maxgenfd-2012.1"
for s in "${install_dir}/settings.d/"*.sh; do
	source $s
done
