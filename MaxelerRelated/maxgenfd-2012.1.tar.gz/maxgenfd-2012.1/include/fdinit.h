/*********************************************************************
 * MaxGen FD Runtime Interface                                       *
 * Copyright (C) 2012 Maxeler Technologies                           *
 *                                                                   *
 * Version: 2012.1                                                   *
 * Date:    8th June 2012                                            *
 *                                                                   *
 *********************************************************************/

#ifndef MAXELER_MAXGENFD_FDINIT_H
#define MAXELER_MAXGENFD_FDINIT_H

#include <stdbool.h>
#include <stddef.h>

#include <MaxCompilerRT.h>

enum maxlib_swap_port {
	SWAP_PORT_NONE,
	SWAP_PORT_IFPGA,
	SWAP_PORT_MAXRING_MAX2,
	SWAP_PORT_MAXRING_A,
	SWAP_PORT_MAXRING_B,
	SWAP_PORT_PCIE,
	SWAP_PORT_EXTERNAL
};

struct maxlib_earthmodel_field {
	const char *name;
	const char *param_name;	// name of base parameter (same as 'name' for tables)
	HWType compute_type;	// type seen by the user (same as store_type if table compressed)
	HWType store_type;	// type stored in DRAM
	unsigned block_size;	// size of compression block (0 for no compression)
};

struct maxlib_earthmodel_table {
	const char *name;	// name of the input
	const char *param_name;	// name of base parameter
	size_t size;		// number of entries
};

struct maxlib_scalar_input {
	const char* base_name;
	const char* fixed_name;
	const char* dynamic_name;
	HWType dynamic_type; // will be uninitialized if dynamic_name == NULL
	double value;
	float max; // will be NAN if floating point
	bool set;
	bool internal;
	int scale_group;
};

struct maxlib_board_info {
	bool has_compute_ifpga;		// do we have an IFPGA link between compute FPGAs?
	bool has_maxring_ab;		// do we have 2 MaxRing links?
	unsigned pcie_size;		// width of PCIe port (in bytes)
	size_t mem_size;		// minimum memory supported (in bytes)
	const char *memory_type;	// type of memory controller
	unsigned burst_size;		// memory burst size (in bits)
};

struct maxlib_host_scaled_constant_entry {
	char* name;
	double value;
	HWType type;
};

struct maxlib_config {
	/** Number of pipes in the design. */
	unsigned num_pipes;
	/** Tile width. */
	unsigned tile_width;
	/** Tile height. */
	unsigned tile_height;
	/** Axis mapping from XYZ to slow, medium, fast. */
	unsigned axes_xyz[3];
	/** Minimum block width and height. */
	unsigned block_size_min[2];
	/** Maximum block width and height. */
	unsigned block_size_max[2];
};

struct maxlib_parity_check {
	const char* name;
	/*
	  index  Max2    Max3
	    0    DRAM    DRAM
	    1    IFPGA   MaxRing A
	    2    MaxRing MaxRing B
	    3    PCIe    PCIe
	*/
	bool parity[4];
};

struct maxlib_swap_port_shift {
	const char* name;
	int maxring_a;
	int maxring_b;
	int maxring_max2;
	int pcie;
	int ifpga;
};

struct maxlib_derivable_resource {
	const char* const enable;
	const char* const name;
	const char* const reg_name;
	const bool host_type;
};

max_maxfile_t* maxlib_init_get_maxfile(void);
size_t maxlib_init_get_n_earthmodel_params(void);

const char **maxlib_init_get_earthmodel_params(void);
const struct maxlib_config *maxlib_init_get_config(void);

float maxlib_init_earthmodel_param_max (const char* param_name);

size_t maxlib_init_get_n_earthmodel_dram_fields(void);
struct maxlib_earthmodel_field* maxlib_init_get_earthmodel_dram_fields(void);

size_t maxlib_init_get_n_earthmodel_tables(void);
const struct maxlib_earthmodel_table *maxlib_init_get_earthmodel_tables(void);

HWType maxlib_init_get_wavefield_type(void);

size_t maxlib_init_get_n_enable_names(void);
const char **maxlib_init_get_enable_names(void);

/* returns -1 on error */
int maxlib_init_get_dram_region(const char *name);

size_t maxlib_init_get_num_inputs(void);
const char **maxlib_init_get_inputs(void);
int maxlib_init_get_input_padding(const char *name);
bool maxlib_init_is_input(const char *name);

size_t maxlib_init_get_num_outputs(void);
const char **maxlib_init_get_outputs(void);
int maxlib_init_get_output_padding(const char *name);
bool maxlib_init_is_output(const char *name);

size_t maxlib_init_get_n_user_inputs(void);
const char **maxlib_init_get_user_inputs(void);
size_t maxlib_init_get_n_user_outputs(void);
const char **maxlib_init_get_user_outputs(void);

/**
 * \return The number of packed wavefield groups.
 */
size_t maxlib_init_get_n_packed_wavefields(void);

/**
 * This function returns an array of arrays of strings. The first array
 * length is the value returned by maxlib_init_get_n_packed_wavefields().
 * Each subarray is a variable length and terminated by NULL.
 * \return An array of array of strings.
 */
const char ***maxlib_init_get_packed_wavefields(void);

HWType maxlib_init_get_output_type(const char* name);
HWType maxlib_init_get_input_type(const char* name);

float maxlib_init_earthmodel_evaluate_field_by_index(unsigned field_index, float param_value);
float maxlib_init_earthmodel_evaluate_table(const char *name, float param_value);

size_t maxlib_init_num_wavefield_loader_outputs(void);
/**
 * \return NULL if a loader output for the specified group size could not be found.
 */
const char *maxlib_init_get_wavefield_loader_output(unsigned group_size);
const char *maxlib_init_get_wavefield_loader_output_at_index(size_t index);

size_t maxlib_init_num_wavefield_saver_inputs(void);
/**
 * \return NULL if a saver input for the specified group size could not be found.
 */
const char *maxlib_init_get_wavefield_saver_input(unsigned group_size);
const char *maxlib_init_get_wavefield_saver_input_at_index(size_t index);

unsigned maxlib_init_get_earthmodel_loader_width(void);

const struct maxlib_board_info *maxlib_init_get_board_info(void);

size_t maxlib_init_get_num_parity_checks(void);
const struct maxlib_parity_check *maxlib_init_get_parity_check_names(void);

size_t maxlib_init_get_num_host_scaled_constants(void);
const char* maxlib_init_get_host_scaled_constant_name(size_t index);
float maxlib_init_get_host_scaled_constant_value(size_t index);
HWType maxlib_init_get_host_scaled_constant_type(size_t index);
unsigned maxlib_init_get_host_scaled_constant_group(size_t index);


HWType maxlib_init_get_default_type();
unsigned maxlib_init_num_scalar_inputs();
void maxlib_init_scalar_inputs(struct maxlib_scalar_input* array);

bool maxlib_init_port_uses_implicit_type_conversion(const char* name);
int maxlib_init_get_user_param (const char* name, int *value);

int maxlib_init_is_simulation();

unsigned maxlib_init_get_halo(const char* name);
int maxlib_init_mapped_rom_max(const char* name, float* max, int* is_unsigned);

unsigned maxlib_init_max_halo (void);

size_t maxlib_init_num_controlled_outputs(void);
const char** maxlib_init_get_controlled_output_names(void);
int maxlib_init_get_pcie_swap_padding(int num_packed_wavefields);

int maxlib_init_swap_shift (const char* name, enum maxlib_swap_port port);
bool maxlib_init_parity_exists(const char* name, enum maxlib_swap_port port);
size_t maxlib_init_num_memory_streams(void);
const char **maxlib_init_get_memory_streams(void);

unsigned maxlib_init_compressed_block_width(void);

size_t maxlib_init_num_dram_regions(void);
const unsigned *maxlib_init_get_dram_regions(void);

size_t maxlib_init_num_swap_regions(void);
const unsigned *maxlib_init_get_swap_regions(void);
const char *maxlib_init_get_swap_name(size_t index);

int maxlib_init_swap_port_shift(const char* name, enum maxlib_swap_port port, bool is_input);
const char* maxlib_init_get_scale_shift_name();
unsigned maxlib_init_get_scale_group(const char* name);
unsigned maxlib_init_get_num_scale_groups();

int maxlib_init_get_custom_storage_type(const char* name, HWType *type, unsigned *padding);

unsigned maxlib_init_get_num_derived_scale_shifts();
int maxlib_init_get_derived_scale_shift(int* scale_shifts, int id, int* result);

const struct maxlib_derivable_resource* maxlib_init_get_wavefield_loader_input(int num_packed);
const struct maxlib_derivable_resource* maxlib_init_get_wavefield_saver_output(int num_packed);
const struct maxlib_derivable_resource* maxlib_init_get_earthmodel_loader_input();

int maxlib_init_get_earthmodel_loader_output(const char** result);

const struct maxlib_derivable_resource* maxlib_init_get_custom_loader_input(const char* array_name);
const struct maxlib_derivable_resource* maxlib_init_get_custom_loader_output(const char* array_name);
const struct maxlib_derivable_resource* maxlib_init_get_custom_saver_input(const char* array_name);
const struct maxlib_derivable_resource* maxlib_init_get_custom_saver_output(const char* array_name);

int maxlib_init_get_host_output_scale_group(const char* name);
int maxlib_init_get_wavefield_saver_shift(int num_packed);

int maxlib_init_cast(const char* name);
HWType maxlib_init_cast_type(int index);
int maxlib_init_cast_scale_shift(int* scale_shifts, int id, int* result);

int maxlib_init_get_num_scalar_outputs(void);
int maxlib_init_get_scalar_output_index(const char* name);
HWType maxlib_init_get_scalar_output_type(int index);
const char* maxlib_init_get_scalar_output_name(int index);


bool maxlib_init_is_wavefield_tracking_supported(void);

#endif // !defined(MAXELER_MAXGENFD_FDINIT_H)
