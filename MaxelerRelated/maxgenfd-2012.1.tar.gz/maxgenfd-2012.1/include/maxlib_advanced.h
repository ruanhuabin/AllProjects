/*********************************************************************
 * MaxGen FD Runtime Interface                                       *
 * Copyright (C) 2012 Maxeler Technologies                           *
 *                                                                   *
 * Version: 2012.1                                                   *
 * Date:    8th June 2012                                            *
 *                                                                   *
 *********************************************************************/

#ifndef MAXLIB_MAXGENFD_ADVANCED_H_
#define MAXLIB_MAXGENFD_ADVANCED_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <MaxCompilerRT.h>
#include <maxlib.h>

typedef struct maxlib_block_callback_data_t* maxlib_block_callback_data;

/**
 * \brief Handle to a session.
 */
typedef struct maxlib_session_t* maxlib_session;

/*
 * \brief Start/end of block callback function signature.
 *
 * \param data A pointer to a data structure containing useful information.  This data structure will no longer exist
 * once the callback returns.
 * \param user_data A pointer to data provided by the user when setting the callback.
 */
typedef void(*maxlib_block_callback)(maxlib_block_callback_data data, void* user_data);

/**
 * \brief This will open all devices.  The session will automatically close once all the
 * contexts attached to it have been closed.
 *
 * \return A handle to the open session.
 */
maxlib_session maxlib_open_session(void);

/**
 * \brief This will set up an independent context.
 *
 * \param session A handle to the open session.
 * \param global_region The region to use for boundary conditions.
 * \param local_region The region to compute.
 * \return A handle to the device context.
 */
maxlib_context maxlib_open_problem(maxlib_session session, maxlib_region global_region, maxlib_region local_region);

/**
 * \brief Close the current session and any remaining open contexts.
 *
 * \param session A handle to the open session.
 */
// void maxlib_close_session(maxlib_session session);

/**
 * \brief Get the number of devices currently open in a session.
 *
 * \param session The current session.
 * \param num A pointer to an integer which will be overwritten with the number of devices.
 */
void maxlib_devices_get_num(maxlib_session session, int* num);

/**
 * \brief Get handles to the open devices.
 *
 * \param session The current session.
 * \param device_handles A pointer to an array with enough space to hold pointers to all the device handles.
 * Use maxlib_devices_get_num() to get the number of devices.
 */
void maxlib_devices_get_handles(maxlib_session session, max_device_handle_t** device_handles);

/**
 * \brief Get a handle to the maxfile.
 *
 * \return Pointer to the maxfile.
 */
max_maxfile_t* maxlib_maxfile_get(void);

/**
 * \brief Set a callback to run after the completion of each block within a timestep.
 * For example the callback can be used to read scalar outputs that are reset after
 * each block is completed.
 *
 * \param context A handle to a device context.
 * \param callback The callback function.  Set to NULL to disable the callback.
 * \param user_data A pointer passed to the callback function whenever it is called.
 */
void maxlib_set_end_of_block_callback(maxlib_context context, maxlib_block_callback callback, void* user_data);

/**
 * \brief Set a callback to run before each block is run within a timestep before the device is
 * reset and the register cache committed.
 *
 * \param context A handle to a device context.
 * \param callback The callback function.  Set to NULL to disable the callback.
 * \param user_data A pointer passed to the callback function whenever it is called.
 */
void maxlib_set_start_of_block_callback(maxlib_context context, maxlib_block_callback callback, void* user_data);

/**
 * \brief Get the current context from the callback data.
 *
 * \param callback_data The callback data.
 * \param context Will contain a handle to the device context.
 */
void maxlib_callback_get_context(maxlib_block_callback_data callback_data, maxlib_context* context);

/**
 * \brief Get the current context from the callback data.
 *
 * \param callback_data The callback data.
 * \param index Will contain the device index.
 */
void maxlib_callback_get_device_index(maxlib_block_callback_data callback_data, int* index);

/**
 * \brief Get the current sub-region.
 *
 * \param callback_data The callback data.
 * \param region Will contain the sub-region.
 */
void maxlib_callback_get_region(maxlib_block_callback_data callback_data, maxlib_region* region);

void maxlib_callback_get_memory_setting(maxlib_block_callback_data callback_data, struct max_memory_setting** setting);

/**
 * Get the necessary parameters to setup a custom memory command.
 *
 * \param context A handle to the device context
 * \param array A handle to a pre-allocated on-card DRAM array.
 * \param region The region to work on (must be aligned to tiles).
 * \param device_index The device index obtained from the callback data.
 * \param bx
 * \param by
 * \param bz
 * \param sx
 * \param sy
 * \param sz
 * \param lx
 * \param ly
 * \param lz
 */
void maxlib_memory_get_blocking3d_parameters(
		maxlib_context context,
		maxlib_dram_array array,
		maxlib_region region,
		int device_index,
		int* bx, int* by, int* bz,
		int* sx, int* sy, int* sz,
		int* lx, int* ly, int* lz
);

/**
 * Get the start address for an array allocated in on-card DRAM.  (Note that this will be the same on
 * every device).
 *
 * \param array A handle to a pre-allocated on-card DRAM array.
 * \param start_address Will contain the start address (in bursts).
 */
void maxlib_memory_get_start_address (maxlib_dram_array array, unsigned int* start_address);

/**
 * Limit the region of DRAM written to.
 *
 * \param array Array to limit
 * \param region Tile aligned region to limit write to.
 */
void maxlib_limit_write(maxlib_dram_array array, maxlib_region region);

#ifdef __cplusplus
}
#endif

#endif /* MAXLIB_MAXGENFD_ADVANCED_H_ */
