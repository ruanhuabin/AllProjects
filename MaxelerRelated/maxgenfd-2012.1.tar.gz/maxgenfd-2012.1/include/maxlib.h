/*********************************************************************
 * MaxGen FD Runtime Interface                                       *
 * Copyright (C) 2012 Maxeler Technologies                           *
 *                                                                   *
 * Version: 2012.1                                                   *
 * Date:    8th June 2012                                            *
 *                                                                   *
 *********************************************************************/

#ifndef MAXELER_MAXGENFD_MAXLIB_H
#define MAXELER_MAXGENFD_MAXLIB_H

/** \file
 * MaxGenFD API: 2012.1
 */

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Boundary bit mask - represents the boundary where x = 0.
 */
#define MAXLIB_BOUNDARY_X0 0x01

/**
 * Boundary bit mask - represents the boundary where x = nx.
 */
#define MAXLIB_BOUNDARY_XN 0x02

/**
 * Boundary bit mask - represents the boundary where y = 0.
 */
#define MAXLIB_BOUNDARY_Y0 0x04

/**
 * Boundary bit mask - represents the boundary where y = ny.
 */
#define MAXLIB_BOUNDARY_YN 0x08

/**
 * Boundary bit mask - represents the boundary where z = 0.
 */
#define MAXLIB_BOUNDARY_Z0 0x10

/**
 * Boundary bit mask - represents the boundary where z = nz.
 */
#define MAXLIB_BOUNDARY_ZN 0x20

/**
 * Boundary bit mask - the equivalent to all of the boundaries OR'd together.
 */
#define MAXLIB_BOUNDARY_ALL 0x3f


/**
 * \brief Handle to a device context.
 */
typedef struct maxlib_context_t* maxlib_context;

/**
 * \brief Handle to earth model data.
 */
typedef struct maxlib_earthmodel_t* maxlib_earthmodel;

/**
 * \brief Handle to an on board DRAM array.
 */
typedef struct maxlib_dram_array_t* maxlib_dram_array;

/**
 * \brief Handle to an array of swap data
 */
typedef struct maxlib_swap_array_t* maxlib_swap_array;


/**
 * \brief Enum representing the X, Y and Z axes.
 */
typedef enum {
	AXIS_X,
	AXIS_Y,
	AXIS_Z
} maxlib_axis;

/**
 * Enum representing the different modes that exist for wavefield tracking.
 */
typedef enum {
	MAXLIB_TRACKING_OFF,
	MAXLIB_TRACKING_AUTO,
	MAXLIB_TRACKING_USER_ONLY
} maxlib_tracking_mode;

/**
 * \brief An axis-aligned cuboid which describes a three-dimensional volume.
 */
typedef struct {
	/** Start offset of the region in the X dimension. */
	int x_start;
	/** End offset of the region in the X dimension (i.e. x_start + x_size + 1). */
	int x_end;
	/** Start offset of the region in the Y dimension. */
	int y_start;
	/** End offset of the region in the Y dimension (i.e. y_start + y_size + 1). */
	int y_end;
	/** Start offset of the region in the Z dimension. */
	int z_start;
	/** End offset of the region in the Z dimension (i.e. z_start + z_size + 1). */
	int z_end;
} maxlib_region;

/**
 * \brief Swap callback definition.
 */
typedef void (*maxlib_swap_callback)(void *data, size_t num_bytes, const char* output_name, maxlib_region swap_sub_region, maxlib_region region, void* callback_data);

/**
 * \brief Open the accelerator device.
 *
 * \param nx The size of the X dimension in points.
 * \param ny The size of the Y dimension in points.
 * \param nz The size of the Z dimension in points.
 *
 * \return A handle to the device context.
 */
maxlib_context maxlib_open(int nx, int ny, int nz);

/**
 * \brief Release a device previously opened with maxlib_open().
 */
void maxlib_close(maxlib_context context);

/**
 * \brief Create a region with the specified bounds.
 */
maxlib_region maxlib_region_create(int x_start, int y_start, int z_start, int x_end, int y_end, int z_end);

/**
 * \brief Calculate the intersection of two regions.
 */
maxlib_region maxlib_region_intersection(maxlib_region a, maxlib_region b);

/**
 * \brief Get the number of elements inside a region.
 */
unsigned long maxlib_region_volume(maxlib_region region);

/**
 * \brief Round a region to tile boundaries.
 */
maxlib_region maxlib_region_round_to_tile_boundaries(maxlib_region region);

/**
 * \brief Allocate a wavefield array in on board DRAM.
 *
 * \param context The handle to the device context.
 */
maxlib_dram_array maxlib_dram_alloc_wavefield(maxlib_context context);

/**
 * \brief Allocate a packed wavefield array in on board DRAM.
 *
 * \param context The handle to the device context.
 * \param n_packed Number of packed wavefields in group.
 */
maxlib_dram_array maxlib_dram_alloc_packed_wavefield(maxlib_context context, int n_packed);

/**
 * \brief Allocate an image array in on board DRAM.
 *
 * \param context The handle to the device context.
 * \param array_name The name of the image array.
 */
maxlib_dram_array maxlib_dram_alloc_image(maxlib_context context, const char* array_name);

/**
 * \brief Allocate an earth model array in on board DRAM.
 *
 * \param context The handle to the device context.
 */
maxlib_dram_array maxlib_dram_alloc_earthmodel(maxlib_context context);

/**
 * \brief Load wavefield data into an array in on-board DRAM.
 *
 * \param context The handle to the device context.
 * \param array A handle to an array previously allocated with maxlib_dram_alloc_wavefield()
 * or maxlib_dram_alloc_packed_wavefield().
 * \param ... One or more arrays of float data. If the wavefield array was allocated via
 * maxlib_dram_alloc_wavefield() then there must be only 1 pointer. If the wavefield array
 * was allocated via maxlib_dram_alloc_packed_wavefield() then there must be one
 * pointer for each wavefield in the group.
 */

void maxlib_dram_load_wavefield(maxlib_context context, maxlib_dram_array array, ...);

/**
 * \brief Load zeros into an array in on-board DRAM.  This is an optimised version of maxlib_dram_load_wavefield.
 *
 * \param context The handle to the device context.
 * \param array A handle to an array previously allocated with maxlib_dram_alloc_wavefield()
 * or maxlib_dram_alloc_packed_wavefield().
 */
void maxlib_dram_load_wavefield_with_zeros(maxlib_context context, maxlib_dram_array array);

/**
 * \brief Load data into the array specified.
 *
 * \param context The handle to the device context.
 * \param array A handle to an array previously allocated with maxlib_dram_alloc_image()
 * \param data Float data to load the array with.
 */
void maxlib_dram_load_image(maxlib_context context, maxlib_dram_array array, const float* data);

/**
 * \brief Load earthmodel data into an array in on-board DRAM.
 *
 * \param context A handle to the device context.
 * \param array A handle to an array previously allocate with maxlib_dram_alloc_earthmodel().
 * \param em A handle to earthmodel data previously allocate via maxlib_earthmodel_create_in_memory()
 * (or similar functions).
 */
void maxlib_dram_load_earthmodel(maxlib_context context, maxlib_dram_array array, maxlib_earthmodel em);

/**
 * \brief Save wavefield data in on board DRAM to host memory.
 *
 * \param context The handle to the device context.
 * \param array A handle to an array previously allocated with maxlib_dram_alloc_wavefield()
 * or maxlib_dram_alloc_packed_wavefield().
 * \param ... One or more arrays of float data. If the wavefield array was allocated via
 * maxlib_dram_alloc_wavefield() then there must be only 1 pointer. If the wavefield array
 * was allocated via maxlib_dram_alloc_packed_wavefield() then there must be one
 * pointer for each wavefield in the group.
 */
void maxlib_dram_save_wavefield(maxlib_context context, maxlib_dram_array array, ...);

/**
 * \brief Save the data in an image array in on board DRAM to host memory.
 *
 * \param context The handle to the device context.
 * \param array A handle to an array previously allocated with maxlib_dram_alloc_image()
 * \param data An array of floating point data nx * ny * nz in size.
 */
void maxlib_dram_save_image(maxlib_context context, maxlib_dram_array array, float* data);

/**
 * \brief Stream data from DRAM to chip.
 *
 * \param context The handle to the device context.
 * \param input_name The name of the input to the kernel.
 * \param array The handle to the array to stream.
 */
void maxlib_stream_from_dram(maxlib_context context, const char *input_name, maxlib_dram_array array);

/**
 * \brief Stream the earth model from DRAM to chip.
 *
 * \param context The handle to the device context.
 * \param array The handle to an earth model array previuosly allocated via maxlib_dram_alloc_earthmodel().
 */
void maxlib_stream_earthmodel_from_dram(maxlib_context context, maxlib_dram_array array);

/**
 * \brief Stream data from chip to DRAM.
 *
 * \param context The handle to the device context.
 * \param output_name The name of the output from the kernel.
 * \param array The handle to the array to stream to.
 */
void maxlib_stream_to_dram(maxlib_context context, const char *output_name, maxlib_dram_array array);

/**
 * \brief Stream data from host to chip for a particular computation region.
 *
 * \param context The handle to the device context.
 * \param input_name The name of the input to the kernel.
 * \param data A pointer to the data to stream in.
 * \param x_start "x" coordinate of start of region (inclusive).
 * \param y_start "y" coordinate of start of region (inclusive).
 * \param z_start "z" coordinate of start of region (inclusive).
 * \param x_end "x" coordinate of end of region (exclusive).
 * \param y_end "y" coordinate of end of region (exclusive).
 * \param z_end "z" coordinate of end of region (exclusive).
 */
void maxlib_stream_region_from_host(maxlib_context context, const char *input_name, const float *data,
    int x_start, int y_start, int z_start, int x_end, int y_end, int z_end);

/**
 * \brief Stream data from chip to host for a particular computation region.
 *
 * \param context The handle to the device context.
 * \param output_name The name of the output from the kernel.
 * \param data A pointer to the location to stream the data to.
 * \param x_start "x" coordinate of start of region (inclusive).
 * \param y_start "y" coordinate of start of region (inclusive).
 * \param z_start "z" coordinate of start of region (inclusive).
 * \param x_end "x" coordinate of end of region (exclusive).
 * \param y_end "y" coordinate of end of region (exclusive).
 * \param z_end "z" coordinate of end of region (exclusive).
 */
void maxlib_stream_region_to_host(maxlib_context context, const char *output_name, float *data,
    int x_start, int y_start, int z_start, int x_end, int y_end, int z_end);

/**
 * \brief Set a scalar of unsigned integer type.
 *
 * \param context The handle to the device context.
 * \param name The name of the scalar in the kernel.
 * \param value The value to set.
 */
void maxlib_set_scalar_flag(maxlib_context context, const char* name, uint64_t value);

/**
 * \brief Set a scalar of floating or fixed point type.
 *
 * \param context The handle to the device context.
 * \param name The name of the scalar in the kernel.
 * \param value The value to set.
 */
void maxlib_set_scalar(maxlib_context context, const char* name, float value);

/**
 * \brief Read a scalar of integer or raw bit type.
 *
 * \param context The handle to the device context.
 * \param name The name of the scalar in the kernel.
 * \param device_index The index of the device to read from.
 * \return The value read.
 */
uint64_t maxlib_read_scalar(maxlib_context context, const char* name, int device_index);

/**
 * \brief Set a mapped memory element of integer or raw bit type.
 *
 * \param context The handle to the device context.
 * \param name The name of the memory in the kernel.
 * \param index The index within the mapped memory to set.
 * \param value The value to set.
 */
void maxlib_set_mapped_memory(maxlib_context context, const char* name, int index, int value);


/**
 * \brief Set a mapped memory element of floating or fixed point type.
 *
 * \param context The handle to the device context.
 * \param name The name of the memory in the kernel.
 * \param index The index within the mapped memory to set.
 * \param value The value to set.
 */
void maxlib_set_mapped_memory_f(maxlib_context context, const char* name, int index, float value);

/**
 * \brief Run the computation.
 *
 * This command must be run to execute and synchronize all stream commands.
 *
 * \param context The handle to the device context.
 */
void maxlib_run(maxlib_context context);

/**
 * \brief By default MaxGenFD will abort when it detects parity errors.
 * \param context The handle to the device context.
 * \param enable Set to 0 to disable this behaviour, 1 to re-enable.
 */
void maxlib_abort_on_parity_error(maxlib_context context, int enable);

/**
 * \brief Check for parity errors (note: this function will also clear the error state).
 * \param context The handle to the device context.
 * \return non-zero if errors detected.
 */
int maxlib_check_parity(maxlib_context context);

/**
 * \brief Set a global parameter (integer) for the next maxlib_open
 *
 * This will not affect currently open devices.
 *
 * \param name The name of the parameter;
 * \param value The value to set.
 *
 *  Available parameters:
 *      MAX_DEVICES                   Maximum number of chips to use. Default: 8
 *      FIRST_DEVICE                  First device to attempt to open. Default: 0
 *      DISABLE_MANUAL_SWAP_WARNINGS  Disable manual swap warnings.  Default: 0 (false)
 *      SAMPLE_SIZE...................Set the maximum sample size used for adaptive compression
*/
void maxlib_set_global_parameter(const char* name, int value);

/**
 * \brief Set a global parameter (string) for the next maxlib_open
 *
 * This will not affect currently open devices.
 *
 * \param name The name of the parameter;
 * \param value The value to set.
 *
 *  Available parameters:
 *      SIM_DEVICE      Custom device name for simulation (will not affect hardware). Default: sim0:sim
*/
void maxlib_set_global_parameter_str(const char* name, const char* value);

/**
 * \brief Set a scale factor for the computation.
 *
 * This is for debugging. Set > 1.0 to reduce overflow. Set < 1.0 to reduce underflow.
 *
 * \param context The handle to the device context.
 * \param scale_factor The scale factor.
 */
void maxlib_set_scale_factor(maxlib_context context, float scale_factor);

/**
 * \brief Print some useful status information.
 *
 * \param context The handle to the device context.
 */
void maxlib_print_status(maxlib_context context);

/**
 * \brief Start internal timers.
 *
 * \param context The handle to the device context.
 */
void maxlib_enable_timing(maxlib_context context);

/**
 * \brief Pause internal timers.
 *
 * \param context The handle to the device context.
 */
void maxlib_disable_timing(maxlib_context context);

/**
 * \brief Dump status of internal timers.
 *
 * \param context The handle to the device context.
 */
void maxlib_report_timing(maxlib_context context);

/**
 * \brief Determine if numeric exceptions are enabled in this bitstream.
 *
 * \param context A handle to a device context.
 * \return Returns 1 if exceptions are enabled in the bitstream, otherwise
 * returns 0.
 */
int maxlib_exceptions_enabled(maxlib_context context);

/**
 * \brief Determine if any numeric exceptions occurred during the previous
 * invocation of maxlib_run().
 *
 * Note that this function will generate a warning if numeric exceptions have
 * not been enabled in the bitstream. Use the maxlib_exceptions_enabled() function
 * to determine if numeric exceptions have been enabled.
 *
 * \param context A handle to a device context.
 * \return Returns 1 if exceptions occurred, otherwise returns 0.
 */
int maxlib_exceptions_occurred(maxlib_context context);

/**
 * \brief Generate a report about numeric exceptions that occurred during the
 * previous invocation of maxlib_run().
 *
 * Note that this function will generate a warning if numeric exceptions have
 * not been enabled in the bitstream. Use the maxlib_exceptions_enabled() function
 * to determine if numeric exceptions have been enabled.
 *
 * \param context A handle to a device context.
 * \param output_file A file to write the report to (e.g. stdout).
 */
void maxlib_exceptions_report(maxlib_context context, FILE *output_file);

/**
 * \brief Enable watch data generation.
 *
 * Watch data is only generated during simulation.
 *
 * \param context A handle to a device context.
 * \param dir_name Name of a directory to write watch data to. This directory
 * must exist before calling this function.
 */
void maxlib_watches_enable(maxlib_context context, const char *dir_name);

/**
 * \brief Disable watch data generation.
 *
 * \param context A handle to a device context.
 */
void maxlib_watches_disable(maxlib_context context);

/**
 * \brief Flush watch data to disk.
 *
 * You must have previously called maxlib_watches_enable() for the context.
 *
 * \param context A handle to a device context.
 */
void maxlib_watches_flush(maxlib_context context);

/**
 * \brief Create an earth model in memory.
 *
 * Note that this function will potentially allocate a large amount of memory
 * (i.e. proportional to nx * ny * nz). If an earth model is particularly large
 * then it may be more efficient to use the maxlib_earthmodel_create_file_backed()
 * function.
 *
 * \param nx The size of the earth model in the X dimension.
 * \param ny The size of the earth model in the Y dimension.
 * \param nz The size of the earth model in the Z dimension.
 */
maxlib_earthmodel maxlib_earthmodel_create_in_memory(int nx, int ny, int nz);

/**
 * \brief Create an earth model backed by a file.
 *
 * Note that calling maxlib_earthmodel_release() will not delete the backing file.
 *
 * \param nx The size of the earth model in the X dimension.
 * \param ny The size of the earth model in the Y dimension.
 * \param nz The size of the earth model in the Z dimension.
 * \param filename Name of a file that will store the earth model data.
 */
maxlib_earthmodel maxlib_earthmodel_create_file_backed(int nx, int ny, int nz, const char *filename);

/**
 * \brief Load earth model data from a file.
 *
 * \param filename The name of the file to load the earth model data from (as
 * previously created via maxlib_earthmodel_file_save()).
 * \return A file-backed earth model containing the contents of the specified
 * file.
 */
maxlib_earthmodel maxlib_earthmodel_file_load(const char *filename);

/**
 * \brief Save earth model data to a file.
 *
 * The data in the file may be loaded at a later time via the maxlib_earthmodel_file_load()
 * function.
 *
 * \param em A handle to earth model data.
 * \param filename The name of a file to save the data to.
 */
void maxlib_earthmodel_file_save(maxlib_earthmodel em, const char *filename);

/**
 * \brief Extract a sub-region of particular earth model.
 *
 * This function allows you to extract a specific sub-volume of a particular
 * earth model and work with it directly. For example, this may allow more
 * efficient handling of large data sets.
 *
 * Changes to the returned earth model handle will affect the underlying
 * earth model. If you want to make a separate copy of a particular sub-volume,
 * use the maxlib_earthmodel_copy_subregion_into_memory() function.
 *
 * \param em A handle to earth model data.
 * \param sub_region A sub-region to extract from the specified earth model. Note
 * that this region must be aligned to the earth model's tile size.
 * \return A new earth model handle which refers to a sub-region of an existing
 * earth model. Note that changes to this new earth model will affect the underlying
 * earth model. Once you have finished working with this earth model you should
 * free any resources it uses by calling the maxlib_earthmodel_release() function.
 */
maxlib_earthmodel maxlib_earthmodel_get_subregion(maxlib_earthmodel em, maxlib_region sub_region);

/**
 * \brief Create a copy of a sub-region of a particular earth model.
 *
 * This function creates a copy in memory of a specific sub-volume of a particular
 * earth model.
 *
 * Note that unlike the maxlib_earthmodel_get_subregion() function, changes to
 * the returned earth model do not affect the underlying earth model.
 *
 * \param em A handle to earth model data.
 * \param sub_region A sub-region to copy from the specified earth model. Note that
 * this region must be aligned to the earth model's tile size.
 * \return A new set of earth model data which is a copy of the specified sub-region.
 * Once you have finished working with this earth model you should free any resources
 * it uses by calling the maxlib_earthmodel_release() function.
 */
maxlib_earthmodel maxlib_earthmodel_copy_subregion_into_memory(maxlib_earthmodel em, maxlib_region sub_region);

/**
 * \brief Release resources (e.g. memory, file handles) associated with an
 * earth model.
 *
 * The maxlib_earthmodel handle is no longer valid after it has been passed to
 * maxlib_earthmodel_release().
 *
 * Note that if the earth model data is backed by a file (e.g. if it was created
 * via the maxlib_earthmodel_create_file_backed() or maxlib_earthmodel_file_load()
 * functions) this does not remove the file.
 *
 * \param em A handle to an earth model (for example, as returned by the
 * maxlib_earthmodel_create_in_memory(), maxlib_earthmodel_file_load() or similar functions).
 */
void maxlib_earthmodel_release(maxlib_earthmodel em);

/**
 * \brief Get the volume that a particular earth model represents.
 *
 * \param em A handle to an earth model.
 * \return The volume that the specified earth model represents.
 */
maxlib_region maxlib_earthmodel_get_region(maxlib_earthmodel em);

/**
 * \brief Get the length of a lookup table for a particular earth model parameter.
 *
 * \param em A handle to earth model data.
 * \param param_name The name of an earth model parameter.
 * \return If the specified earth model parameter uses table compression then
 * this returns the length of the lookup table (this will always be a power of 2).
 * If the specified parameter does not use table compression then 0 is returned.
 */
size_t maxlib_earthmodel_get_table_size(maxlib_earthmodel em, const char *param_name);

/**
 * \brief Get the tile size in the X, Y and Z dimensions for a particular earth model.
 *
 * \param em A handle to earth model data.
 * \param tile_size_x Points to an integer that will hold the tile size in the X
 * dimension when the function returns.
 * \param tile_size_y Points to an integer that will hold the tile size in the Y
 * dimension when the function returns.
 * \param tile_size_z Points to an integer that will hold the tile size in the Z
 * dimension when the function returns.
 */
void maxlib_earthmodel_get_tile_size(maxlib_earthmodel em, int* tile_size_x, int* tile_size_y, int* tile_size_z);

/**
 * \brief Set data to be used for a particular earth model parameter.
 *
 * The length of the data array must match the size of the region for the earth
 * model, i.e. the length of the array must equal maxlib_region_volume(maxlib_earthmodel_get_region(em)).
 *
 * \param em A handle to earth model data.
 * \param param_name Name of the earth model parameter.
 * \param data An array of data to be used for the specified earth model parameter.
 * The length of this array must match the size of the region for this earth model
 * (see notes above).
 */
void maxlib_earthmodel_set_data(maxlib_earthmodel em, const char *param_name, const float *data);

/**
 * \brief Use data from a file for a particular earth model parameter.
 *
 * The data file must contain IEEE-754 single-precision (32-bit) floating-point
 * data in little-endian format.
 *
 * This function is equivalent to maxlib_earthmodel_set_data() except that the data
 * is stored in the specified file.
 *
 * \param em A handle to earth model data.
 * \param param_name The name of an earth model parameter.
 * \param filename Name of the file containing floating-point data.
 */
void maxlib_earthmodel_set_data_from_file(maxlib_earthmodel em, const char *param_name, const char *filename);

/**
 * \brief Set the lookup table values for a particular earth model parameter.
 *
 * The length of the floating-point data array must be the same as the length
 * returned by the maxlib_earthmodel_get_table_size() function.
 *
 * Note that it is an error to call this function for an earth model field which
 * does not use table compression. If the maxlib_earthmodel_get_table_size()
 * function returns 0 then the specified field does not use table compression.
 *
 * \param em A handle to earth model data.
 * \param param_name The name of an earth model parameter.
 * \param table_values An array of floating-point data to use as the table values.
 */
void maxlib_earthmodel_set_table_values(maxlib_earthmodel em, const char *param_name, const float *table_values);

/**
 * \brief Set the lookup table indices for a particular earth model parameter.
 *
 * The length of the indices array must match the size of the region for the earth
 * model, i.e. the length of the array must equal maxlib_region_volume(maxlib_earthmodel_get_region(em)).
 *
 * \param em A handle to earth model data.
 * \param param_name The name of an earth model parameter.
 * \param table_indices An array of integers to use as the indices into the compression table.
 * The length of this array must match the size of the region for this earth model
 * (see notes above).
 */
void maxlib_earthmodel_set_table_indices(maxlib_earthmodel em, const char *param_name, const uint16_t *table_indices);

/**
 * \brief Generate a compression table using 'uniform' compression.
 *
 * The values written to 'table_values' are suitable for use with maxlib_earthmodel_set_table_values().
 * The values written to 'table_indices' are suitable for use with maxlib_earthmodel_set_table_indices().
 *
 * \param data An array of data to base the table on (must be at least data_len elements long).
 * \param data_len Number of elements in the data array.
 * \param table_values An array that will have the table values written to it (must be at least table_len elements long).
 * \param table_len Number of elements in the table_values array.
 * \param table_indices An array of that will have the table indices written to it (must be at least data_len elements long).
 */
void maxlib_table_compress_uniform(const float *data, size_t data_len, float *table_values, size_t table_len, uint16_t *table_indices);

/**
 * \brief Generate a compression table using a faster (but less accurate) version of 'uniform' compression.
 *
 * The values written to 'table_values' are suitable for use with maxlib_earthmodel_set_table_values().
 * The values written to 'table_indices' are suitable for use with maxlib_earthmodel_set_table_indices().
 *
 * \param data An array of data to base the table on (must be at least data_len elements long).
 * \param data_len Number of elements in the data array.
 * \param table_values An array that will have the table values written to it (must be at least table_len elements long).
 * \param table_len Number of elements in the table_values array.
 * \param table_indices An array of that will have the table indices written to it (must be at least data_len elements long).
 */
void maxlib_table_compress_uniform_fast(const float *data, size_t data_len, float *table_values, size_t table_len, uint16_t *table_indices);

/**
 * \brief Generate a compression table using 'adaptive' compression.
 *
 * The values written to 'table_values' are suitable for use with maxlib_earthmodel_set_table_values().
 * The values written to 'table_indices' are suitable for use with maxlib_earthmodel_set_table_indices().
 *
 * \param data An array of data to base the table on (must be at least data_len elements long).
 * \param data_len Number of elements in the data array.
 * \param table_values An array that will have the table values written to it (must be at least table_len elements long).
 * \param table_len Number of elements in the table_values array.
 * \param table_indices An array of that will have the table indices written to it (must be at least data_len elements long).
 */
void maxlib_table_compress_adaptive(const float *data, size_t data_len, float *table_values, size_t table_len, uint16_t *table_indices);

/**
* \brief Generate a compression table using 'adaptive' compression with the table values provided guaranteed to be present in the final
* table.
*
* The values written to 'table_values' are suitable for use with maxlib_earthmodel_set_table_values().
* The values written to 'table_indices' are suitable for use with maxlib_earthmodel_set_table_indices().
*
* \param data An array of data to base the table on (must be at least data_len elements long).
* \param data_len Number of elements in the data array.
* \param insert_values An array of values to include in the table·
* \param insert_len Number of elements in the insert_values array.
* \param table_values An array that will have the table values written to it (must be at least table_len elements long).
* \param table_len Number of elements in the table_values array.
* \param table_indices An array of that will have the table indices written to it (must be at least data_len elements long).
*/
void maxlib_table_compress_adaptive_with_values(const float *data, size_t data_len, const float *insert_values, size_t insert_len, float *table_values, size_t table_len, uint16_t *table_indices);

/**
 * \brief Stream the specified hollow cube from the host to the chip.
 *
 * \param context The handle to the device context.
 * \param input_name The name of the input to the kernel.
 * \param data A pointer to the data to stream in.
 * \param inner_cube The region to exclude.
 * \param outer_cube The region to include (excluding the inner_cube).
 */
void maxlib_stream_hollow_cube_from_host(maxlib_context context, const char* input_name,
		const void* data, const maxlib_region inner_cube, const maxlib_region outer_cube);

/**
 * \brief Stream the specified hollow cube from the chip to the host.
 *
 * \param context The handle to the device context.
 * \param output_name The name of the output from the kernel.
 * \param data A pointer to the location to stream the data to.
 * \param inner_cube The region to exclude.
 * \param outer_cube The region to include (excluding the inner_cube).
 */
void maxlib_stream_hollow_cube_to_host(maxlib_context context, const char* output_name,
		void* data, const maxlib_region inner_cube, const maxlib_region outer_cube);

/**
 * \brief Calculate the size required to store the specified hollow cube.
 *
 * \param context The handle to the device context.
 * \param name The name of the input/output from the kernel.
 * \param inner_cube The region to exclude.
 * \param outer_cube The region to include (excluding the inner_cube).
 *
 * \return The size required in bytes.
 */
size_t maxlib_hollow_cube_size(maxlib_context context, const char* name, const maxlib_region inner_cube,
		const maxlib_region outer_cube);

/**
 * \brief Get the value at the specified point within the given hollow cube data.
 *
 * \param hollow_cube_data Pointer to the floating point hollow cube data.
 * \param inner_cube The region to exclude.
 * \param outer_cube The region to include (excluding the inner_cube).
 * \param x The position in the X dimension.
 * \param y The position in the Y dimension.
 * \param z The position in the Z dimension.
 *
 * \return Value at the specified point.
 */
float maxlib_hollow_cube_get_value(const float *hollow_cube_data, maxlib_region inner_cube, maxlib_region outer_cube, int x, int y, int z);

/**
 * \brief Set the value at the specified point within the given hollow cube data.
 *
 * \param hollow_cube_data Pointer to the floating point hollow cube data.
 * \param inner_cube The region to exclude.
 * \param outer_cube The region to include (excluding the inner_cube).
 * \param x The position in the X dimension.
 * \param y The position in the Y dimension.
 * \param z The position in the Z dimension.
 * \param value The value to set the point in the hollow cube to.
 */
void maxlib_hollow_cube_set_value(float* hollow_cube_data, maxlib_region inner_cube, maxlib_region outer_cube, int x, int y, int z, float value);

/**
 * \brief Determine whether or not the program is running in simulation mode.
 *
 * \return Non-zero if running in simulation.
 */
int maxlib_is_simulation(void);

/**
 * \brief Get the value of a user specified parameter.
 *
 * Parameters may be specified in FDConfig.  Access them using this function.
 *
 * \param name The name of the parameter.
 * \param value Contains the value of the parameter upon successful completion.
 *
 * \return Zero if the parameter was obtained successfully, non-zero if the named
 * parameter does not exist.
 */
int maxlib_get_user_parameter(const char* name, int* value);

/**
 * \brief Get the tile size.
 *
 * \param tile_size_x Points to an integer that will hold the tile size in the X
 * dimension when the function returns.
 * \param tile_size_y Points to an integer that will hold the tile size in the Y
 * dimension when the function returns.
 * \param tile_size_z Points to an integer that will hold the tile size in the Z
 * dimension when the function returns.
 */
void maxlib_get_tile_size(int* tile_size_x, int* tile_size_y, int* tile_size_z);

/**
 * \brief Specify an output mask to use.  An output mask may only be set for a controlled host
 * output.  This function must be called before maxlib_run and the mask will be disabled once
 * maxlib_run returns.  The parameters rx, ry and rz must not be modified or deleted until
 * maxlib_run has returned.
 *
 * \param context A handle to a device context.
 * \param output_name The name of the controlled host output to mask.
 * \param rx An array of integers with the size matching the length of the X dimension
 * of the problem size, holding values of either 0 (discard the output) or 1(keep the output).
 * * \param ry An array of integers with the size matching the length of the Y dimension
 * of the problem size, holding values of either 0 (discard the output) or 1(keep the output).
 * * \param rz An array of integers with the size matching the length of the Z dimension
 * of the problem size, holding values of either 0 (discard the output) or 1(keep the output).
 */
void maxlib_output_mask_set(maxlib_context context, const char* output_name, const int* rx, const int* ry, const int* rz);

/**
 * \brief Set the sub-region that you wish to produce output for.  This must be called before maxlib_open().
 *
 * \param region The region to produce output for.
 */
void maxlib_set_output_region(maxlib_region region);

/**
 * \brief Allocate an array of swap data for use in manual edge swap.
 *
 * \param context A handle to a device context.
 * \param num_packed_wavefields The number of packed wavefields this swap array needs to store.
 * \param swap_region The region bounding this swap array.
 *
 * \return Handle to a new swap array.
 */
maxlib_swap_array maxlib_swap_alloc_packed_wavefield(maxlib_context context, int num_packed_wavefields, maxlib_region swap_region);

/**
 * \brief Allocate an array of swap data for use in manual edge swap.
 *
 * \param context A handle to a device context.
 * \param swap_region The region bounding this swap array.
 *
 * \return Handle to a new swap array.
 */
maxlib_swap_array maxlib_swap_alloc_wavefield(maxlib_context context, maxlib_region swap_region);

/**
 * \brief Send the swap data specified to the device from the host.
 *
 * \param context A handle to a device context.
 * \param input_name The name of the packed wavefield the swap data is to be used for.
 * \param swap_array A handle to swap data.
 */
void maxlib_swap_from_host(maxlib_context context, const char* input_name, maxlib_swap_array swap_array);

/**
 * \brief Send swap data for the specified region to the host.
 *
 * \param context A handle to the device context.
 * \param output_name The name of the wavefield output.
 * \param num_packed_wavefields The number of packed wavefields being sent.
 * \param swap_region The region of swap data to send to the host.
 * \param callback A callback which is called multiple times during maxlib_run as data is generated.
 * \param callback_data A pointer to some user specified data which will be passed to the callback.
 */
void maxlib_swap_to_host(maxlib_context context, const char* output_name, int num_packed_wavefields, maxlib_region swap_region, maxlib_swap_callback callback, void* callback_data);

/**
 * \brief Copy data into a swap array.
 *
 * \param context A handle to the device context.
 * \param swap_sub_region_data The raw swap data.  This data needs to be use the type used internally by the FPGA.
 * \param swap_sub_region The sub region the data represents.
 * \param destination_array The swap array to copy into.
 */
void maxlib_swap_copy(maxlib_context context, void* swap_sub_region_data, maxlib_region swap_sub_region, maxlib_swap_array destination_array);

/**
 * \brief Get the halo size for the specified packed wavefield.
 *
 * \param input_name The name of the packed wavefield.
 *
 * \return The size of the halo.
 */
int maxlib_get_packed_wavefield_halo(const char* input_name);


/**
 * \brief Get the halo size for the earthmodel.
 *
 * \return The size of the halo.
 */
int maxlib_get_earthmodel_halo(void);

/**
 * \brief Get the axis order.
 *
 * \param slow Returns the axis used as the slow dimension.  Ignored if set to NULL.
 * \param medium Returns the axis used as the medium dimension.  Ignored if set to NULL.
 * \param fast Returns the axis used as the fast dimension.  Ignored if set to NULL.
 */
void maxlib_get_axis_order (maxlib_axis* slow, maxlib_axis* medium, maxlib_axis* fast);

/**
 * \brief Calculate the size of a packed wavefield in the storage type used on the FPGA.
 *
 * \param region The wavefield region.
 * \param num_packed The number of packed wavefields.
 *
 * \return The size in bytes.
 */
size_t maxlib_wavefield_region_size(maxlib_region region, int num_packed);

/**
 * \brief Calculate the scale shifts.  Must be done after all to/from swap/host/dram calls have been made.
 *
 * \param context A handle to a device context.
 */
void maxlib_scale_shifts_calculate(maxlib_context context);

/**
 * \brief Override the scale shift calculated in maxlib_run.
 *
 * \param context A handle to a device context.
 * \param new_scale_shifts The values to set the scale shift to.
 *
 */
void maxlib_scale_shifts_set(maxlib_context context, const int* new_scale_shifts);

/**
 * \brief Get the last scale shift/the values calculated after the call to maxlib_scale_shift_calculate
 *
 * \param context A handle to a device context.
 * \param scale_shifts An array of integers at least maxlib_scale_shift_get_num() long.
 */
void maxlib_scale_shifts_get(maxlib_context context, int* scale_shifts);

/**
 * \brief Get the number of scale shifts in use.
 *
 * \param context A handle to a device context.
 * \return The number of scale shifts.
 */
int maxlib_scale_shifts_get_num(maxlib_context context);

/**
 * \brief Enable wave field tracking.
 *
 * There are 3 possible modes:
 * <ul>
 * <li><b>MAXLIB_TRACKING_OFF</b> Wave field tracking is disabled completely.</li>
 * <li><b>MAXLIB_TRACKING_AUTO</b> Wave field tracking is enabled and MaxGen FD will
 * decide how much of the problem to compute automatically based on the location of non-zero values
 * in the wave field inputs.  If a bounding box is specified with maxlib_tracking_mark_non_zero()
 * then this will be combined with the one that MaxGen FD calculates.</li>
 * <li><b>MAXLIB_TRACKING_USER_ONLY</b> MaxGen FD will <b>only</b> use the bounding box specified
 * using maxlib_tracking_mark_non_zero() when calculating which points need to be computed.</li>
 * </ul>
 *
 * Note that when using wave field tracking zeroes may not be streamed out of the card when streaming
 * to the host.
 *
 * \param context A handle to a device context.
 * \param mode The mode to use.
 * \param x Enable in the X-dimension (0 disabled, 1 enabled)
 * \param y Enable in the Y-dimension (0 disabled, 1 enabled)
 * \param z Enable in the Z-dimension (0 disabled, 1 enabled)
 */
void maxlib_tracking_enable(maxlib_context context, maxlib_tracking_mode mode, int x, int y, int z);

/**
 * \brief Set the halo to use for wavefield tracking in each dimension.
 *
 * If this is not set then the halo
 * used is the largest specified in the kernel.
 *
 * \param context A handle to a device context
 * \param x Halo in X-dimension
 * \param y Halo in Y-dimension
 * \param z Halo in Z-dimension
 */
void maxlib_tracking_set_halo(maxlib_context context, int x, int y, int z);

/**
 * \brief Manually mark an area as non-zero.
 *
 * This allows you to manually extend the bounding box used by MaxGen FD internally.
 * Calls to this function are cumulative and maxlib_tracking_clear() should be used
 * to reset the bounding box.
 *
 * \param context A handle to the device context
 * \param region The region to force computation within
 */
void maxlib_tracking_mark_non_zero(maxlib_context context, maxlib_region region);

/**
 * \brief Clear the bounding box set using maxlib_tracking_mark_non_zero().
 *
 * \param context A handle to the device context
 */
void maxlib_tracking_clear(maxlib_context context);

/**
 * \brief Calculate the current bounding box.
 *
 * When in <b>MAXLIB_TRACKING_AUTO</b> mode this will need to be the last function called
 * before maxlib_run() otherwise the bounding box provided may be inaccurate.
 *
 * \param context A handle to the device context
 * \param region A pointer to a region which will contain the calculated bounding box.
 */
void maxlib_tracking_calculate_region(maxlib_context context, maxlib_region *region);

/**
 * \brief Get the bounding box from an individual DRAM array.
 *
 * \param context A handle to a device context
 * \param array The array to get the bounding box
 * \param region A pointer to a region which will contain the bounding box (all dimensions will be zero length
 * if a bounding box does not exist for the specified array)
 */
void maxlib_tracking_get_bounding_box(maxlib_context context, maxlib_dram_array array, maxlib_region *region);

#ifdef __cplusplus
}
#endif

#endif // !defined(MAXELER_MAXGENFD_MAXLIB_H)
