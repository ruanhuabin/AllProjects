#!/bin/bash - 
rm -rf JACOBI.max
ln -s /network-scratch/hruan/maxdc_builds/17-04-12/JACOBI/scratch/JACOBI.max JACOBI.max
