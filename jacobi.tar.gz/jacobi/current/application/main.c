#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "JACOBI.max"
int max_alloc_double_vector(double **p, unsigned int n)
{
	*p = (double *)malloc(n * sizeof(double));
	if(*p == NULL)
	{
		fprintf(stderr, "[%s:%d]: Memory allocation failed.\n",\
				__FILE__, __LINE__);
		return 1;
	}


	/**
	 *  Setting the vector's initial value to zero
	 */
	memset(*p, 0, (n + 1) *sizeof(double));
	return 0;
}
void max_free_double_vector(double **p)
{
	free(*p);
	*p = NULL;
}

void max_print_matrix(double *m, int rows, int cols, char *hint_msg)
{
	fprintf(stderr, "====>%s\n", hint_msg);
	for(int i = 0; i < rows; i ++)
	{
		for(int j = 0; j < cols; j ++)
		{
			fprintf(stderr, "%g ", m[i * cols + j]);
		}
		fprintf(stderr, "\n");
	}
}
int main(int argc, const char** argv) {
	int RUN = 5000;
	int dim = atoi(argv[1]);   // this should be a scalar input in the bitstream
	RUN = argv[2] != NULL ? atoi(argv[2]): RUN;

	double* A = malloc(dim*dim*sizeof(double));  // probably 'dim' mapped rom
	double* diagA = malloc(dim * sizeof(double));
    double* x_base = malloc(RUN*dim*sizeof(double)); // output of the bitstream
	double* x = NULL;
	double* z = malloc(dim*sizeof(double));
	double* b_base = malloc(RUN*dim*sizeof(double)); // this will be streamed into the bitstream
	double* b = b_base;

	int i, j, run;

	clock_t start, end;
	clock_t cpu_time = 0;

	srand(time(NULL));

	for(i = 0; i < dim; ++i) {
		double sum = 0;
		for(j = 0; j < dim; ++j) {
			if(i != j) {
                /*
				 *A[i*dim+j] = 2.0*rand()/(double)RAND_MAX - 1;  //random number between -1 and 1
				 *sum += fabs(A[i*dim+j]);
                 */
				A[i*dim+j] =1;  // random number between -1 and 1
				sum += fabs(A[i*dim+j]);

			}
		}
		A[i*dim+i] = 1 + sum;
		diagA[i] = 1 + sum;
	}
	for(i = 0; i < dim*RUN; ++i) {
        /*
		 *b[i] = 2.0*rand()/(double)RAND_MAX - 1;  // random number between -1 and 1
         */
		b[i] = 300;  // random number between -1 and 1
	}

	printf("Starting solver\n");

	/**
	* Start solving. This will go into HW.
	*
	* 	JACOBI(dim, A, b_base, x_base);
	**/

	max_print_matrix(A, dim, dim, "Values in A");

	printf("Transpose A:\n");
	double *TA = NULL;
	max_alloc_double_vector(&TA, dim*dim);
	for(int i = 0; i < dim; i ++)
	{
		for(int j = 0; j < dim; j ++)
		{
			TA[i * dim + j] = A[j * dim + i];	
		}
	}
	double *data_out = (double *)malloc(dim * dim * sizeof(double));
	memset(data_out, 0, sizeof(double) * dim * dim);

	double *output_sum = NULL;
	double *output_sum2 = NULL;
	double *output_z = NULL;
	double *expected_sum = NULL;
	double *error = NULL;
	max_alloc_double_vector(&output_sum, dim);
	max_alloc_double_vector(&output_sum2, dim);
	max_alloc_double_vector(&output_z, dim);
	max_alloc_double_vector(&expected_sum, dim);
	max_alloc_double_vector(&error, dim);
	for(int i = 0; i < dim; i ++)
	{
		expected_sum[i] = 0.0;
		for(int j = 0; j < dim ; j ++)
		{

				expected_sum[i] += A[i * dim + j];
		}
	}

	int cycles = dim * dim;
	JACOBI(cycles,
		   dim,
		   dim,
		   b,
		   RUN * dim * sizeof(double),
		   error,
		   dim * sizeof(double),
		   data_out,
		   dim * dim * sizeof(double),
		   output_sum,
		   dim *sizeof(double),
		   output_sum2,
		   dim *sizeof(double),
		   output_z,
		   dim *sizeof(double),
		   TA,
		   diagA);

	max_print_matrix(data_out, dim, dim, "Values in data_out");
	max_print_matrix(output_sum, 1, dim, "Values in output_sum");
	max_print_matrix(expected_sum, 1, dim, "Values in expected_sum");
	max_print_matrix(output_z, 1, dim, "Values in output_z");
	max_print_matrix(output_sum2, 1, dim, "Values in output_sum2");
	max_print_matrix(error, 1, dim, "Values in error");
	free(data_out);
	free(diagA);
	max_free_double_vector(&TA);
	max_free_double_vector(&output_sum);
	max_free_double_vector(&output_sum2);
	max_free_double_vector(&output_z);
	max_free_double_vector(&expected_sum);
	max_free_double_vector(&error);
	
	return 0;


	int stage = 0;
	for(run = 0; run < RUN; ++run) 
	{
		x  = x_base + run*dim;
		start = clock();
		double error = 1000;
		for(i = 0; i < dim; ++i) 
		{
			x[i] = 0;
		}
		while(error > 1e-9) {
			// update x
			for(i = 0; i < dim; ++i) 
			{
				double sigma = 0;
				for(j = 0; j < dim; ++j) 
				{
					if(j != i) 
					{
						sigma += A[i*dim+j]*x[j];
					}
				}
				z[i] = (b[i]-sigma)/A[i*dim+i];
				++stage;
			}
			double *tmp = x;
			x = z;
			z = tmp;
			// compute error
			error = 0;
			for(i = 0; i < dim; ++i) 
			{
				double y = 0;
				for(j = 0; j < dim; ++j) 
				{
					y += A[i*dim+j]*x[j];
				}
				error += fabs(y-b[i]);
			}
			//printf("error at stage %d is %g\n", stage, error);
		}
		end = clock();
	
		cpu_time += end-start;

		// move to next problem to solve
		b += dim;
	}
	printf("Solved in %g seconds and %d stages\n", (cpu_time/(double)CLOCKS_PER_SEC), stage);

	printf("total run = %d\n", run);
	free(A);
	free(b_base);
	free(x_base);
}
